# Development Plan

<!-- Replace this template with your project's development plan. -->
<!-- AI agents use this file to understand current priorities and progress. -->

## Active Work

<!-- Add your current work items here -->

## Completed Work

<!-- Track completed phases and milestones here -->
