#!/usr/bin/env bash
# aidd-upgrade.sh — Upgrade AIDD Framework files from upstream
# https://github.com/paralleldrive/aidd
#
# Usage:
#   ./scripts/aidd-upgrade.sh [--dry-run]
#
# This script updates the AIDD framework files (ai/, .cursor/, AGENTS.md)
# from the upstream paralleldrive/aidd repository while preserving your
# project-specific customizations (aidd-custom/, vision.md, plan.md, .github/).

set -euo pipefail

UPSTREAM_REPO="https://github.com/paralleldrive/aidd.git"
TEMP_DIR=$(mktemp -d)
DRY_RUN=false

# Parse arguments
for arg in "$@"; do
  case $arg in
    --dry-run)
      DRY_RUN=true
      shift
      ;;
    --help|-h)
      echo "Usage: $0 [--dry-run]"
      echo ""
      echo "Upgrades AIDD framework files from upstream."
      echo ""
      echo "Options:"
      echo "  --dry-run    Show what would be updated without making changes"
      echo "  --help       Show this help message"
      exit 0
      ;;
  esac
done

# Find project root (where AGENTS.md lives)
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"

echo "🔄 AIDD Framework Upgrade"
echo "========================="
echo ""
echo "Project root: $PROJECT_ROOT"
echo "Upstream:     $UPSTREAM_REPO"
echo ""

# Check for npx aidd first (preferred method)
if command -v npx &> /dev/null; then
  echo "📦 npx is available."
  echo ""
  read -p "Use npx aidd (recommended)? [Y/n] " USE_NPX
  USE_NPX=${USE_NPX:-Y}
  if [[ "$USE_NPX" =~ ^[Yy]$ ]]; then
    echo ""
    echo "Running: npx aidd ."
    npx aidd "$PROJECT_ROOT"
    echo ""
    echo "✨ AIDD framework updated via npx!"
    exit 0
  fi
  echo ""
  echo "Falling back to git-based upgrade..."
  echo ""
fi

# Clone upstream (shallow)
echo "📥 Fetching latest AIDD framework..."
git clone --depth 1 "$UPSTREAM_REPO" "$TEMP_DIR" 2>/dev/null

if [ ! -d "$TEMP_DIR/ai" ]; then
  echo "❌ Failed to clone upstream repository"
  rm -rf "$TEMP_DIR"
  exit 1
fi

# Get upstream version if available
if [ -f "$TEMP_DIR/package.json" ]; then
  UPSTREAM_VERSION=$(grep '"version"' "$TEMP_DIR/package.json" | head -1 | sed 's/.*"version": "\(.*\)".*/\1/')
  echo "📋 Upstream version: $UPSTREAM_VERSION"
fi

echo ""

# Files/directories to update from upstream
FRAMEWORK_ITEMS=(
  "ai"
  "AGENTS.md"
)

if [ "$DRY_RUN" = true ]; then
  echo "🔍 Dry run — showing what would be updated:"
  echo ""
  for item in "${FRAMEWORK_ITEMS[@]}"; do
    if [ -e "$TEMP_DIR/$item" ]; then
      echo "  ✅ Would update: $item"
    else
      echo "  ⚠️  Not found in upstream: $item"
    fi
  done
  echo ""
  echo "  ℹ️  Preserved (not modified):"
  echo "     - aidd-custom/"
  echo "     - vision.md"
  echo "     - plan.md"
  echo "     - .github/agents/"
  echo "     - .github/copilot-instructions.md"
  echo "     - .vscode/"
  echo "     - COPILOT-QUICKSTART.md"
else
  echo "📝 Updating framework files..."
  echo ""

  for item in "${FRAMEWORK_ITEMS[@]}"; do
    if [ -e "$TEMP_DIR/$item" ]; then
      if [ -d "$TEMP_DIR/$item" ]; then
        # Directory: remove old and copy new
        rm -rf "$PROJECT_ROOT/$item"
        cp -r "$TEMP_DIR/$item" "$PROJECT_ROOT/$item"
      else
        # File: copy over
        cp "$TEMP_DIR/$item" "$PROJECT_ROOT/$item"
      fi
      echo "  ✅ Updated: $item"
    else
      echo "  ⚠️  Not found in upstream: $item"
    fi
  done

  # Update .cursor symlink if it exists
  if [ -L "$PROJECT_ROOT/.cursor" ] || [ -d "$PROJECT_ROOT/.cursor" ]; then
    rm -rf "$PROJECT_ROOT/.cursor"
    ln -s ai "$PROJECT_ROOT/.cursor"
    echo "  ✅ Updated: .cursor (symlink to ai/)"
  fi

  echo ""
  echo "✨ AIDD framework updated successfully!"
  echo ""
  echo "Next steps:"
  echo "  1. Review changes: git diff"
  echo "  2. Test the agent: @aidd help"
  echo "  3. Commit: git add ai/ .cursor/ AGENTS.md && git commit -m 'chore: upgrade AIDD framework'"
fi

# Cleanup
rm -rf "$TEMP_DIR"
