/**
 * CLI Integration Tests
 * 
 * Tests CLI argument parsing, command routing, and output formatting.
 * Does NOT duplicate lint engine tests - focuses only on CLI-specific behavior.
 */

import { describe, test, expect } from '@jest/globals';
import { execSync } from 'child_process';
import { join } from 'path';
import { existsSync } from 'fs';

const CLI_PATH = join(__dirname, '../../cli/pql-lint.ts');
const TEST_FILE = join(__dirname, '../../pqlint-api/test-files/calendar.tmdl');
const TEST_DIR = join(__dirname, '../../pqlint-api/test-files');

/**
 * Helper to run CLI commands and capture output
 */
function runCLI(args: string): { stdout: string; stderr: string; exitCode: number } {
  try {
    const stdout = execSync(`bun run ${CLI_PATH} ${args}`, {
      encoding: 'utf-8',
      stdio: 'pipe'
    });
    return { stdout, stderr: '', exitCode: 0 };
  } catch (error: any) {
    return {
      stdout: error.stdout || '',
      stderr: error.stderr || '',
      exitCode: error.status || 1
    };
  }
}

describe('CLI Entry Point', () => {
  test('should display help when no arguments provided', () => {
    const result = runCLI('');
    expect(result.stdout).toContain('USAGE:');
    expect(result.stdout).toContain('pql-lint');
    expect(result.exitCode).toBe(1);
  });

  test('should display help with --help flag', () => {
    const result = runCLI('--help');
    expect(result.stdout).toContain('USAGE:');
    expect(result.stdout).toContain('COMMANDS:');
    expect(result.exitCode).toBe(0);
  });

  test('should display version with --version flag', () => {
    const result = runCLI('--version');
    expect(result.stdout).toMatch(/pql-lint v\d+\.\d+\.\d+/);
    expect(result.exitCode).toBe(0);
  });

  test('should handle unknown command gracefully', () => {
    const result = runCLI('unknown-command');
    expect(result.stderr || result.stdout).toContain('Unknown command');
    expect(result.exitCode).toBe(1);
  });
});

describe('Lint Command', () => {
  test('should accept file path argument', () => {
    if (!existsSync(TEST_FILE)) {
      console.warn(`Test file not found: ${TEST_FILE}`);
      return;
    }

    const result = runCLI(`lint ${TEST_FILE}`);
    // Should not crash - exit code 0 or 1 depending on lint results
    expect([0, 1]).toContain(result.exitCode);
  });

  test('should accept directory path argument', () => {
    if (!existsSync(TEST_DIR)) {
      console.warn(`Test directory not found: ${TEST_DIR}`);
      return;
    }

    const result = runCLI(`lint ${TEST_DIR}`);
    // Should not crash
    expect([0, 1]).toContain(result.exitCode);
  });

  test('should handle missing path argument', () => {
    const result = runCLI('lint');
    expect(result.stderr || result.stdout).toContain('Missing path');
    expect(result.exitCode).toBe(1);
  });

  test('should handle non-existent path', () => {
    const result = runCLI('lint /non/existent/path');
    expect(result.stderr || result.stdout).toContain('does not exist');
    expect(result.exitCode).toBe(1);
  });

  test('should output JSON when --json flag is provided', () => {
    if (!existsSync(TEST_FILE)) {
      console.warn(`Test file not found: ${TEST_FILE}`);
      return;
    }

    const result = runCLI(`lint ${TEST_FILE} --json`);
    
    // Should output valid JSON
    expect(() => JSON.parse(result.stdout)).not.toThrow();
    
    const jsonOutput = JSON.parse(result.stdout);
    expect(jsonOutput).toHaveProperty('summary');
    expect(jsonOutput).toHaveProperty('files');
    expect(jsonOutput.summary).toHaveProperty('totalFiles');
    expect(jsonOutput.summary).toHaveProperty('totalIssues');
  });
});

describe('Rules Command', () => {
  test('should list all available rules', () => {
    const result = runCLI('rules');
    expect(result.stdout).toContain('Available Lint Rules');
    expect(result.stdout).toContain('total');
    expect(result.exitCode).toBe(0);
  });

  test('should display rule details', () => {
    const result = runCLI('rules');
    // Should contain rule information
    expect(result.stdout).toContain('Category:');
    expect(result.stdout).toContain('Severity:');
    expect(result.stdout).toContain('Description:');
  });

  test('should show summary counts', () => {
    const result = runCLI('rules');
    expect(result.stdout).toContain('Summary:');
    expect(result.stdout).toContain('Total Rules:');
  });
});

describe('Architecture Validation', () => {
  test('CLI should only import from shared core', () => {
    const cliContent = execSync(`Get-Content ${CLI_PATH} -Raw`, {
      encoding: 'utf-8',
      shell: 'powershell.exe'
    });

    // Should NOT import from pqlint-api/src/functions
    expect(cliContent).not.toContain('pqlint-api/src/functions');
    expect(cliContent).not.toContain('@azure/functions');
    
    // Should import from shared core
    expect(cliContent).toMatch(/from ['"].*\/src\//);
  });

  test('CLI commands should only import from shared core', () => {
    const lintContent = execSync(`Get-Content ${join(__dirname, '../../cli/commands/lint.ts')} -Raw`, {
      encoding: 'utf-8',
      shell: 'powershell.exe'
    });

    const rulesContent = execSync(`Get-Content ${join(__dirname, '../../cli/commands/rules.ts')} -Raw`, {
      encoding: 'utf-8',
      shell: 'powershell.exe'
    });

    // Neither should import from Azure Functions
    expect(lintContent).not.toContain('pqlint-api/src/functions');
    expect(lintContent).not.toContain('@azure/functions');
    expect(rulesContent).not.toContain('pqlint-api/src/functions');
    expect(rulesContent).not.toContain('@azure/functions');
  });
});
