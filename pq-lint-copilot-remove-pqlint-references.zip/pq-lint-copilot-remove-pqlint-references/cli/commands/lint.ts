/**
 * Lint command implementation
 * 
 * Processes Power Query (.pq) and TMDL (.tmdl) files, applying lint rules
 * from the shared core and outputting results in human-readable or JSON format.
 */

import { readdirSync, statSync, existsSync } from 'fs';
import { join, extname, relative } from 'path';
import { lintFile } from '../../src/lint/linter-module.js';
import { allPQRules, allTMDLLevelPQRules, allTMDLSecurityLevelPQRules } from '../../src/lint/all-rules.js';
import { RuleResult, SeverityLevel } from '../../src/lint/rule-types.js';

interface LintOptions {
  json?: boolean;
}

interface LintSummary {
  totalFiles: number;
  filesWithIssues: number;
  totalIssues: number;
  errorCount: number;
  warningCount: number;
  infoCount: number;
}

/**
 * Recursively find all .tmdl files in a directory
 */
function findTMDLFiles(dirPath: string): string[] {
  const files: string[] = [];
  
  try {
    const entries = readdirSync(dirPath);
    
    for (const entry of entries) {
      const fullPath = join(dirPath, entry);
      const stat = statSync(fullPath);
      
      if (stat.isDirectory()) {
        files.push(...findTMDLFiles(fullPath));
      } else if (extname(entry) === '.tmdl') {
        files.push(fullPath);
      }
    }
  } catch (error) {
    throw new Error(`Error reading directory ${dirPath}: ${error instanceof Error ? error.message : String(error)}`);
  }
  
  return files;
}

/**
 * Get all files to lint based on the provided path
 */
function getFilesToLint(targetPath: string): string[] {
  if (!existsSync(targetPath)) {
    throw new Error(`Path does not exist: ${targetPath}`);
  }
  
  const stat = statSync(targetPath);
  
  if (stat.isFile()) {
    if (extname(targetPath) !== '.tmdl') {
      throw new Error('Only .tmdl files are currently supported');
    }
    return [targetPath];
  }
  
  if (stat.isDirectory()) {
    const files = findTMDLFiles(targetPath);
    if (files.length === 0) {
      console.warn(`Warning: No .tmdl files found in ${targetPath}`);
    }
    return files;
  }
  
  throw new Error(`Invalid path: ${targetPath}`);
}

/**
 * Get severity label and color for console output
 */
function getSeverityDisplay(severity: SeverityLevel): { label: string; color: string } {
  switch (severity) {
    case SeverityLevel.Error:
      return { label: 'ERROR', color: '\x1b[31m' }; // Red
    case SeverityLevel.Warning:
      return { label: 'WARN', color: '\x1b[33m' }; // Yellow
    case SeverityLevel.Info:
      return { label: 'INFO', color: '\x1b[36m' }; // Cyan
    default:
      return { label: 'NONE', color: '\x1b[0m' }; // Reset
  }
}

/**
 * Format results for human-readable console output
 */
function formatConsoleOutput(fileResults: Map<string, RuleResult[]>, basePath: string): void {
  const reset = '\x1b[0m';
  const bold = '\x1b[1m';
  const dim = '\x1b[2m';
  
  let summary: LintSummary = {
    totalFiles: fileResults.size,
    filesWithIssues: 0,
    totalIssues: 0,
    errorCount: 0,
    warningCount: 0,
    infoCount: 0
  };
  
  fileResults.forEach((results, filePath) => {
    const failures = results.filter(r => !r.Passed);
    
    if (failures.length === 0) {
      return; // Skip files with no issues
    }
    
    summary.filesWithIssues++;
    summary.totalIssues += failures.length;
    
    // Print file header
    const relativePath = relative(basePath, filePath);
    console.log(`\n${bold}${relativePath}${reset}`);
    
    // Print each issue
    failures.forEach(result => {
      const { label, color } = getSeverityDisplay(result.Severity);
      
      // Update severity counters
      if (result.Severity === SeverityLevel.Error) summary.errorCount++;
      else if (result.Severity === SeverityLevel.Warning) summary.warningCount++;
      else if (result.Severity === SeverityLevel.Info) summary.infoCount++;
      
      const lineNum = result.ErrorInformation.errorLocation.positionStart?.lineNumber ?? 0;
      const location = lineNum > 0 ? `:${lineNum}` : '';
      
      console.log(`  ${color}${label}${reset} ${dim}[${result.ID}]${reset} ${result.Name}`);
      console.log(`  ${dim}${relativePath}${location}${reset}`);
      console.log(`  ${result.Description}`);
      console.log();
    });
  });
  
  // Print summary
  if (summary.totalIssues === 0) {
    console.log(`\n${bold}✓${reset} No issues found in ${summary.totalFiles} file(s)`);
  } else {
    console.log(`\n${bold}Summary:${reset}`);
    console.log(`  Files scanned: ${summary.totalFiles}`);
    console.log(`  Files with issues: ${summary.filesWithIssues}`);
    console.log(`  Total issues: ${summary.totalIssues}`);
    if (summary.errorCount > 0) console.log(`    Errors: ${summary.errorCount}`);
    if (summary.warningCount > 0) console.log(`    Warnings: ${summary.warningCount}`);
    if (summary.infoCount > 0) console.log(`    Info: ${summary.infoCount}`);
  }
}

/**
 * Format results as JSON
 */
function formatJsonOutput(fileResults: Map<string, RuleResult[]>, basePath: string): void {
  const output = {
    summary: {
      totalFiles: fileResults.size,
      filesWithIssues: 0,
      totalIssues: 0,
      errorCount: 0,
      warningCount: 0,
      infoCount: 0
    },
    files: [] as any[]
  };
  
  fileResults.forEach((results, filePath) => {
    const failures = results.filter(r => !r.Passed);
    const relativePath = relative(basePath, filePath);
    
    if (failures.length > 0) {
      output.summary.filesWithIssues++;
      output.summary.totalIssues += failures.length;
    }
    
    failures.forEach(result => {
      if (result.Severity === SeverityLevel.Error) output.summary.errorCount++;
      else if (result.Severity === SeverityLevel.Warning) output.summary.warningCount++;
      else if (result.Severity === SeverityLevel.Info) output.summary.infoCount++;
    });
    
    output.files.push({
      path: relativePath,
      issueCount: failures.length,
      issues: failures.map(result => ({
        ruleId: result.ID,
        ruleName: result.Name,
        category: result.Category,
        severity: SeverityLevel[result.Severity],
        description: result.Description,
        location: {
          line: result.ErrorInformation.errorLocation.positionStart?.lineNumber ?? 0,
          column: result.ErrorInformation.errorLocation.positionStart?.lineCodeUnit ?? 0
        }
      }))
    });
  });
  
  console.log(JSON.stringify(output, null, 2));
}

/**
 * Lint command handler
 */
export async function lintCommand(args: string[], options: LintOptions): Promise<void> {
  if (args.length === 0) {
    console.error('Error: Missing path argument');
    console.error('Usage: pql-lint lint <path> [--json]');
    process.exit(1);
  }
  
  const targetPath = args[0];
  const basePath = statSync(targetPath).isDirectory() ? targetPath : process.cwd();
  
  try {
    // Get all files to lint
    const files = getFilesToLint(targetPath);
    
    if (files.length === 0) {
      console.log('No files to lint');
      return;
    }
    
    // Combine all rules
    const allRules = [...allPQRules, ...allTMDLLevelPQRules, ...allTMDLSecurityLevelPQRules];
    
    // Lint each file and collect results
    const fileResults = new Map<string, RuleResult[]>();
    
    for (const file of files) {
      try {
        const results = await lintFile(file, allRules, false, false);
        fileResults.set(file, results);
      } catch (error) {
        console.error(`Error linting ${file}: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
    
    // Output results
    if (options.json) {
      formatJsonOutput(fileResults, basePath);
    } else {
      formatConsoleOutput(fileResults, basePath);
    }
    
    // Exit with error code if issues found
    const hasIssues = Array.from(fileResults.values()).some(results => 
      results.some(r => !r.Passed && r.Severity === SeverityLevel.Error)
    );
    
    if (hasIssues) {
      process.exit(1);
    }
    
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}
