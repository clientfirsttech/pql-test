/**
 * Rules command implementation
 * 
 * Lists all available lint rules from the shared core with their descriptions,
 * categories, and severity levels.
 */

import { allPQRules, allTMDLLevelPQRules, allTMDLSecurityLevelPQRules } from '../../src/lint/all-rules.js';
import { PowerQueryRule, TMDL_Level_PowerQueryRule, SeverityLevel } from '../../src/lint/rule-types.js';

/**
 * Get severity label for display
 */
function getSeverityLabel(severity: SeverityLevel): string {
  switch (severity) {
    case SeverityLevel.Error:
      return 'Error';
    case SeverityLevel.Warning:
      return 'Warning';
    case SeverityLevel.Info:
      return 'Info';
    default:
      return 'None';
  }
}

/**
 * Format rule for console output
 */
function formatRule(rule: PowerQueryRule | TMDL_Level_PowerQueryRule, index: number): string {
  const severityLabel = getSeverityLabel(rule.Severity);
  const bold = '\x1b[1m';
  const dim = '\x1b[2m';
  const reset = '\x1b[0m';
  
  return `${dim}${String(index).padStart(3, ' ')}.${reset} ${bold}${rule.ID}${reset} - ${rule.Name}
     ${dim}Category:${reset} ${rule.Category}
     ${dim}Severity:${reset} ${severityLabel}
     ${dim}Description:${reset} ${rule.Description}`;
}

/**
 * Rules command handler
 */
export async function rulesCommand(): Promise<void> {
  const bold = '\x1b[1m';
  const reset = '\x1b[0m';
  
  // Combine all rules
  const allRules = [...allPQRules, ...allTMDLLevelPQRules, ...allTMDLSecurityLevelPQRules];
  
  console.log(`\n${bold}Available Lint Rules (${allRules.length} total)${reset}\n`);
  
  // Group rules by category
  const rulesByCategory = new Map<string, (PowerQueryRule | TMDL_Level_PowerQueryRule)[]>();
  
  allRules.forEach(rule => {
    if (!rulesByCategory.has(rule.Category)) {
      rulesByCategory.set(rule.Category, []);
    }
    rulesByCategory.get(rule.Category)!.push(rule);
  });
  
  // Sort categories alphabetically
  const sortedCategories = Array.from(rulesByCategory.keys()).sort();
  
  let index = 1;
  
  // Print rules grouped by category
  for (const category of sortedCategories) {
    const rules = rulesByCategory.get(category)!;
    
    console.log(`\n${bold}${category}${reset} (${rules.length} rules)\n`);
    
    for (const rule of rules) {
      console.log(formatRule(rule, index));
      console.log(); // Empty line between rules
      index++;
    }
  }
  
  console.log(`\n${bold}Summary:${reset}`);
  console.log(`  Power Query Rules: ${allPQRules.length}`);
  console.log(`  TMDL Level Rules: ${allTMDLLevelPQRules.length}`);
  console.log(`  TMDL Security Rules: ${allTMDLSecurityLevelPQRules.length}`);
  console.log(`  Total Rules: ${allRules.length}\n`);
}
