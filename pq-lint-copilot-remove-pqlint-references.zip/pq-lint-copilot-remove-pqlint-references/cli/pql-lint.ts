#!/usr/bin/env bun

/**
 * pql-lint CLI - Command-line interface for Power Query linting
 * 
 * This CLI provides standalone access to the linting engine without Azure Functions.
 * It imports ONLY from the shared core at /src/, maintaining architectural separation.
 */

import { parseArgs } from 'util';
import { readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Load package.json for version info
const packageJson = JSON.parse(
  readFileSync(join(__dirname, '..', 'package.json'), 'utf-8')
);

interface CliArgs {
  command?: string;
  positionals: string[];
  values: {
    help?: boolean;
    version?: boolean;
    json?: boolean;
  };
}

/**
 * Display CLI usage information
 */
function showHelp(): void {
  console.log(`
pql-lint v${packageJson.version}

USAGE:
  pql-lint <command> [options] [arguments]

COMMANDS:
  lint <path>     Lint Power Query (.pq) or TMDL (.tmdl) files
  rules           List all available lint rules
  help            Show this help message

OPTIONS:
  --json          Output results in JSON format (for lint command)
  --help, -h      Show help
  --version, -v   Show version number

EXAMPLES:
  pql-lint lint ./queries/MyQuery.pq
  pql-lint lint ./models --json
  pql-lint rules
`);
}

/**
 * Display version information
 */
function showVersion(): void {
  console.log(`pql-lint v${packageJson.version}`);
}

/**
 * Main CLI entry point
 */
async function main(): Promise<void> {
  try {
    const args = parseArgs({
      args: process.argv.slice(2),
      options: {
        help: { type: 'boolean', short: 'h' },
        version: { type: 'boolean', short: 'v' },
        json: { type: 'boolean' }
      },
      allowPositionals: true
    }) as unknown as CliArgs;

    // Handle global flags
    if (args.values.version) {
      showVersion();
      process.exit(0);
    }

    if (args.values.help || args.positionals.length === 0) {
      showHelp();
      process.exit(args.positionals.length === 0 ? 1 : 0);
    }

    // Extract command and arguments
    const command = args.positionals[0];
    const commandArgs = args.positionals.slice(1);

    // Route to command handlers
    switch (command) {
      case 'lint':
        const { lintCommand } = await import('./commands/lint.js');
        await lintCommand(commandArgs, args.values);
        break;

      case 'rules':
        const { rulesCommand } = await import('./commands/rules.js');
        await rulesCommand();
        break;

      case 'help':
        showHelp();
        break;

      default:
        console.error(`Error: Unknown command '${command}'`);
        console.error(`Run 'pql-lint help' for usage information`);
        process.exit(1);
    }
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

// Run the CLI
main();
