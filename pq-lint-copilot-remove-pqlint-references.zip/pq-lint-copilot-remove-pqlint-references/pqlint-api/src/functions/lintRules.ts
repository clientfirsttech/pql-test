import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { getRulesAsJson } from 'src/lint/all-rules';
import { v4 as uuidv4 } from 'uuid'; // For generating GUIDs
import { sendEventToEventHub, RequestDetails, ResponseDetails } from '../helpers/event-hub'; // Import the function to send events to Event Hub
import { EnvironmentConstants, QueryStringConstants } from 'src/helpers/constant-types';
/**
 * Azure Function to process lint rules and return them as a JSON response.
 * - Reads all rule files from the specified directory.
 * - Extracts metadata such as ID, name, category, description, severity, and minimum license level.
 * - Sorts the rules by minimum license level, category, and ID.
 * @param request - The HTTP request object.
 * @param context - The invocation context for logging and other utilities.
 * @returns A JSON response containing the sorted lint rules.
 */
export async function lintRules(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> {

    // Establish connection to Event Hub
    const environment = process.env.ENVIRONMENT || EnvironmentConstants.DEVELOPMENT; // Environment (development or production)

    // Generate a unique request ID
    const requestId = uuidv4();
    // Extract ip address from query string
    const ipAddress = request.query?.get(QueryStringConstants.IP_ADDRESS) || QueryStringConstants.IP_ADDRESS_DEFAULT;
    
    // Capture request details
    const requestDetails: RequestDetails = {
        requestId: requestId,
        function: 'lintRules', // Function name
        method: request.method, // Capture the HTTP method
        ipAddress: ipAddress, // Capture IP address
        utcDate: new Date().toISOString(), // Get the current UTC date in ISO format
        licenseLevel: "", // Capture the license level (Free or Pro)
        environment: environment, // Capture the environment (development or production)
        code: "" // Capture the M Code payload
    };

    let statusCode = 200; // Default status code
    let errorMessage = ''; // Initialize error message
    let responseBody: any = {}; // Initialize response body
    try {

        // Check if the HTTP method is POST
        if (request.method !== 'GET') {
            statusCode = 405; // Method Not Allowed
            responseBody = { status: 405, body: 'Method Not Allowed' };
        }
        else {
            // Extract mode parameter from query string
            const mode = request.query?.get(QueryStringConstants.MODE) || QueryStringConstants.MODE_DEFAULT;
            requestDetails.licenseLevel = mode.toLocaleLowerCase(); // Store the license level in request details

            // Extract email address from headers
            const emailAddress = request.query?.get(QueryStringConstants.EMAIL) || QueryStringConstants.EMAIL_DEFAULT;
            requestDetails.emailAddress = emailAddress; // Store the email address in request details
                        
            // Example usage
            const rules: object[] = getRulesAsJson();

            responseBody = {
                status: 200,
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(rules)
            };
        }

    } catch (error) {
        // Handle errors
        context.log('Error processing request', error);
        const message = error instanceof Error ? error.message : String(error);
        context.log('Error details:', message);
        errorMessage = message || 'Internal Server Error';
        statusCode = 500; // Internal Server Error
        responseBody = { status: 500, body: 'Internal Server Error' };
    } finally {
        // Log response details to Event Hub
        const responseDetails: ResponseDetails = {
            requestDetails: requestDetails,
            statusCode: statusCode, // Include the status code
            responseBody: responseBody, // Include the response body
            errorMessage: errorMessage, // Include error message if any
            utcDate: new Date().toISOString() // Get the current UTC date in ISO format
        };
        // Establish connection to Event Hub
        const connectionString = process.env.EVENT_HUB_CONNECTION_STRING || ""; // Event Hub connection string
        const eventHubName = process.env.EVENT_HUB_NAME || ""; // Event Hub name

        // Send response details to Event Hub
        await sendEventToEventHub(responseDetails, connectionString, eventHubName);

        return responseBody;
    }
};

/**
 * Registers the `lintRules` function as an HTTP-triggered Azure Function.
 * - The function is accessible via HTTP GET requests.
 * - Authentication level is set to 'function'.
 */
app.http('lintRules', {
    methods: ['GET'],
    authLevel: 'function',
    handler: lintRules
});