import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { lintMCode as lintCodeFunction, lintTMDLCode } from 'src/lint/linter-module';
import { v4 as uuidv4 } from 'uuid'; // For generating GUIDs
import { sendEventToEventHub, RequestDetails, ResponseDetails } from '../helpers/event-hub'; // Import the function to send events to Event Hub
import { allTMDLSecurityLevelPQRules, allTMDLSecurityLevelRules } from 'src/lint/all-rules';
import { all } from "@microsoft/powerquery-parser/lib/powerquery-parser/common/arrayUtils";
import { env } from "process";
import { EnvironmentConstants, ModeConstants, QueryStringConstants } from 'src/helpers/constant-types';

export async function scanTMDL(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> {

    context.log(`Http function processed request for url "${request.url}"`);
    const environment = process.env.ENVIRONMENT || EnvironmentConstants.DEVELOPMENT; // Environment (development or production)

    // Generate a unique request ID
    const requestId = uuidv4();
    // Extract ip address from query string
    const ipAddress = request.query?.get(QueryStringConstants.IP_ADDRESS) || QueryStringConstants.IP_ADDRESS_DEFAULT;
    // Capture request details
    const requestDetails: RequestDetails = {
        requestId: requestId,
        function: 'scanTMDL', // Function name
        method: request.method, // Capture the HTTP method
        ipAddress: ipAddress, // Capture IP address
        utcDate: new Date().toISOString(), // Get the current UTC date in ISO format
        licenseLevel: "", // Capture the license level (Free or Pro)
        environment: environment, // Capture the environment (development or production)
        code: "" // Capture the M Code payload
    };

    let statusCode = 200; // Default status code
    let results: any = []; // Initialize results
    let errorMessage = ''; // Initialize error message
    let responseBody: any = {}; // Initialize response body

    // Extract mode parameter from query string
    const mode = request.query?.get(QueryStringConstants.MODE) || QueryStringConstants.MODE_DEFAULT;

    try {
        // Check if the HTTP method is POST
        if (request.method !== 'POST') {
            statusCode = 405; // Method Not Allowed
            responseBody = { status: 405, body: 'Method Not Allowed' };
        } 
        else {
            // Extract email address from headers
            const emailAddress = request.query?.get(QueryStringConstants.EMAIL) || QueryStringConstants.EMAIL_DEFAULT;
            requestDetails.emailAddress = emailAddress; // Store the email address in request details

            // Extract the M Code from the request body
            const code: string = await request.text();

            // Check if M Code is empty, undefined, or just whitespace
            if (!code || code.trim() === '') {
                statusCode = 400; // Bad Request
                responseBody = { status: 400, body: 'Bad Request: TMDL Code payload is required' };
            } else {
                // Check if we can log the M Code
                if (environment.toLocaleLowerCase() !== EnvironmentConstants.PRODUCTION && 
                    environment.toLocaleLowerCase() !== EnvironmentConstants.PROD) {
                    requestDetails.code = code; // Store the M Code in request details
                }else if (mode.toLocaleLowerCase() === ModeConstants.FREE) {
                    requestDetails.code = code; // Store the M Code in request details
                }

                // Lint the TMDL
                results = await lintTMDLCode(code,[],allTMDLSecurityLevelPQRules,allTMDLSecurityLevelRules, false);

                // Prepare the response body
                responseBody = {
                    status: 200,
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(results)
                };
            }
        }
    } catch (error) {
        // Handle errors
        context.log('Error processing request', error);
        const message = error instanceof Error ? error.message : String(error);
        context.log('Error details:', message);
        errorMessage = message || 'Internal Server Error';
        statusCode = 500; // Internal Server Error
        responseBody = { status: 500, body: 'Internal Server Error' };
    } finally {
        // Log response details to Event Hub
        const responseDetails: ResponseDetails = {
            requestDetails: requestDetails,
            statusCode: statusCode, // Include the status code
            responseBody: responseBody, // Include the response body
            errorMessage: errorMessage, // Include error message if any
            utcDate: new Date().toISOString() // Get the current UTC date in ISO format
        };
        // Establish connection to Event Hub
        const connectionString = process.env.EVENT_HUB_CONNECTION_STRING || ""; // Event Hub connection string
        const eventHubName = process.env.EVENT_HUB_NAME || ""; // Event Hub name
                
        // Send response details to Event Hub
        await sendEventToEventHub(responseDetails, connectionString, eventHubName);

        return responseBody;
    }
}

app.http('scanTMDL', {
    methods: ['POST'],
    authLevel: 'function',
    handler: scanTMDL
});
