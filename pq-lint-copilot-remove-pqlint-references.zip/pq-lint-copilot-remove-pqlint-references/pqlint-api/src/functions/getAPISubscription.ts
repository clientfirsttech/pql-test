import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { v4 as uuidv4 } from 'uuid'; // For generating GUIDs
import { sendEventToEventHub, RequestDetails, ResponseDetails } from '../helpers/event-hub'; // Import the function to send events to Event Hub
import { EnvironmentConstants, QueryStringConstants } from 'src/helpers/constant-types';
import { DefaultAzureCredential } from "@azure/identity";
import { ApiManagementClient } from "@azure/arm-apimanagement";
import { Subscription } from 'src/helpers/http-request-types';
import { formatEmailForSubscription, formatSubscriptionId } from 'src/helpers/format-subscription-ids'; // Import helper functions for formatting

/**
 * Azure Function to retrieve API subscription details from Azure API Management.
 * Validates subscription status and returns subscription information for active subscriptions.
 * Uses helper functions to format email and subscription IDs for compatibility.
 * @param request - HTTP request containing stripe-id and email query parameters
 * @param context - Azure Function invocation context for logging
 * @returns HttpResponseInit with subscription details or error information
 */
export async function getAPISubscription(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> {
    // Initialize environment and tracking variables
    const environment = process.env.ENVIRONMENT || EnvironmentConstants.DEVELOPMENT; // Environment (development or production)

    // Generate a unique request ID for tracking and correlation
    const requestId = uuidv4();
    // Extract client IP address from query parameters for logging
    const ipAddress = request.query?.get(QueryStringConstants.IP_ADDRESS) || QueryStringConstants.IP_ADDRESS_DEFAULT;

    // Create request details object for Event Hub logging
    const requestDetails: RequestDetails = {
        requestId: requestId,
        function: 'getAPISubscription', // Function name
        method: request.method, // Capture the HTTP method
        ipAddress: ipAddress, // Capture IP address
        utcDate: new Date().toISOString(), // Get the current UTC date in ISO format
        licenseLevel: "", // Capture the license level (Free or Pro)
        environment: environment, // Capture the environment (development or production)
        code: "" // Capture the M Code payload
    };

    // Initialize response tracking variables
    let statusCode = 200; // Default status code
    let errorMessage = ''; // Initialize error message
    let responseBody: any = {}; // Initialize response body

    try {
        // Validate HTTP method - only GET requests are allowed
        if (request.method !== 'GET') {
            statusCode = 405; // Method Not Allowed
            responseBody = { status: 405, body: 'Method Not Allowed' };
        }
        else {
            // Extract required parameters from query string
            const stripIdFromQueryString = request.query?.get(QueryStringConstants.STRIPE_ID) || QueryStringConstants.STRIPE_ID_DEFAULT;

            // Format stripId using helper for API Management compatibility
            const stripIdFormatted = formatSubscriptionId(stripIdFromQueryString);

            // Generate multiple stripId variants to check (base + numbered variations)
            // This allows finding subscriptions with numbered suffixes (e.g., stripId-1, stripId-2, etc.)
            const stripIdsToCheck = [];
            const checkLimit = 1; // Number of variations to generate
            for (let i = 0; i < checkLimit; i++) {
                let stripIdCheck = stripIdFormatted;
                if (i > 0) {
                    // Add numbered suffix for variations (stripId-1, stripId-2, etc.)
                    stripIdCheck = stripIdFormatted + `-${i}`
                }
                stripIdsToCheck.push(stripIdCheck);
            }

            const emailAddress = request.query?.get(QueryStringConstants.EMAIL) || QueryStringConstants.EMAIL_DEFAULT;
            requestDetails.emailAddress = emailAddress; // Store the email address in request details

            // Format email using helper for subscription lookup
            let formattedEmail = formatEmailForSubscription(emailAddress);

            // Validate required email parameter
            if (!emailAddress) {
                statusCode = 400; // Bad Request
                responseBody = { status: 400, body: 'Email address is required' };
                return responseBody;
            }
            else {
                // Initialize Azure API Management client using managed identity
                const credential = new DefaultAzureCredential();
                const client = new ApiManagementClient(credential, process.env.API_MANAGEMENT_SUBSCRIPTION_ID || "");

                let productName = '';

                // Determine product name based on stripe-id presence
                if (stripIdFromQueryString === QueryStringConstants.STRIPE_ID_DEFAULT) {
                    productName = process.env.API_MANAGEMENT_PRODUCT_ID_FREE || "";
                } else {
                    productName = process.env.API_MANAGEMENT_PRODUCT_ID_PRO || "";
                }

                // Get configuration values from environment variables
                const resourceGroupName = process.env.API_MANAGEMENT_RESOURCE_GROUP || "";
                const apiManagementName = process.env.API_MANAGMENT_NAME || "";

                // Search for subscription details across all stripId variations
                // This accommodates scenarios where subscriptions may have numbered suffixes
                let results = [];

                if (productName === process.env.API_MANAGEMENT_PRODUCT_ID_FREE) {
                    try {
                        // For free product, use formatted email as subscription id
                        const tempResult = await client.subscription.get(resourceGroupName, apiManagementName, formattedEmail);
                        if (tempResult) {
                            results.push(tempResult);
                        }
                    } catch (error) {
                        // Only handle/log if error is a 404 (Not Found)
                        if ((error as any).statusCode === 404 || (error as any).code === 'ResourceNotFound') {
                            context.log('Subscription not found (404):', error);
                        } else {
                            // For other errors, rethrow or handle differently
                            throw error;
                        }
                    }
                } else { // Paid
                    for (const stripIdCheck of stripIdsToCheck) {
                        try {
                            // Attempt to retrieve subscription for current stripId variant
                            const tempResult = await client.subscription.get(resourceGroupName, apiManagementName, stripIdCheck);
                            if (tempResult) {
                                results.push(tempResult);
                            }
                        } catch (error) {
                            // Log error but continue checking other stripId variants
                            context.log('Error retrieving subscription:', error);
                        }
                    }
                }

                context.log('API Subscription Details:', results);

                // Validate at least one subscription was found
                if (!results || results.length === 0) {
                    statusCode = 404; // Not Found
                    responseBody = { status: 404, body: 'Subscription not found' };
                }
                // Validate first subscription is active
                else if (results[0].state !== 'active') {
                    statusCode = 403; // Forbidden
                    responseBody = { status: 403, body: 'Subscription is not active' };
                }
                // Validate subscription belongs to the correct product scope
                else if (results[0].scope?.endsWith(productName) === false) {
                    statusCode = 404; // Not Found
                    responseBody = { status: 404, body: 'Subscription is not in the correct product scope' };
                }
                else {
                    // Retrieve subscription keys for all found subscriptions
                    // This provides access keys for all valid subscription variants
                    const subscriptionKeys: Subscription[] = [];

                    if (productName === process.env.API_MANAGEMENT_PRODUCT_ID_FREE) {
                        // For free product, use formatted email as subscription id
                        const secrets = await client.subscription.listSecrets(resourceGroupName, apiManagementName, formattedEmail);
                        subscriptionKeys.push({ subscriptionId: formattedEmail, subscriptionKey: secrets.primaryKey ?? '' });
                    }
                    else {
                        for (const stripIdCheck of stripIdsToCheck) {
                            try {
                                const secrets = await client.subscription.listSecrets(resourceGroupName, apiManagementName, stripIdCheck);
                                subscriptionKeys.push({ subscriptionId: stripIdCheck, subscriptionKey: secrets.primaryKey ?? '' });
                            } catch (error) {
                                // Silently continue if keys not found for this variant
                            }
                        }
                    }
                    // Validate that at least one set of subscription keys was retrieved
                    if (!subscriptionKeys || subscriptionKeys.length === 0) {
                        statusCode = 404; // Not Found
                        responseBody = { status: 404, body: 'Subscription keys not found' };
                    }
                    else {
                        // Return successful response with all found subscription keys
                        responseBody = {
                            status: 200,
                            headers: {
                                "Content-Type": "application/json",
                            },
                            body: JSON.stringify(subscriptionKeys)
                        };
                    }
                }
            }
        }
    } catch (error) {
        // Handle and log any unexpected errors
        context.log('Error processing request', error);
        if (error instanceof Error) {
            errorMessage = error.message;
        } else if (typeof error === 'string') {
            errorMessage = error;
        } else {
            errorMessage = 'Internal Server Error';
        }
        statusCode = 500; // Internal Server Error
        responseBody = { status: 500, body: 'Internal Server Error' };
    } finally {
        // Always log response details to Event Hub for monitoring and analytics
        const responseDetails: ResponseDetails = {
            requestDetails: requestDetails,
            statusCode: statusCode,
            responseBody: responseBody,
            errorMessage: errorMessage,
            utcDate: new Date().toISOString()
        };

        // Get Event Hub configuration from environment variables
        const connectionString = process.env.EVENT_HUB_CONNECTION_STRING || "";
        const eventHubName = process.env.EVENT_HUB_NAME || "";

        // Send response details to Event Hub for logging and monitoring
        await sendEventToEventHub(responseDetails, connectionString, eventHubName);

        return responseBody;
    }
};

// Register the Azure Function with HTTP trigger configuration
app.http('getAPISubscription', {
    methods: ['GET'],
    authLevel: 'function',
    handler: getAPISubscription
});