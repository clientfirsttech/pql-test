import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { fixTMDL, StreamCallback } from "../rewrite/fix-tmdl";
import { FixTMDLRequest } from 'src/helpers/http-request-types';
import { EnvironmentConstants, ModeConstants, QueryStringConstants } from 'src/helpers/constant-types';
import { extractMCodeAndProperties } from 'src/parser/tmdl/tmdl-parser';
import { sendEventToEventHub, RequestDetails, ResponseDetails } from '../helpers/event-hub';
import { v4 as uuidv4 } from 'uuid';
import { logDebug } from 'src/lint/rule-assistance';
import { log } from "console";

/**
 * Azure Function to fix TMDL code using AI with streaming responses.
 * 
 * This function:
 * 1. Validates the request (POST method, Pro mode, valid TMDL code)
 * 2. Streams AI-generated fixes back to the client using Server-Sent Events (SSE)
 * 3. Logs request/response details to Event Hub for monitoring
 * 
 * Request Body (FixTMDLRequest):
 * - code: TMDL code string to be fixed
 * - rulesResults: Array of lint rule results with AIFixInstructions
 * 
 * Query Parameters:
 * - mode: Must be "pro" for authorization
 * - code: Function key for authentication
 * - ip: Optional IP address for logging
 * - email: Optional email address for tracking
 * 
 * Response Format (text/event-stream):
 * - data: {"type":"status","message":"Processing X rules..."}
 * - data: {"type":"batch_status","message":"Processing batch X of Y..."}
 * - data: {"type":"delta","content":"incremental TMDL code chunk"}
 * - data: {"type":"final","content":"complete fixed TMDL code"}
 * - data: {"type":"error","message":"error description"}
 * - data: [DONE]
 * 
 * @param request - HTTP request containing TMDL code and rules
 * @param context - Azure Function invocation context for logging
 * @returns HttpResponseInit with streaming body or error response
 */
export async function fixTMDLStreaming(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> {
    logDebug(`Http function processed request for url "${request.url}"`, '', 'fixTMDLStreaming');
    const environment = process.env.ENVIRONMENT || EnvironmentConstants.DEVELOPMENT;
    const requestId = uuidv4();
    const ipAddress = request.query?.get(QueryStringConstants.IP_ADDRESS) || QueryStringConstants.IP_ADDRESS_DEFAULT;
    const requestDetails: RequestDetails = {
        requestId: requestId,
        function: 'fixTMDLStreaming',
        method: request.method,
        ipAddress: ipAddress,
        utcDate: new Date().toISOString(),
        licenseLevel: "",
        environment: environment,
        code: ""
    };

    let statusCode = 200;
    let errorMessage = '';
    let responseBody: any = {};
    const mode = request.query?.get(QueryStringConstants.MODE) || QueryStringConstants.MODE_DEFAULT;
    requestDetails.licenseLevel = mode.toLocaleLowerCase();

    try {
        logDebug(`Starting validations`, requestId, 'fixTMDLStreaming');
        
        // Validation: Check HTTP method
        if (request.method !== 'POST') {
            statusCode = 405;
            responseBody = { status: 405, body: 'Method Not Allowed' };
            return responseBody;
        }

        // Validation: Check Pro mode
        if (mode.toLowerCase() !== ModeConstants.PRO) {
            statusCode = 401;
            responseBody = { status: 401, body: 'Not Authorized' };
            return responseBody;
        }

        // Validation: Check request body
        const requestText = await request.text();
        if (requestText.trim() === '') {
            statusCode = 400;
            responseBody = { status: 400, body: 'Bad Request: Empty request body' };
            return responseBody;
        }

        // Parse request
        let fixTMDLRequest: FixTMDLRequest;
        try {
            fixTMDLRequest = JSON.parse(requestText);
        } catch (parseError) {
            statusCode = 400;
            responseBody = { status: 400, body: 'Bad Request: Invalid JSON for FixTMDLRequest' };
            return responseBody;
        }

        const { code, rulesResults } = fixTMDLRequest;

        // Validation: Check TMDL code
        if (!code || code.trim().length === 0) {
            statusCode = 400;
            responseBody = { status: 400, body: 'Bad Request: TMDL Code payload is required' };
            return responseBody;
        }

        // Validation: Check TMDL structure
        const extractedMCode = extractMCodeAndProperties(code);
        if (!extractedMCode || extractedMCode.length === 0) {
            statusCode = 400;
            responseBody = { status: 400, body: 'Bad Request: TMDL Code could not be parsed or contains no M code.' };
            return responseBody;
        }

        // Log TMDL code if appropriate
        if (environment.toLocaleLowerCase() !== EnvironmentConstants.PRODUCTION &&
            environment.toLocaleLowerCase() !== EnvironmentConstants.PROD) {
            requestDetails.code = code;
        } else if (mode.toLocaleLowerCase() === ModeConstants.FREE) {
            requestDetails.code = code;
        }

        // Check OpenAI credentials
        const endpoint = process.env.REWRITE_API_URL;
        const apiKey = process.env.REWRITE_API_KEY;

        if (!endpoint || !apiKey) {
            statusCode = 500;
            responseBody = { status: 500, body: 'OpenAI credentials not configured' };
            return responseBody;
        }

        logDebug(`Passed all validations`, requestId, 'fixTMDLStreaming');

        // Create streaming response
        const encoder = new TextEncoder();
        const readable = new ReadableStream({
            async start(controller) {
                try {
                    const streamCallback: StreamCallback = {
                        onStatus: (message) => {
                            const chunk = `data: ${JSON.stringify({ type: 'status', message })}\n\n`;
                            controller.enqueue(encoder.encode(chunk));
                        },
                        onBatchStatus: (current, total) => {
                            const chunk = `data: ${JSON.stringify({
                                type: 'batch_status',
                                message: `Processing batch ${current} of ${total}...`
                            })}\n\n`;
                            controller.enqueue(encoder.encode(chunk));
                        },
                        onDelta: (content) => {
                            const chunk = `data: ${JSON.stringify({ type: 'delta', content })}\n\n`;
                            controller.enqueue(encoder.encode(chunk));
                        },
                        onError: (message) => {
                            const chunk = `data: ${JSON.stringify({ type: 'error', message })}\n\n`;
                            controller.enqueue(encoder.encode(chunk));
                        }
                    };

                    const result = await fixTMDL(endpoint, apiKey, rulesResults || [], code, {
                        debug: false,
                        stream: true,
                        streamCallback
                    });

                    const finalChunk = `data: ${JSON.stringify({ type: 'final', content: result })}\n\n`;
                    controller.enqueue(encoder.encode(finalChunk));
                    controller.enqueue(encoder.encode("data: [DONE]\n\n"));
                    controller.close();
                } catch (err) {
                    context.error('Streaming error:', err);
                    errorMessage = err.message || 'Internal error occurred';
                    const errorChunk = `data: ${JSON.stringify({ type: 'error', message: errorMessage })}\n\n`;
                    controller.enqueue(encoder.encode(errorChunk));
                    controller.enqueue(encoder.encode("data: [DONE]\n\n"));
                    controller.close();
                }
            },
        });

        statusCode = 200;
        responseBody = {
            status: 200,
            headers: {
                "Content-Type": "text/event-stream",
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "Access-Control-Allow-Origin": "*",
            },
            body: readable as any,
        };

        return responseBody;

    } catch (error) {
        const errorStack = error.stack || 'No stack trace available';
        logDebug(`Error processing request: ${error.message}\nStack trace: ${errorStack}`, requestId, 'fixTMDLStreaming');
        context.error('Error processing request:', error);
        errorMessage = error.message || 'Internal Server Error';
        statusCode = 500;
        responseBody = { status: 500, body: 'Internal Server Error' };
        return responseBody;
    } finally {
        // This will always run, even with early returns
        logDebug(`Logging to Event Hub with status: ${statusCode}`, requestId, 'fixTMDLStreaming');
        
        const responseDetails: ResponseDetails = {
            requestDetails: requestDetails,
            statusCode: statusCode,
            responseBody: responseBody,
            errorMessage: errorMessage,
            utcDate: new Date().toISOString()
        };

        const connectionString = process.env.EVENT_HUB_CONNECTION_STRING || "";
        const eventHubName = process.env.EVENT_HUB_NAME || "";

        // Event Hub logging happens regardless of return path
        await sendEventToEventHub(responseDetails, connectionString, eventHubName);
    }
}

app.http('fixTMDLStreaming', {
    methods: ['POST'],
    authLevel: 'function',
    handler: fixTMDLStreaming
});