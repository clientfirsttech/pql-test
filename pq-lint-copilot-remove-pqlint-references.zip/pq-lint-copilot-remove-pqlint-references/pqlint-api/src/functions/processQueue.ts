import { app, input, InvocationContext } from "@azure/functions";
import { BlobServiceClient } from "@azure/storage-blob";
import { JobStatus, JobStatusEnum, QueueMessage, QueueAction  } from 'src/helpers/queue-types';
import { readJobStatus, writeJobStatus } from "../helpers/queue-assistance";
import { cleanupPQ } from "../rewrite/cleanup-pq";
import { FixTMDLRequest } from 'src/helpers/http-request-types';
import { fixTMDL } from "../rewrite/fix-tmdl";
/**
 * Azure Function to process items from the job-queue storage queue.
 * Updates job status as it progresses and writes results or errors to blob storage.
 */
export async function processQueue(queueItem: unknown, context: InvocationContext): Promise<void> {
  context.log('Storage queue function processed work item:', queueItem);

  const tempQueueItem: QueueMessage = queueItem as QueueMessage;

  // Set initial job status to Started and write to blob storage
  const status: JobStatus = {
    jobId: tempQueueItem.jobId,
    status: JobStatusEnum.Started,
    updatedAt: new Date().toISOString()    
  };
  const connectionString = process.env["AzureWebJobsStorage"]!;
  const blobServiceClient = BlobServiceClient.fromConnectionString(connectionString);
  const resultContainer = blobServiceClient.getContainerClient("job-results");
  await writeJobStatus(resultContainer, status);

  // Route processing based on queue action type
  switch (tempQueueItem.action) {
    case QueueAction.CleanupPQ:
      const cleanupStatus: JobStatus = await processCleanupPQ(context, JSON.stringify(tempQueueItem));
      break;
    case QueueAction.CleanupTMDL:
      const cleanupStatus2: JobStatus = await processCleanupTMDL(context, JSON.stringify(tempQueueItem));
      break;
  }
}

/**
 * Processes a single job from the queue, updating status throughout.
 * Handles job input, calls external logic, and writes results or errors.
 */
const processCleanupPQ = async function (
  context: InvocationContext,
  queueMessage: string
): Promise<JobStatus> {

  const apiKey = process.env["REWRITE_API_KEY"]!;
  const endpoint = process.env["REWRITE_API_URL"]!;

  const connectionString = process.env["AzureWebJobsStorage"]!;
  const blobServiceClient = BlobServiceClient.fromConnectionString(connectionString);

  const job = JSON.parse(queueMessage) as QueueMessage;
  const jobId = job.jobId;

  const resultContainer = blobServiceClient.getContainerClient("job-results");

  // Read job status from blob storage to get input blob
  const inputStatus: JobStatus | null = await readJobStatus(resultContainer, jobId);
  
  if (!inputStatus) {
    const errorStatus: JobStatus = {
      jobId: jobId,
      status: JobStatusEnum.Failed,
      updatedAt: new Date().toISOString(),
      error: 'Job status not found',
    };
    await writeJobStatus(resultContainer, errorStatus);
    return errorStatus;
  }

  // Update status to "In Progress"
  let status: JobStatus = {
    jobId: jobId,
    status: JobStatusEnum.InProgress,
    updatedAt: new Date().toISOString()
  };
  await writeJobStatus(resultContainer, status);

  try {
    // Download job input from blob storage
    const mCode = JSON.parse(inputStatus.input) as string;
    
    // Use endpoint and apiKey declared in beforeAll
    const rewrittenCode = await cleanupPQ(endpoint, apiKey, mCode, false);
    
    // Write completed status and result to blob storage
    status = {
      jobId: jobId,
      status: JobStatusEnum.Completed,
      updatedAt: new Date().toISOString(),
      result: JSON.stringify(rewrittenCode)
    };
    await writeJobStatus(resultContainer, status);
    return status;

  } catch (error) {
    // On error, log and write failed status to blob storage
    context.log(`Error processing job ${jobId}:`, error);
    status = {
      jobId: jobId,
      status: JobStatusEnum.Failed,
      updatedAt: new Date().toISOString(),
      error: error instanceof Error ? error.message : String(error),
    };
    await writeJobStatus(resultContainer, status);
    return status;
  }
};

/**
 * Processes a single job from the queue, updating status throughout.
 * Handles job input, calls external logic, and writes results or errors.
 */
const processCleanupTMDL = async function (
  context: InvocationContext,
  queueMessage: string
): Promise<JobStatus> {

  const apiKey = process.env["REWRITE_API_KEY"]!;
  const endpoint = process.env["REWRITE_API_URL"]!;

  const connectionString = process.env["AzureWebJobsStorage"]!;
  const blobServiceClient = BlobServiceClient.fromConnectionString(connectionString);

  const job = JSON.parse(queueMessage) as QueueMessage;
  const jobId = job.jobId;

  const resultContainer = blobServiceClient.getContainerClient("job-results");

  // Read job status from blob storage to get input blob
  const inputStatus: JobStatus | null = await readJobStatus(resultContainer, jobId);
  
  if (!inputStatus) {
    const errorStatus: JobStatus = {
      jobId: jobId,
      status: JobStatusEnum.Failed,
      updatedAt: new Date().toISOString(),
      error: 'Job status not found',
    };
    await writeJobStatus(resultContainer, errorStatus);
    return errorStatus;
  }

  // Update status to "In Progress"
  let status: JobStatus = {
    jobId: jobId,
    status: JobStatusEnum.InProgress,
    updatedAt: new Date().toISOString()
  };
  await writeJobStatus(resultContainer, status);

  try {
    // Download job input from blob storage
    const fixTMDLRequest = JSON.parse(inputStatus.input) as FixTMDLRequest;
    
    // Use endpoint and apiKey declared in beforeAll
    const rewrittenCode = await fixTMDL(endpoint, apiKey, fixTMDLRequest.rulesResults, fixTMDLRequest.code);

    // Write completed status and result to blob storage
    status = {
      jobId: jobId,
      status: JobStatusEnum.Completed,
      updatedAt: new Date().toISOString(),
      result: JSON.stringify(rewrittenCode)
    };
    await writeJobStatus(resultContainer, status);
    return status;

  } catch (error) {
    // On error, log and write failed status to blob storage
    context.log(`Error processing job ${jobId}:`, error);
    status = {
      jobId: jobId,
      status: JobStatusEnum.Failed,
      updatedAt: new Date().toISOString(),
      error: error instanceof Error ? error.message : String(error),
    };
    await writeJobStatus(resultContainer, status);
    return status;
  }
};


/**
 * Azure Function binding for the job-queue storage queue.
 */
app.storageQueue('ProcessJob', {
  queueName: 'job-queue',
  connection: '',
  handler: processQueue
});