import { app, input, InvocationContext } from "@azure/functions";
import { getRulesAsJson } from 'src/lint/all-rules';
import { lintMCode as lintCodeFunction, lintTMDLCode } from 'src/lint/linter-module';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { allPQRules } from 'src/lint/all-rules';
import { LicenseLevel, SeverityLevel } from 'src/lint/rule-types';
import parseCopiedPQ from 'src/parser/pq/parse-copied-pq';
import { FormatConstants, LintRequest } from 'src/helpers/http-request-types';
import { extractMCodeAndProperties } from 'src/parser/tmdl/tmdl-parser';
import { logDebug } from 'src/lint/rule-assistance';
import { log } from "console";
import { parse } from "path";
import { ParseResult } from 'src/parser/pq/parse-types';

// Constants for MCP tool definitions
const GET_LINTING_RULES_TOOL_NAME = "get-linting-rules";
const GET_LINTING_RULES_TOOL_DESCRIPTION = "Gets all available linting rules for Power Query M code and TMDL code";
const LINT_CODE_TOOL_NAME = "lint-code";
const LINT_CODE_TOOL_DESCRIPTION = "Lints Power Query M code or TMDL code and returns rule violations";

// Property constants
const CODE_PROPERTY_NAME = "code";
const RULES_PROPERTY_NAME = "rules";
const FORMAT_PROPERTY_NAME = "format";
const SEVERITY_PROPERTY_NAME = "severity";
const CODE_PROPERTY_DESCRIPTION = "The Power Query M or TMDL code to lint";
const RULES_PROPERTY_DESCRIPTION = "Optional array of specific rule names to check (comma-separated)";
const FORMAT_PROPERTY_DESCRIPTION = "Optional linting format (e.g., 'pq' for Power Query, 'tmdl' for TMDL)";
const PROPERTY_TYPE_STRING = "string";

// Tool properties for Get Linting Rules (no parameters needed)
const GET_LINTING_RULES_TOOL_PROPERTIES: any[] = [];

// Tool properties for Lint Code based on LintRequest interface
const LINT_CODE_TOOL_PROPERTIES = [
  {
    propertyName: "code",
    propertyType: "string",
    description: "Multiline Power Query M or TMDL code to lint (with linebreaks)"
  },
  {
    propertyName: "rules",
    propertyType: "string",
    description: "Optional comma-separated list of specific rule names to apply (e.g., 'rule1,rule2,rule3')"
  },
  {
    propertyName: "severity",
    propertyType: "string", 
    description: "Optional minimum severity level to include in results. Valid values: '1' (Information), '2' (Best Practice), '3' (Potential Issue), '4' (Warning), '5' (Error). Use '2' for best practices, '3' for potential issues."
  },
  {
    propertyName: "format",
    propertyType: "string",
    description: "Optional code format type. Valid values: 'pq' for Power Query M code, 'tmdl' for TMDL code. Defaults to 'pq'"
  }
];

/**
 * Comprehensive logging function for MCP requests using logDebug
 * Logs all available message and context information for debugging
 */
function logAllMCPRequestDetails(message: any, context: InvocationContext, toolName: string): void {
  logDebug(`=== MCP ${toolName} Request Details ===`);
  logDebug(`Timestamp: ${new Date().toISOString()}`);
  logDebug(`Invocation ID: ${context.invocationId}`);
  logDebug(`Function Name: ${context.functionName}`);
  
  // Log message structure and arguments
  if (message) {
    logDebug('Message keys:', Object.keys(message));
    logDebug('Message arguments:', JSON.stringify(message.arguments, null, 2));
    
    // Log any additional message properties
    Object.entries(message).forEach(([key, value]) => {
      if (key !== 'arguments') {
        logDebug(`Message.${key}:`, value);
      }
    });
  } else {
    logDebug('Message: null/undefined');
  }
  
  // Log context details
  logDebug('Context keys:', Object.keys(context));
  
  // Log extra inputs if available
  if (context.extraInputs) {
    logDebug('Extra inputs:', context.extraInputs);
  }
  
  // Log extra outputs if available
  if (context.extraOutputs) {
    logDebug('Extra outputs:', context.extraOutputs);
  }
  
  // Log trace context if available
  if (context.traceContext) {
    logDebug('Trace context:', context.traceContext);
  }
  
  // Log any other context properties that might contain request info
  Object.entries(context).forEach(([key, value]) => {
    if (!['log', 'error', 'warn', 'info', 'debug', 'trace', 'invocationId', 'functionName', 'extraInputs', 'extraOutputs', 'traceContext'].includes(key)) {
      logDebug(`Context.${key}:`, value);
    }
  });
  
  logDebug(`=== End MCP ${toolName} Request Details ===`);
}

/**
 * MCP Tool: Get Linting Rules
 * Retrieves all available linting rules for Power Query M code and TMDL code
 */
async function getLintingRulesHandler(
  message: any,
  context: InvocationContext,
): Promise<string> {
  context.log("MCP Tool: Get Linting Rules called");
  
  // Log all available request details for debugging
  logAllMCPRequestDetails(message, context, "Get Linting Rules");

  try {

    // Call the core rules function directly
    const rules = getRulesAsJson();
    
    let resultText = `Retrieved ${rules.length} linting rules successfully.\n\n`;
    resultText += "The rules cover various categories including:\n";
    resultText += "- Performance optimizations\n";
    resultText += "- Best practices\n";
    resultText += "- Potential issues\n";
    resultText += "- Code maintainability\n\n";
    
    
    resultText += `Full rules data (JSON):\n${JSON.stringify(rules, null, 2)}`;
    
    return resultText;
  } catch (error) {
    context.error('Error in getLintingRules:', error);
    return `Failed to retrieve linting rules: ${error instanceof Error ? error.message : String(error)}`;
  }
}


// Helper function to parse severity with correct mappings
function parseSeverityLevel(severityInput: string | undefined): SeverityLevel | undefined {
  if (!severityInput) return undefined;
  
  const severity = severityInput.toLowerCase().trim();
  
  // Handle numeric values
  switch (severity) {
    case '1': return SeverityLevel.Info;
    case '2': return SeverityLevel.Warning;
    case '3': return SeverityLevel.Error;
  }
  
  // Handle string values
  switch (severity) {
    case 'information': return SeverityLevel.Info;
    case 'best practice':
    case 'warning': return SeverityLevel.Warning;
    case 'bestpractice': return SeverityLevel.Warning;        // = 2
    case 'potential issue':
    case 'potentialissue': return SeverityLevel.Error;    // = 3
    case 'error': return SeverityLevel.Error;
    default: 
      throw new Error(`Invalid severity level: ${severityInput}. Valid values are: 1 (Information), 2 (Best Practice), 3 (Potential Issue), 4 (Warning), 5 (Error)`);
  }
}

// Updated lintCodeHandler with correct severity parsing
async function lintCodeHandler(
  message: any,
  context: InvocationContext
): Promise<string> {
  context.log("MCP Tool: Lint Code called");
  context.log("MCP Tool: Lint Code called with message arguments:", JSON.stringify(message?.arguments, null, 3));
  
  // Log all available request details for debugging
  logAllMCPRequestDetails(message, context, "Lint Code");
  
  try {
    // Retrieve MCP tool arguments
    const mcpToolArgs = message?.arguments as {
      code?: string;
      rules?: string;
      format?: string;
      severity?: string;
    }

    const code = mcpToolArgs?.code;
    const rulesParam = mcpToolArgs?.rules;
    const formatParam = mcpToolArgs?.format;
    const severityParam = mcpToolArgs?.severity;

    if (!code) {
      return "Error: code parameter is required";
    }

    // Parse format with default
    const format = formatParam?.toLowerCase() === FormatConstants.TMDL 
      ? FormatConstants.TMDL 
      : FormatConstants.PQ;

    // Parse severity with correct numeric assignments
    let severity: SeverityLevel | undefined;
    if (severityParam) {
      try {
        severity = parseSeverityLevel(severityParam);
      } catch (error) {
        return `Error: ${error instanceof Error ? error.message : String(error)}`;
      }
    }

    context.log(`Linting code with format: ${format}, severity: ${severity || 'all'}`);

    // Parse rules if provided (comma-separated string to array)
    const rulesArray: string[] | undefined = rulesParam ? 
      rulesParam.split(',').map((r: string) => r.trim()).filter((r: string) => r) 
      : undefined;

    // Create LintRequest object following the interface
    const lintRequest: LintRequest = {
      code,
      rules: rulesArray,
      options: {
        severity,
        format
      }
    };

    // Call the appropriate linting function based on format
    let lintResult;
    
    if (format === FormatConstants.TMDL) {
      // For TMDL code - filter rules by name if specified
      const filteredRules = rulesArray ? 
        allPQRules.filter(rule => rulesArray.includes(rule.ID)) : 
        allPQRules;
      
      lintResult = await lintTMDLCode(
        code,
        filteredRules,
        [],
        [],
        false
      );
    } else {
      // For Power Query M code - filter rules by name if specified
      const filteredRules = rulesArray ? 
        allPQRules.filter(rule => rulesArray.includes(rule.ID)) : 
        allPQRules;
      
      try {
        const parseResult: ParseResult = await parsePowerQueryText(code);
        lintResult = await lintCodeFunction(
          parseResult,
          filteredRules,
          false,
          0,
          false
        );
      } catch (parseError) {
        return `Error parsing Power Query code: ${parseError instanceof Error ? parseError.message : String(parseError)}`;
      }
    }

    // Filter by severity if specified
    const filteredResults = severity 
      ? lintResult.filter(result => result.Severity >= severity)
      : lintResult;

    // Format the response
    if (!filteredResults || filteredResults.length === 0) {
      return `Linting completed successfully. No violations found with severity filter: ${severity || 'all'}`;
    }
    
    let resultText = `Linting completed. Found ${filteredResults.length} violation(s):\n\n`;
    
    filteredResults.forEach((result, index) => {
      resultText += `${index + 1}. Rule: ${result.Name} (${result.ID})\n`;
      resultText += `   Category: ${result.Category}\n`;
      resultText += `   Severity: ${result.Severity} (${getSeverityName(result.Severity)})\n`;
      resultText += `   Description: ${result.Description}\n`;
      resultText += `   Passed: ${result.Passed}\n`;
      
      if (result.ErrorInformation?.errorLocation) {
        const location = result.ErrorInformation.errorLocation;
        resultText += `   Location: Line ${location.positionStart.lineNumber}, Column ${location.positionStart.lineCodeUnit}\n`;
      }
      
      if (result.AIFixInstructions?.Description) {
        resultText += `   AI Fix Available: ${result.AIFixInstructions.Description}\n`;
        resultText += `   AI Fix Active: ${result.AIFixInstructions.IsActive}\n`;
      }
      
      resultText += '\n';
    });
    
    return resultText;
    
  } catch (error) {
    context.error('Error in lintCode:', error);
    return `Failed to lint code: ${error instanceof Error ? error.message : String(error)}`;
  }
}

// Helper function to convert severity number to readable name
function getSeverityName(severity: SeverityLevel): string {
  switch (severity) {
    case SeverityLevel.Info: return "Information";
    case SeverityLevel.Warning: return "Warning/Best Practice";
    case SeverityLevel.Error: return "Error/Potential Issue";
    default: return "Unknown";
  }
}

// Complete app.mcpTool registrations with correct severity mappings
// Disabled for now
/*
app.mcpTool("get-linting-rules", {
  toolName: "lint_rules",
  description: "Gets all available linting rules for Power Query M code and TMDL code",
  toolProperties: GET_LINTING_RULES_TOOL_PROPERTIES,
  handler: getLintingRulesHandler
});

app.mcpTool("lint-code", {
  toolName: "lint_code", 
  description: "Lints Power Query M code or TMDL code and returns rule violations. Use severity '2' for best practices, '3' for potential issues.",
  toolProperties: LINT_CODE_TOOL_PROPERTIES,
  handler: lintCodeHandler
});
*/