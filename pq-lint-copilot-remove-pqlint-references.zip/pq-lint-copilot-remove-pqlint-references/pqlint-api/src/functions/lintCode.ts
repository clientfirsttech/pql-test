import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { lintMCode as lintCodeFunction } from 'src/lint/linter-module';
import { M_Code_From_Copied_PQ, ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { allPQRules } from 'src/lint/all-rules';
import { LicenseLevel } from 'src/lint/rule-types';
import { v4 as uuidv4 } from 'uuid'; // For generating GUIDs
import { sendEventToEventHub, RequestDetails, ResponseDetails } from '../helpers/event-hub'; // Import the function to send events to Event Hub
import parseCopiedPQ from 'src/parser/pq/parse-copied-pq';
import { EnvironmentConstants, ModeConstants, QueryStringConstants } from 'src/helpers/constant-types';

// Define lintCode function
export async function lintCode(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> {
    context.log(`Http function processed request for url "${request.url}"`);
    // Establish connection to Event Hub
    const environment = process.env.ENVIRONMENT || EnvironmentConstants.DEVELOPMENT; // Environment (development or production)

    // Generate a unique request ID
    const requestId = uuidv4();
    // Extract ip address from query string
    const ipAddress = request.query?.get(QueryStringConstants.IP_ADDRESS) || QueryStringConstants.IP_ADDRESS_DEFAULT;
    // Capture request details
    const requestDetails: RequestDetails = {
        requestId: requestId,
        function: 'lintCode', // Function name
        method: request.method, // Capture the HTTP method
        ipAddress: ipAddress, // Capture IP address
        utcDate: new Date().toISOString(), // Get the current UTC date in ISO format
        licenseLevel: "", // Capture the license level (Free or Pro)
        environment: environment, // Capture the environment (development or production)
        code: "" // Capture the M Code payload
    };

    let statusCode = 200; // Default status code
    let results: any = []; // Initialize results
    let errorMessage = ''; // Initialize error message
    let responseBody: any = {}; // Initialize response body

    try {
        // Check if the HTTP method is POST
        if (request.method !== 'POST') {
            statusCode = 405; // Method Not Allowed
            responseBody = { status: 405, body: 'Method Not Allowed' };
        } else {
            // Extract mode parameter from query string
            const mode = request.query?.get(QueryStringConstants.MODE) || QueryStringConstants.MODE_DEFAULT;
            requestDetails.licenseLevel = mode.toLocaleLowerCase(); // Store the license level in request details

            // Extract email address from headers
            const emailAddress = request.query?.get(QueryStringConstants.EMAIL) || QueryStringConstants.EMAIL_DEFAULT;
            requestDetails.emailAddress = emailAddress; // Store the email address in request details

            // Extract the raw M Code from the request body
            const rawCode = await request.text();

            // If the input contains escaped characters (e.g., \" for quotes), unescape them
            const code = rawCode.replace(/\\\"/g, '"'); // Replace escaped quotes with regular quotes

            // Check if M Code is empty, undefined, or just whitespace
            if (!code || code.trim() === '') {
                statusCode = 400; // Bad Request
                responseBody = { status: 400, body: 'Bad Request: M Code payload is required' };
            } else {
                // Check if we can log the M Code
                if (environment.toLocaleLowerCase() !== EnvironmentConstants.PRODUCTION &&
                    environment.toLocaleLowerCase() !== EnvironmentConstants.PROD) {
                    requestDetails.code = "code"; // Store the M Code in request details
                } else if (mode.toLocaleLowerCase() === ModeConstants.FREE) {
                    requestDetails.code = code; // Store the M Code in request details
                }

                // Select rules based on mode
                let rules = allPQRules.filter(rule => rule.MinLicenseLevel === LicenseLevel.Free);

                // Check the mode and filter rules accordingly
                if (mode.toLocaleLowerCase() === ModeConstants.PRO) {
                    rules = allPQRules.filter(rule => rule.MinLicenseLevel === LicenseLevel.Pro || rule.MinLicenseLevel === LicenseLevel.Free);
                }

                try {

                    // Parse the Power Query text
                    const mCodes: M_Code_From_Copied_PQ[] = await parseCopiedPQ(code);

                    await Promise.all(mCodes.map(async (mCode) => {
                        let isParseError = false;
                        let parseErrorMsg = "";

                        const parsedCode: ParseResult = await parsePowerQueryText(mCode.code ?? '');
                        context.log(`Parsed M Code: ${JSON.stringify(parsedCode)}`);
                        context.log(`MCodes: ${JSON.stringify(mCode)}`);
                        // Check if there are any parse errors
                        if (parsedCode.error && parsedCode.error.length > 0) {

                            isParseError = true;
                            parseErrorMsg = parsedCode.error;
                        }

                        if (isParseError === false) {
                            // Lint the code
                            const tempResults = await lintCodeFunction(parsedCode, rules, false, mCode.lineNumber);
                            // Add to the results
                            results.push(...tempResults);
                            // Prepare the response body
                            responseBody = {
                                status: 200,
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify(results)
                            };
                        }
                        else {
                            statusCode = 400; // Bad Request
                            responseBody = {
                                status: 400,
                                body: JSON.stringify({
                                    error: "Parse Error: " + parseErrorMsg
                                })
                            };
                        }

                    }));

                } catch (error) {
                    throw error; // Rethrow the error to be caught in the catch block
                }
            }
        }
    } catch (error) {
        // Handle errors
        context.log('Error processing request', error);
        const message = error instanceof Error ? error.message : String(error);
        context.log('Error details:', message);
        errorMessage = message || 'Internal Server Error';
        statusCode = 500; // Internal Server Error
        responseBody = { status: 500, body: 'Internal Server Error' };
    } finally {
        // Log response details to Event Hub
        const responseDetails: ResponseDetails = {
            requestDetails: requestDetails,
            statusCode: statusCode, // Include the status code
            responseBody: responseBody, // Include the response body
            errorMessage: errorMessage, // Include error message if any
            utcDate: new Date().toISOString() // Get the current UTC date in ISO format
        };
        // Establish connection to Event Hub
        const connectionString = process.env.EVENT_HUB_CONNECTION_STRING || ""; // Event Hub connection string
        const eventHubName = process.env.EVENT_HUB_NAME || ""; // Event Hub name

        // Send response details to Event Hub
        await sendEventToEventHub(responseDetails, connectionString, eventHubName);

        return responseBody;
    }
}

// Azure Function HTTP trigger configuration
app.http('lintCode', {
    methods: ['POST'],
    authLevel: 'function',
    handler: lintCode
});