import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { lintMCode, lintTMDLCode} from 'src/lint/linter-module';
import { M_Code_From_Copied_PQ, ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { allPQRules, allTMDLLevelPQRules } from 'src/lint/all-rules';
import { LicenseLevel, SeverityLevel } from 'src/lint/rule-types';
import { v4 as uuidv4 } from 'uuid'; // For generating GUIDs
import { sendEventToEventHub, APIRequestDetails, APIResponseDetails } from '../helpers/event-hub'; // Import the function to send events to Event Hub
import parseCopiedPQ from 'src/parser/pq/parse-copied-pq';
import { EnvironmentConstants, HeaderConstants, ModeConstants, QueryStringConstants } from 'src/helpers/constant-types';
import { LintRequest, FormatConstants } from 'src/helpers/http-request-types';
import { extractMCodeAndProperties, M_Code } from 'src/parser/tmdl/tmdl-parser';
import { logDebug } from 'src/lint/rule-assistance';

// Define lintCode function
/**
 * Azure Function HTTP trigger for linting Power Query (M) or TMDL code.
 * 
 * This function receives a POST request containing code and linting options,
 * validates the request, parses the code, applies linting rules, and returns
 * the linting results. It also logs request and response details to Azure Event Hub.
 * 
 * @param request - The incoming HTTP request containing the code and options.
 * @param context - The Azure Functions invocation context for logging and environment info.
 * @returns A Promise resolving to an HTTP response with linting results or error details.
 */
export async function lintCodeV2(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> {
    context.log(`Http function processed request for url "${request.url}"`);
    // Establish connection to Event Hub
    const environment = process.env.ENVIRONMENT || EnvironmentConstants.DEVELOPMENT; // Environment (development or production)

    // Generate a unique request ID
    const requestId = uuidv4();
    // Try to get the IP from the X-Forwarded-For header (set by APIM)
    const xForwardedFor = request.headers.get("x-forwarded-for");
    let ipAddress = QueryStringConstants.IP_ADDRESS_DEFAULT; // Default IP address

    if (xForwardedFor) {
        // The header may contain a comma-separated list; the first is the original client
        ipAddress = xForwardedFor.split(",")[0].trim();
    }

    // Extract subscription key from query string or headers
    const subKey = request.query?.get(QueryStringConstants.SUBSCRIPTION_KEY) || 
                   request.headers.get(QueryStringConstants.SUBSCRIPTION_KEY) || 
                   request.headers.get(HeaderConstants.SUBSCRIPTION_KEY) ||
                    QueryStringConstants.SUBSCRIPTION_KEY_DEFAULT;

    // Extract subscription ID from query string or headers
    const subId = request.query?.get(QueryStringConstants.SUBSCRIPTION_ID) || 
                   request.headers.get(QueryStringConstants.SUBSCRIPTION_ID) || 
                   QueryStringConstants.SUBSCRIPTION_ID_DEFAULT;

    // Extract product ID from query string or headers
    const productId = request.query?.get(QueryStringConstants.API_PRODUCT_ID) ||
                      request.headers.get(QueryStringConstants.API_PRODUCT_ID) ||
                      QueryStringConstants.API_PRODUCT_ID_DEFAULT;

    // Capture request details
    const requestDetails: APIRequestDetails = {
        requestId: requestId,
        function: 'lintCodeV2', // Function name
        method: request.method, // Capture the HTTP method
        ipAddress: ipAddress, // Capture IP address
        utcDate: new Date().toISOString(), // Get the current UTC date in ISO format
        subscriptionId: subId, // Capture the subscription ID
        apiProductId: productId, // Capture the API Product ID
        environment: environment, // Capture the environment (development or production)
        code: "" // Capture the M Code payload
    };

    let statusCode = 200; // Default status code
    let results: any = []; // Initialize results
    let errorMessage = ''; // Initialize error message
    let responseBody: any = {}; // Initialize response body

    try {
        // Check if the HTTP method is POST
        if (request.method !== 'POST') {
            statusCode = 405; // Method Not Allowed
            responseBody = { status: 405, body: 'Method Not Allowed' };
        }
        else if (subKey === QueryStringConstants.SUBSCRIPTION_KEY_DEFAULT) {
            statusCode = 403; // Forbidden
            responseBody = { status: 403, body: 'Forbidden: Subscription Key is required' };
        }
        else if (subId === QueryStringConstants.SUBSCRIPTION_ID_DEFAULT) {
            statusCode = 403; // Forbidden
            responseBody = { status: 403, body: 'Forbidden: Subscription ID is required' };
        }
        else if (productId === QueryStringConstants.API_PRODUCT_ID_DEFAULT) {
            statusCode = 403; // Forbidden
            responseBody = { status: 403, body: 'Forbidden: Product ID is required' };
        } else {
            // Default to free mode
            let mode = ModeConstants.FREE;
            
            if(productId === process.env.API_MANAGEMENT_PRODUCT_ID_PRO){
                mode = ModeConstants.PRO;
            } // end if

            // Extract and parse the request body as LintRequest
            let lintRequest: LintRequest | null = null;
            let canParseRequest: boolean = false;
            try {
                const requestText = await request.text()
                if (requestText.trim() === '') {
                    throw "Bad Request: Empty request body";
                }
                lintRequest = JSON.parse(requestText);
                canParseRequest = true; // Set flag to true if parsing is successful
            } catch (parseError) {
                statusCode = 400;
                responseBody = { status: 400, body: 'Bad Request: Invalid JSON for LintRequest' };
            }
            logDebug(`Lint Code V2 Request: ${JSON.stringify(lintRequest ?? '')}`);
            if (canParseRequest === true && lintRequest !== null) {
                // Access properties as needed
                const rawCode = lintRequest.code;
                const rulesProvided = lintRequest.rules;
                const optionsProvided = lintRequest.options;
                const format: string = optionsProvided?.format || FormatConstants.PQ; // Default to Power Query format if not provided
                const verbose: boolean = optionsProvided?.verbose || false; // Default to false if not provided
                logDebug(`Lint Code V2 Request for Verbose: ${verbose}`);
                // Check if M Code (PQ format) or TMDL Code is empty, undefined, or just whitespace
                if (!rawCode || rawCode.trim() === '') {
                    statusCode = 400; // Bad Request
                    responseBody = { status: 400, body: 'Bad Request: M Code (PQ format) or TMDL Code payload is required' };
                } else {
                    // If the input contains escaped characters (e.g., \" for quotes), unescape them
                    const code = rawCode.replace(/\\\"/g, '"'); // Replace escaped quotes with regular quotes

                    // Check if we can log the M Code based on environment and license level
                    if (mode.toLocaleLowerCase() === ModeConstants.FREE) {
                        requestDetails.code = code; // Store the M Code in request details
                    }

                    // If rulesProvided is not undefined or empty, filter allPQRules by those names
                    let filteredRules = allPQRules;
                    let filteredTMDLLevelRules = allTMDLLevelPQRules;

                    // Then filter rules 
                    if (rulesProvided && Array.isArray(rulesProvided) && rulesProvided.length > 0) {
                        filteredRules = filteredRules.filter(rule => rulesProvided.includes(rule.ID));
                        filteredTMDLLevelRules = filteredTMDLLevelRules.filter(rule => rulesProvided.includes(rule.ID));
                    }

                    // If optionsProvided is not undefined or empty, filter by severity level if specified
                    if (optionsProvided?.severity !== undefined && Object.values(SeverityLevel).includes(optionsProvided.severity)) {
                        filteredRules = filteredRules.filter(rule => rule.Severity >= optionsProvided.severity!);
                        filteredTMDLLevelRules = filteredTMDLLevelRules.filter(rule => rule.Severity >= optionsProvided.severity!);
                    }

                    // Finally, filter by mode (free or pro)
                    if (mode.toLocaleLowerCase() === ModeConstants.FREE) {
                        filteredRules = filteredRules.filter(rule => rule.MinLicenseLevel === LicenseLevel.Free);
                        filteredTMDLLevelRules = filteredTMDLLevelRules.filter(rule => rule.MinLicenseLevel === LicenseLevel.Free);
                    } else if (mode.toLocaleLowerCase() === ModeConstants.PRO) {
                        filteredRules = filteredRules.filter(rule =>
                            rule.MinLicenseLevel === LicenseLevel.Free ||
                            rule.MinLicenseLevel === LicenseLevel.Pro
                        );
                    }
                    logDebug(`Filtered Rules Count: ${filteredRules.length}`);

                    try {
                        if (format === FormatConstants.TMDL) {

                            const tempResults = await lintTMDLCode(code, filteredRules, filteredTMDLLevelRules, [], false, verbose);
                            // Add to the results
                            results.push(...tempResults);
                            // Prepare the response body
                            responseBody = {
                                status: 200,
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify(results)
                            };
                        } else { // Default to Power Query (PQ) format
                            // Parse copied Power Query code
                            let mCodes: M_Code_From_Copied_PQ[] = await parseCopiedPQ(code);

                            // Process each Power Query code block
                            await Promise.all(mCodes.map(async (mCode) => {
                                let isParseError = false;
                                let parseErrorMsg = "";

                                const parsedCode: ParseResult = await parsePowerQueryText(mCode.code ?? '');
                                // Check if there are any parse errors
                                if (parsedCode.error && parsedCode.error.length > 0) {

                                    isParseError = true;
                                    parseErrorMsg = parsedCode.error;
                                }

                                if (isParseError === false) {
                                    // Lint the code
                                    const tempResults = await lintMCode(parsedCode, filteredRules, false, mCode.lineNumber, verbose);
                                    // Add to the results
                                    results.push(...tempResults);
                                    // Prepare the response body
                                    responseBody = {
                                        status: 200,
                                        headers: {
                                            'Content-Type': 'application/json'
                                        },
                                        body: JSON.stringify(results)
                                    };
                                }
                                else {
                                    statusCode = 400; // Bad Request
                                    responseBody = {
                                        status: 400,
                                        body: JSON.stringify({
                                            error: "Parse Error: " + parseErrorMsg
                                        })
                                    };
                                }

                            }));
                        }


                    } catch (error) {
                        throw error; // Rethrow the error to be caught in the catch block
                    }
                }
            }
        }
    } catch (error) {
        // Handle errors
        context.log('Error processing request', error);
        const message = error instanceof Error ? error.message : String(error);
        context.log('Error details:', message);
        errorMessage = message || 'Internal Server Error';
        statusCode = 500; // Internal Server Error
        responseBody = { status: 500, body: 'Internal Server Error' };
    } finally {
        // Log response details to Event Hub
        const responseDetails: APIResponseDetails = {
            requestDetails: requestDetails,
            statusCode: statusCode, // Include the status code
            responseBody: responseBody, // Include the response body
            errorMessage: errorMessage, // Include error message if any
            utcDate: new Date().toISOString() // Get the current UTC date in ISO format
        };
        // Establish connection to Event Hub
        const connectionString = process.env.EVENT_HUB_CONNECTION_STRING || ""; // Event Hub connection string
        const eventHubName = process.env.EVENT_V2_HUB_NAME || ""; // Event Hub name

        // Send response details to Event Hub
        await sendEventToEventHub(responseDetails, connectionString, eventHubName);

        return responseBody;
    }
}

// Azure Function HTTP trigger configuration
app.http('lintCodeV2', {
    methods: ['POST'],
    authLevel: 'function',
    handler: lintCodeV2
});