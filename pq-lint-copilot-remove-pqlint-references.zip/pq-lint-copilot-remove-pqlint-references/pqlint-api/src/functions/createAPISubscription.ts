import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { v4 as uuidv4 } from 'uuid'; // For generating GUIDs
import { sendEventToEventHub, RequestDetails, ResponseDetails } from '../helpers/event-hub'; // Import the function to send events to Event Hub
import { EnvironmentConstants, QueryStringConstants } from 'src/helpers/constant-types';
import { DefaultAzureCredential } from "@azure/identity";
import { ApiManagementClient, SubscriptionCreateOrUpdateResponse } from "@azure/arm-apimanagement";
import { Subscription } from 'src/helpers/http-request-types';
import { formatEmailForSubscription, formatSubscriptionId } from 'src/helpers/format-subscription-ids'; // Import formatting helpers

export async function createAPISubscription(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> {
    // Initialize environment and tracking variables
    const environment = process.env.ENVIRONMENT || EnvironmentConstants.DEVELOPMENT;

    // Generate a unique request ID for tracking and correlation
    const requestId = uuidv4();
    // Extract client IP address from query parameters for logging
    const ipAddress = request.query?.get(QueryStringConstants.IP_ADDRESS) || QueryStringConstants.IP_ADDRESS_DEFAULT;

    // Create request details object for Event Hub logging
    const requestDetails: RequestDetails = {
        requestId: requestId,
        function: 'createAPISubscription',
        method: request.method,
        ipAddress: ipAddress,
        utcDate: new Date().toISOString(),
        licenseLevel: "",
        environment: environment,
        code: ""
    };

    // Initialize response tracking variables
    let statusCode = 200;
    let errorMessage = '';
    let responseBody: any = {};

    try {
        // Only allow POST requests
        if (request.method !== 'POST') {
            statusCode = 405;
            responseBody = { status: 405, body: 'Method Not Allowed' };
        }
        else {
            // Extract and format required parameters
            const stripIdFromQueryString = request.query?.get(QueryStringConstants.STRIPE_ID) || QueryStringConstants.STRIPE_ID_DEFAULT;
            const stripIdFormatted = formatSubscriptionId(stripIdFromQueryString); // Format subscription id for compatibility

            // Default to Free product
            let apiProductID = process.env.API_MANAGEMENT_PRODUCT_ID_FREE || "";

            // Extract and format email address
            const emailAddress = request.query?.get(QueryStringConstants.EMAIL) || QueryStringConstants.EMAIL_DEFAULT;
            requestDetails.emailAddress = emailAddress;

            // Format email for use as subscription id if needed
            let formattedEmail = formatEmailForSubscription(emailAddress);

            // Validate required email parameter
            if (emailAddress === QueryStringConstants.EMAIL_DEFAULT) {
                statusCode = 400;
                responseBody = { status: 400, body: 'Email address is required' };
                return responseBody;
            }
            else {
                // Initialize Azure API Management client using managed identity
                const credential = new DefaultAzureCredential();
                const client = new ApiManagementClient(credential, process.env.API_MANAGEMENT_SUBSCRIPTION_ID || "");

                // Determine subscription id and product based on presence of stripe-id
                let userSubscriptionId = '';
                if(stripIdFormatted === QueryStringConstants.STRIPE_ID_DEFAULT){
                    apiProductID = process.env.API_MANAGEMENT_PRODUCT_ID_FREE || "";
                    userSubscriptionId = formattedEmail; // Use formatted email for free product
                }else{
                    apiProductID = process.env.API_MANAGEMENT_PRODUCT_ID_PRO || "";
                    userSubscriptionId = stripIdFormatted; // Use formatted stripe-id for paid product
                }

                context.log(`Using userSubscriptionId: ${userSubscriptionId} for email: ${emailAddress} with product: ${apiProductID}`);

                // Get configuration values from environment variables
                const resourceGroupName = process.env.API_MANAGEMENT_RESOURCE_GROUP || "";
                const apiManagementName = process.env.API_MANAGMENT_NAME || "";

                // Attempt to retrieve existing subscription
                let results = [];
                try {
                    const tempResult = await client.subscription.get(resourceGroupName, apiManagementName, userSubscriptionId);
                    if (tempResult) {
                        results.push(tempResult);
                    }
                } catch (error) {
                    // Log error but continue to creation if not found
                    context.log('Error retrieving subscription:', error);
                }

                context.log('API Subscription Details:', results);

                // Filter for active subscriptions matching product scope
                results = results.filter(sub => (sub.scope?.endsWith("/" + apiProductID) ?? false) && sub.state === 'active');

                // If no active subscription found, create a new one
                if (!results || results.length === 0) {
                    const subscriptionResponse: SubscriptionCreateOrUpdateResponse = await client.subscription.createOrUpdate(
                        resourceGroupName,
                        apiManagementName,
                        userSubscriptionId,
                        {
                            displayName: `${emailAddress}`,
                            scope: `/products/${apiProductID}`,
                            state: 'active'
                        }
                    );
                }
                // Retrieve subscription keys for the subscription
                const secrets = await client.subscription.listSecrets(resourceGroupName, apiManagementName, userSubscriptionId);

                // Build Subscription object for response
                const subscription: Subscription = {
                    subscriptionId: userSubscriptionId,
                    subscriptionKey: secrets.primaryKey || ''
                };

                responseBody = {
                    status: 200,
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify(subscription)
                };
            }
        }
    } catch (error) {
        // Handle and log any unexpected errors
        context.log('Error processing request', error);
        errorMessage = error instanceof Error ? error.message : 'Internal Server Error';
        statusCode = 500;
        responseBody = { status: 500, body: 'Internal Server Error' };
    } finally {
        // Always log response details to Event Hub for monitoring and analytics
        const responseDetails: ResponseDetails = {
            requestDetails: requestDetails,
            statusCode: statusCode,
            responseBody: responseBody,
            errorMessage: errorMessage,
            utcDate: new Date().toISOString()
        };

        // Get Event Hub configuration from environment variables
        const connectionString = process.env.EVENT_HUB_CONNECTION_STRING || "";
        const eventHubName = process.env.EVENT_HUB_NAME || "";

        // Send response details to Event Hub for logging and monitoring
        await sendEventToEventHub(responseDetails, connectionString, eventHubName);

        return responseBody;
    }
};

app.http('createAPISubscription', {
    methods: ['POST'],
    authLevel: 'function',
    handler: createAPISubscription
});
