import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { BlobServiceClient } from "@azure/storage-blob";
import { v4 as uuidv4 } from 'uuid'; // For generating GUIDs
import { sendEventToEventHub, RequestDetails, ResponseDetails } from '../helpers/event-hub'; // Import the function to send events to Event Hub
import { readJobStatus } from "../helpers/queue-assistance";
import { EnvironmentConstants, ModeConstants, QueryStringConstants } from 'src/helpers/constant-types';
/**
 * Azure Function to get the status of a job.
 * Requires 'mode' and 'email' in the query string and 'jobId' in the URL path.
 */
export async function getJobStatus(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> {
    context.log(`Http function processed request for url "${request.url}"`);   

    // Generate a unique request ID
    const requestId = uuidv4();
    // Extract ip address from query string
    const ipAddress = request.query?.get(QueryStringConstants.IP_ADDRESS) || QueryStringConstants.IP_ADDRESS_DEFAULT;
    // Capture request details
    const requestDetails: RequestDetails = {
        requestId: requestId,
        function: 'getJobStatus', // Function name
        method: request.method, // Capture the HTTP method
        ipAddress: ipAddress, // Capture IP address
        utcDate: new Date().toISOString(), // Get the current UTC date in ISO format
        licenseLevel: "", // Capture the license level (Free or Pro)
        environment: process.env.ENVIRONMENT || EnvironmentConstants.DEVELOPMENT, // Capture the environment (development or production)
        code: "" // Capture the M Code payload
    };

    let statusCode = 200; // Default status code
    let errorMessage = ''; // Initialize error message
    let responseBody: any = {}; // Initialize response body

    // Extract required query parameters
    const mode = request.query?.get(QueryStringConstants.MODE) || QueryStringConstants.MODE_DEFAULT;
    const email = request.query?.get(QueryStringConstants.EMAIL) || QueryStringConstants.EMAIL_DEFAULT;
    // Extract jobId from the URL path (e.g., /api/getJobStatus/{jobId})
    const jobIdMatch = request.url.match(/\/getJobStatus\/([^/?]+)/i);
    const jobId = jobIdMatch ? jobIdMatch[1] : null;

    try {
    
        // Validate required parameters
        if (!mode || !email || !jobId) {
            statusCode = 400; // Bad Request
            responseBody =
            {
                status: 400,
                body: JSON.stringify({
                    error: "Missing required parameters. 'mode', 'email' (query) and 'jobId' (URL) are required."
                })
            };
        }        
        else if (mode.toLocaleLowerCase() !== ModeConstants.PRO){
            requestDetails.licenseLevel = mode.toLocaleLowerCase(); // Store the license level in request details
            statusCode = 401; // Method Not Authorized
            responseBody = { status: 401, body: 'Not Authorized' };            
        }
        else {
            // Extract email address from headers
            const emailAddress = request.query?.get(QueryStringConstants.EMAIL) || QueryStringConstants.EMAIL_DEFAULT;
            requestDetails.emailAddress = emailAddress; // Store the email address in request details

            const connectionString = process.env["AzureWebJobsStorage"] || "";
            const blobServiceClient = BlobServiceClient.fromConnectionString(connectionString);
            const resultsBlobContainerClient = blobServiceClient.getContainerClient("job-results");
            const results = await readJobStatus(resultsBlobContainerClient, jobId);

            if(results?.email !== emailAddress) { // If the email in the job status does not match the provided email
                statusCode = 401; // Method Not Authorized
                responseBody = { status: 401, body: 'Not Authorized' };                   
            }
            else{
                // Prepare the response body
                statusCode = 200; // OK
                responseBody = {
                    status: 200,
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(results)
                };
            }// end


        }
    } catch (error) {
        // Handle errors
        context.log('Error processing request', error);
        const message = error instanceof Error ? error.message : String(error);
        console.log('Error message:', message);
        errorMessage = message || 'Internal Server Error';
        statusCode = 500; // Internal Server Error
        responseBody = { status: 500, body: 'Internal Server Error' };
    } finally {
        // Log response details to Event Hub
        const responseDetails: ResponseDetails = {
            requestDetails: requestDetails,
            statusCode: statusCode, // Include the status code
            responseBody: "", // Exclude the response body for security reasons
            errorMessage: errorMessage, // Include error message if any
            utcDate: new Date().toISOString() // Get the current UTC date in ISO format
        };
        // Establish connection to Event Hub
        const connectionString = process.env.EVENT_HUB_CONNECTION_STRING || ""; // Event Hub connection string
        const eventHubName = process.env.EVENT_HUB_NAME || ""; // Event Hub name
                
        // Send response details to Event Hub
        await sendEventToEventHub(responseDetails, connectionString, eventHubName);

        return responseBody;
    }
}

app.http('getJobStatus', {
    methods: ['GET'],
    authLevel: 'function',
    route: 'getJobStatus/{jobId}', // Enables jobId in the URL
    handler: getJobStatus
});