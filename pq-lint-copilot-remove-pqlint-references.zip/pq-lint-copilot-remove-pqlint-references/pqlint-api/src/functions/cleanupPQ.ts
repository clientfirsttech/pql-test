import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { QueueClient } from "@azure/storage-queue";
import { BlobServiceClient } from "@azure/storage-blob";
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { v4 as uuidv4 } from 'uuid'; // For generating GUIDs
import { sendEventToEventHub, RequestDetails, ResponseDetails } from '../helpers/event-hub'; // Import the function to send events to Event Hub
import { QueueMessage, QueueAction, JobStatusEnum, JobStatus } from 'src/helpers/queue-types'; // Import the QueueMessage and QueueAction types
import { writeJobStatus } from '../helpers/queue-assistance'; // Import the function to write job status to blob storage
import { EnvironmentConstants, ModeConstants, QueryStringConstants } from 'src/helpers/constant-types';

export async function cleanupPQ(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> {
    context.log(`Http function processed request for url "${request.url}"`);

    const environment = process.env.ENVIRONMENT || EnvironmentConstants.DEVELOPMENT; // Environment (development or production)
    // Generate a unique request ID
    const requestId = uuidv4();
    // Extract ip address from query string
    const ipAddress = request.query?.get(QueryStringConstants.IP_ADDRESS) || QueryStringConstants.IP_ADDRESS_DEFAULT;
    // Capture request details
    const requestDetails: RequestDetails = {
        requestId: requestId,
        function: 'cleanupPQ', // Function name
        method: request.method, // Capture the HTTP method
        ipAddress: ipAddress, // Capture IP address
        utcDate: new Date().toISOString(), // Get the current UTC date in ISO format
        licenseLevel: "", // Capture the license level (Free or Pro)
        environment: environment, // Capture the environment (development or production)
        code: "" // Capture the M Code payload
    };

    let statusCode = 200; // Default status code
    let errorMessage = ''; // Initialize error message
    let responseBody: any = {}; // Initialize response body

    // Extract mode parameter from query string
    const mode = request.query?.get(QueryStringConstants.MODE) || QueryStringConstants.MODE_DEFAULT;
    requestDetails.licenseLevel = mode.toLocaleLowerCase(); // Store the license level in request details

    try {
        // Check if the HTTP method is POST
        if (request.method !== 'POST') {
            statusCode = 405; // Method Not Allowed
            responseBody = { status: 405, body: 'Method Not Allowed' };
        }
        // Check if free
        else if (mode.toLocaleLowerCase() !== ModeConstants.PRO) {
            requestDetails.licenseLevel = mode.toLocaleLowerCase(); // Store the license level in request details
            statusCode = 401; // Method Not Authorized
            responseBody = { status: 401, body: 'Not Authorized' };
        }
        else {
            // Extract email address from headers
            const emailAddress = request.query?.get(QueryStringConstants.EMAIL) || QueryStringConstants.EMAIL_DEFAULT;
            requestDetails.emailAddress = emailAddress; // Store the email address in request details

            // Extract the raw M Code from the request body
            const rawCode = await request.text();

            // If the input contains escaped characters (e.g., \" for quotes), unescape them
            const code = rawCode.replace(/\\\"/g, '"'); // Replace escaped quotes with regular quotes

            // Check if M Code is empty, undefined, or just whitespace
            if (!code || code.trim() === '') {
                statusCode = 400; // Bad Request
                responseBody = { status: 400, body: 'Bad Request: M Code payload is required' };
            } else {
                // Check if we can log the M Code
                if (environment.toLocaleLowerCase() !== EnvironmentConstants.PRODUCTION &&
                    environment.toLocaleLowerCase() !== EnvironmentConstants.PROD) {
                    requestDetails.code = code; // Store the M Code in request details
                } else if (mode.toLocaleLowerCase() === ModeConstants.FREE) {
                    requestDetails.code = code; // Store the M Code in request details
                }

                try {
                    // Parse the M Code
                    const parseCheck: ParseResult = await parsePowerQueryText(code);

                    if (parseCheck.error !== undefined && parseCheck.error !== null) {
                        statusCode = 400; // Bad Request
                        responseBody = { status: 400, body: 'Bad Request: M Code could not be parsed.' };
                    }// end if
                    else {
                        const jobId = uuidv4();

                        const connectionString = process.env["AzureWebJobsStorage"] || "";
                        const blobServiceClient = BlobServiceClient.fromConnectionString(connectionString);
                        const resultsBlobContainerClient = blobServiceClient.getContainerClient("job-results");
                        await resultsBlobContainerClient.createIfNotExists();

                        const status: JobStatus = {
                            jobId: jobId,
                            status: JobStatusEnum.Queued,
                            updatedAt: new Date().toISOString(),
                            email: emailAddress,
                            input: JSON.stringify(code),
                            error: undefined
                        };

                        writeJobStatus(resultsBlobContainerClient, status);

                        const queueClient = new QueueClient(connectionString, "job-queue");
                        await queueClient.createIfNotExists();
                        const queueMessage: QueueMessage = {
                            jobId: jobId,
                            action: QueueAction.CleanupPQ
                        };
                        await queueClient.sendMessage(Buffer.from(JSON.stringify(queueMessage)).toString("base64"));

                        // Prepare the response body
                        statusCode = 202;
                        responseBody = {
                            status: 202,
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({ jobId: jobId, message: 'Job submitted successfully. Check the status using the job ID.' })
                        };
                    }


                } catch (e) {
                    throw e
                }
            }
        }
    } catch (error) {
        // Handle errors
        context.log('Error processing request', error);
        errorMessage = error instanceof Error ? error.message : 'Internal Server Error';
        statusCode = 500; // Internal Server Error
        responseBody = { status: 500, body: 'Internal Server Error' };
    } finally {
        // Log response details to Event Hub
        const responseDetails: ResponseDetails = {
            requestDetails: requestDetails,
            statusCode: statusCode, // Include the status code
            responseBody: responseBody, // Include the response body
            errorMessage: errorMessage, // Include error message if any
            utcDate: new Date().toISOString() // Get the current UTC date in ISO format
        };
        // Establish connection to Event Hub
        const connectionString = process.env.EVENT_HUB_CONNECTION_STRING || ""; // Event Hub connection string
        const eventHubName = process.env.EVENT_HUB_NAME || ""; // Event Hub name

        // Send response details to Event Hub
        await sendEventToEventHub(responseDetails, connectionString, eventHubName);

        return responseBody;
    }
};


app.http('cleanupPQ', {
    methods: ['POST'],
    authLevel: 'function',
    handler: cleanupPQ
});