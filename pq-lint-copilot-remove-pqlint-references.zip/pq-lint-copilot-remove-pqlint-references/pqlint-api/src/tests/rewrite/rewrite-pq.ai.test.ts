import { cleanupPQ } from "../../rewrite/cleanup-pq";
import * as fs from "fs";
import * as path from "path";
import { RuleResult } from 'src/lint/rule-types';

// Define file paths for test data
const _JSON_Version1_DataFilePath = path.resolve('./test-files/rewrite/version1-rule-results.json'); // Path to lint rule results JSON

// Set global timeout for all tests in this file to 2 minutes
jest.setTimeout(120000);

describe("AI: cleanupPQ standard tests", () => {
    let endpoint = "https://example-openai-endpoint.azure.com/"; // Default endpoint for Azure OpenAI
    let apiKey = ""; // API key for Azure OpenAI
    const lintRules: RuleResult[] = JSON.parse(fs.readFileSync(_JSON_Version1_DataFilePath, 'utf-8')) as RuleResult[]; // Parse lint rules from JSON file
    const powerQueryCode = `
let
    Source = Excel.Workbook(File.Contents("C:\\data.xlsx"), null, true),
    Data = Source{[Name="Sheet1"]}[Content]
in
    Data
`; // Sample Power Query code for testing

    beforeAll(() => {
        // Load environment variables from local.settings.json
        const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
        if (fs.existsSync(localSettingsPath)) {
            const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
            Object.entries(localSettings.Values).forEach(([key, value]) => {
                process.env[key] = value as string; // Set environment variables
            });
        }

        // Assign API key and endpoint from environment variables
        apiKey = process.env.REWRITE_API_KEY ?? apiKey;
        endpoint = process.env.REWRITE_API_URL ?? endpoint;
    });

    it("should throw an error if endpoint or apiKey is missing", async () => {
        // Test case: Missing endpoint
        await expect(cleanupPQ("", apiKey, powerQueryCode)).rejects.toThrow(
            "Azure OpenAI endpoint and API key are required."
        );

        // Test case: Missing API key
        await expect(cleanupPQ(endpoint, "", powerQueryCode)).rejects.toThrow(
            "Azure OpenAI endpoint and API key are required."
        );
    });

    it("should throw an error if powerQueryCode is not provided", async () => {
        // Test case: Empty Power Query code
        await expect(cleanupPQ(endpoint, apiKey, "")).rejects.toThrow(
            "Power Query code must be provided."
        );
    });
});