import { buildRuleGroups } from '../../rewrite/fix-tmdl';
import { RuleResult, SeverityLevel } from 'src/lint/rule-types';

describe('buildRuleGroups', () => {
    it('should return empty map when no lint results provided', () => {
        const result = buildRuleGroups([]);
        expect(result.size).toBe(0);
    });

    it('should return empty map when no rules have IsActive=true', () => {
        const lintResults: RuleResult[] = [{
            ID: 'test-rule',
            Name: 'Test Rule',
            Category: 'Test',
            Description: 'Test description',
            References: [],
            Severity: SeverityLevel.Warning,
            Passed: false,
            ErrorInformation: {
                errorLocation: {
                    positionStart: { lineNumber: 10, lineCodeUnit: 0, codeUnit: 0 },
                    positionEnd: { lineNumber: 10, lineCodeUnit: 10, codeUnit: 10 }
                },
                filePath: null
            },
            AIFixInstructions: {
                Description: 'Fix description',
                IsActive: false
            }
        }];

        const result = buildRuleGroups(lintResults);
        expect(result.size).toBe(0);
    });

    it('should group multiple violations of the same rule', () => {
        const lintResults: RuleResult[] = [
            {
                ID: 'use-distinct-step-names',
                Name: 'Use Distinct Step Names',
                Category: 'Best Practice',
                Description: 'Test',
                References: [],
                Severity: SeverityLevel.Warning,
                Passed: false,
                ErrorInformation: {
                    errorLocation: {
                        positionStart: { lineNumber: 5, lineCodeUnit: 0, codeUnit: 0 },
                        positionEnd: { lineNumber: 5, lineCodeUnit: 10, codeUnit: 10 }
                    },
                    filePath: null
                },
                AIFixInstructions: {
                    Description: 'Rename steps',
                    IsActive: true
                }
            },
            {
                ID: 'use-distinct-step-names',
                Name: 'Use Distinct Step Names',
                Category: 'Best Practice',
                Description: 'Test',
                References: [],
                Severity: SeverityLevel.Warning,
                Passed: false,
                ErrorInformation: {
                    errorLocation: {
                        positionStart: { lineNumber: 10, lineCodeUnit: 0, codeUnit: 0 },
                        positionEnd: { lineNumber: 10, lineCodeUnit: 10, codeUnit: 10 }
                    },
                    filePath: null
                },
                AIFixInstructions: {
                    Description: 'Rename steps',
                    IsActive: true
                }
            }
        ];

        const result = buildRuleGroups(lintResults);
        expect(result.size).toBe(1);

        const group = result.get('use-distinct-step-names');
        expect(group).toBeDefined();
        expect(group!.lines).toEqual(['5', '10']);
        expect(group!.aiFixInstructions).toBeDefined();
        expect(group!.aiFixInstructions.Prompt).toBeDefined();
        expect(typeof group!.aiFixInstructions.Prompt).toBe('string');
        expect(group!.aiFixInstructions.IsWholeQueryFix).toBeDefined();        
        expect(typeof group!.aiFixInstructions.IsWholeQueryFix).toBe('boolean');
    });

    it('should populate Prompt property from rule definitions for use-table-format-for-source-control', () => {
        const lintResults: RuleResult[] = [{
            ID: 'use-table-format-for-source-control',
            Name: 'Use #table Instead of Binary.FromText for Hardcoded Data',
            Category: 'Best Practice',
            Description: 'Consider using #table instead of Binary.FromText because source control will work better in tracking changes with hard-coded data. Courtesy of Daryl Lynch.',
            References: [
                {
                    Description: 'Idea from Daryl Lynch',
                    Link: 'https://www.linkedin.com/in/daryl-lynch-75a08584/'
                }
            ],
            Severity: SeverityLevel.Warning,
            Passed: false,
            ErrorInformation: {
                errorLocation: {
                    positionStart: { lineNumber: 48, lineCodeUnit: 56, codeUnit: 60 },
                    positionEnd: { lineNumber: 48, lineCodeUnit: 71, codeUnit: 75 }
                },
                filePath: null
            },
            AIFixInstructions: {
                Description: '',
                IsActive: false
            }
        }];

        const result = buildRuleGroups(lintResults);
        
        // Note: This rule has IsActive=false, so it won't be included in groups
        // To test Prompt lookup, we need a rule with IsActive=true
        expect(result.size).toBe(0);
    });

    it('should populate Prompt property from rule definitions for use-table-format-for-source-control', () => {
        const lintResults: RuleResult[] = [{
            ID: 'use-table-format-for-source-control',
            Name: 'Use #table Instead of Binary.FromText for Hardcoded Data',
            Category: 'Best Practice',
            Description: 'Consider using #table instead of Binary.FromText because source control will work better in tracking changes with hard-coded data. Courtesy of Daryl Lynch.',
            References: [
                {
                    Description: 'Idea from Daryl Lynch',
                    Link: 'https://www.linkedin.com/in/daryl-lynch-75a08584/'
                }
            ],
            Severity: SeverityLevel.Warning,
            Passed: false,
            ErrorInformation: {
                errorLocation: {
                    positionStart: { lineNumber: 48, lineCodeUnit: 56, codeUnit: 60 },
                    positionEnd: { lineNumber: 48, lineCodeUnit: 71, codeUnit: 75 }
                },
                filePath: null
            },
            AIFixInstructions: {
                Description: '',
                IsActive: true
            }
        }];

        const result = buildRuleGroups(lintResults);
        
        // Note: This rule has IsActive=false, so it won't be included in groups
        // To test Prompt lookup, we need a rule with IsActive=true
        expect(result.size).toBe(1);

        const group = result.get('use-table-format-for-source-control');
        expect(group).toBeDefined();
        expect(group!.lines).toEqual(['48']);
        expect(group!.aiFixInstructions).toBeDefined();
        expect(group!.aiFixInstructions.Prompt).toBeDefined();
        expect(typeof group!.aiFixInstructions.Prompt).toBe('string');
        expect(group!.aiFixInstructions.Prompt.length).toBeGreaterThan(0);        
    });    

    it('should populate Prompt property from rule definitions when IsActive is true', () => {
        const lintResults: RuleResult[] = [{
            ID: 'use-distinct-step-names',
            Name: 'Rename Similar Query Steps for Clarity',
            Category: 'Best Practice',
            Description: 'Rename Query Steps to Provide Better Documentation',
            References: [],
            Severity: SeverityLevel.Warning,
            Passed: false,
            ErrorInformation: {
                errorLocation: {
                    positionStart: { lineNumber: 5, lineCodeUnit: 0, codeUnit: 0 },
                    positionEnd: { lineNumber: 5, lineCodeUnit: 10, codeUnit: 10 }
                },
                filePath: null
            },
            AIFixInstructions: {
                Description: 'Automatically rename Power Query steps',
                IsActive: true
            }
        }];

        const result = buildRuleGroups(lintResults);
        expect(result.size).toBe(1);

        const group = result.get('use-distinct-step-names');
        expect(group).toBeDefined();
        expect(group!.aiFixInstructions).toBeDefined();
        expect(group!.aiFixInstructions.Prompt).toBeDefined();
        expect(typeof group!.aiFixInstructions.Prompt).toBe('string');
        expect(group!.aiFixInstructions.Prompt.length).toBeGreaterThan(0);
    });
});
