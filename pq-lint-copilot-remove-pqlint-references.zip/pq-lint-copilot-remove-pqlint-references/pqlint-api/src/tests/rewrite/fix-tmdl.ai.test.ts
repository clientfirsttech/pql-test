import { fixTMDL } from '../../rewrite/fix-tmdl';
import { RuleResult, SeverityLevel } from 'src/lint/rule-types';
import { lintTMDLCode } from 'src/lint/linter-module';
import { allPQRules } from 'src/lint/all-rules';
import { loadApiCredentials } from '../rule-testing-assistance';
import * as fs from 'fs';
import * as path from 'path';

describe('fix-tmdl', () => {
    const { endpoint, apiKey } = loadApiCredentials();
    
    const sampleTMDLCode = `createOrReplace

	/// Use: https://raw.githubusercontent.com/fivethirtyeight/data/master/comic-characters/marvel-wikia-data.csv
	expression WebURL = "https://raw.githubusercontent.com/fivethirtyeight/data/master/comic-characters/marvel-wikia-data.csv" meta [IsParameterQuery=true, Type="Any", IsParameterQueryRequired=true]
		lineageTag: 82d1cfde-eee7-4ae8-9d6e-4e2d1c4d13b5
		queryGroup: Parameters

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = Text`;

    const fixedTMDLCode = `createOrReplace

	/// Use: https://raw.githubusercontent.com/fivethirtyeight/data/master/comic-characters/marvel-wikia-data.csv
	expression WebURL = "https://raw.githubusercontent.com/fivethirtyeight/data/master/comic-characters/marvel-wikia-data.csv" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]
		lineageTag: 82d1cfde-eee7-4ae8-9d6e-4e2d1c4d13b5
		queryGroup: Parameters

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = Text`;


    afterAll(() => {
        // Force cleanup of any remaining handles
        jest.clearAllTimers();
    });

    it('should return fixed code when rules provided', async () => {
        const ruleResults: RuleResult[] = await lintTMDLCode(sampleTMDLCode, allPQRules,[],[],false);
                
        const result = await fixTMDL(endpoint, apiKey, ruleResults, sampleTMDLCode, { debug: false, stream: false });
        expect(result).toBe(fixedTMDLCode);
    }, 60000);

    it('should return original code when no lint rules provided', async () => {
        const result = await fixTMDL(endpoint, apiKey, [], sampleTMDLCode, { debug: false, stream: false });
        expect(result).toBe(sampleTMDLCode);
    }, 60000); // Add timeout    
    /*
    test('should return original code when no applicable rules', async () => {
        const mockRuleResults: RuleResult[] = [
            {
                ID: 'test-rule',
                Name: 'Test Rule',
                Category: 'Test',
                Description: 'Test description',
                Passed: false,
                References: [],
                Severity: SeverityLevel.Warning,
                ErrorInformation: {
                    errorLocation: {
                        positionStart: { codeUnit: 0, lineCodeUnit: 0, lineNumber: 1 },
                        positionEnd: { codeUnit: 0, lineCodeUnit: 0, lineNumber: 1 }
                    },
                    filePath: null
                },
                AIFixInstructions: {
                    Description: "Test fix",
                    IsActive: false // Not active
                }
            }
        ];

        const result = await fixTMDL(testEndpoint, testApiKey, mockRuleResults, sampleTMDLCode, false);
        expect(result).toBe(sampleTMDLCode);
    });

    test('should throw error when endpoint is missing', async () => {
        await expect(fixTMDL('', testApiKey, [], sampleTMDLCode, false))
            .rejects.toThrow('Azure OpenAI endpoint and API key are required.');
    });

    test('should throw error when API key is missing', async () => {
        await expect(fixTMDL(testEndpoint, '', [], sampleTMDLCode, false))
            .rejects.toThrow('Azure OpenAI endpoint and API key are required.');
    });

    test('should throw error when TMDL code is empty', async () => {
        await expect(fixTMDL(testEndpoint, testApiKey, [], '', false))
            .rejects.toThrow('Power Query code must be provided.');
    });

    test('should process active AI fix instructions', async () => {
        // Skip this test if no real API credentials are available
        if (!process.env.REWRITE_API_URL || !process.env.REWRITE_API_KEY) {
            console.log('Skipping AI integration test - no API credentials');
            return;
        }

        const mockRuleResults: RuleResult[] = [
            {
                ID: 'test-rule',
                Name: 'Test Rule',
                Category: 'Test',
                Description: 'Test description',
                Passed: false,
                References: [],
                Severity: SeverityLevel.Warning,
                ErrorInformation: {
                    errorLocation: {
                        positionStart: { codeUnit: 0, lineCodeUnit: 0, lineNumber: 3 },
                        positionEnd: { codeUnit: 0, lineCodeUnit: 0, lineNumber: 3 }
                    },
                    filePath: null
                },
                AIFixInstructions: {
                    Description: "Add comments to explain the parameter",
                    IsActive: true,
                    Prompt: "Add a descriptive comment above the WebURL parameter explaining its purpose."
                }
            }
        ];

        const result = await fixTMDL(testEndpoint, testApiKey, mockRuleResults, sampleTMDLCode, true);
        
        // The result should be different from the original (AI should have made changes)
        expect(result).toBeDefined();
        expect(result.length).toBeGreaterThan(0);
        
        // Should still be valid TMDL code starting with createOrReplace
        expect(result.trim()).toMatch(/^createOrReplace/);
    }, 30000); // 30 second timeout for AI calls

    test('should consolidate rules with same ID', async () => {
        const mockRuleResults: RuleResult[] = [
            {
                ID: 'same-rule',
                Name: 'Same Rule',
                Category: 'Test',
                Description: 'Test description',
                Passed: false,
                References: [],
                Severity: SeverityLevel.Warning,
                ErrorInformation: {
                    errorLocation: {
                        positionStart: { codeUnit: 0, lineCodeUnit: 0, lineNumber: 3 },
                        positionEnd: { codeUnit: 0, lineCodeUnit: 0, lineNumber: 3 }
                    },
                    filePath: null
                },
                AIFixInstructions: {
                    Description: "Test fix",
                    IsActive: false
                }
            },
            {
                ID: 'same-rule', // Same ID as above
                Name: 'Same Rule',
                Category: 'Test',
                Description: 'Test description',
                Passed: false,
                References: [],
                Severity: SeverityLevel.Warning,
                ErrorInformation: {
                    errorLocation: {
                        positionStart: { codeUnit: 0, lineCodeUnit: 0, lineNumber: 5 },
                        positionEnd: { codeUnit: 0, lineCodeUnit: 0, lineNumber: 5 }
                    },
                    filePath: null
                },
                AIFixInstructions: {
                    Description: "Test fix",
                    IsActive: false
                }
            }
        ];

        const result = await fixTMDL(testEndpoint, testApiKey, mockRuleResults, sampleTMDLCode, false);
        // Should return original since rules are not active
        expect(result).toBe(sampleTMDLCode);
    });*/
});
