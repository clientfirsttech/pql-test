import { buildPromptsFromRuleGroups } from '../../rewrite/fix-tmdl';
import { RuleResult, SeverityLevel } from 'src/lint/rule-types';

describe('buildPromptsFromRuleGroups', () => {
    it('should return empty array for empty rule groups map', () => {
        const ruleGroups = new Map();
        const result = buildPromptsFromRuleGroups(ruleGroups);
        expect(result).toEqual([]);
    });

    it('should format single line violation correctly', () => {
        const mockRule: RuleResult = {
            ID: 'test-rule',
            Name: 'Test Rule Name',
            Category: 'Test',
            Description: 'Test',
            References: [],
            Severity: SeverityLevel.Warning,
            Passed: false,
            ErrorInformation: {
                errorLocation: {
                    positionStart: { lineNumber: 10, lineCodeUnit: 0, codeUnit: 0 },
                    positionEnd: { lineNumber: 10, lineCodeUnit: 10, codeUnit: 10 }
                },
                filePath: null
            }
        };

        const ruleGroups = new Map([
            ['test-rule', {
                rule: mockRule,
                lines: ['42'],
                aiFixInstructions: {
                    Prompt: 'Fix this issue by doing X',
                    Description: 'Test fix',
                    IsActive: true
                }
            }]
        ]);

        const result = buildPromptsFromRuleGroups(ruleGroups);
        expect(result.length).toBe(1);
        expect(result[0]).toContain('Rule test-rule (Test Rule Name) at line 42:');
        expect(result[0]).toContain('Fix this issue by doing X');
    });

    it('should format multiple line violations correctly', () => {
        const mockRule: RuleResult = {
            ID: 'use-distinct-step-names',
            Name: 'Use Distinct Step Names',
            Category: 'Best Practice',
            Description: 'Test',
            References: [],
            Severity: SeverityLevel.Warning,
            Passed: false,
            ErrorInformation: {
                errorLocation: {
                    positionStart: { lineNumber: 10, lineCodeUnit: 0, codeUnit: 0 },
                    positionEnd: { lineNumber: 10, lineCodeUnit: 10, codeUnit: 10 }
                },
                filePath: null
            }
        };

        const ruleGroups = new Map([
            ['use-distinct-step-names', {
                rule: mockRule,
                lines: ['5', '10', '15'],
                aiFixInstructions: {
                    Prompt: 'Rename steps to be unique',
                    Description: 'Rename',
                    IsActive: true
                }
            }]
        ]);

        const result = buildPromptsFromRuleGroups(ruleGroups);
        expect(result.length).toBe(1);
        expect(result[0]).toContain('at lines 5, 10, 15:');
        expect(result[0]).toContain('Rename steps to be unique');
        console.log('Generated Prompt:', result[0]);
    });

    it('should handle missing prompt gracefully', () => {
        const mockRule: RuleResult = {
            ID: 'test-rule',
            Name: 'Test Rule',
            Category: 'Test',
            Description: 'Test',
            References: [],
            Severity: SeverityLevel.Warning,
            Passed: false,
            ErrorInformation: {
                errorLocation: {
                    positionStart: { lineNumber: 10, lineCodeUnit: 0, codeUnit: 0 },
                    positionEnd: { lineNumber: 10, lineCodeUnit: 10, codeUnit: 10 }
                },
                filePath: null
            }
        };

        const ruleGroups = new Map([
            ['test-rule', {
                rule: mockRule,
                lines: ['1'],
                aiFixInstructions: {
                    Description: 'Fix',
                    IsActive: true
                }
            }]
        ]);

        const result = buildPromptsFromRuleGroups(ruleGroups);
        expect(result.length).toBe(1);
        expect(result[0]).toContain('Rule test-rule (Test Rule) at line 1:');
        // Should have empty prompt content after the colon
    });
});
