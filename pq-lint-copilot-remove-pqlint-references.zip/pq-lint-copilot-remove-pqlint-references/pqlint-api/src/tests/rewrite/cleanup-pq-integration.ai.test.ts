import { cleanupPQ } from '../../rewrite/cleanup-pq';
import * as fs from "fs";
import * as path from "path";
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { ParseResult } from 'src/parser/pq/parse-types';
import { logDebug } from 'src/lint/rule-assistance';

// Set global timeout for all tests in this file to 2 minutes
jest.setTimeout(120000);

// Remove all contents in test-results/cleanupPQ recursively before running any tests
beforeAll(() => {
    const cleanupDir = path.resolve('./test-results/cleanupPQ');
    if (fs.existsSync(cleanupDir)) {
        fs.rmSync(cleanupDir, { recursive: true, force: true });
    }
    // Ensure the cleanupPQ directory exists after cleaning
    fs.mkdirSync(cleanupDir, { recursive: true });
    // Load environment variables from local.settings.json if it exists
    const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
    if (fs.existsSync(localSettingsPath)) {
        const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
        Object.entries(localSettings.Values).forEach(([key, value]) => {
            process.env[key] = value as string; // Set environment variables
        });
    }
});

// Utility to make a string safe for file/directory names
function safeName(name: string) {
    return name.replace(/[^a-zA-Z0-9-_]/g, "_");
}

// Individual test for version1.pq
test('cleanupPQ - Test with version1.pq', async () => {
    const endpoint = process.env.REWRITE_API_URL ?? "";
    const apiKey = process.env.REWRITE_API_KEY ?? "";

    const absPath = path.resolve(__dirname, '../../../test-files/rewrite/version1.pq');
    logDebug(`Running test: Test with version1.pq with file: ${absPath}`);
    const fileContentBefore = fs.readFileSync(absPath, 'utf-8');
    logDebug(`File content before cleanup: ${fileContentBefore}`);
    const rewrittenCode = await cleanupPQ(endpoint, apiKey, fileContentBefore, false);
    logDebug(`Rewritten code: ${rewrittenCode}`);
    
    // Validate that the returned code can be parsed without errors
    const parseCheck: ParseResult = await parsePowerQueryText(rewrittenCode);

    expect(
        parseCheck.error === undefined ||
        parseCheck.error === null ||
        (Array.isArray(parseCheck.error) && parseCheck.error.length === 0)
    ).toBe(true);
});
/*
// Individual test for protect-comments.pq with comment preservation testing
test('cleanupPQ - Test with protect-comments.pq - comments preservation', async () => {
    const endpoint = process.env.REWRITE_API_URL ?? "";
    const apiKey = process.env.REWRITE_API_KEY ?? "";

    const absPath = path.resolve(__dirname, '../../../test-files/rewrite/protect-comments.pq');
    logDebug(`Running test: Test with protect-comments.pq - comments preservation with file: ${absPath}`);
    const fileContentBefore = fs.readFileSync(absPath, 'utf-8');
    logDebug(`File content before cleanup: ${fileContentBefore}`);
    const rewrittenCode = await cleanupPQ(endpoint, apiKey, fileContentBefore, false);
    logDebug(`Rewritten code: ${rewrittenCode}`);
    
    // Validate that the returned code can be parsed without errors
    const parseCheck: ParseResult = await parsePowerQueryText(rewrittenCode);
    logDebug(`Parse check result for error: ${parseCheck.error}`);
    expect(
        parseCheck.error === undefined ||
        parseCheck.error === null ||
        (Array.isArray(parseCheck.error) && parseCheck.error.length === 0)
    ).toBe(true);

    // Additional test for comment preservation
    // Extract comments from original code using regex
    const originalComments = fileContentBefore.match(/\/\*[\s\S]*?\*\/|\/\/.*$/gm) || [];
    const rewrittenComments = rewrittenCode.match(/\/\*[\s\S]*?\*\/|\/\/.*$/gm) || [];
    
    logDebug(`Original comments found: ${originalComments}`);
    logDebug(`Rewritten comments found: ${rewrittenComments}`);
    
    // Verify that all original comments are preserved in the rewritten code
    originalComments.forEach(comment => {
        expect(rewrittenComments).toContain(comment.trim());
    });
    
    // Verify that the number of comments is preserved or increased (never decreased)
    expect(rewrittenComments.length).toBeGreaterThanOrEqual(originalComments.length);
});

// Individual test for protect-comments-2.pq with comment preservation testing
test('cleanupPQ - Test with protect-comments-2.pq - comments preservation', async () => {
    const endpoint = process.env.REWRITE_API_URL ?? "";
    const apiKey = process.env.REWRITE_API_KEY ?? "";

    const absPath = path.resolve(__dirname, '../../../test-files/rewrite/protect-comments-2.pq');
    logDebug(`Running test: Test with protect-comments-2.pq - comments preservation with file: ${absPath}`);
    const fileContentBefore = fs.readFileSync(absPath, 'utf-8');
    logDebug(`File content before cleanup: ${fileContentBefore}`);
    const rewrittenCode = await cleanupPQ(endpoint, apiKey, fileContentBefore, false);
    logDebug(`Rewritten code: ${rewrittenCode}`);
    
    // Validate that the returned code can be parsed without errors
    const parseCheck: ParseResult = await parsePowerQueryText(rewrittenCode);

    expect(
        parseCheck.error === undefined ||
        parseCheck.error === null ||
        (Array.isArray(parseCheck.error) && parseCheck.error.length === 0)
    ).toBe(true);

    // Additional test for comment preservation
    // Extract comments from original code using regex
    const originalComments = fileContentBefore.match(/\/\*[\s\S]*?\*\/|\/\/.*$/gm) || [];
    const rewrittenComments = rewrittenCode.match(/\/\*[\s\S]*?\*\/|\/\/.*$/gm) || [];
    
    logDebug(`Original comments found: ${originalComments}`);
    logDebug(`Rewritten comments found: ${rewrittenComments}`);
    
    // Verify that all original comments are preserved in the rewritten code
    originalComments.forEach(comment => {
        expect(rewrittenComments).toContain(comment.trim());
    });
    
    // Verify that the number of comments is preserved or increased (never decreased)
    expect(rewrittenComments.length).toBeGreaterThanOrEqual(originalComments.length);
});
*/
