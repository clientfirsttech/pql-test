import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useTypeWithAddColumn } from 'src/lint/pq/use-type-with-add-column';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';
import requireCommentForTableAddColumn from 'src/lint/pq/require-comment-for-table-add-column';
import useCultureForDateFunctions from 'src/lint/pq/use-culture-for-date-functions';
import { logDebug } from 'src/lint/rule-assistance';
import { allPQRules, allTMDLLevelPQRules, allTMDLSecurityLevelPQRules, allTMDLSecurityLevelRules } from 'src/lint/all-rules';
import * as fs from 'fs';
import * as path from 'path';
import useListBufferForSelectingRows from 'src/lint/pq/use-list-buffer-for-selecting-rows';

const _DateDim = `
let
    Source = MarvelSource,
    #"Removed Other Columns" = Table.SelectColumns(Source,{"FIRST APPEARANCE", "Year"}),
    #"Split Column by Delimiter" = Table.SplitColumn(#"Removed Other Columns", "FIRST APPEARANCE", Splitter.SplitTextByDelimiter("-", QuoteStyle.Csv), {"FIRST APPEARANCE.1", "FIRST APPEARANCE.2"}),
    #"Changed Type1" = Table.TransformColumnTypes(#"Split Column by Delimiter",{{"FIRST APPEARANCE.1", type text}, {"FIRST APPEARANCE.2", Int64.Type}}),
    #"Added Custom" = Table.AddColumn(#"Changed Type1", "Date", each Date.FromText([FIRST APPEARANCE.1]&" 1, "&Text.From([Year]))),
    #"Filtered Rows" = Table.SelectRows(#"Added Custom", each ([Date] <> null)),
    #"Sorted Rows" = Table.Sort(#"Filtered Rows",{{"Date", Order.Ascending}}),
    #"Removed Columns" = Table.RemoveColumns(#"Sorted Rows",{"FIRST APPEARANCE.1", "FIRST APPEARANCE.2", "Year"}),
    #"Added Custom1" = Table.AddColumn(#"Removed Columns", "EndDate", each Date.From(DateTime.LocalNow())),
    #"Filtered Rows1" = Table.SelectRows(#"Added Custom1", let earliest = List.Min(#"Added Custom1"[Date]) in each [Date] = earliest),
    #"Removed Duplicates" = Table.Distinct(#"Filtered Rows1", {"Date"}),
    #"Renamed Columns" = Table.RenameColumns(#"Removed Duplicates",{{"Date", "StartDate"}}),
    #"Added Custom2" = Table.AddColumn(#"Renamed Columns", "Dates", each {Number.From([StartDate])..Number.From([EndDate])}),
    #"Expanded Dates" = Table.ExpandListColumn(#"Added Custom2", "Dates"),
    #"Changed Type2" = Table.TransformColumnTypes(#"Expanded Dates",{{"Dates", type date}}),
    #"Filter1stMonth" = Table.SelectRows(#"Changed Type2", each Date.Day([Dates]) = 1),
    #"Removed Columns1" = Table.RemoveColumns(#"Filter1stMonth",{"StartDate", "EndDate"}),
    #"Added Index" = Table.AddIndexColumn(#"Removed Columns1", "Index", 1, 1, Int64.Type),
    #"Reordered Columns" = Table.ReorderColumns(#"Added Index",{"Index", "Dates"}),
    #"Added Custom3" = Table.AddColumn(#"Reordered Columns", "DateKey", each Date.ToText([Dates],"MMM-yyyy")),
    #"Renamed Columns1" = Table.RenameColumns(#"Added Custom3",{{"Dates", "Date"}, {"Index", "DateID"}}),
    #"Appended Query" = Table.Combine({#"Renamed Columns1", DateDimBlank}),
    #"Sorted Rows1" = Table.Sort(#"Appended Query",{{"DateID", Order.Ascending}}),
    #"Replaced Value" = Table.ReplaceValue(#"Sorted Rows1","","Jan-0001",Replacer.ReplaceValue,{"DateKey"}),
    #"Added Custom4" = Table.AddColumn(#"Replaced Value", "MonthYearSort", each Date.Year([Date])*100 + Date.Month([Date]))
in
    #"Added Custom4"`


describe('Integration Testing', () => {

    // Test to verify all rule files in src/lint/pq included in allPQRules
    it('should have all rule files in src/lint/pq included in allPQRules array', () => {
        const rulesDirectory = path.resolve(__dirname, '../../../src/lint/pq');
        const ruleFiles = fs.readdirSync(rulesDirectory)
            .filter(file => file.endsWith('.ts') && !file.endsWith('.test.ts'))
            .filter(file => file !== 'index.ts'); // Exclude index files if any

        const ruleFileCount = ruleFiles.length;
        const allPQRulesCount = allPQRules.length;

        logDebug(`Found ${ruleFileCount} rule files in src/lint/pq directory`);
        logDebug(`Found ${allPQRulesCount} rules in allPQRules array`);
        logDebug(`Rule files: ${ruleFiles.join(', ')}`);

        expect(ruleFileCount).toBe(allPQRulesCount);
    });

    // Test to verify all TMDL rule files are included in allTMDLRules
    it('should have all rule files in src/lint/tmdl included in allTMDLRules array', () => {
        const rulesDirectory = path.resolve(__dirname, '../../../src/lint/tmdl');
        
        // Get all .ts files recursively from tmdl directory and subdirectories
        const getAllTsFiles = (dir: string): string[] => {
            const files: string[] = [];
            const entries = fs.readdirSync(dir, { withFileTypes: true });
            
            for (const entry of entries) {
                const fullPath = path.join(dir, entry.name);
                if (entry.isDirectory()) {
                    files.push(...getAllTsFiles(fullPath));
                } else if (entry.isFile() && entry.name.endsWith('.ts') && !entry.name.endsWith('.test.ts')) {
                    files.push(entry.name);
                }
            }
            return files;
        };

        const ruleFiles = getAllTsFiles(rulesDirectory)
            .filter(file => file !== 'index.ts'); // Exclude index files if any

        const ruleFileCount = ruleFiles.length;
        const allTMDLRulesCount =  allTMDLLevelPQRules.length + allTMDLSecurityLevelPQRules.length + allTMDLSecurityLevelRules.length;

        logDebug(`Found ${ruleFileCount} rule files in src/lint/tmdl directory`);
        logDebug(`Found ${allTMDLRulesCount} rules in allTMDLRules array`);
        logDebug(`Rule files: ${ruleFiles.join(', ')}`);

        expect(ruleFileCount).toBe(allTMDLRulesCount);
    });

    // Test case for Date Dimension with another rule to test line numbers
    it('should return the expected RuleResult for DateDim with another rule', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(_DateDim);
        const results: RuleResult[] = await lintMCode(parsedCode, [useTypeWithAddColumn, requireCommentForTableAddColumn,useCultureForDateFunctions, useListBufferForSelectingRows]);//,useParametersForConnectionsAndPaths]);

        expect(results.length).toBe(13);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            logDebug("ErrorObject: ", JSON.stringify(result.ErrorInformation.errorLocation.positionStart.lineNumber, null, 2));
        });

        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(7);
        expect(results[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(11);
        expect(results[2].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(15);
        expect(results[3].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(22);
        expect(results[4].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(27);     
        // requireCommentForTableAddColumn
        expect(results[5].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(7);
        expect(results[6].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(11);
        expect(results[7].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(15);
        expect(results[8].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(22);
        expect(results[9].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(27);     
        // useCultureForDateFunctions
        expect(results[10].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(7);
        expect(results[11].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(11); 
        expect(results[12].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(22);          
       
    });       
    
    // Test case for Date Dimension with another rule to test line numbers
    it('should return the expected RuleResult for DateDim with Prompts in the Rule Results', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(_DateDim);
        const results: RuleResult[] = await lintMCode(parsedCode, [useTypeWithAddColumn, requireCommentForTableAddColumn,useCultureForDateFunctions, useListBufferForSelectingRows]);//,useParametersForConnectionsAndPaths]);

        expect(results.length).toBe(13);

        const rulesWithPromptProperty: string[] = [];
        results.forEach(result => {
            if (result.AIFixInstructions && 'Prompt' in result.AIFixInstructions) {
                rulesWithPromptProperty.push(result.ID);
            }
        });// end for each
        // All rule results should now include the Prompt property
        expect(rulesWithPromptProperty.length).toBe(results.length);
    });        
    
});
