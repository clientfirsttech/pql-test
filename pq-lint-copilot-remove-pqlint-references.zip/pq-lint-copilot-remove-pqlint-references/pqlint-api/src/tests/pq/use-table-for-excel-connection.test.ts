import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useTableForExcelConnection } from 'src/lint/pq/use-table-for-excel-connection';
import * as path from 'path';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';

const _UsesTableParameter = `				
let
    Source = Excel.Workbook(File.Contents("c:\\users\\file.xlsx"), null, true),
    TestTable_Table = Source{[Item="TestTable",Kind="Table"]}[Data],
    #"Changed Type" = Table.TransformColumnTypes(TestTable_Table,{{"Column A", type text}, {"Column B", Int64.Type}})
in
    #"Changed Type"
`;

const _DoesNotUsesTableParameter = `let
        Source = Excel.Workbook(File.Contents("c:\\users\\file.xlsx"), null, true),
        Sheet1_Sheet = Source{[Item="Sheet1",Kind="Sheet"]}[Data],
        #"Promoted Headers" = Table.PromoteHeaders(Sheet1_Sheet, [PromoteAllScalars=true]),
        #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Column A", type text}, {"Column B", Int64.Type}})
    in
        #"Changed Type"
`;

const _NullSecondParameter = `
// Source Files
let
    Source = Excel.Workbook(File.Contents("c:\\users\\file.xlsx"), null, true)
in
    Source
`;

const _ReferenceTable = `let
    Source = #"Source Files",
    Sheet1_Sheet = Source{[Item="Sheet1",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(Sheet1_Sheet, [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"project_name", type text}, {"project_description", type text}, {"start_date", type date}, {"end_date", type date}, {"project_manager", type text}, {"project_budget", type text}, {"project_status", type text}, {"client_name", type text}, {"client_email", type text}, {"client_phone", type text}})
in
    #"Changed Type"`

const _NoItemKind = `
let
    Source = Excel.Workbook(File.Contents("c:\\users\\file.xlsx"), null, true),
    Sheet1_Sheet = Source{[Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(Sheet1_Sheet, [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Column A", type text}, {"Column B", Int64.Type}})
in
    #"Changed Type"
`;

describe('useTableForExcelConnection Rule', () => {
    it('should return the expected RuleResult for _UsesTableParameter', async () => {
        const parsedCode = await parsePowerQueryText(_UsesTableParameter);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableForExcelConnection]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });


    it('should return the expected RuleResult for _DoesNotUsesTableParameter', async () => {
        const parsedCode = await parsePowerQueryText(_DoesNotUsesTableParameter);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableForExcelConnection]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            // Check if the error location is correct
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(2);
        });
    });


    it('should return the expected RuleResult for _NullSecondParameter', async () => {
        const parsedCode = await parsePowerQueryText(_NullSecondParameter);
        console.log(JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableForExcelConnection]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });

    it('should return the expected RuleResult for _ReferenceTable', async () => {
        const parsedCode = await parsePowerQueryText(_ReferenceTable);
        console.log(JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableForExcelConnection]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });    

    it('should return the expected RuleResult for _NoItemKind', async () => {
        const parsedCode = await parsePowerQueryText(_NoItemKind);
        console.log(JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableForExcelConnection]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            // Check if the error location is correct
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(3);
        });
    });

});