import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useNameForSalesforceData } from 'src/lint/pq/use-name-for-salesforce-data';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';

let nameUse = `let
  Source = Salesforce.Data("https://login.salesforce.com"),
  Table = Source{[Name = "00O5g00000C0v1iEAB"]}[Data]
in
  #"Table"`;

let labelUse = `let
  Source = Salesforce.Data("https://login.salesforce.com"),
  Table = Source{[Label = "Finance Report"]}[Data]
in
  #"Table"`;

describe('useNameForSalesforceData Rule', () => {
  it('should return the expected RuleResult for Name Use', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(nameUse);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNameForSalesforceData]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });

  it('should return the expected RuleResult for Label Use', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(labelUse);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNameForSalesforceData]);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(3);
    });
    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);
  });
});
