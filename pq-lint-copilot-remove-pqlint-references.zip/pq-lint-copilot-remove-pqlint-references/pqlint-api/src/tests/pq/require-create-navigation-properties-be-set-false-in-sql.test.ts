import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { requireCreateNavigationPropertiesBeSetToFalseInSQL } from 'src/lint/pq/require-create-navigation-properties-be-set-false-in-sql';
import * as path from 'path';

// requireCreateNavigationPropertiesBeSetToFalseInSQL Rule
const _require_create_navigation_properties_be_set_false_SQL_Fail_DataFilePath = path.resolve('./test-files/Files/require-create-navigation-properties-be-set-false.SemanticModel/definition/tables/SQLServer_Pull_Data_Fail.tmdl');
const _require_create_navigation_properties_be_set_false_SQL_Success_DataFilePath = path.resolve('./test-files/Files/require-create-navigation-properties-be-set-false.SemanticModel/definition/tables/SQLServer_Pull_Data_Success.tmdl');

describe('requireCreateNavigationPropertiesBeSetToFalseInSQL Rule', () => {
    it('should return the expected RuleResult for SQLServer_Include_Relationships_Fail.tmdl', async () => {
        const parsedCode = await parseHelper(_require_create_navigation_properties_be_set_false_SQL_Fail_DataFilePath);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireCreateNavigationPropertiesBeSetToFalseInSQL]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            // Check if the error location is correct
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(2);
        });        
    });    


    it('should return the expected RuleResult for SQLServer_Include_Relationships_Success.tmdl', async () => {
        const parsedCode = await parseHelper(_require_create_navigation_properties_be_set_false_SQL_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireCreateNavigationPropertiesBeSetToFalseInSQL]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });    
    
 
});