import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useReplaceNullValuesBeforeTableUnpivotOtherColumns } from 'src/lint/pq/use-replace-null-values-before-table-unpivot-other-columns';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';
import { logDebug } from 'src/lint/rule-assistance';

let unpivotPass = `let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales_WithNulls.xlsx"), null, true),
    #"FakeSales (2)_Sheet" = Source{[Item="FakeSales (2)",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(#"FakeSales (2)_Sheet", [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Removed Other Columns" = Table.SelectColumns(#"Changed Type",{"Product", "Category"}),
    #"Reordered Columns" = Table.ReorderColumns(#"Removed Other Columns",{"Category", "Product"}),
    #"Replaced Value" = Table.ReplaceValue(#"Reordered Columns",null,"|_NULL_|",Replacer.ReplaceValue,{"Product"}),
    #"Unpivoted Columns" = Table.UnpivotOtherColumns(#"Replaced Value", {"Category"}, "Attribute", "Value")
in
    #"Unpivoted Columns"`;

let unpivotPass2 = `
let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales_WithNulls.xlsx"), null, true),
    #"FakeSales (2)_Sheet" = Source{[Item="FakeSales (2)",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(#"FakeSales (2)_Sheet", [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Replaced Value" = Table.ReplaceValue(#"Changed Type",null,"Product XYZ",Replacer.ReplaceValue,{"Product"}),
    #"Reordered Columns" = Table.ReorderColumns(#"Replaced Value",{"Date", "Category", "Product", "Sales Amount", "Quantity", "Customer Region"}),
    #"Removed Other Columns" = Table.SelectColumns(#"Reordered Columns",{"Category", "Product"}),
    #"Unpivoted Columns" = Table.UnpivotOtherColumns(#"Removed Other Columns", {"Category"}, "Attribute", "Value"),
    #"Sorted Rows" = Table.Sort(#"Unpivoted Columns",{{"Value", Order.Ascending}}),
    #"Replaced Value1" = Table.ReplaceValue(#"Sorted Rows","Product XYZ",null,Replacer.ReplaceValue,{"Value"})
in
    #"Replaced Value1"
`

let unpivotPassAndFail = `let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales_WithNulls.xlsx"), null, true),
    #"FakeSales (2)_Sheet" = Source{[Item="FakeSales (2)",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(#"FakeSales (2)_Sheet", [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Reordered Columns" = Table.ReorderColumns(#"Changed Type",{"Date", "Category", "Product", "Sales Amount", "Quantity", "Customer Region"}),
    #"Removed Other Columns" = Table.SelectColumns(#"Reordered Columns",{"Category", "Product"}),
    #"Unpivoted Columns" = Table.UnpivotOtherColumns(#"Removed Other Columns", {"Category"}, "Attribute", "Value"),
    #"Sorted Rows" = Table.Sort(#"Unpivoted Columns",{{"Value", Order.Ascending}}),
    #"Replaced Value1" = Table.ReplaceValue(#"Sorted Rows",null,"Product XYZ",Replacer.ReplaceValue,{"Value"}),
    #"Unpivoted Other Columns" = Table.UnpivotOtherColumns(#"Replaced Value1", {"Value"}, "Attribute.1", "Value.1")
in
    #"Unpivoted Other Columns"`

let unpivotFail = `let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales_WithNulls.xlsx"), null, true),
    #"FakeSales (2)_Sheet" = Source{[Item="FakeSales (2)",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(#"FakeSales (2)_Sheet", [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Removed Other Columns" = Table.SelectColumns(#"Changed Type",{"Product", "Category"}),
    #"Reordered Columns" = Table.ReorderColumns(#"Removed Other Columns",{"Category", "Product"}),
    #"Unpivoted Columns" = Table.UnpivotOtherColumns(#"Reordered Columns", {"Category"}, "Attribute", "Value")
in
    #"Unpivoted Columns"`;

let unpivotFail2 = `
let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales_WithNulls.xlsx"), null, true),
    #"FakeSales (2)_Sheet" = Source{[Item="FakeSales (2)",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(#"FakeSales (2)_Sheet", [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Replaced Value" = Table.ReplaceValue(#"Changed Type","Product A","Product XYZ",Replacer.ReplaceText,{"Product"}),
    #"Reordered Columns" = Table.ReorderColumns(#"Replaced Value",{"Date", "Category", "Product", "Sales Amount", "Quantity", "Customer Region"}),
    #"Removed Other Columns" = Table.SelectColumns(#"Reordered Columns",{"Category", "Product"}),
    #"Unpivoted Columns" = Table.UnpivotOtherColumns(#"Removed Other Columns", {"Category"}, "Attribute", "Value"),
    #"Sorted Rows" = Table.Sort(#"Unpivoted Columns",{{"Value", Order.Ascending}}),
    #"Replaced Value1" = Table.ReplaceValue(#"Sorted Rows","Product XYZ",null,Replacer.ReplaceValue,{"Value"})
in
    #"Replaced Value1"
`

let unpivotFail3 = `let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales_WithNulls.xlsx"), null, true),
    #"FakeSales (2)_Sheet" = Source{[Item="FakeSales (2)",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(#"FakeSales (2)_Sheet", [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Reordered Columns" = Table.ReorderColumns(#"Changed Type",{"Date", "Category", "Product", "Sales Amount", "Quantity", "Customer Region"}),
    #"Removed Other Columns" = Table.SelectColumns(#"Reordered Columns",{"Category", "Product"}),
    #"Unpivoted Columns" = Table.UnpivotOtherColumns(#"Removed Other Columns", {"Category"}, "Attribute", "Value"),
    #"Sorted Rows" = Table.Sort(#"Unpivoted Columns",{{"Value", Order.Ascending}}),
    #"Replaced Value1" = Table.ReplaceValue(#"Sorted Rows","Product XYZ",null,Replacer.ReplaceValue,{"Value"}),
    #"Unpivoted Other Columns" = Table.UnpivotOtherColumns(#"Replaced Value1", {"Value"}, "Attribute.1", "Value.1")
in
    #"Unpivoted Other Columns"`

describe('useReplaceNullValuesBeforeTableUnpivotOtherColumns Rule', () => {
  it('should return the expected RuleResult for unpivotPass', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(unpivotPass);
    logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useReplaceNullValuesBeforeTableUnpivotOtherColumns]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });

  it('should return the expected RuleResult for unpivotPass2', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(unpivotPass2);
    logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useReplaceNullValuesBeforeTableUnpivotOtherColumns]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });  

  it('should return the expected RuleResult for unpivotPassAndFail', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(unpivotPassAndFail);
    logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useReplaceNullValuesBeforeTableUnpivotOtherColumns]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(8);
    });    
  });    

  it('should return the expected RuleResult for unpivotFail', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(unpivotFail);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useReplaceNullValuesBeforeTableUnpivotOtherColumns]);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(8);
    });
    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);
  });

  it('should return the expected RuleResult for unpivotFail2', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(unpivotFail2);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useReplaceNullValuesBeforeTableUnpivotOtherColumns]);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(10);
    });
    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);
  });  

  it('should return the expected RuleResult for unpivotFail3', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(unpivotFail3);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useReplaceNullValuesBeforeTableUnpivotOtherColumns]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(2);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
    });

    expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(8);
    expect(results[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(11);

  });    
});
