import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useNewColumnNamesForTableExpandColumn } from 'src/lint/pq/use-new-column-names-for-table-expand-column';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';


const expandTableColumnFail = `
let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales.xlsx"), null, true),
    #"FakeSales (2)_Sheet" = Source{[Item="FakeSales (2)",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(#"FakeSales (2)_Sheet", [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Merged Queries" = Table.NestedJoin(#"Changed Type", {"Product", "Category"}, FakeSales, {"Product", "Category"}, "FakeSales", JoinKind.LeftOuter),
    #"Expanded FakeSales" = Table.ExpandTableColumn(#"Merged Queries", "FakeSales", {"Date", "Product"}, {"FakeSales.Date", "FakeSales.Product"}),
    #"Renamed Columns" = Table.RenameColumns(#"Expanded FakeSales",{{"FakeSales.Date", "Fake Sales Data"}}),
    #"Sorted Rows" = Table.Sort(#"Renamed Columns",{{"Quantity", Order.Ascending}})
in
    #"Sorted Rows"
`

const expandTableColumnFail2 = `
let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales.xlsx"), null, true),
    #"FakeSales (2)_Sheet" = Source{[Item="FakeSales (2)",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(#"FakeSales (2)_Sheet", [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Merged Queries" = Table.NestedJoin(#"Changed Type", {"Product", "Category"}, FakeSales, {"Product", "Category"}, "FakeSales", JoinKind.LeftOuter),
    #"Expanded FakeSales" = Table.ExpandTableColumn(#"Merged Queries", "FakeSales", {"Date", "Product"}, {"FakeSales.Date", "FakeSales.Product"}),
    #"Renamed Columns" = Table.RenameColumns(#"Expanded FakeSales",{{"FakeSales.Date", "Fake Sales Data"}}),
    #"Sorted Rows" = Table.Sort(#"Renamed Columns",{{"Quantity", Order.Ascending}}),
    #"Renamed Columns1" = Table.RenameColumns(#"Sorted Rows",{{"FakeSales.Product", "Fake Sales Product"}})
in
    #"Renamed Columns1"
`
const expandTableColumnPass = `
let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales.xlsx"), null, true),
    #"FakeSales (2)_Sheet" = Source{[Item="FakeSales (2)",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(#"FakeSales (2)_Sheet", [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Merged Queries" = Table.NestedJoin(#"Changed Type", {"Product", "Category"}, FakeSales, {"Product", "Category"}, "FakeSales", JoinKind.LeftOuter),
    #"Expanded FakeSales" = Table.ExpandTableColumn(#"Merged Queries", "FakeSales", {"Date", "Product"}, {"Fake Sales Data", "FakeSales.Product"}),
    #"Sorted Rows" = Table.Sort(#"Expanded FakeSales",{{"Quantity", Order.Ascending}})
in
    #"Sorted Rows"`

const expandTableColumnPass2 = `
let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales.xlsx"), null, true),
    #"FakeSales (2)_Sheet" = Source{[Item="FakeSales (2)",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(#"FakeSales (2)_Sheet", [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Merged Queries" = Table.NestedJoin(#"Changed Type", {"Product", "Category"}, FakeSales, {"Product", "Category"}, "FakeSales", JoinKind.LeftOuter),
    #"Expanded FakeSales" = Table.ExpandTableColumn(#"Merged Queries", "FakeSales", {"Date", "Product"}, {"Fake Sales Data", "Fake Sales Product"}),
    #"Sorted Rows" = Table.Sort(#"Expanded FakeSales",{{"Quantity", Order.Ascending}})
in
    #"Sorted Rows"`


describe('useNewColumnNamesForTableExpandColumn Rule', () => {
  
  it('should return the expected RuleResult for expandColumnFail', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(expandTableColumnFail);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNewColumnNamesForTableExpandColumn]);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(9);
    });
    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);
  });

  it('should return the expected RuleResult for expandColumnFail2', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(expandTableColumnFail2);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNewColumnNamesForTableExpandColumn]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(2);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
    });

    expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(9);
    expect(results[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(11);

  });  

  it('should return the expected RuleResult for expandColumnPass', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(expandTableColumnPass);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNewColumnNamesForTableExpandColumn]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });    

  it('should return the expected RuleResult for expandColumnPass2', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(expandTableColumnPass2);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNewColumnNamesForTableExpandColumn]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });      

});
