import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { requireInspectionOfTransformForCombiningSharepointFiles } from 'src/lint/pq/require-inspection-of-transform-for-combining-sharepoint-files';
import * as path from 'path';

// requireInspectionOfTransformForCombiningSharepointFiles.test
const _SharePoint_Combine_Content_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/ManipulatingFilesLinter.SemanticModel/definition/tables/Combine_Content_Fail.tmdl');
const _SharePoint_Combine_Content_Success_DataFilePath = path.resolve('./test-files/test_tmdl/ManipulatingFilesLinter.SemanticModel/definition/tables/Combine_Content_Success.tmdl');
const _SharePoint_Combine_Content_Success_2_DataFilePath = path.resolve('./test-files/test_tmdl/ManipulatingFilesLinter.SemanticModel/definition/tables/Combine_Content_Success_2.tmdl');

describe('requireInspectionOfTransformForCombiningSharepointFiles.test Rule', () => {
    it('should return the expected RuleResult for Combine_Content_Success.tmdl', async () => {
        const parsedCode = await parseHelper(_SharePoint_Combine_Content_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireInspectionOfTransformForCombiningSharepointFiles]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    }); 

    it('should return the expected RuleResult for Combine_Content_Success_2.tmdl', async () => {
        const parsedCode = await parseHelper(_SharePoint_Combine_Content_Success_2_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireInspectionOfTransformForCombiningSharepointFiles]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });     

    it('should return the expected RuleResult for Combine_Content_Fail.tmdl', async () => {
        const parsedCode = await parseHelper(_SharePoint_Combine_Content_Fail_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireInspectionOfTransformForCombiningSharepointFiles]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);
    });            
});