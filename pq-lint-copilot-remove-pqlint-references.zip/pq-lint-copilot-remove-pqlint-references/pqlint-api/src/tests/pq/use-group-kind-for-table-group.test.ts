import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useGroupKindForTableGroup } from 'src/lint/pq/use-group-kind-for-table-group';
import * as path from 'path';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';

// FOURTH_ARGUMENT_FOR_TABLE_GROUP Rule
const _FOURTH_ARGUMENT_FOR_TABLE_GROUP_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Table_Group_HasArgument.tmdl');
const _NO_FOURTH_ARGUMENT_FOR_TABLE_GROUP_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Table_Group_MissingArgument.tmdl');
const _MULTIPLE_TABLE_GROUP_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Table_Group_Multiple_Missing_One.tmdl');

describe('FOURTH_ARGUMENT_FOR_TABLE_GROUP Rule', () => {
    it('should return the expected RuleResult for Table_Group_HasArgument.tmdl', async () => {
        const parsedCode = await parseHelper(_FOURTH_ARGUMENT_FOR_TABLE_GROUP_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useGroupKindForTableGroup]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    }); 

    it('should return the expected RuleResult for Table_Group_Missing_Argument.tmdl', async () => {
        const parsedCode = await parseHelper(_NO_FOURTH_ARGUMENT_FOR_TABLE_GROUP_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useGroupKindForTableGroup]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });   
    
    it('should return the expected RuleResult for Table_Group_Multiple_Missing_One.tmdl', async () => {
        const parsedCode = await parseHelper(_MULTIPLE_TABLE_GROUP_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useGroupKindForTableGroup]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });   
    
    it('should return the expected RuleResult for _SharePointFunction', async () => {
        const parsedCode = await parsePowerQueryText(_SharePointFunction);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useGroupKindForTableGroup]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);       
    });     
    
});


const _SharePointFunction = `let
  func = (Fields as table, optional FilterQuery as text) as any =>
    let
      _X = (Fields as table, Source as any, NextAPIQuery as text) as any =>
        let

          // Define internal function                           
          _GetJsonFromSharePoint = (url as text) as any =>
            let

              //Set Options and odata/json response                                     
              Options = [RelativePath = url, Headers = [Accept = "application/json;odata=verbose"]],
              RawData = Web.Contents(SharePoint_URL, Options),
              Json = Json.Document(RawData)
            in
              Json,
          // Define Next Link internal function                                     
          _GetNextLink = (jsonResults as record) as any =>
            let
              #"Converted to Table" = Record.ToTable(jsonResults),
              #"Expanded Value" = Table.ExpandRecordColumn(
                #"Converted to Table",
                "Value",
                {"__next"},
                {"Value.__next"}
              ),
              #"Removed Columns" = Table.RemoveColumns(#"Expanded Value", {"Name"})
            in
              Table.FirstValue(#"Removed Columns"),
          // Convert Table to Query String is NextAPIQuery is not supplied                                                                
          QueryString =
            if NextAPIQuery <> null and NextAPIQuery <> "" then
              NextAPIQuery
            else
              let
                #"Grouped Rows" = Table.Group(
                    Fields,
                    {},
                    {
                    {"$Select", each Text.Combine(List.Distinct([Select Parameter]), ","), type text},
                    // Take distinct items to remove duplicate secondary lookups
                    {"$Expand", each Text.Combine(List.Distinct([Expand Parameter]),","), type nullable text},
                    {"List Name", each List.Min([List Name]), type text}
                    }
                ,GroupKind.Global),
                #"Added Custom" = Table.AddColumn(
                    #"Grouped Rows",
                    "Query String",
                    each "/_api/lists/GetByTitle('"
                    & [List Name]
                    & "')/items?$select="
                    & [#"$Select"]
                    & "&$expand="
                    & [#"$Expand"]
                    & "&$top=5000"),
                QueryString = #"Added Custom"{0}[Query String],
                // Handle if Filter Query was provided                                      
                QueryString2 =
                  if FilterQuery <> null and FilterQuery <> "" then
                    QueryString & "&$filter=" & FilterQuery
                  else
                    QueryString
              in
                QueryString2,
          //With the internal functions defined, get the data                                                   
          Json = _GetJsonFromSharePoint(QueryString),
          // Convert to List                  
          Records = Json[d][results],
          // Combine results                  
          NewRecords = if Source is null then Records else List.Combine({Source, Records}),
          // Get next link, if exists                           
          NextLink = _GetNextLink(Json),
          // Build Base URL for recursive call                                    
          BaseUrlLength = Text.Length(SharePoint_URL),
          // Call Recursively if Next Link exists                                       
          Result =
            if NextLink is null then
              let

                //Get ls of internal and exteral names                                      
                LstInternalNames = Table.ToList(Table.SelectColumns(Table.SelectRows(Fields, each [#"Table Expand Argument - Internal Name"] <> null and [#"Table Expand Argument - Internal Name"] <> ""),{"Table Expand Argument - Internal Name"})),
                // Filter out null or empty expansion values
                LstDisplayNames = Table.ToList(Table.SelectColumns(Table.SelectRows(Fields, each [#"Table Expand Argument - Display Name"] <> null and [#"Table Expand Argument - Display Name"] <> ""),{"Table Expand Argument - Display Name"})),
                // Convert list of records to table                                   
                #"Converted to Table" = Table.FromList(
                  NewRecords,
                  Splitter.SplitByNothing(),
                  null,
                  null,
                  ExtraValues.Error
                ),
                // Row Count Check
                RowCount = Table.RowCount(#"Converted to Table"),
                // Check Row Count, if Zero then return just Display Names as a table, else Expand based on fields supplied.                                   
                #"Expanded Column1" = if RowCount = 0 then #table(LstDisplayNames,{}) else Table.ExpandRecordColumn(
                  #"Converted to Table",
                  "Column1",
                  LstInternalNames,
                  LstDisplayNames
                )
              in
                #"Expanded Column1"
            else
              @_X(Fields, NewRecords, Text.Range(NextLink, BaseUrlLength))
        in
          Result
    in
      _X(Fields, null, ""),
  documentation = [
    Documentation.Name = " fnGetSharePointData ",
    Documentation.Description
      = " Returns data from a SharePoint list when supplied a table of Fields produced by fnGetFields function.",
    Documentation.LongDescription
      = " Returns data from a SharePoint list when supplied a table of Fields produced by fnGetFields function.  To filter the data please provide a correctly formatted OData query in the FilterQuery parameter.",
    Documentation.Category = " SharePoint ",
    Documentation.Source = "https://github.com/kerski/power-query-sharepoint-faster-easier",
    Documentation.Version = "1",
    Documentation.Author = " John Kerski ",
    Documentation.Examples = {
      [
        Description = "  ",
        Code        = " fnGetSharePointData( #table, ""Title eq 'Example'"") ",
        Result      = " {#record, #record, #record} "
      ]
    }
  ],
  Custom = Value.ReplaceType(func, Value.ReplaceMetadata(Value.Type(func), documentation))
in
  Custom`