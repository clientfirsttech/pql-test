import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { RuleResult } from 'src/lint/rule-types';
import { useDistinctSourceNameForReferencingTable } from 'src/lint/pq/use-distinct-source-name-for-referencing-table';
import * as path from 'path';

// use-distinct-source-name-for-referencing-table
const _Source_SQL_Success_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Source_SQL_Success.tmdl');
const _Source_SQL_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Source_SQL_Fail.tmdl');
const _Source_Variable_Success_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Source_Variable_Success.tmdl');
const _Source_Variable_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Source_Variable_Fail.tmdl');
const _Rename_SQL_Success_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Rename_SQL_Success.tmdl');
const _Source_Append_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Source_Append_Fail.tmdl');

describe('useDistinctSourceNameForReferencingTable Rule', () => {
    it('should return the expected RuleResult for Source_SQL_Success.tmdl', async () => {
        const parsedCode = await parseHelper(_Source_SQL_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useDistinctSourceNameForReferencingTable]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    }); 

    it('should return the expected RuleResult for Source_SQL_Fail.tmdl', async () => {
        const parsedCode = await parseHelper(_Source_SQL_Fail_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useDistinctSourceNameForReferencingTable]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });   
    
    it('should return the expected RuleResult for Rename_SQL_Success.tmdl', async () => {
        const parsedCode = await parseHelper(_Rename_SQL_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useDistinctSourceNameForReferencingTable]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    }); 
    
    it('should return the expected RuleResult for Source_Variable_Success.tmdl', async () => {
        const parsedCode = await parseHelper(_Source_Variable_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useDistinctSourceNameForReferencingTable]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });     

    it('should return the expected RuleResult for Source_Variable_Fail.tmdl', async () => {
        const parsedCode = await parseHelper(_Source_Variable_Fail_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useDistinctSourceNameForReferencingTable]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });    
    
    it('should return the expected RuleResult for Source_Append_Fail.tmdl', async () => {
        const parsedCode = await parseHelper(_Source_Append_Fail_DataFilePath);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useDistinctSourceNameForReferencingTable]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });       
});