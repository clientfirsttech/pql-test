import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useItemAndKindForExcelConnection } from 'src/lint/pq/use-item-and-kind-for-excel-connection';
import * as path from 'path';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import * as fs from 'fs';

// useTableForExcelConnection Rule
const _no_Kind_DataFilePath = path.resolve('./test-files/Files/use-table-for-excel-connections.SemanticModel/definition/tables/No_Kind.tmdl');
const _no_Item_DataFilePath = path.resolve('./test-files/Files/use-table-for-excel-connections.SemanticModel/definition/tables/No_Item.tmdl');
const _use_Item_and_Kind_DataFilePath = path.resolve('./test-files/Files/use-table-for-excel-connections.SemanticModel/definition/tables/Use_Item_and_Kind.tmdl');

const _sharePointFilesWithItemAndKind = `					let
					    Source = SharePoint.Files(Folder, [ApiVersion = 15]),
					
					    ProcessRegionFile = (FileName as text, FolderPath as text, UnitName as text) as table =>
					
					        let
					            SourceFile = Source{[Name = FileName & ".xlsx", #"Folder Path" = FolderPath]}[Content],
					            ExtractWorkbook = Excel.Workbook(SourceFile, null, true),
					
					            FilteredRows = Table.SelectRows(ExtractWorkbook, each ([Item] = "TickMarks" and [Kind] = "Table")),
					            TargetTable = FilteredRows{0}[Data]
					        in
					            TargetTable,
					
					    TableTest = ProcessRegionFile("A","https://clientfirsttechnologies.sharepoint.com/sites/PowerQueryLint/Demo Library/","C")
					in
					    TableTest`;

describe('useTableForExcelConnection Rule', () => {
    it('should return the expected RuleResult for No_Kind.tmdl', async () => {
        const parsedCode = await parseHelper(_no_Kind_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useItemAndKindForExcelConnection]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            // Check if the error location is correct
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(3);
        }); 
    });    
    
    it('should return the expected RuleResult for No_Item.tmdl', async () => {
        const parsedCode = await parseHelper(_no_Item_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useItemAndKindForExcelConnection]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            // Check if the error location is correct
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(3);
        }); 
    }); 
    
    it('should return the expected RuleResult for Use_Item_and_Kind.tmdl', async () => {
        const parsedCode = await parseHelper(_use_Item_and_Kind_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useItemAndKindForExcelConnection]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });     

    it('should return zero results for SharePoint Files with ProcessRegionFile function', async () => {
        const parsedCode = await parsePowerQueryText(_sharePointFilesWithItemAndKind);
        //fs.writeFileSync('parsed-code-output.json', JSON.stringify(parsedCode.lexed, null, 2));
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useItemAndKindForExcelConnection]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });
 
});