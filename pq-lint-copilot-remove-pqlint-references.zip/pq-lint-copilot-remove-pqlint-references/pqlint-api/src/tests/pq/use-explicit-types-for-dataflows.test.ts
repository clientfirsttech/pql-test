import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useExplicitTypesForDataflows } from 'src/lint/pq/use-explicit-types-for-dataflows';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';

const notSetExplicitly = `
let
  Source = Excel.Workbook(Web.Contents("https://kerski-my.sharepoint.com/personal/john_kerski_net/Documents/Apps/Microsoft Power Query/Uploaded Files/FakeSales.xlsx"), null, true),
  #"Navigation 1" = Source{[Item = "FakeSales", Kind = "Sheet"]}[Data],
  #"Promoted headers" = Table.PromoteHeaders(#"Navigation 1", [PromoteAllScalars = true]),
  #"Replaced value" = Table.ReplaceValue(#"Promoted headers", "North", "North,South", Replacer.ReplaceValue, {"Customer Region"}),
  #"Added custom" = Table.AddColumn(#"Replaced value", "Custom", each Text.Split([Customer Region], ",")),
  #"Transform columns" = Table.TransformColumnTypes(#"Added custom", {{"Date", type text}, {"Product", type text}, {"Category", type text}, {"Sales Amount", type text}, {"Quantity", type text}, {"Customer Region", type text}}),
  #"Replace errors" = Table.ReplaceErrorValues(#"Transform columns", {{"Date", null}, {"Product", null}, {"Category", null}, {"Sales Amount", null}, {"Quantity", null}, {"Customer Region", null}}),
  #"Transform columns 1" = Table.TransformColumnTypes(#"Replace errors", {{"Custom", type text}}),
  #"Replace errors 1" = Table.ReplaceErrorValues(#"Transform columns 1", {{"Custom", null}})
in
  #"Replace errors 1"
`

const notSetExplicitly2 = `
let
  Source = SharePoint.Tables("https://kerski.sharepoint.com", [Implementation = "2.0", ViewMode = "All"]),
  #"Navigation 1" = Source{[Id = "2eff6ebd-398b-4fce-a646-ef6c9ff05735"]}[Items],
  #"Changed column type" = Table.TransformColumnTypes(#"Navigation 1", {{"Version", Int64.Type}}),
  #"Transform columns" = Table.TransformColumnTypes(#"Changed column type", {{"Title", type text}, {"Content Type", type text}, {"Created By", type text}, {"Modified By", type text}, {"Edit", type text}, {"Type", type text}, {"Item Child Count", type text}, {"Folder Child Count", type text}, {"Label setting", type text}, {"Retention label", type text}, {"Retention label Applied", type text}, {"Label applied by", type text}, {"Item is a Record", type text}, {"App Created By", type text}, {"App Modified By", type text}}),
  #"Replace errors" = Table.ReplaceErrorValues(#"Transform columns", {{"Title", null}, {"Content Type", null}, {"Created By", null}, {"Modified By", null}, {"Edit", null}, {"Type", null}, {"Item Child Count", null}, {"Folder Child Count", null}, {"Label setting", null}, {"Retention label", null}, {"Retention label Applied", null}, {"Label applied by", null}, {"Item is a Record", null}, {"App Created By", null}, {"App Modified By", null}})
in
  #"Replace errors"
`

const setExplicitly = `
let
  Source = SharePoint.Tables("https://kerski.sharepoint.com", [Implementation = "2.0", ViewMode = "All"]),
  #"Navigation 1" = Source{[Id = "2eff6ebd-398b-4fce-a646-ef6c9ff05735"]}[Items],
  #"Removed other columns" = Table.SelectColumns(#"Navigation 1", {"FieldsXML", "Version"})
in
  #"Removed other columns"
`

const setExplicitly2 = `
let
  Source = SharePoint.Tables("https://kerski.sharepoint.com", [Implementation = "2.0", ViewMode = "All"]),
  #"Navigation 1" = Source{[Id = "2eff6ebd-398b-4fce-a646-ef6c9ff05735"]}[Items],
  #"Removed other columns" = Table.SelectColumns(#"Navigation 1", {"FieldsXML", "Version"}),
  #"Changed column type" = Table.TransformColumnTypes(#"Removed other columns", {{"Version", Int64.Type}})
in
  #"Changed column type"
`


describe('useExplicitTypesForDataflows Rule', () => {
  it('should return the expected RuleResult for notSetExplicitly', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(notSetExplicitly);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useExplicitTypesForDataflows]);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(11);
    });
    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);
  });

  it('should return the expected RuleResult for notSetExplicitly2', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(notSetExplicitly2);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useExplicitTypesForDataflows]);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(7);
    });
    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);
  });

  it('should return the expected RuleResult for setExplicitly', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(setExplicitly);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useExplicitTypesForDataflows]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });

  it('should return the expected RuleResult for setExplicitly2', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(setExplicitly2);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useExplicitTypesForDataflows]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });
});
