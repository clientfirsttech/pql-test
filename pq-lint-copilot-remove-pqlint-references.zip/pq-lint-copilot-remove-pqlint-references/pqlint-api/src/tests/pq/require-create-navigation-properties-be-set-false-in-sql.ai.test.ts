import { requireCreateNavigationPropertiesBeSetToFalseInSQL } from 'src/lint/pq/require-create-navigation-properties-be-set-false-in-sql';
import { testAIFix } from '../rule-testing-assistance';

describe('AI: Rewrite require-create-navigation-properties-be-set-false-in-sql Rule', () => {
    it('should fix SQL Server navigation properties violations', async () => {
        await testAIFix(
            sqlServerNavigationPropertiesTest,
            requireCreateNavigationPropertiesBeSetToFalseInSQL,
            1, // Expected number of violations
            { debug: true, fileName: 'require-create-nav-props-sql' }
        );
    }, 60000);
});

const sqlServerNavigationPropertiesTest = `createOrReplace

	table SQLServer_Pull_Data_Fail
		lineageTag: d04dd095-024d-494d-b37e-04bb1cb54693

		column SaleID
			dataType: int64
			formatString: 0
			lineageTag: 33c1468c-65f8-49dd-9460-ef9ab5cd8eed
			summarizeBy: count
			sourceColumn: SaleID

			annotation SummarizationSetBy = Automatic

		column CustomerName
			dataType: string
			lineageTag: d9033a7b-51da-48d0-8b38-4227360ffd0f
			summarizeBy: none
			sourceColumn: CustomerName

			annotation SummarizationSetBy = Automatic

		column SaleDate
			dataType: dateTime
			formatString: Long Date
			lineageTag: b2a61728-65b1-42f7-892c-1874c4a70c07
			summarizeBy: none
			sourceColumn: SaleDate

			annotation SummarizationSetBy = Automatic

			annotation UnderlyingDateTimeDataType = Date

		column Amount
			dataType: double
			lineageTag: 5b0fea33-c1f7-40ea-aa02-630da0554ba0
			summarizeBy: sum
			sourceColumn: Amount

			annotation SummarizationSetBy = Automatic

			annotation PBI_FormatHint = {"isGeneralNumber":true}

		column IsProcessed
			dataType: boolean
			formatString: """TRUE"";""TRUE"";""FALSE"""
			lineageTag: 4f35f228-eb1d-4eed-9908-ab86c5fe2f1c
			summarizeBy: none
			sourceColumn: IsProcessed

			annotation SummarizationSetBy = Automatic

		partition SQLServer_Pull_Data_Fail = m
			mode: import
			source =
					let
					    Source = Sql.Databases("azure-sql-db-jk.database.windows.net"),
					    #"azure-sql-db-jk" = Source{[Name="azure-sql-db-jk"]}[Data],
					    dbo_FakeSales = #"azure-sql-db-jk"{[Schema="dbo",Item="FakeSales"]}[Data]
					in
					    dbo_FakeSales

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = Table
`;