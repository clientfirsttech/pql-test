import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useSpecificParametersForNumberRound } from 'src/lint/pq/use-specific-parameter-for-number-round';
import * as path from 'path';

// useSpecificParametersForNumberRound Rule
const _useSpecificParametersForNumberRound_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/NumberRoundDefault.tmdl');
const _NO_useSpecificParametersForNumberRound_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/NumberRoundWithRoundingMode.tmdl');
const _TWO_useSpecificParametersForNumberRound_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/NumberRoundWithRoundingModeTwoErrors.tmdl');

describe('useSpecificParametersForNumberRound Rule', () => {
    it('should return the expected RuleResult for NumberRoundDefault.tmdl', async () => {
        const parsedCode = await parseHelper(_useSpecificParametersForNumberRound_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useSpecificParametersForNumberRound]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    }); 
    
    it('should return the expected RuleResult for NumberRoundWithRoundingMode.tmdl', async () => {
        const parsedCode = await parseHelper(_NO_useSpecificParametersForNumberRound_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useSpecificParametersForNumberRound]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });
    
    it('should return the expected RuleResult for NumberRoundWithRoundingModeWithTwoErrors.tmdl', async () => {
        const parsedCode = await parseHelper(_TWO_useSpecificParametersForNumberRound_DataFilePath);   

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useSpecificParametersForNumberRound]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(2);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });    
});