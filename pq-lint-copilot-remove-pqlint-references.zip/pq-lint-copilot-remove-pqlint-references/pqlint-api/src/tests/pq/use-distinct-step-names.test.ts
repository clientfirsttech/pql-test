import { lintMCode } from 'src/lint/linter-module';
import { parseHelper, loadApiCredentials, testAIFix } from '../rule-testing-assistance';
import { useDistinctStepNames } from 'src/lint/pq/use-distinct-step-names';
import * as path from 'path';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { logDebug } from 'src/lint/rule-assistance';
import { ParseResult } from 'src/parser/pq/parse-types';
import { fixTMDL } from '../../rewrite/fix-tmdl';
import * as fs from 'fs';
import { log } from 'console';

// Test file paths for use-distinct-step-names rule
const _use_distinct_step_names_DataFilePath = path.resolve('./test-files/Files/use-distinct-step-names.SemanticModel/definition/tables/MultipleCustomColumns.tmdl');
const _use_MarvelFact_DataFilePath = path.resolve('./test-files/Files/use-distinct-step-names.SemanticModel/definition/tables/MarvelFact.tmdl');
const basicFunction = `(x) => x + 1`;

describe('use-distinct-step-names Rule', () => {
    it('should return the expected RuleResult for MultipleCustomColumns.tmdl', async () => {
        // Parse the TMDL file to extract M code
        const parsedCode = await parseHelper(_use_distinct_step_names_DataFilePath);

        // Lint the M code using the use-distinct-step-names rule
        const results = await lintMCode(parsedCode, [useDistinctStepNames]);

        // Verify 5 violations are found (duplicate step names)
        expect(results.length).toBe(5);

        // Verify each result has error location information
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    }); 

    it('should return the expected RuleResult for MarvelFact.tmdl', async () => {
        // Parse the TMDL file to extract M code
        const parsedCode = await parseHelper(_use_MarvelFact_DataFilePath);

        // Lint the M code using the use-distinct-step-names rule
        const results = await lintMCode(parsedCode, [useDistinctStepNames]);

        // Verify 8 violations are found (duplicate step names)
        expect(results.length).toBe(8);

        // Verify each result has error location information
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });           
    });

    it('should return the expected RuleResult for basic function', async () => {
        // Parse a simple function expression
        const parsedCode: ParseResult = await parsePowerQueryText(basicFunction);
        logDebug('Parsed Code:', JSON.stringify(parsedCode));

        // Lint the function using the use-distinct-step-names rule
        const results = await lintMCode(parsedCode, [useDistinctStepNames]);

        // Verify no violations are found (no duplicate step names in simple function)
        expect(results.length).toBe(0); 
    }); 

});