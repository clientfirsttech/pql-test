import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useListBufferForSelectingRows} from 'src/lint/pq/use-list-buffer-for-selecting-rows';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';

let noBufferFail = `
    let
        Source = X,
        Y = Table.SelectRows(#"Source", each List.Contains(List[List], [Item]))
    in
        Y
`;

let noBufferFail2 = `
    let
        Source = X,
        // Hello Test
        Y = Table.SelectRows(#"Source", each List.Contains(List[List2], [Item]))
    in
        Y
`

let noBufferFail3 = `let
    // Loads the MarvelSource table into the query for further processing
    #"Loaded Marvel Source" = MarvelSource,
    // Keeps only the FIRST APPEARANCE and Year columns to reduce data
    #"Kept Appearance and Year Columns" = Table.SelectColumns(#"Loaded Marvel Source",{"FIRST APPEARANCE", "Year"}),
    // Splits the FIRST APPEARANCE column into two columns using hyphen as delimiter
    #"Split First Appearance Column by Hyphen" = Table.SplitColumn(#"Kept Appearance and Year Columns", "FIRST APPEARANCE", Splitter.SplitTextByDelimiter("-", QuoteStyle.Csv), {"FIRST APPEARANCE.1", "FIRST APPEARANCE.2"}),
    // Sets appropriate types: text for part of the appearance, number for the year
    #"Changed Types for Split Columns" = Table.TransformColumnTypes(#"Split First Appearance Column by Hyphen",{{"FIRST APPEARANCE.1", type text}, {"FIRST APPEARANCE.2", Int64.Type}}),
    // Adds Date column using the split appearance and year for conversion to date
    #"Added Comic Date Column" = Table.AddColumn(#"Changed Types for Split Columns", "Date", each Date.FromText([FIRST APPEARANCE.1]&" 1, "&Text.From([Year]))),
    // Filters out any rows where the newly created Date is null
    #"Filtered out Null Dates" = Table.SelectRows(#"Added Comic Date Column", each ([Date] <> null)),
    // Sorts the table by Date in ascending order and buffers for performance
    #"Sorted Comics by Date Buffered" = Table.Buffer(Table.Sort(#"Filtered out Null Dates",{{"Date", Order.Ascending}})),
    // Removes the now unnecessary split columns and year to clean up the dataset
    #"Removed Appearance and Year Columns" = Table.RemoveColumns(#"Sorted Comics by Date Buffered",{"FIRST APPEARANCE.1", "FIRST APPEARANCE.2", "Year"}),
    // Adds a column indicating the current date as the end date for each comic
    #"Appended Current EndDate Column" = Table.AddColumn(#"Removed Appearance and Year Columns", "EndDate", each Date.From(DateTime.LocalNow())),
    // Finds the earliest date row(s) in the dataset to mark comic beginnings
    #"Kept Earliest Comic Appearance" = Table.SelectRows(#"Appended Current EndDate Column", let earliest = List.Min(#"Appended Current EndDate Column"[Date]) in each [Date] = earliest),
    // Removes duplicate entries based on the Date column from the filtered result
    #"Removed Duplicate Earliest Dates" = Table.Distinct(#"Kept Earliest Comic Appearance", {"Date"}),
    // Renames the main Date column to StartDate for clarity
    #"Renamed Date to StartDate" = Table.RenameColumns(#"Removed Duplicate Earliest Dates",{{"Date", "StartDate"}}),
    // Creates a list of dates between StartDate and EndDate for period expansion
    #"Generated List of Dates between Start and End" = Table.AddColumn(#"Renamed Date to StartDate", "Dates", each {Number.From([StartDate])..Number.From([EndDate])}),
    // Expands the Dates column so each row represents a single date within the range
    #"Expanded List of Dates" = Table.ExpandListColumn(#"Generated List of Dates between Start and End", "Dates"),
    // Converts the Dates column from numbers to actual date type for further use
    #"Converted Expanded Dates to Date Type" = Table.TransformColumnTypes(#"Expanded List of Dates",{{"Dates", type date}}),
    // Retains only rows where the Dates value is the first day of a given month
    #"Kept Only First Day of Each Month" = Table.SelectRows(#"Converted Expanded Dates to Date Type", each Date.Day([Dates]) = 1),
    // Cleans up the table by removing StartDate and EndDate columns
    #"Removed Start and EndDate Columns" = Table.RemoveColumns(#"Kept Only First Day of Each Month",{"StartDate", "EndDate"}),
    // Adds an index column starting from 1 to uniquely identify dates
    #"Added Date Index Column" = Table.AddIndexColumn(#"Removed Start and EndDate Columns", "Index", 1, 1, Int64.Type),
    // Puts the Index column first and Dates column second for readability
    #"Reordered Date and Index Columns" = Table.ReorderColumns(#"Added Date Index Column",{"Index", "Dates"}),
    // Creates a text-based DateKey column in the format MMM-yyyy for easy grouping
    #"Created Month Year Text Key Column" = Table.AddColumn(#"Reordered Date and Index Columns", "DateKey", each Date.ToText([Dates],"MMM-yyyy")),
    // Renames Dates to Date and Index to DateID for clearer column names
    #"Renamed Dates and Index Columns" = Table.RenameColumns(#"Created Month Year Text Key Column",{{"Dates", "Date"}, {"Index", "DateID"}}),
    // Appends additional blank date dimension rows into the existing table
    #"Appended Blank Date Dimension Rows" = Table.Combine({#"Renamed Dates and Index Columns", DateDimBlank}),
    // Sorts table by DateID in ascending order for sequential processing
    #"Sorted by DateID Ascending" = Table.Sort(#"Appended Blank Date Dimension Rows",{{"DateID", Order.Ascending}}),
    // Replaces any missing text in DateKey to a default value Jan-0001 for consistency
    #"Replaced Missing DateKey Values" = Table.ReplaceValue(#"Sorted by DateID Ascending","","Jan-0001",Replacer.ReplaceValue,{"DateKey"}),
    // Calculates a MonthYearSort column for easy chronological sorting
    #"Added Sort Field for MonthYear" = Table.AddColumn(#"Replaced Missing DateKey Values", "MonthYearSort", each Date.Year([Date])*100 + Date.Month([Date])),
    // Extracts the year from the Date column for reporting purposes
    #"Extracted Year from Date" = Table.AddColumn(#"Added Sort Field for MonthYear", "Year", each Date.Year([Date])),
    #"Filtered Rows" = Table.SelectRows(#"Extracted Year from Date", each List.Contains(List,[DateID])),
    // Converts Year column to number type for better calculations or joins
    #"Converted Year To Number Type" = Table.TransformColumnTypes(#"Filtered Rows",{{"Year", Int64.Type}}),
    // Adds FiscalYear column by invoking a function on each Date row
    #"Calculated Fiscal Year Column" = Table.AddColumn(#"Converted Year To Number Type", "FiscalYear", each GetFiscalYear([Date]), Int32.Type
)
in
    #"Calculated Fiscal Year Column"`

let noListRefPass = `
    let
        Source = X,
        Y = Table.SelectRows(#"Source", each List.Contains({"Item1", "Item2"}, [Item]))
    in
        Y
`

let hasBufferPass = `
    let
        Source = X,
        BufferedList = List.Buffer(Source[List]),
        Y = Table.SelectRows(#"Source", each List.Contains(BufferedList, [Item]))
    in
        Y
`;

let noFailPositive = `
    let
        Source = X,
        BufferedList = List.Buffer(Source[List]),
        Y = Table.SelectRows(#"Source", each Item = "Item1")
    in
        Y
`;

let noFailPositive2 = `let
    // Loads the MarvelSource table into the query for further processing
    #"Loaded Marvel Source" = MarvelSource,
    // Keeps only the FIRST APPEARANCE and Year columns to reduce data
    #"Kept Appearance and Year Columns" = Table.SelectColumns(#"Loaded Marvel Source",{"FIRST APPEARANCE", "Year"}),
    // Splits the FIRST APPEARANCE column into two columns using hyphen as delimiter
    #"Split First Appearance Column by Hyphen" = Table.SplitColumn(#"Kept Appearance and Year Columns", "FIRST APPEARANCE", Splitter.SplitTextByDelimiter("-", QuoteStyle.Csv), {"FIRST APPEARANCE.1", "FIRST APPEARANCE.2"}),
    // Sets appropriate types: text for part of the appearance, number for the year
    #"Changed Types for Split Columns" = Table.TransformColumnTypes(#"Split First Appearance Column by Hyphen",{{"FIRST APPEARANCE.1", type text}, {"FIRST APPEARANCE.2", Int64.Type}}),
    // Adds Date column using the split appearance and year for conversion to date
    #"Added Comic Date Column" = Table.AddColumn(#"Changed Types for Split Columns", "Date", each Date.FromText([FIRST APPEARANCE.1]&" 1, "&Text.From([Year]))),
    // Filters out any rows where the newly created Date is null
    #"Filtered out Null Dates" = Table.SelectRows(#"Added Comic Date Column", each ([Date] <> null)),
    // Sorts the table by Date in ascending order and buffers for performance
    #"Sorted Comics by Date Buffered" = Table.Buffer(Table.Sort(#"Filtered out Null Dates",{{"Date", Order.Ascending}})),
    // Removes the now unnecessary split columns and year to clean up the dataset
    #"Removed Appearance and Year Columns" = Table.RemoveColumns(#"Sorted Comics by Date Buffered",{"FIRST APPEARANCE.1", "FIRST APPEARANCE.2", "Year"}),
    // Adds a column indicating the current date as the end date for each comic
    #"Appended Current EndDate Column" = Table.AddColumn(#"Removed Appearance and Year Columns", "EndDate", each Date.From(DateTime.LocalNow())),
    // Finds the earliest date row(s) in the dataset to mark comic beginnings
    #"Kept Earliest Comic Appearance" = Table.SelectRows(#"Appended Current EndDate Column", let earliest = List.Min(#"Appended Current EndDate Column"[Date]) in each [Date] = earliest),
    // Removes duplicate entries based on the Date column from the filtered result
    #"Removed Duplicate Earliest Dates" = Table.Distinct(#"Kept Earliest Comic Appearance", {"Date"}),
    // Renames the main Date column to StartDate for clarity
    #"Renamed Date to StartDate" = Table.RenameColumns(#"Removed Duplicate Earliest Dates",{{"Date", "StartDate"}}),
    // Creates a list of dates between StartDate and EndDate for period expansion
    #"Generated List of Dates between Start and End" = Table.AddColumn(#"Renamed Date to StartDate", "Dates", each {Number.From([StartDate])..Number.From([EndDate])}),
    // Expands the Dates column so each row represents a single date within the range
    #"Expanded List of Dates" = Table.ExpandListColumn(#"Generated List of Dates between Start and End", "Dates"),
    // Converts the Dates column from numbers to actual date type for further use
    #"Converted Expanded Dates to Date Type" = Table.TransformColumnTypes(#"Expanded List of Dates",{{"Dates", type date}}),
    // Retains only rows where the Dates value is the first day of a given month
    #"Kept Only First Day of Each Month" = Table.SelectRows(#"Converted Expanded Dates to Date Type", each Date.Day([Dates]) = 1),
    // Cleans up the table by removing StartDate and EndDate columns
    #"Removed Start and EndDate Columns" = Table.RemoveColumns(#"Kept Only First Day of Each Month",{"StartDate", "EndDate"}),
    // Adds an index column starting from 1 to uniquely identify dates
    #"Added Date Index Column" = Table.AddIndexColumn(#"Removed Start and EndDate Columns", "Index", 1, 1, Int64.Type),
    // Puts the Index column first and Dates column second for readability
    #"Reordered Date and Index Columns" = Table.ReorderColumns(#"Added Date Index Column",{"Index", "Dates"}),
    // Creates a text-based DateKey column in the format MMM-yyyy for easy grouping
    #"Created Month Year Text Key Column" = Table.AddColumn(#"Reordered Date and Index Columns", "DateKey", each Date.ToText([Dates],"MMM-yyyy")),
    // Renames Dates to Date and Index to DateID for clearer column names
    #"Renamed Dates and Index Columns" = Table.RenameColumns(#"Created Month Year Text Key Column",{{"Dates", "Date"}, {"Index", "DateID"}}),
    // Appends additional blank date dimension rows into the existing table
    #"Appended Blank Date Dimension Rows" = Table.Combine({#"Renamed Dates and Index Columns", DateDimBlank}),
    // Sorts table by DateID in ascending order for sequential processing
    #"Sorted by DateID Ascending" = Table.Sort(#"Appended Blank Date Dimension Rows",{{"DateID", Order.Ascending}}),
    // Replaces any missing text in DateKey to a default value Jan-0001 for consistency
    #"Replaced Missing DateKey Values" = Table.ReplaceValue(#"Sorted by DateID Ascending","","Jan-0001",Replacer.ReplaceValue,{"DateKey"}),
    // Calculates a MonthYearSort column for easy chronological sorting
    #"Added Sort Field for MonthYear" = Table.AddColumn(#"Replaced Missing DateKey Values", "MonthYearSort", each Date.Year([Date])*100 + Date.Month([Date])),
    // Extracts the year from the Date column for reporting purposes
    #"Extracted Year from Date" = Table.AddColumn(#"Added Sort Field for MonthYear", "Year", each Date.Year([Date])),
    #"Filtered Rows" = Table.SelectRows(#"Extracted Year from Date", each [DateID] = 1),
    // Converts Year column to number type for better calculations or joins
    #"Converted Year To Number Type" = Table.TransformColumnTypes(#"Filtered Rows",{{"Year", Int64.Type}}),
    // Adds FiscalYear column by invoking a function on each Date row
    #"Calculated Fiscal Year Column" = Table.AddColumn(#"Converted Year To Number Type", "FiscalYear", each GetFiscalYear([Date]), Int32.Type
)
in
    #"Calculated Fiscal Year Column"`

describe('useListBufferForSelectingRows Rule', () => {
  it('should return the expected RuleResult for noBufferFail1', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(noBufferFail);
    //logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useListBufferForSelectingRows]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);
    expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(4);
  });   

  it('should return the expected RuleResult for noBufferFail12', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(noBufferFail2);
    //logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useListBufferForSelectingRows]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);
    expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(5);
  }); 

  it('should return the expected RuleResult for noBufferFail13', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(noBufferFail3);
    //logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useListBufferForSelectingRows]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);
    expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(54);
  });   
  
  it('should return the expected RuleResult for noListRefPass', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(noListRefPass);
    //logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useListBufferForSelectingRows]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });  

  it('should return the expected RuleResult for hasBufferPass', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(hasBufferPass);
    //logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useListBufferForSelectingRows]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });  
  
  it('should return the expected RuleResult for noFalsePositive', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(noFailPositive);
    //logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useListBufferForSelectingRows]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });    

  it('should return the expected RuleResult for noFalsePositive2', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(noFailPositive2);
    //logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useListBufferForSelectingRows]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });      
});
