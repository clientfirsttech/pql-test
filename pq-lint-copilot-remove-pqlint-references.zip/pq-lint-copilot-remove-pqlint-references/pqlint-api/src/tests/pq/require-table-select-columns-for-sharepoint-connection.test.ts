import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { requireTableSelectColumnsForSharepointConnection } from 'src/lint/pq/require-table-select-columns-for-sharepoint-connection';
import * as path from 'path';

// use-distinct-source-name-for-referencing-table
const _SharePoint_Select_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SharePoint_Select_Fail.tmdl');
const _SharePoint_Select_Fail_2_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SharePoint_Select_Fail_2.tmdl');
const _SharePoint_Select_Success_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SharePoint_Select_Success.tmdl');

describe('requireTableSelectColumnsForSharepointConnection Rule', () => {
    it('should return the expected RuleResult for SharePoint_Select_Fail.tmdl', async () => {
        const parsedCode = await parseHelper(_SharePoint_Select_Fail_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireTableSelectColumnsForSharepointConnection]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);
    }); 

    it('should return the expected RuleResult for SharePoint_Select_Fail_2.tmdl', async () => {
        const parsedCode = await parseHelper(_SharePoint_Select_Fail_2_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireTableSelectColumnsForSharepointConnection]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });     

    it('should return the expected RuleResult for SharePoint_Select_Success.tmdl', async () => {
        const parsedCode = await parseHelper(_SharePoint_Select_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireTableSelectColumnsForSharepointConnection]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });         
});