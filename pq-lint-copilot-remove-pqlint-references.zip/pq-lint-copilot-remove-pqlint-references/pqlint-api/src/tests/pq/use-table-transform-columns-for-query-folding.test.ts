import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useTableTransformColumnsForQueryFolding } from 'src/lint/pq/use-table-transform-columns-for-query-folding';
import * as path from 'path';


// use-table-transform-columns-for-query-folding
const _SQLServer_ChangeType_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SQLServer_ChangedType_Fail.tmdl');
const _SQLServer_ChangeType_Success_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SQLServer_ChangedType_Success.tmdl');
const _SQLServer_ChangeType_Success_MultiSteps_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SQLServer_ChangedType_Multisteps.tmdl');
const _SQLServer_Pull_Data_Sucess_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SQLServer_Pull_Data_Success.tmdl');
const _Dataverse_ChangeType_Success_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Dataverse_ChangedType_Success.tmdl');
const _Dataverse_ChangeType_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Dataverse_ChangedType_Fail.tmdl');
const _SQLServer_Single_ChangeType_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SQLServer_Single_ChangeType_Fail.tmdl');
const _use_distinct_step_names_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/MultipleCustomColumns.tmdl');



describe('useTableTransformColumnsForQueryFolding Rule', () => {
    it('should return the expected RuleResult for SQLServer_ChangedType_Fail.tmdl', async () => {
        const parsedCode = await parseHelper(_SQLServer_ChangeType_Fail_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableTransformColumnsForQueryFolding]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    }); 

    it('should return the expected RuleResult for SQLServer_ChangedType_Success.tmdl', async () => {
        const parsedCode = await parseHelper(_SQLServer_ChangeType_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableTransformColumnsForQueryFolding]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });    

    it('should return the expected RuleResult for SQLServer_ChangeType_Success_MultiSteps.tmdl as it has both TransformColumns and TransformColumnTypes', async () => {
        const parsedCode = await parseHelper(_SQLServer_ChangeType_Success_MultiSteps_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableTransformColumnsForQueryFolding]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });      
    
    it('should return the expected RuleResult for Dataverse_ChangeType_Success_DataFilePath.tmdl', async () => {
        const parsedCode = await parseHelper(_Dataverse_ChangeType_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableTransformColumnsForQueryFolding]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    }); 

    it('should return the expected RuleResult for Dataverse_ChangeType_Fail_DataFilePath.tmdl', async () => {
        const parsedCode = await parseHelper(_Dataverse_ChangeType_Fail_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableTransformColumnsForQueryFolding]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });

    it('should return the expected RuleResult for MultipleCustomColumns.tmdl (No False Positive)', async () => {
        const parsedCode = await parseHelper(_use_distinct_step_names_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableTransformColumnsForQueryFolding]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });  
    
    it('should return the expected RuleResult for _SQLServer_Pull_Data_Sucess_DataFilePath.tmdl (No False Positive)', async () => {
        const parsedCode = await parseHelper(_SQLServer_Pull_Data_Sucess_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableTransformColumnsForQueryFolding]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });   

    
    it('should return the expected RuleResult for SQLServer_Single_ChangeType_Fail.tmdl', async () => {
        const parsedCode = await parseHelper(_SQLServer_Single_ChangeType_Fail_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableTransformColumnsForQueryFolding]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });       
    
});
