import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { consolidateSimilarTableRenames } from 'src/lint/pq/consolidate-similar-table-renames';
import * as path from 'path';

// consolidate-similar-table-renames
const _Multiple_Rename_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Multiple_Renames_Fail.tmdl');
const _Multiple_Rename_Success_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Multiple_Renames_Success.tmdl');
const _No_Renames_Success_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/No_Renames_Success.tmdl');
const _Two_Renames_Success_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Two_Renames_Success.tmdl');

describe('consolidate-similar-table-renames Rule', () => {
    it('should return the expected RuleResult for Multiple_Renames_Fail.tmdl', async () => {
        const parsedCode = await parseHelper(_Multiple_Rename_Fail_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [consolidateSimilarTableRenames]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(4);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });    

    it('should return the expected RuleResult for Multiple_Renames_Success.tmdl', async () => {
        const parsedCode = await parseHelper(_Multiple_Rename_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [consolidateSimilarTableRenames]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);        
    });      

    it('should return the expected RuleResult for No_Renames_Success.tmdl', async () => {
        const parsedCode = await parseHelper(_No_Renames_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [consolidateSimilarTableRenames]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });  
    
    it('should return the expected RuleResult for Two_Renames_Success.tmdl', async () => {
        const parsedCode = await parseHelper(_Two_Renames_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [consolidateSimilarTableRenames]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });      
});