import { lintMCode } from 'src/lint/linter-module'  // Adjust the import path according to your project structure
import { ParseResult } from 'src/parser/pq/parse-types';
import { RuleResult } from 'src/lint/rule-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { parseHelper, parseHelperForFunctions } from '../rule-testing-assistance';
import { logDebug } from 'src/lint/rule-assistance';
import * as path from 'path';
import * as fs from 'fs';
import requireCommentForTableAddColumn from 'src/lint/pq/require-comment-for-table-add-column';

// PQ_COMMENT_RULE_ADDCOLUMN
const _AddColumn_Comment_HasComment_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/AddColumn_Comment_HasComment.tmdl');
const _AddColumn_Comment_HasNoComment_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/AddColumn_Comment_HasNoComment.tmdl');
const _AddColumn_Comment_HasMultilineComment_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/AddColumn_Comment_HasMultilineComment.tmdl');
const _Multiple_Comments_DataFilePath = path.resolve('./test-files/Files/pq-comment-example.md');

describe('require-comment-for-table-add-column Rule', () => {
    it('should return the expected RuleResult for Multiple_Comments.tmdl', async () => {;
        const fileContent = fs.readFileSync(_Multiple_Comments_DataFilePath, 'utf8');
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(fileContent);
        logDebug(JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireCommentForTableAddColumn]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });

    it('should return the expected RuleResult for AddColumn_Comment_HasComment.tmdl', async () => {
        const parsedCode = await parseHelper(_AddColumn_Comment_HasComment_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireCommentForTableAddColumn]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });     
    
    it('should return the expected RuleResult for AddColumn_Comment_HasNoComment.tmdl', async () => {
        const parsedCode = await parseHelper(_AddColumn_Comment_HasNoComment_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireCommentForTableAddColumn]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    }); 
    
    it('should return the expected RuleResult for AddColumn_Comment_HasMultilineComment.tmdl', async () => {
        const parsedCode = await parseHelper(_AddColumn_Comment_HasMultilineComment_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireCommentForTableAddColumn]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });   
});