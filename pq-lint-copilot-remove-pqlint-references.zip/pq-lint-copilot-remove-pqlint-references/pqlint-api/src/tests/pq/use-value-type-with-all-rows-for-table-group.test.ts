import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useValueTypeWithAllRowsForTableGroup } from 'src/lint/pq/use-value-type-with-all-rows-for-table-group';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';

let allRowsFail = `
let
    Source = #"Functions Table",
    #"Filtered Rows" = Table.SelectRows(Source, each Text.Contains([Custom.Documentation.LongDescription], "<code>culture</code>",Comparer.OrdinalIgnoreCase)),
    #"Sorted Rows" = Table.Sort(#"Filtered Rows",{{"Custom.Documentation.Name", Order.Ascending}}),
    #"Kept First Rows" = Table.FirstN(#"Sorted Rows",10),
    #"Removed Other Columns" = Table.SelectColumns(#"Kept First Rows",{"Custom.Documentation.LongDescription", "Custom.Documentation.Name"}),
    #"Split Column by Delimiter1" = Table.ExpandListColumn(Table.TransformColumns(#"Removed Other Columns", {{"Custom.Documentation.LongDescription", Splitter.SplitTextByDelimiter("</code>", QuoteStyle.Csv), let itemType = (type nullable text) meta [Serialized.Text = true] in type {itemType}}}), "Custom.Documentation.LongDescription"),
    #"Filtered Rows1" = Table.SelectRows(#"Split Column by Delimiter1", each Text.Contains([Custom.Documentation.LongDescription], "<code>",Comparer.OrdinalIgnoreCase)),
    #"Split Column by Delimiter" = Table.SplitColumn(#"Filtered Rows1", "Custom.Documentation.LongDescription", Splitter.SplitTextByEachDelimiter({"<code>"}, QuoteStyle.Csv, false), {"Custom.Documentation.LongDescription.1", "Custom.Documentation.LongDescription.2"}),
    #"Renamed Columns" = Table.RenameColumns(#"Split Column by Delimiter",{{"Custom.Documentation.LongDescription.2", "Parameters"}}),
    #"Removed Columns" = Table.RemoveColumns(#"Renamed Columns",{"Custom.Documentation.LongDescription.1"}),
    #"Changed Type" = Table.TransformColumnTypes(#"Removed Columns",{{"Custom.Documentation.Name", type text}}),
    #"Added Custom" = Table.AddColumn(#"Changed Type", "Custom", each 1.2, Currency.Type),
    #"Grouped Rows" = Table.Group(#"Added Custom", {"Custom.Documentation.Name"}, {{"AllRows", each _, type table [Parameters=nullable text, Custom.Documentation.Name=text]}}),
    #"Expanded AllRows" = Table.ExpandTableColumn(#"Grouped Rows", "AllRows", {"Parameters", "Custom.Documentation.Name", "Custom"}, {"Parameters", "Custom.Documentation.Name.1", "Custom"})
in
    #"Expanded AllRows"
`

let allRowsFail2 = `
let
    Source = #"Functions Table",
    #"Filtered Rows" = Table.SelectRows(Source, each Text.Contains([Custom.Documentation.LongDescription], "<code>culture</code>",Comparer.OrdinalIgnoreCase)),
    #"Sorted Rows" = Table.Sort(#"Filtered Rows",{{"Custom.Documentation.Name", Order.Ascending}}),
    #"Kept First Rows" = Table.FirstN(#"Sorted Rows",10),
    #"Removed Other Columns" = Table.SelectColumns(#"Kept First Rows",{"Custom.Documentation.LongDescription", "Custom.Documentation.Name"}),
    #"Split Column by Delimiter1" = Table.ExpandListColumn(Table.TransformColumns(#"Removed Other Columns", {{"Custom.Documentation.LongDescription", Splitter.SplitTextByDelimiter("</code>", QuoteStyle.Csv), let itemType = (type nullable text) meta [Serialized.Text = true] in type {itemType}}}), "Custom.Documentation.LongDescription"),
    #"Filtered Rows1" = Table.SelectRows(#"Split Column by Delimiter1", each Text.Contains([Custom.Documentation.LongDescription], "<code>",Comparer.OrdinalIgnoreCase)),
    #"Split Column by Delimiter" = Table.SplitColumn(#"Filtered Rows1", "Custom.Documentation.LongDescription", Splitter.SplitTextByEachDelimiter({"<code>"}, QuoteStyle.Csv, false), {"Custom.Documentation.LongDescription.1", "Custom.Documentation.LongDescription.2"}),
    #"Renamed Columns" = Table.RenameColumns(#"Split Column by Delimiter",{{"Custom.Documentation.LongDescription.2", "Parameters"}}),
    #"Removed Columns" = Table.RemoveColumns(#"Renamed Columns",{"Custom.Documentation.LongDescription.1"}),
    #"Changed Type" = Table.TransformColumnTypes(#"Removed Columns",{{"Custom.Documentation.Name", type text}}),
    #"Added Custom" = Table.AddColumn(#"Changed Type", "Custom", each 1.2, Int64.Type),
    #"Grouped Rows" = Table.Group(#"Added Custom", {"Custom.Documentation.Name"}, {{"AllRows", each _, type table [Parameters=nullable text, Custom.Documentation.Name=nullable text, Custom=number]}, {"Sum", each List.Sum([Custom]), type number}}),
    #"Expanded AllRows" = Table.ExpandTableColumn(#"Grouped Rows", "AllRows", {"Parameters", "Custom.Documentation.Name", "Custom"}, {"Parameters", "Custom.Documentation.Name.1", "Custom"})
in
    #"Expanded AllRows"
`

let allRowsOnePassOneFail = `
let
    Source = #"Functions Table",
    #"Filtered Rows" = Table.SelectRows(Source, each Text.Contains([Custom.Documentation.LongDescription], "<code>culture</code>",Comparer.OrdinalIgnoreCase)),
    #"Sorted Rows" = Table.Sort(#"Filtered Rows",{{"Custom.Documentation.Name", Order.Ascending}}),
    #"Kept First Rows" = Table.FirstN(#"Sorted Rows",10),
    #"Removed Other Columns" = Table.SelectColumns(#"Kept First Rows",{"Custom.Documentation.LongDescription", "Custom.Documentation.Name"}),
    #"Split Column by Delimiter1" = Table.ExpandListColumn(Table.TransformColumns(#"Removed Other Columns", {{"Custom.Documentation.LongDescription", Splitter.SplitTextByDelimiter("</code>", QuoteStyle.Csv), let itemType = (type nullable text) meta [Serialized.Text = true] in type {itemType}}}), "Custom.Documentation.LongDescription"),
    #"Filtered Rows1" = Table.SelectRows(#"Split Column by Delimiter1", each Text.Contains([Custom.Documentation.LongDescription], "<code>",Comparer.OrdinalIgnoreCase)),
    #"Split Column by Delimiter" = Table.SplitColumn(#"Filtered Rows1", "Custom.Documentation.LongDescription", Splitter.SplitTextByEachDelimiter({"<code>"}, QuoteStyle.Csv, false), {"Custom.Documentation.LongDescription.1", "Custom.Documentation.LongDescription.2"}),
    #"Renamed Columns" = Table.RenameColumns(#"Split Column by Delimiter",{{"Custom.Documentation.LongDescription.2", "Parameters"}}),
    #"Removed Columns" = Table.RemoveColumns(#"Renamed Columns",{"Custom.Documentation.LongDescription.1"}),
    #"Changed Type" = Table.TransformColumnTypes(#"Removed Columns",{{"Custom.Documentation.Name", type text}}),
    #"Added Custom" = Table.AddColumn(#"Changed Type", "Custom", each 1.2, Int64.Type),
    #"Grouped Rows" = Table.Group(#"Added Custom", {"Custom.Documentation.Name"}, {{"AllRows", each _, type table [Parameters=nullable text, Custom.Documentation.Name=nullable text, Custom=number]}, {"Sum", each List.Sum([Custom]), type number}, {"SecondTry", each _, type table [Parameters=nullable text, Custom.Documentation.Name=nullable text, Custom=number]}}),
    #"Expanded AllRows" = Table.ExpandTableColumn(#"Grouped Rows", "AllRows", {"Parameters", "Custom.Documentation.Name", "Custom"}, {"Parameters", "Custom.Documentation.Name.1", "Custom"})
in
    #"Expanded AllRows"`

let allRowsPass = `
let
    Source = #"Functions Table",
    #"Filtered Rows" = Table.SelectRows(Source, each Text.Contains([Custom.Documentation.LongDescription], "<code>culture</code>",Comparer.OrdinalIgnoreCase)),
    #"Sorted Rows" = Table.Sort(#"Filtered Rows",{{"Custom.Documentation.Name", Order.Ascending}}),
    #"Kept First Rows" = Table.FirstN(#"Sorted Rows",10),
    #"Removed Other Columns" = Table.SelectColumns(#"Kept First Rows",{"Custom.Documentation.LongDescription", "Custom.Documentation.Name"}),
    #"Split Column by Delimiter1" = Table.ExpandListColumn(Table.TransformColumns(#"Removed Other Columns", {{"Custom.Documentation.LongDescription", Splitter.SplitTextByDelimiter("</code>", QuoteStyle.Csv), let itemType = (type nullable text) meta [Serialized.Text = true] in type {itemType}}}), "Custom.Documentation.LongDescription"),
    #"Filtered Rows1" = Table.SelectRows(#"Split Column by Delimiter1", each Text.Contains([Custom.Documentation.LongDescription], "<code>",Comparer.OrdinalIgnoreCase)),
    #"Split Column by Delimiter" = Table.SplitColumn(#"Filtered Rows1", "Custom.Documentation.LongDescription", Splitter.SplitTextByEachDelimiter({"<code>"}, QuoteStyle.Csv, false), {"Custom.Documentation.LongDescription.1", "Custom.Documentation.LongDescription.2"}),
    #"Renamed Columns" = Table.RenameColumns(#"Split Column by Delimiter",{{"Custom.Documentation.LongDescription.2", "Parameters"}}),
    #"Removed Columns" = Table.RemoveColumns(#"Renamed Columns",{"Custom.Documentation.LongDescription.1"}),
    #"Changed Type" = Table.TransformColumnTypes(#"Removed Columns",{{"Custom.Documentation.Name", type text}}),
    #"Added Custom" = Table.AddColumn(#"Changed Type", "Custom", each 1.2, Currency.Type),
    #"Grouped Rows" = Table.Group(#"Added Custom", {"Custom.Documentation.Name"}, {{"AllRows", each _, Value.Type(#"Added Custom")}}),
    #"Expanded AllRows" = Table.ExpandTableColumn(#"Grouped Rows", "AllRows", {"Parameters", "Custom.Documentation.Name", "Custom"}, {"Parameters", "Custom.Documentation.Name.1", "Custom"})
in
    #"Expanded AllRows"
`

let allRowsPass2 = `
let
    Source = #"Functions Table",
    #"Filtered Rows" = Table.SelectRows(Source, each Text.Contains([Custom.Documentation.LongDescription], "<code>culture</code>",Comparer.OrdinalIgnoreCase)),
    #"Sorted Rows" = Table.Sort(#"Filtered Rows",{{"Custom.Documentation.Name", Order.Ascending}}),
    #"Kept First Rows" = Table.FirstN(#"Sorted Rows",10),
    #"Removed Other Columns" = Table.SelectColumns(#"Kept First Rows",{"Custom.Documentation.LongDescription", "Custom.Documentation.Name"}),
    #"Split Column by Delimiter1" = Table.ExpandListColumn(Table.TransformColumns(#"Removed Other Columns", {{"Custom.Documentation.LongDescription", Splitter.SplitTextByDelimiter("</code>", QuoteStyle.Csv), let itemType = (type nullable text) meta [Serialized.Text = true] in type {itemType}}}), "Custom.Documentation.LongDescription"),
    #"Filtered Rows1" = Table.SelectRows(#"Split Column by Delimiter1", each Text.Contains([Custom.Documentation.LongDescription], "<code>",Comparer.OrdinalIgnoreCase)),
    #"Split Column by Delimiter" = Table.SplitColumn(#"Filtered Rows1", "Custom.Documentation.LongDescription", Splitter.SplitTextByEachDelimiter({"<code>"}, QuoteStyle.Csv, false), {"Custom.Documentation.LongDescription.1", "Custom.Documentation.LongDescription.2"}),
    #"Renamed Columns" = Table.RenameColumns(#"Split Column by Delimiter",{{"Custom.Documentation.LongDescription.2", "Parameters"}}),
    #"Removed Columns" = Table.RemoveColumns(#"Renamed Columns",{"Custom.Documentation.LongDescription.1"}),
    #"Changed Type" = Table.TransformColumnTypes(#"Removed Columns",{{"Custom.Documentation.Name", type text}}),
    #"Added Custom" = Table.AddColumn(#"Changed Type", "Custom", each 1.2, Int64.Type),
    #"Grouped Rows" = Table.Group(#"Added Custom", {"Custom.Documentation.Name"}, {{"AllRows", each _, Value.Type(#"Added Custom")}, {"Sum", each List.Sum([Custom]), type number}}),
    #"Expanded AllRows" = Table.ExpandTableColumn(#"Grouped Rows", "AllRows", {"Parameters", "Custom.Documentation.Name", "Custom"}, {"Parameters", "Custom.Documentation.Name.1", "Custom"})
in
    #"Expanded AllRows"
`

describe('useValueTypeWithAllRowsForTableGroup Rule', () => {
  it('should return the expected RuleResult for allRowsPass', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(allRowsPass);
    //logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useValueTypeWithAllRowsForTableGroup]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });

  it('should return the expected RuleResult for allRowsPass2', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(allRowsPass2);
    //logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useValueTypeWithAllRowsForTableGroup]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });  

  it('should return the expected RuleResult for allRowsFail', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(allRowsFail);
    //logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useValueTypeWithAllRowsForTableGroup]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
        expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
        expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      });    
  
      expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(15);    

  }); 

  it('should return the expected RuleResult for allRowsFail2', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(allRowsFail2);
    //logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useValueTypeWithAllRowsForTableGroup]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
        expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
        expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      });    
  
      expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(15);    

  }); 

  it('should return the expected RuleResult for allRowsOnePassOneFail', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(allRowsOnePassOneFail);
    //logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useValueTypeWithAllRowsForTableGroup]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
        expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
        expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      });    
  
      expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(15);    
  });     
});
