import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useTableBufferForTableSort } from 'src/lint/pq/use-table-buffer-for-table-sort';
import * as path from 'path';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';

// use-distinct-source-name-for-referencing-table
const _Sort_Check_Without_Buffer_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Sort_Check_Without_Buffer_Fail.tmdl');
const _Sort_Check_With_Buffer_Fail_2_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Sort_Check_With_Buffer_Fail_2.tmdl');
const _Sort_Check_With_Buffer_Success_2_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Sort_Check_With_Buffer_Success_2.tmdl');

describe('useTableBufferForTableSort Rule', () => {
    it('should return the expected RuleResult for Sort_Check_Without_Buffer_Fail.tmdl', async () => {
        const parsedCode = await parseHelper(_Sort_Check_Without_Buffer_Fail_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableBufferForTableSort]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    }); 

    it('should return the expected RuleResult for Sort_Check_With_Buffer_Fail_2.tmdl', async () => {
        const parsedCode = await parseHelper(_Sort_Check_With_Buffer_Fail_2_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableBufferForTableSort]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);
    }); 
    
    it('should return the expected RuleResult for Sort_Check_With_Buffer_Success_2.tmdl', async () => {
        const parsedCode = await parseHelper(_Sort_Check_With_Buffer_Success_2_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableBufferForTableSort]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });
    
    it('should return the expected RuleResult for Check False Positive', async () => {
        const parsedCode = await parsePowerQueryText(_Check_False_Positive);
        
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableBufferForTableSort]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });     
});

const _Check_False_Positive = `
let
    Source = MarvelSource,
    #"Removed Other Columns" = Table.SelectColumns(Source,{"EYE"}),
    #"Duplicated Column" = Table.DuplicateColumn(#"Removed Other Columns", "EYE", "EYE - Copy"),
    #"Removed Duplicates" = Table.Distinct(#"Duplicated Column", {"EYE"}),
    #"Renamed Columns" = Table.RenameColumns(#"Removed Duplicates",{{"EYE", "EyeKey"}}),
    #"Split Column by Delimiter" = Table.SplitColumn(#"Renamed Columns", "EYE - Copy", Splitter.SplitTextByDelimiter(" ", QuoteStyle.Csv), {"EYE - Copy.1", "EYE - Copy.2"}),
    #"Changed Type" = Table.TransformColumnTypes(#"Split Column by Delimiter",{{"EYE - Copy.1", type text}, {"EYE - Copy.2", type text}}),
    #"Removed Columns" = Table.RemoveColumns(#"Changed Type",{"EYE - Copy.2"}),
    #"Sorted Rows" = Table.Sort(#"Removed Columns",{{"EYE - Copy.1", Order.Ascending}}),
    #"Added Index" = Table.AddIndexColumn(#"Sorted Rows", "Index", 0, 1, Int64.Type),
    #"Reordered Columns" = Table.ReorderColumns(#"Added Index",{"Index", "EyeKey", "EYE - Copy.1"}),
    #"Renamed Columns1" = Table.RenameColumns(#"Reordered Columns",{{"Index", "EyeID"}, {"EYE - Copy.1", "Eye Color"}}),
    #"Replaced Value" = Table.ReplaceValue(#"Renamed Columns1","","Not Available",Replacer.ReplaceValue,{"Eye Color"})
in
    #"Replaced Value"
`