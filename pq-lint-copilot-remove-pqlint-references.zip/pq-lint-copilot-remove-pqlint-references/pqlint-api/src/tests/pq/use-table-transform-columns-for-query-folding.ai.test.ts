import { lintMCode } from 'src/lint/linter-module';
import { parseHelper, testAIFix } from '../rule-testing-assistance';
import { useTableTransformColumnsForQueryFolding } from 'src/lint/pq/use-table-transform-columns-for-query-folding';
import * as path from 'path';


// use-table-transform-columns-for-query-folding
const _SQLServer_ChangeType_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SQLServer_ChangedType_Fail.tmdl');
const _SQLServer_ChangeType_Success_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SQLServer_ChangedType_Success.tmdl');
const _SQLServer_ChangeType_Success_MultiSteps_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SQLServer_ChangedType_Multisteps.tmdl');
const _SQLServer_Pull_Data_Sucess_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SQLServer_Pull_Data_Success.tmdl');
const _Dataverse_ChangeType_Success_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Dataverse_ChangedType_Success.tmdl');
const _Dataverse_ChangeType_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Dataverse_ChangedType_Fail.tmdl');
const _SQLServer_Single_ChangeType_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SQLServer_Single_ChangeType_Fail.tmdl');
const _use_distinct_step_names_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/MultipleCustomColumns.tmdl');


describe('AI: Rewrite use-table-transform-columns-for-query-folding Rule', () => {
    it('should fix SQL Server multi-step column type violations', async () => {
        await testAIFix(
            sqlMultistepFail,
            useTableTransformColumnsForQueryFolding,
            1, // Expected number of violations
            { debug: false, fileName: 'use-table-transform-multistep-sql' }
        );
    }, 60000);

    it('should fix Dataverse column type violations', async () => {
        await testAIFix(
            dataverseFail,
            useTableTransformColumnsForQueryFolding,
            2, // Expected number of violations
            { debug: false, fileName: 'use-table-transform-dataverse' }
        );
    }, 120000);
});


const sqlMultistepFail = `createOrReplace

	table Query1
		lineageTag: 9022759c-3023-4b98-9fa4-eb32f728ac18

		column SaleID
			dataType: int64
			formatString: 0
			lineageTag: 659e9b09-f38e-4f03-8511-14c4121de70d
			summarizeBy: count
			sourceColumn: SaleID

			annotation SummarizationSetBy = Automatic

		column CustomerName
			dataType: string
			lineageTag: d9b46de0-e74b-46a9-a03b-c2e713c81455
			summarizeBy: none
			sourceColumn: CustomerName

			annotation SummarizationSetBy = Automatic

		column SaleDate
			dataType: dateTime
			formatString: General Date
			lineageTag: 640d08a4-7bfd-482c-b87a-2a890f8485b5
			summarizeBy: none
			sourceColumn: SaleDate

			annotation SummarizationSetBy = Automatic

		column Amount
			dataType: decimal
			formatString: \$#,0.###############;(\$#,0.###############);\$#,0.###############
			lineageTag: b14ac0e1-8ab3-4620-9e37-f43ac4d2dd49
			summarizeBy: sum
			sourceColumn: Amount

			annotation SummarizationSetBy = Automatic

			annotation PBI_FormatHint = {"currencyCulture":"en-US"}

		column IsProcessed
			dataType: boolean
			formatString: """TRUE"";""TRUE"";""FALSE"""
			lineageTag: f10b54b9-ae31-43a2-8e62-1f4d3677b15d
			summarizeBy: none
			sourceColumn: IsProcessed

			annotation SummarizationSetBy = Automatic

		partition Query1 = m
			mode: import
			source =
					let
					    Source = Sql.Databases("azure-sql-db-jk.database.windows.net"),
					    #"azure-sql-db-jk" = Source{[Name="azure-sql-db-jk"]}[Data],
					    dbo_FakeSales = #"azure-sql-db-jk"{[Schema="dbo",Item="FakeSales"]}[Data],
					    #"Changed Type" = Table.TransformColumnTypes(dbo_FakeSales,{{"SaleDate", type datetimezone}}),
					    #"Sorted Rows" = Table.Sort(#"Changed Type",{{"Amount", Order.Ascending}})
					in
					    #"Sorted Rows"

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = Table
`;

const dataverseFail = `createOrReplace

	table Query2
		lineageTag: 165d1aa7-3638-42d9-923d-9787106dfd41

		column canvasapprowid
			dataType: string
			lineageTag: 69a67999-c8a1-4671-b4b3-e9cad7fcfa77
			summarizeBy: none
			sourceColumn: canvasapprowid

			annotation SummarizationSetBy = Automatic

		column appversion
			dataType: string
			lineageTag: 694c4171-a288-488d-a3c0-535a13ec73aa
			summarizeBy: none
			sourceColumn: appversion

			annotation SummarizationSetBy = Automatic

		column Status
			dataType: string
			lineageTag: f85a9dbe-56f5-4e14-adc1-43c5b78bdd23
			summarizeBy: none
			sourceColumn: status

			annotation SummarizationSetBy = Automatic

		column createdbyclientversion
			dataType: string
			lineageTag: 3d773e20-fc33-48e7-a5bc-838f04a50a98
			summarizeBy: none
			sourceColumn: createdbyclientversion

			annotation SummarizationSetBy = Automatic

		column minclientversion
			dataType: string
			lineageTag: 1443bb36-bc68-4a23-8777-7c8dc1e69dd1
			summarizeBy: none
			sourceColumn: minclientversion

			annotation SummarizationSetBy = Automatic

		column tags
			dataType: string
			lineageTag: 40dc384d-1979-4544-8f3b-7709e98cc952
			summarizeBy: none
			sourceColumn: tags

			annotation SummarizationSetBy = Automatic

		column 'Created Time'
			dataType: dateTime
			formatString: General Date
			lineageTag: b293df9e-5cb9-436a-a28d-2cd80476d1b5
			summarizeBy: none
			sourceColumn: createdtime

			annotation SummarizationSetBy = Automatic

		column appopenuri
			dataType: string
			lineageTag: c3b70cd3-f87c-46d5-bdbb-fea2a02a195b
			summarizeBy: none
			sourceColumn: appopenuri

			annotation SummarizationSetBy = Automatic

		column iscdsupgraded
			dataType: boolean
			formatString: """TRUE"";""TRUE"";""FALSE"""
			lineageTag: 79c6895d-f7d2-4103-8845-594b5075c03f
			summarizeBy: none
			sourceColumn: iscdsupgraded

			annotation SummarizationSetBy = Automatic

		column 'The gallery item identifier'
			dataType: string
			lineageTag: 0adc0331-d364-4a5f-ba52-2846df408fc6
			summarizeBy: none
			sourceColumn: galleryitemid

			annotation SummarizationSetBy = Automatic

		column 'CanvasApp Name'
			dataType: string
			lineageTag: 43b8e73d-1cd9-4573-bafb-939abe071c37
			summarizeBy: none
			sourceColumn: name

			annotation SummarizationSetBy = Automatic

		column 'Last Modified By'
			dataType: string
			lineageTag: b028b16b-9104-49c5-be62-ed9078f0e870
			summarizeBy: none
			sourceColumn: aadlastmodifiedbyid

			annotation SummarizationSetBy = Automatic

		column 'Last Published By'
			dataType: string
			lineageTag: 0ff81ca7-4f43-4977-a35e-1c60c95bc322
			summarizeBy: none
			sourceColumn: aadlastpublishedbyid

			annotation SummarizationSetBy = Automatic

		column displayname
			dataType: string
			lineageTag: b27e0035-f7f3-46a4-aa40-2fea598f6ccb
			summarizeBy: none
			sourceColumn: displayname

			annotation SummarizationSetBy = Automatic

		column 'The description.'
			dataType: string
			lineageTag: a2cc3121-aa90-4f54-b51c-eeb6276cb84b
			summarizeBy: none
			sourceColumn: description

			annotation SummarizationSetBy = Automatic

		column 'The commit message.'
			dataType: string
			lineageTag: d387e430-23ab-4b63-806b-c02cfabfb934
			summarizeBy: none
			sourceColumn: commitmessage

			annotation SummarizationSetBy = Automatic

		column publisher
			dataType: string
			lineageTag: bd1cce55-96b7-4244-bc19-810f3cdf768f
			summarizeBy: none
			sourceColumn: publisher

			annotation SummarizationSetBy = Automatic

		column 'Last Modified Time'
			dataType: dateTime
			formatString: Long Date
			lineageTag: 399626f9-fffe-472a-9387-b8bb3f5005f2
			summarizeBy: none
			sourceColumn: lastmodifiedtime

			annotation SummarizationSetBy = Automatic

			annotation UnderlyingDateTimeDataType = Date

		column 'Last Publish Time'
			dataType: dateTime
			formatString: General Date
			lineageTag: 8fc5eb73-dcf6-42d5-a395-bd3aad2515dc
			summarizeBy: none
			sourceColumn: lastpublishtime

			annotation SummarizationSetBy = Automatic

		column connectionreferences
			dataType: string
			lineageTag: a53ac7cf-a310-4038-8544-dc1f9b2d2aca
			summarizeBy: none
			sourceColumn: connectionreferences

			annotation SummarizationSetBy = Automatic

		column isfeaturedapp
			dataType: boolean
			formatString: """TRUE"";""TRUE"";""FALSE"""
			lineageTag: 64d552ef-d60b-416c-8f45-72e7e3af5c6b
			summarizeBy: none
			sourceColumn: isfeaturedapp

			annotation SummarizationSetBy = Automatic

		column bypassconsent
			dataType: boolean
			formatString: """TRUE"";""TRUE"";""FALSE"""
			lineageTag: 89785737-b205-44f7-b6d0-1ea8d41cd5c0
			summarizeBy: none
			sourceColumn: bypassconsent

			annotation SummarizationSetBy = Automatic

		column admincontrolbypassconsent
			dataType: boolean
			formatString: """TRUE"";""TRUE"";""FALSE"""
			lineageTag: 0b7b9ee8-0070-4b3a-ba2b-dca639222d7f
			summarizeBy: none
			sourceColumn: admincontrolbypassconsent

			annotation SummarizationSetBy = Automatic

		column isheroapp
			dataType: boolean
			formatString: """TRUE"";""TRUE"";""FALSE"""
			lineageTag: e9f467bd-faa4-4a5a-92d0-703de8e94ed4
			summarizeBy: none
			sourceColumn: isheroapp

			annotation SummarizationSetBy = Automatic

		column ishidden
			dataType: boolean
			formatString: """TRUE"";""TRUE"";""FALSE"""
			lineageTag: 878cdb91-3a6b-444d-ac1a-b48b945c55af
			summarizeBy: none
			sourceColumn: ishidden

			annotation SummarizationSetBy = Automatic

		column canvasappid
			dataType: string
			lineageTag: 93b007e9-04f3-4434-a845-52dec9b24fac
			summarizeBy: none
			sourceColumn: canvasappid

			annotation SummarizationSetBy = Automatic

		column backgroundcolor
			dataType: string
			lineageTag: ee6bdca4-8bfd-4198-a1dc-4e5ab7e324bb
			summarizeBy: none
			sourceColumn: backgroundcolor

			annotation SummarizationSetBy = Automatic

		column Solution
			dataType: string
			lineageTag: c2a41ab1-2598-4ab9-884d-321c15b77474
			summarizeBy: none
			sourceColumn: solutionid

			annotation SummarizationSetBy = Automatic

		column componentstate
			dataType: int64
			formatString: 0
			lineageTag: 22f1120a-2c06-4462-89ad-5801775aca34
			summarizeBy: sum
			sourceColumn: componentstate

			annotation SummarizationSetBy = Automatic

		column 'Record Overwrite Time'
			dataType: dateTime
			formatString: General Date
			lineageTag: b9f2e9ff-fd59-40ac-aa59-248b15ea1149
			summarizeBy: none
			sourceColumn: overwritetime

			annotation SummarizationSetBy = Automatic

		column ismanaged
			dataType: boolean
			formatString: """TRUE"";""TRUE"";""FALSE"""
			lineageTag: 3ff1588b-4761-4bac-9499-19024c571e14
			summarizeBy: none
			sourceColumn: ismanaged

			annotation SummarizationSetBy = Automatic

		column 'Introduced Version'
			dataType: string
			lineageTag: 4d503691-4398-4681-91fa-7c050c6fe23b
			summarizeBy: none
			sourceColumn: introducedversion

			annotation SummarizationSetBy = Automatic

		column ownerid
			dataType: string
			lineageTag: dbcdd46e-3659-4374-ad11-b4a75e5155d1
			summarizeBy: none
			sourceColumn: ownerid

			annotation SummarizationSetBy = Automatic

		column owningbusinessunit
			dataType: string
			lineageTag: e4c41748-6162-43be-8f8a-b2ff34fff6dc
			summarizeBy: none
			sourceColumn: owningbusinessunit

			annotation SummarizationSetBy = Automatic

		column owningteam
			dataType: string
			lineageTag: 4a17426a-7ce8-4bdd-819b-1a5ee586704a
			summarizeBy: none
			sourceColumn: owningteam

			annotation SummarizationSetBy = Automatic

		column owninguser
			dataType: string
			lineageTag: c232db32-af20-4ba0-b233-4aad6fa94349
			summarizeBy: none
			sourceColumn: owninguser

			annotation SummarizationSetBy = Automatic

		column 'Is CDS Upgraded'
			dataType: boolean
			formatString: """TRUE"";""TRUE"";""FALSE"""
			lineageTag: 6cf84804-6b3a-4a20-8ba5-a5b6f69bc57f
			summarizeBy: none
			sourceColumn: iscdsupgradedname

			annotation SummarizationSetBy = Automatic

		column 'Is Featured App'
			dataType: string
			lineageTag: 871dc34a-b306-4835-b232-68f1c0fcb1d8
			summarizeBy: none
			sourceColumn: isfeaturedappname

			annotation SummarizationSetBy = Automatic

		column 'Bypass Consent'
			dataType: boolean
			formatString: """TRUE"";""TRUE"";""FALSE"""
			lineageTag: e5dab878-4e8c-4b36-8843-9a5c15611d6b
			summarizeBy: none
			sourceColumn: bypassconsentname

			annotation SummarizationSetBy = Automatic

		column 'Admin Control Bypass Consent'
			dataType: string
			lineageTag: 1fb3cdbd-f9e8-475e-b094-8f2a5c4236f2
			summarizeBy: none
			sourceColumn: admincontrolbypassconsentname

			annotation SummarizationSetBy = Automatic

		column 'Is Hero App'
			dataType: string
			lineageTag: 93895373-383d-4291-95fa-d8ebd65fa955
			summarizeBy: none
			sourceColumn: isheroappname

			annotation SummarizationSetBy = Automatic

		column 'Is Hidden'
			dataType: string
			lineageTag: bd7cbad4-2a96-44e4-9ab9-b7f4ab702635
			summarizeBy: none
			sourceColumn: ishiddenname

			annotation SummarizationSetBy = Automatic

		column Owner
			dataType: string
			lineageTag: 9854a34f-12de-4d33-9adc-f9034b85a63a
			summarizeBy: none
			sourceColumn: owneridname

			annotation SummarizationSetBy = Automatic

		column 'Owning Business Unit'
			dataType: string
			lineageTag: 924ab540-900d-4b99-836a-7bcc8915ab20
			summarizeBy: none
			sourceColumn: owningbusinessunitname

			annotation SummarizationSetBy = Automatic

		column 'Is Managed'
			dataType: string
			lineageTag: 1935c093-d972-4b5c-9d8f-ebf0e78f81de
			summarizeBy: none
			sourceColumn: ismanagedname

			annotation SummarizationSetBy = Automatic

		column 'Created By'
			dataType: string
			lineageTag: 8ab0df20-7ec3-4903-beba-c6ce2bea4a18
			summarizeBy: none
			sourceColumn: aadcreatedbyid

			annotation SummarizationSetBy = Automatic

		column authorizationreferences
			dataType: string
			lineageTag: 2e7703ed-e866-4d4a-ba9a-eb7f64fa0193
			summarizeBy: none
			sourceColumn: authorizationreferences

			annotation SummarizationSetBy = Automatic

		column embeddedapp
			dataType: string
			lineageTag: e6662be8-3bf1-46db-b936-db1785cf11f1
			summarizeBy: none
			sourceColumn: embeddedapp

			annotation SummarizationSetBy = Automatic

		column cdsdependencies
			dataType: string
			lineageTag: 97aea467-377f-45fa-af83-aec594bcc305
			summarizeBy: none
			sourceColumn: cdsdependencies

			annotation SummarizationSetBy = Automatic

		column databasereferences
			dataType: string
			lineageTag: 729527bf-7f26-45f8-96bd-0a5e85d71d17
			summarizeBy: none
			sourceColumn: databasereferences

			annotation SummarizationSetBy = Automatic

		column appcomponents
			dataType: string
			lineageTag: 5e4d18d0-0162-4316-a347-2b8358929c45
			summarizeBy: none
			sourceColumn: appcomponents

			annotation SummarizationSetBy = Automatic

		column appcomponentdependencies
			dataType: string
			lineageTag: f237e25e-65e0-48af-9b29-2033d22fa673
			summarizeBy: none
			sourceColumn: appcomponentdependencies

			annotation SummarizationSetBy = Automatic

		column canvasapptype
			dataType: int64
			formatString: 0
			lineageTag: 49267283-4393-4b9f-aa35-63e7dbe232d1
			summarizeBy: sum
			sourceColumn: canvasapptype

			annotation SummarizationSetBy = Automatic

		column canconsumeapppass
			dataType: boolean
			formatString: """TRUE"";""TRUE"";""FALSE"""
			lineageTag: 7bc2a8ae-b4fa-4bbf-9c56-9774375ecdf9
			summarizeBy: none
			sourceColumn: canconsumeapppass

			annotation SummarizationSetBy = Automatic

		column 'Unique CanvasApp Id'
			dataType: string
			lineageTag: 05c4d320-05d7-4686-90ad-db04df512424
			summarizeBy: none
			sourceColumn: uniquecanvasappid

			annotation SummarizationSetBy = Automatic

		partition Query2 = m
			mode: import
			source =
					let
					    Source = CommonDataService.Database("org9871aa3d.crm.dynamics.com"),
					    dbo_canvasapp = Source{[Schema="dbo",Item="canvasapp"]}[Data],
					    #"Changed Type" = Table.TransformColumnTypes(dbo_canvasapp,{{"iscdsupgradedname", type logical}}),
					    #"Sorted Rows" = Table.Sort(#"Changed Type",{{"lastmodifiedtime", Order.Ascending}}),
					    #"Changed Type1" = Table.TransformColumnTypes(#"Sorted Rows",{{"bypassconsentname", type logical}, {"lastmodifiedtime", type date}})
					in
					#"Changed Type1"

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = Table
`;