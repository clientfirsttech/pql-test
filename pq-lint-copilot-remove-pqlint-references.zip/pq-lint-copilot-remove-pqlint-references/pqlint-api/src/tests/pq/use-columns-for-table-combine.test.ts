import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useColumnsForTableCombine } from 'src/lint/pq/use-columns-for-table-combine';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';

const appendColumnFail = `
let
    Source = Table.Combine({#"FakeSales (2)", FakeSales}),
    #"Removed Other Columns" = Table.SelectColumns(Source,{"Category", "Sales Amount"}),
    #"Kept First Rows" = Table.FirstN(#"Removed Other Columns",10)
in
    #"Kept First Rows"
`

const appendColumnFail2 = `
let
    Source = Table.Combine({#"FakeSales (2)", FakeSales, #"FakeSales (3)"}),
    #"Removed Columns" = Table.RemoveColumns(Source,{"Customer.Region"})
in
    #"Removed Columns"
`

const appendColumnFail3 = `
let
    Source = Table.Combine({#"FakeSales (2)", FakeSales},{"Product","Category","Sales Amount"}),
    #"Removed Other Columns" = Table.SelectColumns(Source,{"Category", "Sales Amount"}),
    #"Kept First Rows" = Table.FirstN(#"Removed Other Columns",10)
in
    #"Kept First Rows"
`

const appendColumnPass = `
let
    Source = Table.Combine({#"FakeSales (2)", FakeSales},{"Product","Category"})
in
    Source
`

const appendColumnPass2 = `
let
    Source = Table.Combine({#"FakeSales (2)", FakeSales}),
    #"Sorted Rows" = Table.Sort(Source,{{"Date", Order.Ascending}}),
    #"Kept First Rows" = Table.FirstN(#"Sorted Rows",10),
    #"Removed Other Columns" = Table.SelectColumns(#"Kept First Rows",{"Category", "Sales Amount"})
in
    #"Removed Other Columns"
`

const appendColumnPass3 = `let
    Source = Table.Combine({#"FakeSales (2)", FakeSales},{"Category","Sales Amount"}),
    #"Kept First Rows" = Table.FirstN(Source,10)
in
    #"Kept First Rows"
`

describe('useColumnsForTableCombine Rule', () => {
  
  it('should return the expected RuleResult for appendColumnFail', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(appendColumnFail);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useColumnsForTableCombine]);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(4);
    });
    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);
  });

  it('should return the expected RuleResult for appendColumnFail2', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(appendColumnFail2);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useColumnsForTableCombine]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
    });

    expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(4);
  });  

  it('should return the expected RuleResult for appendColumnFail3', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(appendColumnFail3);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useColumnsForTableCombine]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
    });

    expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(4);
  });    

  it('should return the expected RuleResult for appendColumnPass', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(appendColumnPass);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useColumnsForTableCombine]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });  
  
  it('should return the expected RuleResult for appendColumnPass2', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(appendColumnPass2);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useColumnsForTableCombine]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });    

  it('should return the expected RuleResult for appendColumnPass3', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(appendColumnPass3);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useColumnsForTableCombine]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });    
    
});
