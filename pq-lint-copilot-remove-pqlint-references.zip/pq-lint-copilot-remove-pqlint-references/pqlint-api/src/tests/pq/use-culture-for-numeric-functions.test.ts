import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useCultureForNumericFunctions} from 'src/lint/pq/use-culture-for-numeric-functions';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';
import { logDebug } from 'src/lint/rule-assistance';

const nestedFail = `let 
// Test
#"Added Fiscal Year as date" = Table.AddColumn(Source, "Fiscal Year as Date", each #date(2000 + Number.FromText(Text.Range(Number.ToText([Fiscal_Year_C], null, "en-US"),2)),9,30), type date)
in #"Added Fiscal Year as date"
`;

const allTableCultureFail = `
let
    // Step 1: Define sample data for testing
    data = {"10.25", "20.50", "30.75", "40.00", "50.25"},
    #"Converted to Table" = Table.FromList(data, Splitter.SplitByNothing(), null, null, ExtraValues.Error),
    // Step 2: Define culture to use
    culture = "fr-FR",
    // Step 3: Apply all conversion functions to the data
    // Currency conversion (applies culture for currency formatting)
    CurrencyConverted = Table.AddColumn(#"Converted to Table", "Currency", each Currency.From(10.25)),
    // Decimal conversion
    DecimalConverted = Table.AddColumn(CurrencyConverted, "Decimal", each Decimal.From([Column1])),
    // Double conversion
    DoubleConverted = Table.AddColumn(DecimalConverted, "Double", each Double.From([Column1])),
    // Int16 conversion
    Int16Converted = Table.AddColumn(DoubleConverted, "Int16", each Int16.From([Column1])),
    // Int32 conversion
    Int32Converted = Table.AddColumn(Int16Converted, "Int32", each Int32.From([Column1])),
    // Int64 conversion
    Int64Converted = Table.AddColumn(Int32Converted, "Int64", each Int64.From([Column1])),
    // Int8 conversion
    Int8Converted = Table.AddColumn(Int64Converted, "Int8", each Int8.From([Column1])),
    // Number conversion
    NumberConverted = Table.AddColumn(Int8Converted, "Number", each Number.From([Column1])),
    // Number from Text conversion
    NumberFromTextConverted = Table.AddColumn(NumberConverted, "NumberFromText", each Number.FromText([Column1])),
    // Percentage conversion (assuming the input is in percentage format)
    PercentageConverted = Table.AddColumn(NumberFromTextConverted, "Percentage", each Percentage.From([Column1])),
    // Single conversion
    SingleConverted = Table.AddColumn(PercentageConverted, "Single", each Single.From([Column1])),
    // Convert numbers to text with culture formatting
    NumberToTextConverted = Table.AddColumn(SingleConverted, "NumberToText", each Number.ToText([Currency]))
in
    NumberToTextConverted
`

const allListCultureFail = `
let
    // Step 1: Define sample data for testing
    data = {"10.25", "20.50", "30.75", "40.00", "50.25"},
    // Step 2: Define culture to use
    culture = "fr-FR",
    // Step 3: Apply all conversion functions to the data
    
    // Currency conversion (applies culture for currency formatting)
    CurrencyConverted = List.Transform(data, each Currency.From(_)),
    // Decimal conversion
    DecimalConverted = List.Transform(data, each Decimal.From(_)),
    // Double conversion
    DoubleConverted = List.Transform(data, each Double.From(_)),
    // Int16 conversion
    Int16Converted = List.Transform(data, each Int16.From(_)),
    // Int32 conversion
    Int32Converted = List.Transform(data, each Int32.From(_)),
    // Int64 conversion
    Int64Converted = List.Transform(data, each Int64.From(_)),
    // Int8 conversion
    Int8Converted = List.Transform(data, each Int8.From(_)),
    // Number conversion
    NumberConverted = List.Transform(data, each Number.From(_)),
    // Number from Text conversion
    NumberFromTextConverted = List.Transform(data, each Number.FromText(_)),
    // Percentage conversion (assuming the input is in percentage format)
    PercentageConverted = List.Transform(data, each Percentage.From(_)),
    // Single conversion
    SingleConverted = List.Transform(data, each Single.From(_)),
    // Convert numbers to text with culture formatting
    NumberToTextConverted = List.Transform(data, each Number.ToText(_)),
    // Step 4: Create a table with all the converted values
    resultTable = Table.FromColumns({
        CurrencyConverted, 
        DecimalConverted, 
        DoubleConverted, 
        Int16Converted, 
        Int32Converted, 
        Int64Converted, 
        Int8Converted, 
        NumberConverted, 
        NumberFromTextConverted, 
        PercentageConverted, 
        SingleConverted, 
        NumberToTextConverted
    }, {"Currency", "Decimal", "Double", "Int16", "Int32", "Int64", "Int8", "Number", "NumberFromText", "Percentage", "Single", "NumberToText"}),
    // Step 5: Add a new column (e.g., sum of Int32 and Int64)
    resultWithNewColumn = Table.AddColumn(resultTable, "SumInt32AndInt64", each Number.From([Int32]))

in
    resultWithNewColumn`
const allTableCulturePass = `
let
    // Step 1: Define sample data for testing
    data = {"10.25", "20.50", "30.75", "40.00", "50.25"},
    // Step 2: Define culture to use
    culture = "fr-FR",
    #"Converted to Table" = Table.FromList(data, Splitter.SplitByNothing(), null, null, ExtraValues.Error),
    #"Changed Type" = Table.TransformColumnTypes(#"Converted to Table",{{"Column1", type number}}),
    // Step 3: Apply all conversion functions to the data with culture argument
    // Currency conversion (applies culture for currency formatting)
    CurrencyConverted = Table.AddColumn(#"Changed Type", "Currency", each Currency.From([Column1],culture)),
    // Decimal conversion
    DecimalConverted = Table.AddColumn(CurrencyConverted, "Decimal", each Decimal.From([Column1],culture)),
    // Double conversion
    DoubleConverted = Table.AddColumn(DecimalConverted, "Double", each Double.From([Column1],culture)),
    // Int16 conversion
    Int16Converted = Table.AddColumn(DoubleConverted, "Int16", each Int16.From([Column1],culture)),
    // Int32 conversion
    Int32Converted = Table.AddColumn(Int16Converted, "Int32", each Int32.From([Column1],culture)),
    // Int64 conversion
    Int64Converted = Table.AddColumn(Int32Converted, "Int64", each Int64.From([Column1],culture)),
    // Int8 conversion
    Int8Converted = Table.AddColumn(Int64Converted, "Int8", each Int8.From([Column1],culture)),
    // Number conversion
    NumberConverted = Table.AddColumn(Int8Converted, "Number", each Number.From([Column1],culture)),
    // Number from Text conversion
    NumberFromTextConverted = Table.AddColumn(NumberConverted, "NumberFromText", each Number.FromText([Column1],culture)),
    // Percentage conversion (assuming the input is in percentage format)
    PercentageConverted = Table.AddColumn(NumberFromTextConverted, "Percentage", each Percentage.From([Column1],culture)),
    // Single conversion
    SingleConverted = Table.AddColumn(PercentageConverted, "Single", each Single.From([Column1],culture)),
    // Convert numbers to text with culture formatting
    NumberToTextConverted = Table.AddColumn(SingleConverted, "NumberToText", each Number.ToText([Column1],null,[Culture=culture]))
in
    NumberToTextConverted`;

const allTableCultureSomeFail = `
let
    // Step 1: Define sample data for testing
    data = {"10.25", "20.50", "30.75", "40.00", "50.25"},
    #"Converted to Table" = Table.FromList(data, Splitter.SplitByNothing(), null, null, ExtraValues.Error),
    // Step 2: Define culture to use
    culture = "fr-FR",
    // Step 3: Apply all conversion functions to the data
    // Currency conversion (applies culture for currency formatting)
    CurrencyConverted = Table.AddColumn(#"Converted to Table", "Currency", each Currency.From(10.25)),
    // Decimal conversion
    DecimalConverted = Table.AddColumn(CurrencyConverted, "Decimal", each Decimal.From([Column1])),
    // Double conversion
    DoubleConverted = Table.AddColumn(DecimalConverted, "Double", each Double.From([Column1])),
    // Int16 conversion
    Int16Converted = Table.AddColumn(DoubleConverted, "Int16", each Int16.From([Column1],culture)),
    // Int32 conversion
    Int32Converted = Table.AddColumn(Int16Converted, "Int32", each Int32.From([Column1])),
    // Int64 conversion
    Int64Converted = Table.AddColumn(Int32Converted, "Int64", each Int64.From([Column1])),
    // Int8 conversion
    Int8Converted = Table.AddColumn(Int64Converted, "Int8", each Int8.From([Column1])),
    // Number conversion
    NumberConverted = Table.AddColumn(Int8Converted, "Number", each Number.From([Column1])),
    // Number from Text conversion
    NumberFromTextConverted = Table.AddColumn(NumberConverted, "NumberFromText", each Number.FromText([Column1],culture)),
    // Percentage conversion (assuming the input is in percentage format)
    PercentageConverted = Table.AddColumn(NumberFromTextConverted, "Percentage", each Percentage.From([Column1])),
    // Single conversion
    SingleConverted = Table.AddColumn(PercentageConverted, "Single", each Single.From([Column1])),
    // Convert numbers to text with culture formatting
    NumberToTextConverted = Table.AddColumn(SingleConverted, "NumberToText", each Number.ToText([Currency],null,[Culture=culture]))
in
    NumberToTextConverted
`;   

describe('useCultureForNumericFunctions Rule', () => {
  
  it('should return the expected RuleResult for allTableCultureFail', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(allTableCultureFail);
    logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useCultureForNumericFunctions]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(12);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
    });    

    expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(10);
    expect(results[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(12);
    expect(results[2].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(14);
    expect(results[3].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(16);
    expect(results[4].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(18);
    expect(results[5].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(20);
    expect(results[6].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(22);
    expect(results[7].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(24);
    expect(results[8].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(26);
    expect(results[9].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(28);
    expect(results[10].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(30);    
    expect(results[11].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(32);    
  });    

  it('should return the expected RuleResult for allListCultureFail', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(allListCultureFail);
    logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useCultureForNumericFunctions]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(13);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
    });    

    expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(10);
    expect(results[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(12);
    expect(results[2].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(14);
    expect(results[3].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(16);
    expect(results[4].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(18);
    expect(results[5].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(20);
    expect(results[6].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(22);
    expect(results[7].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(24);
    expect(results[8].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(26);
    expect(results[9].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(28);
    expect(results[10].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(30);    
    expect(results[11].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(32);    
  });  

  it('should return the expected RuleResult for allTableCultureSomeFail', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(allTableCultureSomeFail);
    logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useCultureForNumericFunctions]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(9);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
    });    

    expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(10);
    expect(results[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(12);
    expect(results[2].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(14);
    expect(results[3].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(18);
    expect(results[4].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(20);
    expect(results[5].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(22);
    expect(results[6].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(24);
    expect(results[7].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(28);
    expect(results[8].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(30);  
  });     
  
  it('should return the expected RuleResult for allTableCulturePass', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(allTableCulturePass);
    logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useCultureForNumericFunctions]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
   
  });    

  it('should return the expected RuleResult for nestedFail', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(nestedFail);
    logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useCultureForNumericFunctions]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);
   
  });   

});
