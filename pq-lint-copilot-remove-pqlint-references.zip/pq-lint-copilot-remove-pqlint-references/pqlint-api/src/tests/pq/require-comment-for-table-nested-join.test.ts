import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { requireCommentForTableNestedJoin } from 'src/lint/pq/require-comment-for-table-nested-join';
import * as path from 'path';

// PQ_COMMENT_RULE_NESTEDJOIN
const _NestedJoin_MissingComment_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/NestedJoin_MissingComment.tmdl');
const _NestedJoin_HasComment_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/NestedJoin_HasComment.tmdl');

describe('requireCommentForTableFuzzyNestedJoin Rule', () => {
    it('should return the expected RuleResult for NestedJoin_MissingComment.tmdl', async () => {
        const parsedCode = await parseHelper(_NestedJoin_MissingComment_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireCommentForTableNestedJoin]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });     
    
    it('should return the expected RuleResult for NestedJoin_HasComment.tmdl', async () => {
        const parsedCode = await parseHelper(_NestedJoin_HasComment_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireCommentForTableNestedJoin]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });        
});