import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useValueTypeWithConditionalJoin } from 'src/lint/pq/use-value-type-with-conditional-join';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';
import { logDebug } from 'src/lint/rule-assistance';

const crossJoinType = `let
    Source = #"Manual Data",
    #"Added Custom" = Table.AddColumn(Source, "No Value Type", each #"Manual Table with Types"),
    #"Expanded No Value Type" = Table.ExpandTableColumn(#"Added Custom", "No Value Type", {"ID", "Name", "Timestamp", "Amount", "DueDate"}, {"ID", "Name", "Timestamp", "Amount", "DueDate"})
in
    #"Expanded No Value Type"
`

const selectRowsNoValueType = `let
    Source = #"Manual Data",
    #"Added Custom" = Table.AddColumn(Source, "No Value Type", (x) => Table.SelectRows(#"Manual Table with Types",each x[Start]>[DueDate])),
    #"Expanded No Value Type" = Table.ExpandTableColumn(#"Added Custom", "No Value Type", {"ID", "Name", "Timestamp", "Amount", "DueDate"}, {"ID", "Name", "Timestamp", "Amount", "DueDate"})
in
    #"Expanded No Value Type"`

const selectRowsWithValueType = `let
    Source = #"Manual Data",
    #"Added Custom" = Table.AddColumn(Source, "No Value Type", (x) => Table.SelectRows(#"Manual Table with Types",each x[Start]>[DueDate]),Value.Type(#"Manual Table with Types")),
    #"Expanded No Value Type" = Table.ExpandTableColumn(#"Added Custom", "No Value Type", {"ID", "Name", "Timestamp", "Amount", "DueDate"}, {"ID", "Name", "Timestamp", "Amount", "DueDate"})
in
    #"Expanded No Value Type"`

const selectRowOneGoodOneFail = `let
    Source = #"Manual Data",
    #"Added Custom" = Table.AddColumn(Source, "No Value Type", (x) => Table.SelectRows(#"Manual Table with Types",each x[Start]>[DueDate]),Value.Type(#"Manual Table with Types")),
    #"Expanded No Value Type" = Table.ExpandTableColumn(#"Added Custom", "No Value Type", {"ID", "Name", "Timestamp", "Amount", "DueDate"}, {"ID", "Name", "Timestamp", "Amount", "DueDate"}),
    #"Added Custom1" = Table.AddColumn(#"Expanded No Value Type", "Bad", (x) => Table.SelectRows(#"Manual Table with Types",each x[Start]>[DueDate]))
in
    #"Added Custom1"`


describe('useValueTypeWithConditionalJoin Rule', () => {
  it('should return the expected RuleResult for crossJoinType', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(crossJoinType); // for now cross join won't work
    logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useValueTypeWithConditionalJoin]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });

  it('should return the expected RuleResult for selectRowsNoValueType', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(selectRowsNoValueType); // for now cross join won't work
    logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useValueTypeWithConditionalJoin]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
        expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
        expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      });    
  
      expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(3);        
  });  

  it('should return the expected RuleResult for selectRowsWithValueType', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(selectRowsWithValueType); // for now cross join won't work
    logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useValueTypeWithConditionalJoin]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);

  });  
  
  it('should return the expected RuleResult for selectRowOneGoodOneFail', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(selectRowOneGoodOneFail); // for now cross join won't work
    logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useValueTypeWithConditionalJoin]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
        expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
        expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      });    
  
      expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(5);        
  });    
});
