import { lintMCode } from 'src/lint/linter-module'  // Adjust the import path according to your project structure
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { consolidateSimilarTableTransformColumnTypes } from  'src/lint/pq/consolidate-similar-table-transform-column-types';
import * as path from 'path';

// consolidate-similar-table-transform-column-types
const _Multiple_Change_Types_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Multiple_Change_Types_Fail.tmdl');
const _Multiple_Change_Types_Success_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Multiple_Change_Types_Success.tmdl');
const _No_Change_Type_Success_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/No_Change_Types_Success.tmdl');
const _Two_Renames_Success_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Two_Renames_Success.tmdl');


describe('consolidate-similar-table-transform-column-types Rule', () => {
    it('should return the expected RuleResult for Multiple_Change_Types_Fail.tmdl', async () => {
        const parsedCode = await parseHelper(_Multiple_Change_Types_Fail_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [consolidateSimilarTableTransformColumnTypes]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(4);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });    

    it('should return the expected RuleResult for Multiple_Change_Types_Success.tmdl', async () => {
        const parsedCode = await parseHelper(_Multiple_Change_Types_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [consolidateSimilarTableTransformColumnTypes]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);      
    });     

    it('should return the expected RuleResult for No_Change_Type_Success.tmdl', async () => {
        const parsedCode = await parseHelper(_No_Change_Type_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [consolidateSimilarTableTransformColumnTypes]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });  
    
    it('should return the expected RuleResult for Two_Renames_Success.tmdl', async () => {
        const parsedCode = await parseHelper(_Two_Renames_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [consolidateSimilarTableTransformColumnTypes]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });      
});