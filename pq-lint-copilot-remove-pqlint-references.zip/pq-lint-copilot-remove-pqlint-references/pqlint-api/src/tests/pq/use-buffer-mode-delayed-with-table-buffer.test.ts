import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useBufferModeDelayedWithTableBuffer } from 'src/lint/pq/use-buffer-mode-delayed-with-table-buffer';
import * as path from 'path';

// nuseBufferModeDelayedWithTableBuffer Rule
const _use_buffer_mode_delayed_with_table_buffer_Success_DataFilePath = path.resolve('./test-files/Files/use-buffer-mode-delayed-with-table-buffer.SemanticModel/definition/tables/use-buffer-mode-delayed-with-table-buffer_success.tmdl');
const _use_buffer_mode_delayed_with_table_buffer_Fail_DataFilePath = path.resolve('./test-files/Files/use-buffer-mode-delayed-with-table-buffer.SemanticModel/definition/tables/use-buffer-mode-delayed-with-table-buffer_fail.tmdl');

describe('useBufferModeDelayedWithTableBuffer Rule', () => {
    it('should return the expected RuleResult for use-buffer-mode-delayed-with-table-buffer_fail.tmdl', async () => {
        const parsedCode = await parseHelper(_use_buffer_mode_delayed_with_table_buffer_Fail_DataFilePath);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useBufferModeDelayedWithTableBuffer]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });    


    it('should return the expected RuleResult for use-buffer-mode-delayed-with-table-buffer_success.tmdl', async () => {
        const parsedCode = await parseHelper(_use_buffer_mode_delayed_with_table_buffer_Success_DataFilePath);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useBufferModeDelayedWithTableBuffer]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);    
    });     
    
 
});