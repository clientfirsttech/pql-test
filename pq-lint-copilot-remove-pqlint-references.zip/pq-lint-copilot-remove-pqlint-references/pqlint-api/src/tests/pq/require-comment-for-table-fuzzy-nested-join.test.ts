import { lintMCode } from 'src/lint/linter-module'  // Adjust the import path according to your project structure
import { ParseResult } from 'src/parser/pq/parse-types';
import { RuleResult } from 'src/lint/rule-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { parseHelper, parseHelperForFunctions } from '../rule-testing-assistance';
import { logDebug } from 'src/lint/rule-assistance';
import * as path from 'path';
import * as fs from 'fs';
import requireCommentForTableFuzzyNestedJoin from 'src/lint/pq/require-comment-for-table-fuzzy-nested-join';

// require-comment-for-table-fuzzy-nested-join
const _FuzzyMatch_HasNoComment_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/FuzzyMatch_HasNoComment.tmdl');
const _FuzzyMatch_HasComment_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/FuzzyMatch_HasComment.tmdl');

describe('require-comment-for-table-fuzzy-nested-join Rule', () => {
    it('should return the expected RuleResult for FuzzyMatch_HasNoComment.tmdl', async () => {
        const parsedCode = await parseHelper(_FuzzyMatch_HasNoComment_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireCommentForTableFuzzyNestedJoin]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });    
    
    it('should return the expected RuleResult for FuzzyMatch_HasComment.tmdl', async () => {
        const parsedCode = await parseHelper(_FuzzyMatch_HasComment_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireCommentForTableFuzzyNestedJoin]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });     
});