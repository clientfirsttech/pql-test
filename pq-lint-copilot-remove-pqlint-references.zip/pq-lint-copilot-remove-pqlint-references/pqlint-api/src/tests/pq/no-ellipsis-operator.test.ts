import { lintMCode } from 'src/lint/linter-module'  // Adjust the import path according to your project structure
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';
import noEllipsisOperator from 'src/lint/pq/no-ellipsis-operator';
import { logDebug } from 'src/lint/rule-assistance';

// M Code example with Authorization header using "Bearer" and a token
const ellipsisOperatorUsage = `let 
    complexCode =  
        if 1 + 1 = 2
        then "That's right"
        else ...
    in
    complexCode
`

const noEllipsisOperatorUsage = `let
    Source = Json.Document(Web.Contents(GraphUrl & "groups",[Headers = [Authorization = "Bearer " & fx_AuthToken]]))
    in
    Source
`

describe('noEllipsisOperator Rule', () => {
    it('should return the expected RuleResult for Ellipsis Operator', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(ellipsisOperatorUsage);
        logDebug(`Parsed Code: ${JSON.stringify(parsedCode, null, 2)}`);
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noEllipsisOperator]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(5);

    });         

    it('should return the expected RuleResult for No Ellipsis Operator', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(noEllipsisOperatorUsage);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noEllipsisOperator]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });      
    
 
});