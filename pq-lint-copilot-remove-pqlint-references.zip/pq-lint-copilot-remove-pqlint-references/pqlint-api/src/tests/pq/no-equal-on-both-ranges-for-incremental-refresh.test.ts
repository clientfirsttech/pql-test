import { lintMCode } from 'src/lint/linter-module'  // Adjust the import path according to your project structure
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';
import { logDebug } from 'src/lint/rule-assistance';
import noEqualOnBohRangesForIncrementalRefresh from 'src/lint/pq/no-equal-on-both-ranges-for-incremental-refresh';

describe('no-equal-on-both-ranges-for-incremental Rule', () => {
    it('should return the expected RuleResult for hasDoubleRange', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(hasDoubleRange);
        // Create directory if it doesn't exist
        /*const outputDir = path.resolve('./src/lint/parsed_files');
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }
        
        // Save parsed code to JSON file
        const outputPath = path.join(outputDir, 'doubleequals.json');
        fs.writeFileSync(outputPath, JSON.stringify(parsedCode.lexed, null, 2));*/
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noEqualOnBohRangesForIncrementalRefresh]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(5);
    }); 
    
    it('should return the expected RuleResult for hasDoubleRange2', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(hasDoubleRange2);

        const results: RuleResult[] = await lintMCode(parsedCode, [noEqualOnBohRangesForIncrementalRefresh]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(5);
    }); 
    
    it('should return the expected RuleResult for hasDoubleRange3', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(hasDoubleRange3);

        const results: RuleResult[] = await lintMCode(parsedCode, [noEqualOnBohRangesForIncrementalRefresh]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(5);
    }); 
    
    it('should return the expected RuleResult for hasDoubleRange4', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(hasDoubleRange4);

        const results: RuleResult[] = await lintMCode(parsedCode, [noEqualOnBohRangesForIncrementalRefresh]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(5);
    });     

    it('should return the expected RuleResult for hasOneRange', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(hasOneRange);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noEqualOnBohRangesForIncrementalRefresh]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    }); 
    
    it('should return the expected RuleResult for hasOneRange', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(hasOneRange);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noEqualOnBohRangesForIncrementalRefresh]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    }); 
    
    it('should return the expected RuleResult for hasOneRange2', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(hasOneRange2);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noEqualOnBohRangesForIncrementalRefresh]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    }); 
    
    it('should return the expected RuleResult for hasOneRange3', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(hasOneRange3);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noEqualOnBohRangesForIncrementalRefresh]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    }); 
    
    it('should return the expected RuleResult for hasOneRange4', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(hasOneRange4);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noEqualOnBohRangesForIncrementalRefresh]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });  
    
    it('should return the expected RuleResult for hasOneRange5', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(hasOneRange5);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noEqualOnBohRangesForIncrementalRefresh]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });     
    
 
});

const hasDoubleRange = `let
    Source = Upstream,

    // Filters rows by created date to keep records in the specified range
    #"Filtered Rows By Created Date Range" = Table.SelectRows(Source, each [Created] >= RangeStart and [Created] <= RangeEnd)

    in #"Filtered Rows By Created Date Range"
`

const hasDoubleRange2 = `let
    Source = Upstream,

    // Filters rows by created date to keep records in the specified range
    #"Filtered Rows By Created Date Range" = Table.SelectRows(Source, each [Created] >= RangeStart and RangeEnd >= [Created])

    in #"Filtered Rows By Created Date Range"
`

const hasDoubleRange3 = `let
    Source = Upstream,

    // Filters rows by created date to keep records in the specified range
    #"Filtered Rows By Created Date Range" = Table.SelectRows(Source, each [Created] <= RangeEnd and [Created] >= RangeStart)

    in #"Filtered Rows By Created Date Range"
`

const hasDoubleRange4 = `let
    Source = Upstream,

    // Filters rows by created date to keep records in the specified range
    #"Filtered Rows By Created Date Range" = Table.SelectRows(Source, each RangeStart >= [Created] and [Created] <= RangeEnd)

    in #"Filtered Rows By Created Date Range"
`

const hasOneRange = `let
    Source = Upstream,

    // Filters rows by created date to keep records in the specified range
    #"Filtered Rows By Created Date Range" = Table.SelectRows(Source, each [Created] > RangeStart and [Created] <= RangeEnd)

    in #"Filtered Rows By Created Date Range"
`

const hasOneRange2 = `let
    Source = Upstream,

    // Filters rows by created date to keep records in the specified range
    #"Filtered Rows By Created Date Range" = Table.SelectRows(Source, each [Created] >= RangeStart and [Created] < RangeEnd)

    in #"Filtered Rows By Created Date Range"
`

const hasOneRange3 = `let
    Source = Upstream,

    // Filters rows by created date to keep records in the specified range
    #"Filtered Rows By Created Date Range" = Table.SelectRows(Source, each [Created] >= RangeStart)

    in #"Filtered Rows By Created Date Range"
`

const hasOneRange4 = `let
    Source = Upstream,

    // Filters rows by created date to keep records in the specified range
    #"Filtered Rows By Created Date Range" = Table.SelectRows(Source, each [Created] <= RangeEnd and [Created] > RangeStart)

    in #"Filtered Rows By Created Date Range"
`

const hasOneRange5 = `let
    Source = Upstream,

    // Filters rows by created date to keep records in the specified range
    #"Filtered Rows By Created Date Range" = Table.SelectRows(Source, each RangeStart >= [Created] and RangeStart <[Created])

    in #"Filtered Rows By Created Date Range"
`

