import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useCultureForTablePromoteHeaders } from 'src/lint/pq/use-culture-for-table-promote-headers';
import * as path from 'path';

// use-distinct-source-name-for-referencing-table
const _Does_Not_Uses_Culture_DataFilePath = path.resolve('./test-files/Files/use-culture-with-table-promote-headers.SemanticModel/definition/tables/Table_Without_Culture.tmdl');
const _Uses_Culture_DataFilePath = path.resolve('./test-files/Files/use-culture-with-table-promote-headers.SemanticModel/definition/tables/Table_With_Culture.tmdl');
const _SharePoint_Online_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SharePoint_Fail.tmdl');

describe('useCultureForTablePromoteHeaders Rule', () => {
    it('should return the expected RuleResult for Table_Without_Culture.tmdl', async () => {
        const parsedCode = await parseHelper(_Does_Not_Uses_Culture_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useCultureForTablePromoteHeaders]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();

            // Check if the error location is correct
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(3);            
        });        
    });
    
    it('should return the expected RuleResult for Table_With_Culture.tmdl', async () => {
        const parsedCode = await parseHelper(_Uses_Culture_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useCultureForTablePromoteHeaders]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);       
    });    

    it('should return the expected RuleResult for avoiding a False Positive', async () => {
        const parsedCode = await parseHelper(_SharePoint_Online_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useCultureForTablePromoteHeaders]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });         
});