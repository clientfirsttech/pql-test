import { lintMCode } from 'src/lint/linter-module'  // Adjust the import path according to your project structure
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';
import noAIFunctions from 'src/lint/pq/no-ai-functions';

let hasAIFunctions = `let
    Source = MarvelSource,
    #"Changed Type" = Table.TransformColumnTypes(Source,{{"page_id", Int64.Type}, {"name", type text}, {"urlslug", type text}, {"ID", type text}, {"ALIGN", type text}, {"EYE", type text}, {"HAIR", type text}, {"SEX", type text}, {"GSM", type text}, {"ALIVE", type text}, {"APPEARANCES", Int64.Type}, {"FIRST APPEARANCE", type text}, {"Year", Int64.Type}}),
    #"Split Column by Delimiter" = Table.SplitColumn(#"Changed Type", "FIRST APPEARANCE", Splitter.SplitTextByDelimiter("-", QuoteStyle.Csv), {"FIRST APPEARANCE.1", "FIRST APPEARANCE.2"}),
    #"Changed Type1" = Table.TransformColumnTypes(#"Split Column by Delimiter",{{"FIRST APPEARANCE.1", type text}, {"FIRST APPEARANCE.2", Int64.Type}}),
    #"Added Custom" = Table.AddColumn(#"Changed Type1", "DateKey", each [FIRST APPEARANCE.1]&"-"&Text.From([Year])),
    #"Replaced Value" = Table.ReplaceValue(#"Added Custom",null,"Jan-0001",Replacer.ReplaceValue,{"DateKey"}),
    #"Removed Columns" = Table.RemoveColumns(#"Replaced Value",{"FIRST APPEARANCE.1", "FIRST APPEARANCE.2", "Year"}),
    #"Merged Queries" = Table.NestedJoin(#"Removed Columns", {"DateKey"}, DateDim, {"DateKey"}, "DateDim", JoinKind.LeftOuter),
    #"Expanded DateDim" = Table.ExpandTableColumn(#"Merged Queries", "DateDim", {"DateID"}, {"DateDim.DateID"}),
    #"Removed Columns1" = Table.RemoveColumns(#"Expanded DateDim",{"DateKey"}),
    #"Renamed Columns" = Table.RenameColumns(#"Removed Columns1",{{"DateDim.DateID", "DateID"}}),
    #"Removed Columns2" = Table.RemoveColumns(#"Renamed Columns",{"SEX", "GSM", "ALIVE", "urlslug"}),
    #"Merged Queries1" = Table.NestedJoin(#"Removed Columns2", {"EYE"}, EyeColorDim, {"EyeKey"}, "EyeColorDim", JoinKind.LeftOuter),
    #"Expanded EyeColorDim" = Table.ExpandTableColumn(#"Merged Queries1", "EyeColorDim", {"EyeID"}, {"EyeID"}),
    #"Removed Columns3" = Table.RemoveColumns(#"Expanded EyeColorDim",{"HAIR"}),
    #"Merged Queries2" = Table.NestedJoin(#"Removed Columns3", {"ALIGN"}, AlignmentDim, {"AlignmentKey"}, "AlignmentDim", JoinKind.LeftOuter),
    #"Expanded AlignmentDim" = Table.ExpandTableColumn(#"Merged Queries2", "AlignmentDim", {"AlignmentID"}, {"AlignmentID"}),
    #"Removed Columns4" = Table.RemoveColumns(#"Expanded AlignmentDim",{"ID", "ALIGN", "EYE"}),
    #"Renamed Columns1" = Table.RenameColumns(#"Removed Columns4",{{"name", "Name"}, {"APPEARANCES", "Appearances"}, {"page_id", "ID"}}),
    #"Applied Detect language" = AIFunctions.PostProcess(Table.AddColumn(#"Renamed Columns1", "Detect language", each #"Detect language"([Name])), "Detect language", "CognitiveServices.DetectLanguagetext") meta [FunctionBrowser="TextAnalytics"],
    #"Applied Extract key phrases" = AIFunctions.PostProcess(Table.AddColumn(#"Applied Detect language", "Extract key phrases", each #"Extract key phrases"([Name], null)), "Extract key phrases", "CognitiveServices.ExtractKeyPhrasestexttext") meta [FunctionBrowser="TextAnalytics"]
in
    #"Applied Extract key phrases"`

let hasAIFunctions2 = `AIFunctions.Contents(){[Key = "CognitiveServices.DetectLanguagetext"]}[Data]`

let noFalsePositive = `let
    Source = AzureDataExplorer.Contents(Eventhouse_Cluster_URL, Database, "Commits #(lf)| where Date >= ago(" & Number.ToText(Days_Since_Filter) &"d)", [MaxRows=null, MaxSize=null, NoTruncate=null, AdditionalSetStatements=null])
in
    Source`

describe('noAIFunctions Rule', () => {
  it('should return the expected RuleResult for hasAIFunctions', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(hasAIFunctions);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [noAIFunctions]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(2);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
    });

    expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(21);
    expect(results[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(22);


  });

  it('should return the expected RuleResult for hasAIFunctions2', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(hasAIFunctions2);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [noAIFunctions]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
    });

    expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(1);

  });

  it('should return the expected RuleResult for no false positive', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(noFalsePositive);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [noAIFunctions]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });

});
