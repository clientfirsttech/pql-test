import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useNameForSalesforceReports } from 'src/lint/pq/use-name-for-salesforce-reports';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';

let nameUse = `let
  Source = Salesforce.Reports("https://login.salesforce.com"),
  Report = Source{[Name = "00O5g00000C0v1iEAB"]}[Data]
in
  #"Report"`;

let labelUse = `let
  Source = Salesforce.Reports("https://login.salesforce.com"),
  Report = Source{[Label = "Finance Report"]}[Data]
in
  #"Report"`;

describe('useNameForSalesforceReports Rule', () => {
  it('should return the expected RuleResult for Name Use', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(nameUse);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNameForSalesforceReports]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });

  it('should return the expected RuleResult for Label Use', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(labelUse);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNameForSalesforceReports]);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(3);
    });
    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);
  });
});
