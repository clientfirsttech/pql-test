import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { requireCreateNavigationPropertiesBeSetToFalseInDataverse } from 'src/lint/pq/require-create-navigation-properties-be-set-false-in-dataverse';
import * as path from 'path';

// requireCreateNavigationPropertiesBeSetToFalseInDataverse Rule
const _require_create_navigation_properties_be_set_false_Dataverse_Fail_DataFilePath = path.resolve('./test-files/Files/require-create-navigation-properties-be-set-false.SemanticModel/definition/tables/Dataverse_Include_Relationships_Fail.tmdl');
const _require_create_navigation_properties_be_set_false_Dataverse_Success_DataFilePath = path.resolve('./test-files/Files/require-create-navigation-properties-be-set-false.SemanticModel/definition/tables/Dataverse_Include_Relationships_Success.tmdl');

describe('requireCreateNavigationPropertiesBeSetToFalseInDataverse Rule', () => {
    it('should return the expected RuleResult for Dataverse_Include_Relationships_Fail.tmdl', async () => {
        const parsedCode = await parseHelper(_require_create_navigation_properties_be_set_false_Dataverse_Fail_DataFilePath);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireCreateNavigationPropertiesBeSetToFalseInDataverse]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            // Check if the error location is correct
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(2);
        });        
    });    


    it('should return the expected RuleResult for Dataverse_Include_Relationships_Success.tmdl', async () => {
        const parsedCode = await parseHelper(_require_create_navigation_properties_be_set_false_Dataverse_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireCreateNavigationPropertiesBeSetToFalseInDataverse]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });    
    
 
});