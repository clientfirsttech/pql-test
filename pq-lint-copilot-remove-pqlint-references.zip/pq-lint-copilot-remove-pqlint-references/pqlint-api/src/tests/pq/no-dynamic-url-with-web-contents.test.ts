import { lintMCode } from 'src/lint/linter-module'  // Adjust the import path according to your project structure
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';
import { parseHelper } from '../rule-testing-assistance';
import noDynamicUrlWithWebContents from 'src/lint/pq/no-dynamic-url-with-web-contents';
import * as path from 'path';

// noDynamicUrlWithWebContents Rule
const _noDynamicUrlWithWebContents_Success2_DataFilePath = path.resolve('./test-files/Files/use-relative-path-with-web-contents.SemanticModel/definition/tables/use-relative-path-with-web-contents_success2.tmdl');
const _noDynamicUrlWithWebContents_Fail2_DataFilePath = path.resolve('./test-files/Files/use-relative-path-with-web-contents.SemanticModel/definition/tables/use-relative-path-with-web-contents_fail2.tmdl');

describe('noDynamicUrlWithWebContents Rule', () => {
    it('should return the expected RuleResult for use-relative-path-with-contents_fail2.tmdl', async () => {
        const parsedCode = await parseHelper(_noDynamicUrlWithWebContents_Fail2_DataFilePath);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [noDynamicUrlWithWebContents]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });    


    it('should return the expected RuleResult for use-relative-path-with-contents_success2.tmdl', async () => {
        const parsedCode = await parseHelper(_noDynamicUrlWithWebContents_Success2_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [noDynamicUrlWithWebContents]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });    

    it('should return the expected RuleResult for _CSVFunction', async () => {
        const parsedCode = await parsePowerQueryText(_CSVFunction);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [noDynamicUrlWithWebContents]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });    
    
    it('should return the expected RuleResult for _CSVFunction2', async () => {
        const parsedCode = await parsePowerQueryText(_CSVFunction2);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [noDynamicUrlWithWebContents]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });    
        
        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(23);
    });       
    
 
});


const _CSVFunction = `let
    // Connects to Power Platform Dataflows
    #"Fetched Dataflows Source" = PowerPlatform.Dataflows(null),

    // Retrieves the list of available workspaces
    #"Fetched Workspaces List" = #"Fetched Dataflows Source"{[Id="Workspaces"]}[Data],

    // Retrieves data for the specified workspace by its ID
    #"Retrieved Workspace By Id" = #"Fetched Workspaces List"{[workspaceId="1ea8a354-9e2a-4f15-b671-d9238c0e43a1"]}[Data],

    // Retrieves the target dataflow by its ID from the workspace
    #"Retrieved Dataflow By Id" = #"Retrieved Workspace By Id"{[dataflowId=Dataflow_ID]}[Data],

    // Extracts the "SharePoint Results" entity from the dataflow
    #"Extracted SharePoint Results Entity" = #"Retrieved Dataflow By Id"{[entity="SharePoint Results",version=""]}[Data],

    // Filters rows by created date to keep records in the specified range
    #"Filtered Rows By Created Date Range" = Table.SelectRows(#"Extracted SharePoint Results Entity", each [Created] > RangeStart and [Created] <= RangeEnd),

    // Adds a column with downloaded file binary content for each record
    #"Added File Binary Content Column" = Table.AddColumn(#"Filtered Rows By Created Date Range", "Content", each
        Web.Contents(
            SharePoint_URL,
            [
                RelativePath = "/_api/web/GetFileByServerRelativeUrl('" & [Server Relative URL] & "')/$value"
            ]
        )
    ),

    // Filters out hidden files from the result set
    #"Removed Hidden Files From Table" = Table.SelectRows(#"Added File Binary Content Column", each [Attributes]?[Hidden]? <> true),

    // Applies a custom transformation function to the file contents
    #"Applied Custom Transform To File Content" = Table.AddColumn(#"Removed Hidden Files From Table", "Transform File", each #"Transform File"([Content])),

    // Expands the table from the custom transform to show specified columns
    #"Expanded Transformed File Columns" = Table.ExpandTableColumn(#"Applied Custom Transform To File Content", "Transform File", {"project_name", "project_description", "start_date", "end_date", "project_manager", "project_budget", "project_status", "client_name", "client_email", "client_phone"}, {"project_name", "project_description", "start_date", "end_date", "project_manager", "project_budget", "project_status", "client_name", "client_email", "client_phone"}),

    // Keeps only the relevant columns in the final output
    #"Kept Only Relevant Project Columns" = Table.SelectColumns(#"Expanded Transformed File Columns",{"project_name", "project_description", "start_date", "end_date", "project_manager", "project_budget", "project_status", "client_name", "client_email", "client_phone"})
in
    #"Kept Only Relevant Project Columns"`

const _CSVFunction2 = `let
    // Connects to Power Platform Dataflows
    #"Fetched Dataflows Source" = PowerPlatform.Dataflows(null),

    // Retrieves the list of available workspaces
    #"Fetched Workspaces List" = #"Fetched Dataflows Source"{[Id="Workspaces"]}[Data],

    // Retrieves data for the specified workspace by its ID
    #"Retrieved Workspace By Id" = #"Fetched Workspaces List"{[workspaceId="1ea8a354-9e2a-4f15-b671-d9238c0e43a1"]}[Data],

    // Retrieves the target dataflow by its ID from the workspace
    #"Retrieved Dataflow By Id" = #"Retrieved Workspace By Id"{[dataflowId=Dataflow_ID]}[Data],

    // Extracts the "SharePoint Results" entity from the dataflow
    #"Extracted SharePoint Results Entity" = #"Retrieved Dataflow By Id"{[entity="SharePoint Results",version=""]}[Data],

    // Filters rows by created date to keep records in the specified range
    #"Filtered Rows By Created Date Range" = Table.SelectRows(#"Extracted SharePoint Results Entity", each [Created] > RangeStart and [Created] <= RangeEnd),

    // Adds a column with downloaded file binary content for each record
    #"Added File Binary Content Column" = Table.AddColumn(#"Filtered Rows By Created Date Range", "Content", each
        Web.Contents(
            SharePoint_URL & "/$value",
            [
                RelativePath = "/_api/web/GetFileByServerRelativeUrl('" & [Server Relative URL] & "')/$value"
            ]
        )
    ),

    // Filters out hidden files from the result set
    #"Removed Hidden Files From Table" = Table.SelectRows(#"Added File Binary Content Column", each [Attributes]?[Hidden]? <> true),

    // Applies a custom transformation function to the file contents
    #"Applied Custom Transform To File Content" = Table.AddColumn(#"Removed Hidden Files From Table", "Transform File", each #"Transform File"([Content])),

    // Expands the table from the custom transform to show specified columns
    #"Expanded Transformed File Columns" = Table.ExpandTableColumn(#"Applied Custom Transform To File Content", "Transform File", {"project_name", "project_description", "start_date", "end_date", "project_manager", "project_budget", "project_status", "client_name", "client_email", "client_phone"}, {"project_name", "project_description", "start_date", "end_date", "project_manager", "project_budget", "project_status", "client_name", "client_email", "client_phone"}),

    // Keeps only the relevant columns in the final output
    #"Kept Only Relevant Project Columns" = Table.SelectColumns(#"Expanded Transformed File Columns",{"project_name", "project_description", "start_date", "end_date", "project_manager", "project_budget", "project_status", "client_name", "client_email", "client_phone"})
in
    #"Kept Only Relevant Project Columns"`