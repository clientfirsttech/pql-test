import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useOdataForSharepointConnection } from 'src/lint/pq/use-odata-for-sharepoint-connection';
import * as path from 'path';

// use-distinct-source-name-for-referencing-table
const _SharePoint_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SharePoint_Fail.tmdl');
const _Sort_Check_With_Buffer_Success_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Sort_Check_With_Buffer_Success_2.tmdl');

describe('useOdataForSharepointConnection Rule', () => {
    it('should return the expected RuleResult for SharePoint_Fail.tmdl', async () => {
        const parsedCode = await parseHelper(_SharePoint_Fail_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useOdataForSharepointConnection]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    }); 

    it('should return the expected RuleResult for avoiding a False Positive', async () => {
        const parsedCode = await parseHelper(_Sort_Check_With_Buffer_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useOdataForSharepointConnection]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });         
});