import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useCultureForDateFunctions} from 'src/lint/pq/use-culture-for-date-functions';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';
import { logDebug } from 'src/lint/rule-assistance';

let culturePass = `
let
    // Step 1: Define culture to use
    culture = "fr-FR",

    // Step 2: Create a list of 10 dates starting from today
    startDate = Date.From(DateTime.LocalNow(),culture),
    dateList = List.Dates(startDate, 10, #duration(1, 0, 0, 0)),

    // Step 3: Convert to a table
    dateTable = Table.FromList(dateList, Splitter.SplitByNothing(), {"OriginalDate"}),

    // Step 4: Apply functions with culture
    withDayOfWeek = Table.AddColumn(dateTable, "DayOfWeekName", each Date.DayOfWeekName([OriginalDate], culture)),
    withDateFrom = Table.AddColumn(withDayOfWeek, "DateFrom", each Date.From([OriginalDate], "en-US")),
    withMonthName = Table.AddColumn(withDateFrom, "MonthName", each Date.MonthName([OriginalDate], culture)),
    withText = Table.AddColumn(withMonthName, "DateAsText", each Date.ToText([OriginalDate], null,culture))

in
    withDateFrom
`

let culturePass2 = `
let
    // Step 1: Define culture to use
    culture = "fr-FR",

    // Step 2: Create a list of 10 dates starting from today
    startDate = Date.From(DateTime.LocalNow(),"fr-FR"),
    dateList = List.Dates(startDate, 10, #duration(1, 0, 0, 0)),

    // Step 3: Convert to a table
    dateTable = Table.FromList(dateList, Splitter.SplitByNothing(), {"OriginalDate"}),

    // Step 4: Apply functions with culture
    withDayOfWeek = Table.AddColumn(dateTable, "DayOfWeekName", each Date.DayOfWeekName([OriginalDate], culture)),
    withDateFrom = Table.AddColumn(withDayOfWeek, "DateFrom", each Date.From([OriginalDate], culture)),
    withMonthName = Table.AddColumn(withDateFrom, "MonthName", each Date.MonthName([OriginalDate], culture)),
    withText = Table.AddColumn(withMonthName, "DateAsText", each Date.ToText([OriginalDate],null, culture))

in
    withDateFrom
`

let culturePass3 = `
let
    // Step 1: Create a list of 10 dates starting from today
    startDate = Date.From(DateTime.LocalNow(),"en-US"),
    startDT = DateTime.From(DateTime.LocalNow(),"en-US"),
    dateList = List.Dates(startDate, 10, #duration(1, 0, 0, 0)),

    // Step 2: Convert to a table
    dateTable = Table.FromList(dateList, Splitter.SplitByNothing(), {"OriginalDate"}),

    // Step 3: Add each function as a new column
    withDayOfWeek = Table.AddColumn(dateTable, "DayOfWeekName", each Date.DayOfWeekName([OriginalDate], "en-US")),
    withDateFrom = Table.AddColumn(withDayOfWeek, "DateFrom", each Date.From([OriginalDate],"en-US")),
    withMonthName = Table.AddColumn(withDateFrom, "MonthName", each Date.MonthName([OriginalDate], "en-US")),
    withText = Table.AddColumn(withMonthName, "DateAsText", each Date.ToText([OriginalDate],[Culture="fr-FR"])),
    withDTText = Table.AddColumn(withText, "DateTimeAsText", each DateTime.ToText(startDT,[Culture="fr-FR"]))

in
    withDTText`

let cultureSomeFail = `
let
    // Step 1: Create a list of 10 dates starting from today
    startDate = Date.From(DateTime.LocalNow(),"en-US"),
    dateList = List.Dates(startDate, 10, #duration(1, 0, 0, 0)),

    // Step 2: Convert to a table
    dateTable = Table.FromList(dateList, Splitter.SplitByNothing(), {"OriginalDate"}),

    // Step 3: Add each function as a new column
    withDayOfWeek = Table.AddColumn(dateTable, "DayOfWeekName", each Date.DayOfWeekName([OriginalDate], "en-US")),
    withDateFrom = Table.AddColumn(withDayOfWeek, "DateFrom", each Date.From([OriginalDate])),
    withMonthName = Table.AddColumn(withDateFrom, "MonthName", each Date.MonthName([OriginalDate], "en-US")),
    withText = Table.AddColumn(withMonthName, "DateAsText", each Date.ToText([OriginalDate]))

in
    withText
`

let cultureSomeFail2 = `
let
    // Step 1: Create a list of 10 dates starting from today
    startDate = Date.From(DateTime.LocalNow()),
    dateList = List.Dates(startDate, 10, #duration(1, 0, 0, 0)),

    // Step 2: Convert to a table
    dateTable = Table.FromList(dateList, Splitter.SplitByNothing(), {"OriginalDate"}),

    // Step 3: Add each function as a new column
    withDayOfWeek = Table.AddColumn(dateTable, "DayOfWeekName", each Date.DayOfWeekName([OriginalDate])),
    withDateFrom = Table.AddColumn(withDayOfWeek, "DateFrom", each Date.From([OriginalDate], "en-US")),
    withMonthName = Table.AddColumn(withDateFrom, "MonthName", each Date.MonthName([OriginalDate])),
    withText = Table.AddColumn(withMonthName, "DateAsText", each Date.ToText([OriginalDate]))

in
    withText
`

let _DateDim = `
let
    Source = MarvelSource,
    #"Removed Other Columns" = Table.SelectColumns(Source,{"FIRST APPEARANCE", "Year"}),
    #"Split Column by Delimiter" = Table.SplitColumn(#"Removed Other Columns", "FIRST APPEARANCE", Splitter.SplitTextByDelimiter("-", QuoteStyle.Csv), {"FIRST APPEARANCE.1", "FIRST APPEARANCE.2"}),
    #"Changed Type1" = Table.TransformColumnTypes(#"Split Column by Delimiter",{{"FIRST APPEARANCE.1", type text}, {"FIRST APPEARANCE.2", Int64.Type}}),
    #"Added Custom" = Table.AddColumn(#"Changed Type1", "Date", each Date.FromText([FIRST APPEARANCE.1]&" 1, "&Text.From([Year]))),
    #"Filtered Rows" = Table.SelectRows(#"Added Custom", each ([Date] <> null)),
    #"Sorted Rows" = Table.Sort(#"Filtered Rows",{{"Date", Order.Ascending}}),
    #"Removed Columns" = Table.RemoveColumns(#"Sorted Rows",{"FIRST APPEARANCE.1", "FIRST APPEARANCE.2", "Year"}),
    #"Added Custom1" = Table.AddColumn(#"Removed Columns", "EndDate", each Date.From(DateTime.LocalNow())),
    #"Filtered Rows1" = Table.SelectRows(#"Added Custom1", let earliest = List.Min(#"Added Custom1"[Date]) in each [Date] = earliest),
    #"Removed Duplicates" = Table.Distinct(#"Filtered Rows1", {"Date"}),
    #"Renamed Columns" = Table.RenameColumns(#"Removed Duplicates",{{"Date", "StartDate"}}),
    #"Added Custom2" = Table.AddColumn(#"Renamed Columns", "Dates", each {Number.From([StartDate])..Number.From([EndDate])}),
    #"Expanded Dates" = Table.ExpandListColumn(#"Added Custom2", "Dates"),
    #"Changed Type2" = Table.TransformColumnTypes(#"Expanded Dates",{{"Dates", type date}}),
    #"Filter1stMonth" = Table.SelectRows(#"Changed Type2", each Date.Day([Dates]) = 1),
    #"Removed Columns1" = Table.RemoveColumns(#"Filter1stMonth",{"StartDate", "EndDate"}),
    #"Added Index" = Table.AddIndexColumn(#"Removed Columns1", "Index", 1, 1, Int64.Type),
    #"Reordered Columns" = Table.ReorderColumns(#"Added Index",{"Index", "Dates"}),
    #"Added Custom3" = Table.AddColumn(#"Reordered Columns", "DateKey", each Date.ToText([Dates],"MMM-yyyy")),
    #"Renamed Columns1" = Table.RenameColumns(#"Added Custom3",{{"Dates", "Date"}, {"Index", "DateID"}}),
    #"Appended Query" = Table.Combine({#"Renamed Columns1", DateDimBlank}),
    #"Sorted Rows1" = Table.Sort(#"Appended Query",{{"DateID", Order.Ascending}}),
    #"Replaced Value" = Table.ReplaceValue(#"Sorted Rows1","","Jan-0001",Replacer.ReplaceValue,{"DateKey"}),
    #"Added Custom4" = Table.AddColumn(#"Replaced Value", "MonthYearSort", each Date.Year([Date])*100 + Date.Month([Date]))
in
    #"Added Custom4"`

describe('useCultuerForDateFunctions Rule', () => {
  it('should return the expected RuleResult for culturePass', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(culturePass);
    //logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useCultureForDateFunctions]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });

  it('should return the expected RuleResult for culturePass2', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(culturePass2);
    //logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useCultureForDateFunctions]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  }); 

  it('should return the expected RuleResult for culturePass3', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(culturePass3);
    //logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useCultureForDateFunctions]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });    

  it('should return the expected RuleResult for cultureSomeFail', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(cultureSomeFail);
    logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useCultureForDateFunctions]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(2);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
    });    

    expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(12);
    expect(results[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(14);    
  });    

  it('should return the expected RuleResult for cultureSomeFail2', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(cultureSomeFail2);
    logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useCultureForDateFunctions]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(4);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
    });    

    expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(4);
    expect(results[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(11); 
    expect(results[2].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(13); 
    expect(results[3].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(14);    
  });   

  it('should return the expected RuleResult for DateDim', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(_DateDim);
    logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useCultureForDateFunctions]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(3);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
    });    

    expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(7);
    expect(results[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(11); 
    expect(results[2].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(22);   
  });    
});
