import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useRelativePathWithWebContents } from 'src/lint/pq/use-relative-path-or-query-with-web-contents';
import * as path from 'path';
import * as fs from 'fs';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';

// useSpecificParametersForNumberRound Rule
const _useRelativePathWithWebContents_Success_DataFilePath = path.resolve('./test-files/Files/use-relative-path-with-web-contents.SemanticModel/definition/tables/use-relative-path-with-web-contents_success.tmdl');
const _useRelativePathWithWebContents_Success2_DataFilePath = path.resolve('./test-files/Files/use-relative-path-with-web-contents.SemanticModel/definition/tables/use-relative-path-with-web-contents_success2.tmdl');
const _useRelativePathWithWebContents_Fail_DataFilePath = path.resolve('./test-files/Files/use-relative-path-with-web-contents.SemanticModel/definition/tables/use-relative-path-with-web-contents_fail.tmdl');
const _useRelativePathWithWebContents_Fail2_DataFilePath = path.resolve('./test-files/Files/use-relative-path-with-web-contents.SemanticModel/definition/tables/use-relative-path-with-web-contents_fail2.tmdl');

describe('useRelativePathWithWebContents Rule', () => {
    it('should return the expected RuleResult for use-relative-path-with-contents_fail.tmdl', async () => {
        const parsedCode = await parseHelper(_useRelativePathWithWebContents_Fail_DataFilePath);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useRelativePathWithWebContents]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    }); 

    it('should return the expected RuleResult for use-relative-path-with-contents_fail2.tmdl', async () => {
        const parsedCode = await parseHelper(_useRelativePathWithWebContents_Fail2_DataFilePath);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useRelativePathWithWebContents]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });    
    
    it('should return the expected RuleResult for use-relative-path-with-contents_success.tmdl', async () => {
        const parsedCode = await parseHelper(_useRelativePathWithWebContents_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useRelativePathWithWebContents]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });

    it('should return the expected RuleResult for use-relative-path-with-contents_success2.tmdl', async () => {
        const parsedCode = await parseHelper(_useRelativePathWithWebContents_Success2_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useRelativePathWithWebContents]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });    
    

    it('should return the expected RuleResult for _SharePointFunction', async () => {
        const parsedCode = await parsePowerQueryText(_SharePointFunction);
        
        // Create directory if it doesn't exist
        /*const outputDir = path.resolve('./src/lint/parsed_files');
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }
        
        // Save parsed code to JSON file
        const outputPath = path.join(outputDir, 'sharepointfunction.json');
        fs.writeFileSync(outputPath, JSON.stringify(parsedCode.ast, null, 2));*/
        
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useRelativePathWithWebContents]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });      
    
    it('should return the expected RuleResult for _CSVFunction', async () => {
        const parsedCode = await parsePowerQueryText(_CSVFunction);
        
        // Create directory if it doesn't exist
        /*const outputDir = path.resolve('./src/lint/parsed_files');
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }
        
        // Save parsed code to JSON file
        const outputPath = path.join(outputDir, 'sharepointfunction.json');
        fs.writeFileSync(outputPath, JSON.stringify(parsedCode.ast, null, 2));*/
        
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useRelativePathWithWebContents]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });        
 
});


const _SharePointFunction = `let
  func = (Fields as table, optional FilterQuery as text) as any =>
    let
      _X = (Fields as table, Source as any, NextAPIQuery as text) as any =>
        let

          // Define internal function                           
          _GetJsonFromSharePoint = (url as text) as any =>
            let

              //Set Options and odata/json response                                     
              Options = [RelativePath = url, Headers = [Accept = "application/json;odata=verbose"]],
              RawData = Web.Contents(SharePoint_URL, Options),
              Json = Json.Document(RawData)
            in
              Json,
          // Define Next Link internal function                                     
          _GetNextLink = (jsonResults as record) as any =>
            let
              #"Converted to Table" = Record.ToTable(jsonResults),
              #"Expanded Value" = Table.ExpandRecordColumn(
                #"Converted to Table",
                "Value",
                {"__next"},
                {"Value.__next"}
              ),
              #"Removed Columns" = Table.RemoveColumns(#"Expanded Value", {"Name"})
            in
              Table.FirstValue(#"Removed Columns"),
          // Convert Table to Query String is NextAPIQuery is not supplied                                                                
          QueryString =
            if NextAPIQuery <> null and NextAPIQuery <> "" then
              NextAPIQuery
            else
              let
                #"Grouped Rows" = Table.Group(
                    Fields,
                    {},
                    {
                    {"$Select", each Text.Combine(List.Distinct([Select Parameter]), ","), type text},
                    // Take distinct items to remove duplicate secondary lookups
                    {"$Expand", each Text.Combine(List.Distinct([Expand Parameter]),","), type nullable text},
                    {"List Name", each List.Min([List Name]), type text}
                    }
                ,GroupKind.Global),
                #"Added Custom" = Table.AddColumn(
                    #"Grouped Rows",
                    "Query String",
                    each "/_api/lists/GetByTitle('"
                    & [List Name]
                    & "')/items?$select="
                    & [#"$Select"]
                    & "&$expand="
                    & [#"$Expand"]
                    & "&$top=5000"),
                QueryString = #"Added Custom"{0}[Query String],
                // Handle if Filter Query was provided                                      
                QueryString2 =
                  if FilterQuery <> null and FilterQuery <> "" then
                    QueryString & "&$filter=" & FilterQuery
                  else
                    QueryString
              in
                QueryString2,
          //With the internal functions defined, get the data                                                   
          Json = _GetJsonFromSharePoint(QueryString),
          // Convert to List                  
          Records = Json[d][results],
          // Combine results                  
          NewRecords = if Source is null then Records else List.Combine({Source, Records}),
          // Get next link, if exists                           
          NextLink = _GetNextLink(Json),
          // Build Base URL for recursive call                                    
          BaseUrlLength = Text.Length(SharePoint_URL),
          // Call Recursively if Next Link exists                                       
          Result =
            if NextLink is null then
              let

                //Get ls of internal and exteral names                                      
                LstInternalNames = Table.ToList(Table.SelectColumns(Table.SelectRows(Fields, each [#"Table Expand Argument - Internal Name"] <> null and [#"Table Expand Argument - Internal Name"] <> ""),{"Table Expand Argument - Internal Name"})),
                // Filter out null or empty expansion values
                LstDisplayNames = Table.ToList(Table.SelectColumns(Table.SelectRows(Fields, each [#"Table Expand Argument - Display Name"] <> null and [#"Table Expand Argument - Display Name"] <> ""),{"Table Expand Argument - Display Name"})),
                // Convert list of records to table                                   
                #"Converted to Table" = Table.FromList(
                  NewRecords,
                  Splitter.SplitByNothing(),
                  null,
                  null,
                  ExtraValues.Error
                ),
                // Row Count Check
                RowCount = Table.RowCount(#"Converted to Table"),
                // Check Row Count, if Zero then return just Display Names as a table, else Expand based on fields supplied.                                   
                #"Expanded Column1" = if RowCount = 0 then #table(LstDisplayNames,{}) else Table.ExpandRecordColumn(
                  #"Converted to Table",
                  "Column1",
                  LstInternalNames,
                  LstDisplayNames
                )
              in
                #"Expanded Column1"
            else
              @_X(Fields, NewRecords, Text.Range(NextLink, BaseUrlLength))
        in
          Result
    in
      _X(Fields, null, ""),
  documentation = [
    Documentation.Name = " fnGetSharePointData ",
    Documentation.Description
      = " Returns data from a SharePoint list when supplied a table of Fields produced by fnGetFields function.",
    Documentation.LongDescription
      = " Returns data from a SharePoint list when supplied a table of Fields produced by fnGetFields function.  To filter the data please provide a correctly formatted OData query in the FilterQuery parameter.",
    Documentation.Category = " SharePoint ",
    Documentation.Source = "https://github.com/kerski/power-query-sharepoint-faster-easier",
    Documentation.Version = "1",
    Documentation.Author = " John Kerski ",
    Documentation.Examples = {
      [
        Description = "  ",
        Code        = " fnGetSharePointData( #table, ""Title eq 'Example'"") ",
        Result      = " {#record, #record, #record} "
      ]
    }
  ],
  Custom = Value.ReplaceType(func, Value.ReplaceMetadata(Value.Type(func), documentation))
in
  Custom`

const _CSVFunction = `let
    // Connects to Power Platform Dataflows
    #"Fetched Dataflows Source" = PowerPlatform.Dataflows(null),

    // Retrieves the list of available workspaces
    #"Fetched Workspaces List" = #"Fetched Dataflows Source"{[Id="Workspaces"]}[Data],

    // Retrieves data for the specified workspace by its ID
    #"Retrieved Workspace By Id" = #"Fetched Workspaces List"{[workspaceId="1ea8a354-9e2a-4f15-b671-d9238c0e43a1"]}[Data],

    // Retrieves the target dataflow by its ID from the workspace
    #"Retrieved Dataflow By Id" = #"Retrieved Workspace By Id"{[dataflowId=Dataflow_ID]}[Data],

    // Extracts the "SharePoint Results" entity from the dataflow
    #"Extracted SharePoint Results Entity" = #"Retrieved Dataflow By Id"{[entity="SharePoint Results",version=""]}[Data],

    // Filters rows by created date to keep records in the specified range
    #"Filtered Rows By Created Date Range" = Table.SelectRows(#"Extracted SharePoint Results Entity", each [Created] > RangeStart and [Created] <= RangeEnd),

    // Adds a column with downloaded file binary content for each record
    #"Added File Binary Content Column" = Table.AddColumn(#"Filtered Rows By Created Date Range", "Content", each
        Web.Contents(
            SharePoint_URL,
            [
                RelativePath = "/_api/web/GetFileByServerRelativeUrl('" & [Server Relative URL] & "')/$value"
            ]
        )
    ),

    // Filters out hidden files from the result set
    #"Removed Hidden Files From Table" = Table.SelectRows(#"Added File Binary Content Column", each [Attributes]?[Hidden]? <> true),

    // Applies a custom transformation function to the file contents
    #"Applied Custom Transform To File Content" = Table.AddColumn(#"Removed Hidden Files From Table", "Transform File", each #"Transform File"([Content])),

    // Expands the table from the custom transform to show specified columns
    #"Expanded Transformed File Columns" = Table.ExpandTableColumn(#"Applied Custom Transform To File Content", "Transform File", {"project_name", "project_description", "start_date", "end_date", "project_manager", "project_budget", "project_status", "client_name", "client_email", "client_phone"}, {"project_name", "project_description", "start_date", "end_date", "project_manager", "project_budget", "project_status", "client_name", "client_email", "client_phone"}),

    // Keeps only the relevant columns in the final output
    #"Kept Only Relevant Project Columns" = Table.SelectColumns(#"Expanded Transformed File Columns",{"project_name", "project_description", "start_date", "end_date", "project_manager", "project_budget", "project_status", "client_name", "client_email", "client_phone"})
in
    #"Kept Only Relevant Project Columns"`