import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useSpecificParametersForFuzzyMerge } from 'src/lint/pq/use-specific-parameters-for-fuzzy-merge';
import * as path from 'path';

// useSpecificParametersForFuzzyMerge  Rule
const _FuzzyMatch_HasNoParameters_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/FuzzyMatch_HasNoParameters.tmdl');
const _FuzzyMatch_HasBothParameters_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/FuzzyMatch_HasBothParameters.tmdl');
const _FuzzyMatch_HasOnlyOneParameter_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/FuzzyMatch_HasOnlyOneParameter.tmdl');
const _FuzzyMatch_HasTwoFuziesWithOneFailure_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/FuzzyMatch_HasTwoFuzziesWithOneFailure.tmdl');

describe('useSpecificParametersForFuzzyMerge Rule', () => {
    it('should return the expected RuleResult for FuzzyMatch_HasNoParameters.tmdl', async () => {
        const parsedCode = await parseHelper(_FuzzyMatch_HasNoParameters_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useSpecificParametersForFuzzyMerge]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    }); 
    
    it('should return the expected RuleResult for FuzzyMatch_HasBothParameters.tmdl', async () => {
        const parsedCode = await parseHelper(_FuzzyMatch_HasBothParameters_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useSpecificParametersForFuzzyMerge]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });    

    it('should return the expected RuleResult for FuzzyMatch_HasOnlyOneParameter.tmdl', async () => {
        const parsedCode = await parseHelper(_FuzzyMatch_HasOnlyOneParameter_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useSpecificParametersForFuzzyMerge]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });   
    
    it('should return the expected RuleResult for FuzzyMatch_HasTwoFuzziesWithOneFailure.tmdl', async () => {
        const parsedCode = await parseHelper(_FuzzyMatch_HasTwoFuziesWithOneFailure_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useSpecificParametersForFuzzyMerge]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });     
});