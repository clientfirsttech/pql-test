import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useNewColumnNamesForTableExpandRecordColumn } from 'src/lint/pq/use-new-column-names-for-table-expand-record-column';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';

const expandRecordColumnFail = `
let
    Source = SharePoint.Tables("https://kerski.sharepoint.com", [Implementation="2.0", ViewMode="All"]),
    #"418be5b8-415e-4311-93ae-e659b4024a8d" = Source{[Id="418be5b8-415e-4311-93ae-e659b4024a8d"]}[Items],
    #"Expanded Modified By" = Table.ExpandListColumn(#"418be5b8-415e-4311-93ae-e659b4024a8d", "Modified By"),
    #"Expanded Modified By1" = Table.ExpandRecordColumn(#"Expanded Modified By", "Modified By", {"id", "email"}, {"Modified By.id", "Modified By.email"}),
    #"Removed Other Columns" = Table.SelectColumns(#"Expanded Modified By1",{"Modified By.id", "Modified By.email", "Type", "Name", "Modified"}),
    #"Renamed Columns" = Table.RenameColumns(#"Removed Other Columns",{{"Modified By.email", "Email"}})
in
    #"Renamed Columns"
`

const expandRecordColumnFail2 = `
let
    Source = SharePoint.Tables("https://kerski.sharepoint.com", [Implementation="2.0", ViewMode="All"]),
    #"418be5b8-415e-4311-93ae-e659b4024a8d" = Source{[Id="418be5b8-415e-4311-93ae-e659b4024a8d"]}[Items],
    #"Expanded Modified By" = Table.ExpandListColumn(#"418be5b8-415e-4311-93ae-e659b4024a8d", "Modified By"),
    #"Expanded Modified By1" = Table.ExpandRecordColumn(#"Expanded Modified By", "Modified By", {"id", "email"}, {"Modified By.id", "Email"}),
    #"Removed Other Columns" = Table.SelectColumns(#"Expanded Modified By1",{"Modified By.id", "Email", "Type", "Name", "Modified"}),
    #"Sorted Rows" = Table.Sort(#"Removed Other Columns",{{"Modified By.id", Order.Ascending}}),
    #"Renamed Columns" = Table.RenameColumns(#"Sorted Rows",{{"Modified By.id", "User ID"}}),
    #"Changed Type" = Table.TransformColumnTypes(#"Renamed Columns",{{"User ID", Int64.Type}})
in
    #"Changed Type"
`
const expandRecordColumnPass = `
let
    Source = SharePoint.Tables("https://kerski.sharepoint.com", [Implementation="2.0", ViewMode="All"]),
    #"418be5b8-415e-4311-93ae-e659b4024a8d" = Source{[Id="418be5b8-415e-4311-93ae-e659b4024a8d"]}[Items],
    #"Expanded Modified By" = Table.ExpandListColumn(#"418be5b8-415e-4311-93ae-e659b4024a8d", "Modified By"),
    #"Expanded Modified By1" = Table.ExpandRecordColumn(#"Expanded Modified By", "Modified By", {"id", "email"}, {"Modified By.id", "Email"}),
    #"Removed Other Columns" = Table.SelectColumns(#"Expanded Modified By1",{"Modified By.id", "Email", "Type", "Name", "Modified"})
in
    #"Removed Other Columns"
`

describe('useNewColumnNamesForTableExpandRecordColumn Rule', () => {
  
  it('should return the expected RuleResult for expandRecordColumnFail', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(expandRecordColumnFail);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNewColumnNamesForTableExpandRecordColumn]);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(8);
    });
    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);
  });

  it('should return the expected RuleResult for expandRecordColumnFail2', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(expandRecordColumnFail2);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNewColumnNamesForTableExpandRecordColumn]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
    });

    expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(9);
  });  

  it('should return the expected RuleResult for expandRecordColumnPass', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(expandRecordColumnPass);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNewColumnNamesForTableExpandRecordColumn]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });    
    
});
