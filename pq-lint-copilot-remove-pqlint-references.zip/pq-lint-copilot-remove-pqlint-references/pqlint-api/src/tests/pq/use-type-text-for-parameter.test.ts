import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useTypeTextForParameter } from 'src/lint/pq/use-type-text-for-parameter';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';

// Test cases for different scenarios

// Test case: URL with "any" type (should fail)
const websiteURLFail = `
    "https://www.example.com" meta [IsParameterQuery = true, IsParameterQueryRequired = true, Type = type any ]
`;

// Test case: URL with "Any" type (should fail)
const websiteURLFail2 = `
    "https://www.example.com" meta [IsParameterQuery = true, IsParameterQueryRequired = true, Type="Any"]
`;

// Test case: SharePoint URL with "Any" type (should fail)
const sharePointURLFail = `
    "https://contoso.sharepoint.com/sites/ProjectX" meta [IsParameterQuery = true,IsParameterQueryRequired = true,Type=Any.Type]
`;

// Test case: Database hostname with "Any" type (should fail)
const databaseFail = `
"azure-sql-db-jk.database.windows.net" meta [
        IsParameterQuery = true,
        IsParameterQueryRequired = true,
        Type = "Any"
    ]`;

// Test case: File path with "Any" type (should fail)
const filePathFail = `
"C:\\Data\\Monthly\\SalesData.xlsx" meta [
        IsParameterQuery = true,
        IsParameterQueryRequired = true,
        Type = "Any"
    ]
`;

// Test case: SharePoint URL with "text" type (should pass)
const sharePointURLPass = `
    "https://contoso.sharepoint.com/sites/ProjectX" meta [IsParameterQuery = true,IsParameterQueryRequired = true,Type=type text]
`;

// Test case: Database hostname with "Text" type (should pass)
const databasePass = `
"azure-sql-db-jk.database.windows.net" meta [
        IsParameterQuery = true,
        IsParameterQueryRequired = true,
        Type = Text.Type
    ]`;

// Test case: File path with "Text" type (should pass)
const filePathPass = `
"C:\\Data\\Monthly\\SalesData.xlsx" meta [
        IsParameterQuery = true,
        IsParameterQueryRequired = true,
        Type = "Text"
    ]
`;

describe('useTypeTextForParameter Rule', () => {
    // Test case for failing URL with "any" type
    it('should return the expected RuleResult for websiteURLFail', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(websiteURLFail);
        const results: RuleResult[] = await lintMCode(parsedCode, [useTypeTextForParameter]);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(2);
        });
        expect(results.length).toBe(1);
    });

    // Test case for failing URL with "Any" type
    it('should return the expected RuleResult for websiteURLFail2', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(websiteURLFail2);
        const results: RuleResult[] = await lintMCode(parsedCode, [useTypeTextForParameter]);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(2);
        });
        expect(results.length).toBe(1);
    });

    // Test case for failing SharePoint URL with "Any" type
    it('should return the expected RuleResult for sharePointURLFail', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(sharePointURLFail);
        const results: RuleResult[] = await lintMCode(parsedCode, [useTypeTextForParameter]);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(2);
        });
        expect(results.length).toBe(1);
    });

    // Test case for failing database hostname with "Any" type
    it('should return the expected RuleResult for databaseFail', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(databaseFail);
        const results: RuleResult[] = await lintMCode(parsedCode, [useTypeTextForParameter]);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(2);
        });
        expect(results.length).toBe(1);
    });

    // Test case for failing file path with "Any" type
    it('should return the expected RuleResult for filePathFail', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(filePathFail);
        const results: RuleResult[] = await lintMCode(parsedCode, [useTypeTextForParameter]);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(2);
        });
        expect(results.length).toBe(1);
    });

    // Test case for passing SharePoint URL with "text" type
    it('should return the expected RuleResult for sharePointURLPass', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(sharePointURLPass);
        const results: RuleResult[] = await lintMCode(parsedCode, [useTypeTextForParameter]);
        expect(results.length).toBe(0);
    });

    // Test case for passing database hostname with "Text" type
    it('should return the expected RuleResult for databasePass', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(databasePass);
        const results: RuleResult[] = await lintMCode(parsedCode, [useTypeTextForParameter]);
        expect(results.length).toBe(0);
    });

    // Test case for passing file path with "Text" type
    it('should return the expected RuleResult for filePathPass', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(filePathPass);
        const results: RuleResult[] = await lintMCode(parsedCode, [useTypeTextForParameter]);
        expect(results.length).toBe(0);
    });
});