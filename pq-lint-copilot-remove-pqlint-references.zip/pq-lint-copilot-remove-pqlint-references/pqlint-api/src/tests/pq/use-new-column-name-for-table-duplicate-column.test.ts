import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useNewColumnNameForTableDuplicateColumn } from 'src/lint/pq/use-new-column-name-for-table-duplicate-column';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';

const duplicateColumnFail = `
let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales.xlsx"), null, true),
    FakeSales_Sheet = Source{[Item="FakeSales",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(FakeSales_Sheet, [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Duplicated Column" = Table.DuplicateColumn(#"Changed Type", "Date", "Date - Copy"),
    #"Renamed Columns" = Table.RenameColumns(#"Duplicated Column",{{"Date - Copy", "Start of Week"}})
in
    #"Renamed Columns"
`

const duplicateColumnFail2 = `
let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales.xlsx"), null, true),
    FakeSales_Sheet = Source{[Item="FakeSales",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(FakeSales_Sheet, [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Duplicated Column" = Table.DuplicateColumn(#"Changed Type", "Date", "Date2"),
    #"Renamed Columns" = Table.RenameColumns(#"Duplicated Column",{{"Date2", "Start of Week"}})
in
    #"Renamed Columns"
`

const duplicateColumnFail3 = `
let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales.xlsx"), null, true),
    FakeSales_Sheet = Source{[Item="FakeSales",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(FakeSales_Sheet, [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Duplicated Column" = Table.DuplicateColumn(#"Changed Type", "Sales Amount", "Sales Amount - Copy"),
    #"Changed Type1" = Table.TransformColumnTypes(#"Duplicated Column",{{"Sales Amount - Copy", Currency.Type}}),
    #"Renamed Columns" = Table.RenameColumns(#"Changed Type1",{{"Sales Amount - Copy", "Dollar Amount"}})
in
    #"Renamed Columns"
`

const duplicateColumnFail4 = `
let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales.xlsx"), null, true),
    FakeSales_Sheet = Source{[Item="FakeSales",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(FakeSales_Sheet, [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Duplicated Column" = Table.DuplicateColumn(#"Changed Type", "Sales Amount", "Sales Amount - Copy"),
    #"Changed Type1" = Table.TransformColumnTypes(#"Duplicated Column",{{"Sales Amount - Copy", Currency.Type}}),
    #"Renamed Columns" = Table.RenameColumns(#"Changed Type1",{{"Sales Amount - Copy", "Dollar Amount"}}),
    #"Duplicated Column1" = Table.DuplicateColumn(#"Renamed Columns", "Date", "Date - Copy"),
    #"Changed Type2" = Table.TransformColumnTypes(#"Duplicated Column1",{{"Date - Copy", type datetimezone}}),
    #"Renamed Columns1" = Table.RenameColumns(#"Changed Type2",{{"Date - Copy", "Date (TimeZone)"}})
in
    #"Renamed Columns1"
`

const duplicateColumnFail5 = `
let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales.xlsx"), null, true),
    FakeSales_Sheet = Source{[Item="FakeSales",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(FakeSales_Sheet, [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Duplicated Column" = Table.DuplicateColumn(#"Changed Type", "Sales Amount", "Sales Amount - Copy"),
    #"Changed Type1" = Table.TransformColumnTypes(#"Duplicated Column",{{"Sales Amount - Copy", Currency.Type}}),
    #"Duplicated Column1" = Table.DuplicateColumn(#"Changed Type1", "Date", "Date - Copy"),
    #"Changed Type2" = Table.TransformColumnTypes(#"Duplicated Column1",{{"Date - Copy", type datetimezone}}),
    #"Renamed Columns1" = Table.RenameColumns(#"Changed Type2",{{"Date - Copy", "Date (TimeZone)"}, {"Sales Amount - Copy", "Dollar Amount"}})
in
    #"Renamed Columns1"
`
const duplicateColumnPass = `
let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales.xlsx"), null, true),
    FakeSales_Sheet = Source{[Item="FakeSales",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(FakeSales_Sheet, [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Duplicated Column" = Table.DuplicateColumn(#"Changed Type", "Date", "Day of Week"),
    #"Calculated Day of Week" = Table.TransformColumns(#"Duplicated Column",{{"Day of Week", Date.DayOfWeek, Int64.Type}})
in
    #"Calculated Day of Week"
`
const duplicateColumnPass2 = `
let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales.xlsx"), null, true),
    FakeSales_Sheet = Source{[Item="FakeSales",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(FakeSales_Sheet, [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Duplicated Column" = Table.DuplicateColumn(#"Changed Type", "Sales Amount", "Dollar Amount", Currency.Type)
in
    #"Duplicated Column"
`

const duplicateColumnOnePass_OneFail = `
let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales.xlsx"), null, true),
    FakeSales_Sheet = Source{[Item="FakeSales",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(FakeSales_Sheet, [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Duplicated Column" = Table.DuplicateColumn(#"Changed Type", "Sales Amount", "Dollar Amount", Currency.Type),
    #"Duplicated Column1" = Table.DuplicateColumn(#"Duplicated Column", "Date", "Date (Timezone)", DateTimeZone.Type),
    #"Renamed Columns" = Table.RenameColumns(#"Duplicated Column1",{{"Dollar Amount", "Dollar Amount Change"}}),
    #"Sorted Rows" = Table.Sort(#"Renamed Columns",{{"Quantity", Order.Ascending}}),
    #"Renamed Columns1" = Table.RenameColumns(#"Sorted Rows",{"Quantity", "Renamed Quantity"})
in
    #"Renamed Columns1"
`

describe('useNewColumnNameForTableDuplicateColumn Rule', () => {
  
  it('should return the expected RuleResult for duplicateColumnFail', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(duplicateColumnFail);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNewColumnNameForTableDuplicateColumn]);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(8);
    });
    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);
  });

  it('should return the expected RuleResult for duplicateColumnFail2', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(duplicateColumnFail2);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNewColumnNameForTableDuplicateColumn]);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(8);
    });
    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);
  });  

  it('should return the expected RuleResult for duplicateColumnFail3', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(duplicateColumnFail3);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNewColumnNameForTableDuplicateColumn]);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(9);
    });
    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);
  });    

  it('should return the expected RuleResult for duplicateColumnFail4', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(duplicateColumnFail4);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNewColumnNameForTableDuplicateColumn]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(2);    

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
    });

      expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(9);
      expect(results[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(12);    

  }); 
  
  it('should return the expected RuleResult for duplicateColumnFail5', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(duplicateColumnFail5);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNewColumnNameForTableDuplicateColumn]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(2);    

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
    });

      expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(11);
      expect(results[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(11);    

  });    

  it('should return the expected RuleResult for duplicateColumnPass', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(duplicateColumnPass);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNewColumnNameForTableDuplicateColumn]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);    

  });     

  it('should return the expected RuleResult for duplicateColumnPass2', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(duplicateColumnPass2);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNewColumnNameForTableDuplicateColumn]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);    

  });     

  it('should return the expected RuleResult for duplicateColumnOnePass_OneFail', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(duplicateColumnOnePass_OneFail);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useNewColumnNameForTableDuplicateColumn]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);    

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
    });

      expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(9);   
  });    

});
