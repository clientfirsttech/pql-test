import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useDefaultForTableSplitColumn } from 'src/lint/pq/use-default-for-table-split-column';
import { ParseResult } from 'src/parser/pq/parse-types';
import { RuleResult } from 'src/lint/rule-types';
import * as path from 'path';
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure

// use-distinct-step-names
const _Use_Default_Pass_DataFilePath = path.resolve('./test-files/Files/use-default-for-table-split-column.SemanticModel/definition/tables/UseDefault_Success.tmdl');
const _Use_Default_Fail_DataFilePath = path.resolve('./test-files/Files/use-default-for-table-split-column.SemanticModel/definition/tables/UseDefault_Fail.tmdl');
const _SharePoint_Online_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SharePoint_Fail.tmdl');


describe('useDefaultForTableSplitColumn Rule', () => {
  it('should return the expected RuleResult for UseDefault_Fail', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parseHelper(_Use_Default_Fail_DataFilePath);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useDefaultForTableSplitColumn]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(4);
    });

  });

  it('should return the expected RuleResult for UseDefault_Pass', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parseHelper(_Use_Default_Pass_DataFilePath);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useDefaultForTableSplitColumn]);

    expect(results.length).toBe(0);
  });

  it('should return the expected RuleResult for SharePoint (Avoid False Positive)', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parseHelper(_SharePoint_Online_DataFilePath);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useDefaultForTableSplitColumn]);

    expect(results.length).toBe(0);
  });  


});
