import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useCountOrConditionForTableSkip } from 'src/lint/pq/use-count-or-condition-for-table-skip';
import * as path from 'path';

// useCountOrConditionForTableSkip Rule
const _uses_Condition_DataFilePath = path.resolve('./test-files/Files/use-count-or-condition-with-table-skip.SemanticModel/definition/tables/Uses_Condition.tmdl');
const _uses_Count_DataFilePath = path.resolve('./test-files/Files/use-count-or-condition-with-table-skip.SemanticModel/definition/tables/Uses_Count.tmdl');
const _does_Not_Use_Count_Or_Condition_DataFilePath = path.resolve('./test-files/Files/use-count-or-condition-with-table-skip.SemanticModel/definition/tables/No_Count_Or_Condition.tmdl');
const _count_Condition_Test_False_Positive_DataFilePath = path.resolve('./test-files/Files/use-count-or-condition-with-table-skip.SemanticModel/definition/tables/Count_Condition_Test_False_Positive.tmdl');
const _uses_Count_Once_DataFilePath = path.resolve('./test-files/Files/use-count-or-condition-with-table-skip.SemanticModel/definition/tables/Uses_Count_Once.tmdl');

describe('useCountOrConditionForTableSkip Rule', () => {
    it('should return the expected RuleResult for Uses_Condition.tmdl', async () => {
        const parsedCode = await parseHelper(_uses_Condition_DataFilePath);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useCountOrConditionForTableSkip]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });

    it('should return the expected RuleResult for Uses_Count.tmdl', async () => {
        const parsedCode = await parseHelper(_uses_Count_DataFilePath);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useCountOrConditionForTableSkip]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });
    
    it('should return the expected RuleResult for No_Count_Or_Condition.tmdl', async () => {
        const parsedCode = await parseHelper(_does_Not_Use_Count_Or_Condition_DataFilePath);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useCountOrConditionForTableSkip]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();

            // Check if the error location is correct
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(3);            
        });   
    });    

    it('should return the expected RuleResult for Count_Condition_Test_False_Positive.tmdl', async () => {
        const parsedCode = await parseHelper(_count_Condition_Test_False_Positive_DataFilePath);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useCountOrConditionForTableSkip]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });

    it('should return the expected RuleResult for Uses_Count_Once.tmdl', async () => {
        const parsedCode = await parseHelper(_uses_Count_Once_DataFilePath);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useCountOrConditionForTableSkip]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();

            // Check if the error location is correct
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(4);            
        });   
    });        
});

