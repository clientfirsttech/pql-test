import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { requireCommentForTableJoin } from 'src/lint/pq/require-comment-for-table-join'; // Adjust the import path according to your project structure
import * as path from 'path';

// require-comment-for-table-join
const _Join_MissingComment_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Join_MissingComment.tmdl');

describe('require-comment-for-table-join Rule', () => {
    it('should return the expected RuleResult for Join_MissingComment.tmdl', async () => {
        const parsedCode = await parseHelper(_Join_MissingComment_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireCommentForTableJoin]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });           
});