import { testAIFix } from '../rule-testing-assistance';
import { useTextLowerForExtensionFilter } from 'src/lint/pq/use-text-lower-for-extension-filter';
import * as path from 'path';
import * as fs from 'fs';

describe('AI: Rewrite use-text-lower-for-extension-filter Rule', () => {
    it('should fix extension filter violations', async () => {
        await testAIFix(
            aiFixTest,
            useTextLowerForExtensionFilter,
            1, // Expected number of violations
            { debug: true, fileName: 'use-text-lower-extension-filter' }
        );
    }, 60000);
});

const aiFixTest = `createOrReplace

	table Query1
		lineageTag: 250e5031-f8df-4f24-9109-a7c75afe8af4

		column Name
			dataType: string
			lineageTag: 6c8d8ae8-80ab-498d-8a4b-26279201ac45
			summarizeBy: none
			sourceColumn: Name

			annotation SummarizationSetBy = Automatic

		column Extension
			dataType: string
			lineageTag: 2887c593-b7bc-45f5-b9db-556fc60f6da4
			summarizeBy: none
			sourceColumn: Extension

			annotation SummarizationSetBy = Automatic

		column 'Date accessed'
			dataType: dateTime
			formatString: General Date
			lineageTag: c896f727-29c1-4ebf-991f-763dc6d265e0
			summarizeBy: none
			sourceColumn: Date accessed

			annotation SummarizationSetBy = Automatic

		column 'Date modified'
			dataType: dateTime
			formatString: General Date
			lineageTag: f484d3c3-3478-4fff-a8d6-2bbd9d6709d0
			summarizeBy: none
			sourceColumn: Date modified

			annotation SummarizationSetBy = Automatic

		column 'Date created'
			dataType: dateTime
			formatString: General Date
			lineageTag: 12a4303c-dd4f-4a9d-949f-8224322f68a4
			summarizeBy: none
			sourceColumn: Date created

			annotation SummarizationSetBy = Automatic

		column 'Folder Path'
			dataType: string
			lineageTag: 93af3e85-ae8b-4629-9be8-1ffd6a4a7b56
			summarizeBy: none
			sourceColumn: Folder Path

			annotation SummarizationSetBy = Automatic

		partition Query1 = m
			mode: import
			queryGroup: Fact
			source =
					let
					    Source = Folder.Files("C:\Users\JohnKerski\Downloads"),
					    #"Sorted Rows" = Table.Sort(Source,{{"Date modified", Order.Descending}}),
					    #"Kept First Rows" = Table.FirstN(#"Sorted Rows",10),
					    #"Filtered Rows" = Table.SelectRows(#"Kept First Rows", each ([Extension] = ".xlsx"))
					in
					    #"Filtered Rows"

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = Table
`