import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';
import useSharePointContentsForFiles from 'src/lint/pq/use-sharepoint-contents-for-files';


const _SPFolderUse = `
let
    Source = SharePoint.Files("https://kerski.sharepoint.com/sites/DocLibTest", [ApiVersion = 15]),
    #"Filtered Rows" = Table.SelectRows(Source, each Text.Contains([Folder Path], "https://kerski.sharepoint.com/sites/DocLibTest/Shared Documents/3/")),
    #"Lowercased Text" = Table.TransformColumns(#"Filtered Rows",{{"Extension", Text.Lower, type text}}),
    #"Filtered Rows1" = Table.SelectRows(#"Lowercased Text", each true),
    #"Filtered Hidden Files1" = Table.SelectRows(#"Filtered Rows1", each [Attributes]?[Hidden]? <> true),
    #"Invoke Custom Function1" = Table.AddColumn(#"Filtered Hidden Files1", "Transform File", each #"Transform File"([Content])),
    #"Removed Other Columns1" = Table.SelectColumns(#"Invoke Custom Function1", {"Transform File"}),
    #"Expanded Table Column1" = Table.ExpandTableColumn(#"Removed Other Columns1", "Transform File", Table.ColumnNames(#"Transform File"(#"Sample File"))),
    #"Changed Type" = Table.TransformColumnTypes(#"Expanded Table Column1",{{"project_name", type text}, {"project_description", type text}, {"start_date", type date}, {"end_date", type date}, {"project_manager", type text}, {"project_budget", type text}, {"project_status", type text}, {"client_name", type text}, {"client_email", type text}, {"client_phone", type text}})
in
    #"Changed Type"
`

const _SPFolderNoFolderPathFilter = `let
    Source = SharePoint.Files("https://kerski.sharepoint.com/sites/DocLibTest", [ApiVersion = 15]),
    #"Lowercased Text" = Table.TransformColumns(Source,{{"Extension", Text.Lower, type text}})
in
    #"Lowercased Text"`

describe('useSharePointContentsForFiles Rule', () => {
    it('should return the expected RuleResult for _SPFolderUse ', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(_SPFolderUse );
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        const results: RuleResult[] = await lintMCode(parsedCode, [useSharePointContentsForFiles]);
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(4);

    });

    it('should return the expected RuleResult for _SPFolderNoFolderPathFilter', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(_SPFolderNoFolderPathFilter);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        const results: RuleResult[] = await lintMCode(parsedCode, [useSharePointContentsForFiles]);
        expect(results.length).toBe(0);
    }); 

    it('should return the expected RuleResult for testNoFalsePositive', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(testNoFalsePositive);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        const results: RuleResult[] = await lintMCode(parsedCode, [useSharePointContentsForFiles]);
        expect(results.length).toBe(0);

    });
});


const testNoFalsePositive = `let
  Source = CommonDataService.Database(Domain, [CreateNavigationProperties = null]),
  #"Navigation 1" = Source{[Schema = "dbo", Item = "crfac_auditfindingrevamped"]}[Data],
  #"Dataverse Removals" = Table.RemoveColumns(#"Navigation 1", Table.ColumnsOfType(#"Navigation 1", {type table, type record, type list, type nullable binary, type binary, type function}),MissingField.Ignore),

    #"Removed unneeded columns" = Table.RemoveColumns(#"Dataverse Removals", {"createdonbehalfby", "modifiedonbehalfby", "createdbyyominame", "createdonbehalfbyname", "createdonbehalfbyyominame", "modifiedbyyominame", "modifiedonbehalfbyname", "modifiedonbehalfbyyominame", "ownerid", "owneridname", "owneridyominame", "owningbusinessunit", "owninguser", "owningteam", "owningbusinessunitname", "statecode", "statecodename", "statuscode", "statuscodename", "importsequencenumber", "crfac_isparentname", "overriddencreatedon", "utcconversiontimezonecode", "timezoneruleversionnumber", "modifiedby", "createdby", "crfac_fiscalyearname"},MissingField.Ignore),
    #"Renamed columns" = Table.RenameColumns(#"Removed unneeded columns", {{"crfac_pbcs", "PBC Number"}, {"crfac_statuscalc", "Finding Status Name"}, {"crfac_nistcontrolcalc", "NIST Control Number"}, {"crfac_isparent", "Is Parent?"}, {"crfac_parentlookupname", "Parent Name"}, {"crfac_parentlookup", "Parent GUID"}, {"crfac_auditorcontrolnumbers", "Auditor Control Number"}, {"crfac_responselookupname", "Response Name"}, {"crfac_responselookup", "Response GUID"}, {"crfac_previousreportfindingname", "Previous Finding Name"}, {"crfac_previousreportfinding", "Previous Finding GUID"}, {"crfac_recommendation", "Recommendation"}, {"crfac_criteria", "Criteria"}, {"crfac_effect", "Effect"}, {"crfac_cause", "Cause"}, {"crfac_observation", "Observation"}, {"crfac_facilityname", "Facility Number"}, {"crfac_facility", "Audit Target Schedule GUID"}, {"crfac_sourcereportname", "Source Report"}, {"crfac_findingnumber", "Title"}, {"createdon", "Created on"}, {"modifiedon", "Modified on"}, {"crfac_auditfindingrevampedid", "Audit Finding GUID"}, {"createdbyname", "Created by"}, {"modifiedbyname", "Modified by"}, {"crfac_fiscalyear", "Fiscal Year"}}),
    // Merged with the fiscal year table to bring in active column as well as the Fiscal Year - Number column
    #"Merged with Fiscal Years" = Table.NestedJoin(#"Renamed columns", {"Fiscal Year"}, #"Fiscal Years", {"ID"}, "Fiscal Year (2)", JoinKind.LeftOuter),
    #"Expanded Fiscal Year (2)" = Table.ExpandTableColumn(#"Merged with Fiscal Years", "Fiscal Year (2)", {"crfac_active", "Fiscal Year - Number"}, {"Active Fiscal Year?", "Fiscal_Year_C"}),
    // Merged to bring in source report name
    #"Merged with Source Report" = Table.NestedJoin(#"Expanded Fiscal Year (2)", {"crfac_sourcereport"}, #"Source Report", {"crfac_sourcereport"}, "Source Report (2)", JoinKind.LeftOuter),
    #"Expanded Source Report (2)" = Table.ExpandTableColumn(#"Merged with Source Report", "Source Report (2)", {"crfac_sourcereportname"}, {"Source Report Name"}),
    // Added facility and source report key to bring in IsCurrentSourceReport? column
    #"Added key for Current Source Report" = Table.AddColumn(#"Expanded Source Report (2)", "Custom", each [Facility Number] & [Source Report], type text),
   // Merged to create IsCurrentSourceReport column
    #"Merged queries1" = Table.NestedJoin(#"Added key for Current Source Report", {"Custom"}, #"findings per site by source report", {"Custom"}, "findings per site by source report", JoinKind.LeftOuter),
    #"Expanded findings per site by source report" = Table.ExpandTableColumn(#"Merged queries1", "findings per site by source report", {"crfac_sourcereport"}, {"crfac_sourcereport.1"}),
    #"Sorted rows" = Table.Sort(#"Expanded findings per site by source report", {{"Custom", Order.Descending}}),
    //Added IsCurrentSourceReport? Column
    #"Added IsCurrentSourceReport" = Table.AddColumn(#"Sorted rows", "IsCurrentSourceReport", each if [crfac_sourcereport.1] = null then false else if [crfac_sourcereport.1] = "" then false else true, type logical),
    #"Removed extra SourceReport columns" = Table.RemoveColumns(#"Added IsCurrentSourceReport", {"Custom", "crfac_sourcereport.1"}, MissingField.Ignore),
    #"Replace errors" = Table.ReplaceErrorValues(#"Removed extra SourceReport columns", {{"IsCurrentSourceReport", null}}),
    #"Remove columns17" = Table.RemoveColumns(#"Replace errors", Table.ColumnsOfType(#"Replace errors", {type table, type record, type list, type nullable binary, type binary, type function}), MissingField.Ignore),

// Merged with OIT Responses to bring in all needed finding fields
#"Merged OIT Responses" = Table.NestedJoin(#"Remove columns17", {"Response GUID"}, #"OIT Responses", {"crfac_newtable3id"}, "OIT Responses", JoinKind.LeftOuter),
    #"Expanded OIT Responses" = Table.ExpandTableColumn(#"Merged OIT Responses", "OIT Responses", {"Finding Number", "Auditor Inspector Comments", "Concurrence", "CSFC ECL Response", "Expected Completion Date", "GRC POAM Item ID", "NIST Control GUID", "Notes", "Number of Specific Instances", "OIG Sample Size", "OIS Justification", "OIT Data Size", "PBC", "POAM Required?", "Remediated on Site?", "Response Provided By", "Root Cause OIT", "Root Cause Risk Analysis GUID", "Root Cause Risk Category GUID", "Root Cause Risk Subcategory GUID", "SNOW Ticket Required?", "Stakeholders", "System Owner Response", "TA Response", "Control Number", "Analysis Category Name", "NIST Control Name", "Platform and Application Name", "Root Cause Risk Analysis", "Root Cause Risk Category", "Root Cause Risk Subcategory", "Status Name", "GRC Accreditation Boundary GUID", "Snow Ticket Number", "GRC Accreditation Boundary", "crfac_controlleaders", "crfac_controlproviders", "Next Steps", "ECSP Guidance", "Control Provider Response"}, {"Finding Number.1", "Auditor Inspector Comments", "Concurrence", "CSFC ECL Response", "Expected Completion Date", "GRC POAM Item ID", "NIST Control GUID", "Notes", "Number of Specific Instances", "OIG Sample Size", "OIS Justification", "OIT Data Size", "PBC", "POAM Required?", "Remediated on Site?", "Response Provided By", "Root Cause OIT", "Root Cause Risk Analysis GUID", "Root Cause Risk Category GUID", "Root Cause Risk Subcategory GUID", "SNOW Ticket Required?", "Stakeholders", "System Owner Response", "TA Response", "Control Number", "Analysis Category", "NIST Control Name", "Platform and Application Name", "Root Cause Risk Analysis", "Root Cause Risk Category", "Root Cause Risk Subcategory", "Status Name", "GRC Accreditation Boundary GUID", "Snow Ticket Number", "GRC Accreditation Boundary", "Control Leaders", "Control Providers", "Next Steps", "ECSP Guidance", "Control Provider Response"}),
   // Added ARCT Key column to merge with ARCT Mapping and bring in MWTA and NFRs
    #"Added ARCT Key" = Table.AddColumn(#"Expanded OIT Responses", "ARCT Key", each Number.ToText([Fiscal_Year_C], null, "en-US")&[Control Number], type text),
    // Merged with ARCT Mapping to bring in all of the needed fields from ARCT Mapping such as NFRs and MWTAs
    #"Merged ARCT Mapping" = Table.NestedJoin(#"Added ARCT Key", {"NIST Control GUID"}, #"ARCT Mapping", {"ARCT Mapping GUID"}, "ARCT Mapping", JoinKind.LeftOuter),
    #"Expanded ARCT Mapping" = Table.ExpandTableColumn(#"Merged ARCT Mapping", "ARCT Mapping", {"ARCT Analyst Email", "FISMA Topic Area", "MW Topic Area", "NFR Finding Number", "NIST Control Name", "OIT Remediation Oversight Area", "OIT Remediation Oversight Leader"}, {"ARCT Analyst Email",  "FISMA Topic Area", "MW Topic Area", "NFR Number", "NIST Control Name (ARCT Mapping)", "OIT Remediation Oversight Area", "OIT Remediation Oversight Leader"}) // "Control Family"
,
    // Added the findings open column for drill through purposes
    #"Added Finding Open?" = Table.AddColumn( #"Expanded ARCT Mapping", "Finding Open?", each if [Status Name] = "Closed" then 0 else 1, Int64.Type ),
    // Added POAM Required field for drill through purposes
    #"Added POAM Required?" = Table.AddColumn(#"Added Finding Open?", "POAM Required", each if [#"POAM Required?"] = true then 1 else 0, Int64.Type),
    #"Filter out blank Fiscal Years" = Table.SelectRows(#"Added POAM Required?", each ([Fiscal_Year_C] <> null and [Fiscal_Year_C] <> "")),
    #"Duplicated ARCT Mapping Column" = Table.DuplicateColumn(#"Filter out blank Fiscal Years", "ARCT Key", "ARCT Key - Copy"),
    // Added FIscal Year as date to properly account for the end of the fiscal years
    #"Added Fiscal Year as date" = Table.AddColumn(#"Duplicated ARCT Mapping Column", "Fiscal Year as Date", each #date(2000 + Number.FromText(Text.Range(Number.ToText([Fiscal_Year_C], null, "en-US"),2)),9,30), type date),
   
    // Merged with Date Dimension for date id
    #"Merged Date Dimension" = Table.NestedJoin(#"Added Fiscal Year as date", {"Fiscal Year as Date"}, #"Date Dimension", {"Date"}, "Date Dimension", JoinKind.LeftOuter),
    #"Expanded Date Dimension" = Table.ExpandTableColumn(#"Merged Date Dimension", "Date Dimension", {"Date ID"}, {"Date Dimension.Date ID"}),
    #"Removed Fiscal Year as date" = Table.RemoveColumns(#"Expanded Date Dimension",{"Fiscal Year as Date"}, MissingField.Ignore),
    // Added incomplete POAM column for paginated report
    #"Added Incomplete POAM" = Table.AddColumn(#"Removed Fiscal Year as date", "Incomplete POAM", each if [POAM Required] = 1 and [GRC POAM Item ID] = "" then 1 else 0, Int64.Type),
   // Added incomplete ticket column for paginated report
    #"Added Incomplete Tickets" = Table.AddColumn(#"Added Incomplete POAM", "Incomplete Tickets", each if [#"SNOW Ticket Required?"]= true and [Snow Ticket Number] = "" then 1 else 0, Int64.Type),
    // Added created ticket column for paginated report
    #"Added Ticket Created" = Table.AddColumn(#"Added Incomplete Tickets", "Ticket Created", each if [#"SNOW Ticket Required?"]= true and [Snow Ticket Number] <> "" then 1 else 0, Int64.Type),
    // Added POAM created column for paginated report
    #"Added POAM Created" = Table.AddColumn(#"Added Ticket Created", "POAM Created", each if [GRC POAM Item ID] = "" then 0 else if [GRC POAM Item ID] = null then 0 else 1, Int64.Type),
    // Added this to have distinct values for analysis categories and controls
    #"Added Control | Analyst Category" = Table.AddColumn(#"Added POAM Created", "Control | Analyst Category", each [NIST Control Number]&[Analysis Category], type text),
    // Merged with ATS for phase name, audit target name, and assessment type
    #"Merged with ATS" = Table.NestedJoin(#"Added Control | Analyst Category", {"Audit Target Schedule GUID"}, #"Audit Target Schedule", {"Audit Target Schedule GUID"}, "Audit Target Schedule", JoinKind.LeftOuter),
    #"Expanded Target Name & Phase" = Table.ExpandTableColumn(#"Merged with ATS", "Audit Target Schedule", {"Assessment Type Name", "Audit Target", "Control Provider Response Due", "Phase Name"}, {"Assessment Type Name", "Audit Target", "Control Provider Response Due", "Audit Target Phase"}),
    // Added FacilityKey for proper relationship and parameters for paginated reports
    #"Added Facility Key" = Table.AddColumn(#"Expanded Target Name & Phase", "FacilityKey", each Number.ToText([Fiscal_Year_C], null, "en-US")&[Audit Target], type text),
    #"Added Index Column" = Table.AddIndexColumn(#"Added Facility Key", "Index", 1, 1, Int64.Type),
    #"lowercased response provided by email" = Table.TransformColumns(#"Added Index Column",{{"Response Provided By", each Text.Lower(Text.Trim(Text.Clean(_)),"en-US"), type text}}),
    #"Replaced <br> in Stakeholders" = Table.ReplaceValue(#"lowercased response provided by email","<br>","|",Replacer.ReplaceText,{"Stakeholders"}),
    #"Replaced null Stakeholders" = Table.ReplaceValue(#"Replaced <br> in Stakeholders",null,"No Stakeholder Assignments",Replacer.ReplaceValue,{"Stakeholders"}),
    #"Replaced blank Stakeholders" = Table.ReplaceValue(#"Replaced null Stakeholders","","No Stakeholder Assignments",Replacer.ReplaceValue,{"Stakeholders"}),
    // Created custom column to remove the html from the stakeholder column
    #"Removed HTML from Stakeholders" = Table.AddColumn(#"Replaced blank Stakeholders", "Custom", each Html.Table([Stakeholders],{{"text",":root"}}), type text),
    #"Expanded Custom" = Table.ExpandTableColumn(#"Removed HTML from Stakeholders", "Custom", {"text"}, {"Staholders No HTML"}),
    #"Replaced Value4" = Table.ReplaceValue(#"Expanded Custom","|","#(cr)#(lf)",Replacer.ReplaceText,{"Staholders No HTML"}),
    #"Changed Created to Date" = Table.TransformColumnTypes(#"Replaced Value4",{{"Created on", type date}, {"Modified on", type date}}),
    #"Duplicated Column" = Table.DuplicateColumn(#"Changed Created to Date", "Created on", "Start of Week"),
    #"Duplicated Column14" = Table.DuplicateColumn(#"Duplicated Column", "Start of Week", "End of Week"),
    #"Calculated Start of Week" = Table.TransformColumns(#"Duplicated Column14",{{"Start of Week", each Date.StartOfWeek(_, Day.Monday), type date},{"End of Week", each Date.EndOfWeek(_, Day.Sunday), type date}}),
   
   // Added Week Number for the weekly review paginated report
    #"Added Start of Week Number" = Table.AddColumn(#"Calculated Start of Week", "Start of Week Number", each Date.WeekOfYear([Start of Week],Day.Monday), Int64.Type),
    // Added the WeeklyReviewKey for the paginated report
    #"Added WeeklyReviewKey" = Table.AddColumn(#"Added Start of Week Number", "WeeklyReviewKey", each [FacilityKey]&Date.ToText([Start of Week], null, "en-US"), type text),
    // Added SDCD Finding identifier for the SDCD report/ Carol Johnsons team
    #"Added SDCD Y/N" = Table.AddColumn(#"Added WeeklyReviewKey", "SDCD Y/N", each if Text.Contains([Staholders No HTML],"Robinson, Woodie L.",Comparer.OrdinalIgnoreCase) or Text.Contains([Staholders No HTML],"Johnson, Carol",Comparer.OrdinalIgnoreCase) or Text.Contains([Staholders No HTML],"McFadden, Trimaine",Comparer.OrdinalIgnoreCase) or Text.Contains([Staholders No HTML],"Zempko, Kevin",Comparer.OrdinalIgnoreCase) or Text.Contains([Staholders No HTML],"Cassella, Joseph",Comparer.OrdinalIgnoreCase)  or Text.Contains([Staholders No HTML],"Khan, Christopher",Comparer.OrdinalIgnoreCase) or Text.Contains([Staholders No HTML],"Willhite, Jason",Comparer.OrdinalIgnoreCase) then "SDCD" else "Non-SDCD", type text),
    // Added SDCD platofrm identifier for the SDCD report/ Carol Johnsons team
    #"Added SDCD PlatType" = Table.AddColumn(#"Added SDCD Y/N", "SDCD PlatType", each if [Observation] = null then "Non Medical/SPS"



else if Text.Contains([Observation],"medical devices",Comparer.OrdinalIgnoreCase) and Text.Contains([Observation],"special purposes systems",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"medical device",Comparer.OrdinalIgnoreCase) and Text.Contains([Observation],"special-purpose",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"medical device",Comparer.OrdinalIgnoreCase) and Text.Contains([Observation],"special purpose systems",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"MDIA",Comparer.OrdinalIgnoreCase) and Text.Contains([Observation],"special purposes systems",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"MDIA",Comparer.OrdinalIgnoreCase) and Text.Contains([Observation],"special purposes system",Comparer.OrdinalIgnoreCase) or  Text.Contains([Observation],"MDIA",Comparer.OrdinalIgnoreCase) and Text.Contains([Observation],"special-purpose",Comparer.OrdinalIgnoreCase) or
Text.Contains([Observation],"medical devices and special-purpose systems",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"medical devices and special-purpose systems",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"Medical Devices and Special Purpose Systems",Comparer.OrdinalIgnoreCase)  then "Medical/SPS"





else if Text.Contains([Observation],"Medical Device",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"Medical",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"MDIA",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"aligned with a specific system boundary",Comparer.OrdinalIgnoreCase)  then "Medical Device"





else if Text.Contains([Observation],"Special Purpose Systems",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"Special Purposes Systems",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"Special-Purpose",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"sps",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"video surveillance",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"air conditioning or heating",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"air-conditioning or heating",Comparer.OrdinalIgnoreCase)then "SPS"

else "Non Medical/SPS", type text),
// Removed the empty/ null concurrence responses and replaced with Awaiting response for display purposes in visuals
    #"Added Concurrence No Blanks" = Table.AddColumn(#"Added SDCD PlatType", "Concurrence No Blanks", each if [Concurrence] = null or [Concurrence] = "" then "Awaiting Response" else if [Concurrence] = "Non-Concur" or [Concurrence] = "Non-Concur - Lack of Information" then "Non-Concur" else [Concurrence], type text),
    // Removed the empty/ null MWTA responses and replaced with Awaiting response for display purposes in visuals
    #"Added MWTA w/o Blanks" = Table.AddColumn(#"Added Concurrence No Blanks", "Material Weakness Topic Area", each if [MW Topic Area] = null or [MW Topic Area] = "" then "Not Applicable" else [MW Topic Area], type text),
    #"Removed MWTA w/ Blanks" = Table.RemoveColumns(#"Added MWTA w/o Blanks",{"MW Topic Area"}, MissingField.Ignore),
    // Removed the empty/ null NIST Control responses and replaced with Not Assigned for display purposes in visuals
    #"Added Control Number w/o Blanks" = Table.AddColumn(#"Removed MWTA w/ Blanks", "NIST Control Number.1", each if [NIST Control Number] = null or [NIST Control Number] = "" then "Not Assigned" else [NIST Control Number], type text),
    // Removed the empty/ null NIST Control responses and replaced with Not Applicable for display purposes in visuals
    #"Added Control Name w/o blanks" = Table.AddColumn(#"Added Control Number w/o Blanks", "NIST Control Name No Blanks", each if [#"NIST Control Name (ARCT Mapping)"]="" or [#"NIST Control Name (ARCT Mapping)"]= null then "Not Applicable" else [#"NIST Control Name (ARCT Mapping)"], type text),
    #"Duplicated NFR" = Table.DuplicateColumn(#"Added Control Name w/o blanks", "NFR Number", "NFR Finding Number - Copy", type text),
    #"Split Copy NFR" = Table.SplitColumn(#"Duplicated NFR", "NFR Finding Number - Copy", Splitter.SplitTextByPositions({0, 3},  false), null, {"NFR Finding Number - Copy.1", "NFR Finding Number - Copy.2"}),
    #"Split Copy of NFR 2" = Table.SplitColumn(#"Split Copy NFR", "NFR Finding Number - Copy.2", Splitter.SplitTextByPositions({0, 2}, true),null, {"NFR Finding Number - Copy.2.1", "NFR Finding Number - Copy.2.2"}),
    // Merged Needed portions of the original NFR Column
    #"Added NFR w/o year" = Table.AddColumn(#"Split Copy of NFR 2", "NFR wo Year", each [#"NFR Finding Number - Copy.1"]&" "&[#"NFR Finding Number - Copy.2.2"], type text),
    // Removed all characters from NFR besides "NFR" and applicable number
    #"Added NFR" = Table.AddColumn(#"Added NFR w/o year", "NFR Finding Number", each if [NFR wo Year]="Not le" or [NFR wo Year]=null or [NFR wo Year]="" then "Not Assigned" else [NFR wo Year], type text),
   //Removed the null or blank values and replaced with "Not Assigned"
    #"Added Analysis Category Names no Blanks" = Table.AddColumn(#"Added NFR", "Analysis Category Name", each if [Analysis Category] ="" or [Analysis Category] = null then "Not Assigned" else [Analysis Category], type text),
    #"Removed Analysis Category w/ Blanks" = Table.RemoveColumns(#"Added Analysis Category Names no Blanks",{"Analysis Category","NFR Finding Number - Copy.1","NFR Finding Number - Copy.2.1", "NFR Finding Number - Copy.2.2", "NFR wo Year","NFR Number"}, MissingField.Ignore),
    // Added the categorization needed for the SDCD Reports (Carol Johnson is supposed to update us on additions to this if needed)
    #"Added SDCD Categorization" = Table.AddColumn(#"Removed Analysis Category w/ Blanks", "SDCD Categorization", each if [Observation] = null   then "No Category"

else if Text.Contains([Observation],"Vulnerability Reporting",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"Remediation Report",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"Remediation Reports",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"Unauthorized software",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"Unauthorized softwares",Comparer.OrdinalIgnoreCase) then "Vulnerability Reporting"

else if  Text.Contains([Observation],"System Boundary Alignment",Comparer.OrdinalIgnoreCase) then "System Boundary Alignment"

else if   Text.Contains([Observation],"System Back Up",Comparer.OrdinalIgnoreCase) then "System Back Up"

else if  Text.Contains([Observation],"ACL",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"NMAP",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"Access Control List",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"Access Control Lists",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"Segment",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"Segments",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"Segmentation",Comparer.OrdinalIgnoreCase) then "Vulnerability - Access Control List"

else if   Text.Contains([Observation],"Inventory",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"System Boundary Alignment",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"not been aligned with a specific system boundary",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"not associated with boundary",Comparer.OrdinalIgnoreCase) then "Inventory"

else if   Text.Contains([Observation],"ATO",Comparer.OrdinalIgnoreCase) or Text.Contains([Observation],"Authorization to Operate",Comparer.OrdinalIgnoreCase) then "ATO"

else "No Category", type text),
// Merged to bring in the financial system? column needed
    #"Merged Queries3" = Table.NestedJoin(#"Added SDCD Categorization", {"Platform and Application Name"}, #"Platform and Applications", {"System Name"}, "Platform and Applications", JoinKind.LeftOuter),
    #"Expanded Platform and Applications" = Table.ExpandTableColumn(#"Merged Queries3", "Platform and Applications", {"Financial System?"}, {"Financial System?"}),
    #"Replaced Value555" = Table.ReplaceValue(#"Expanded Platform and Applications",null,false,Replacer.ReplaceValue,{"Financial System?"}),
    // Added financial tag for the filter Terry wanted on the analysis report
    #"Added Financial vs Non" = Table.AddColumn(#"Replaced Value555", "Financial Systems", each if [#"Financial System?"] = true then "Financial" else "Non-Financial", type text),
   // Added SDCD Open vs Closed for the guage visual in the SDCD report
    #"Added SDCD Open vs Closed" = Table.AddColumn(#"Added Financial vs Non", "SDCD Open vs Closed", each if [Status Name] = "Remediated" or [Status Name] = "Closed" then "Closed" else "Open", type text),
    // Added FacilityKey with MWTA for the CIO brief groupinngs
    #"Added Custom" = Table.AddColumn(#"Added SDCD Open vs Closed", "FacilityKeyMWTA", each [FacilityKey]&[Material Weakness Topic Area], type text),
    #"Removed Empty Response GUIDs" = Table.SelectRows(#"Added Custom", each [Response GUID] <> null and [Response GUID] <> "")
in
    #"Removed Empty Response GUIDs"`