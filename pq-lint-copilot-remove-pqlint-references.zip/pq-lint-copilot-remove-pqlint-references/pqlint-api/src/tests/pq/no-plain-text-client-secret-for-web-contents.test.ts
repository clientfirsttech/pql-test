import { lintMCode } from 'src/lint/linter-module'  // Adjust the import path according to your project structure
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';
import noPlainTextClientSecretForWebContents from 'src/lint/pq/no-plain-text-client-secret-for-web-contents';

// M Code example with Authorization header using "Bearer" and a token
const headersTokenUsage = `let
    Source = (GroupID) as text =>
   let 
   Token = GetTokenPPU(AuthorityURL,ClientID,ClientSecret,UserName,Password,ResourceURL,TenantID),
   Params =
        [ 
            Headers = [#"Content-Type"="application/json",#"Authorization"="Bearer " & Token],
            RelativePath = "v1.0/myorg/groups/" & GroupID & "/datasets"
        ],
    // Get Pages
    // Hard-coded Base URL because Power BI Service won't recognize parameter despite numerous attempts 
    WebSource = Web.Contents("https://api.powerbi.com",Params),
    // Convert to Json
    Result = Text.FromBinary(WebSource)
in
Result
in
    Source
`

// M Code example with Authorization header using "Bearer" and a different token variable
const headersTokenUsageSecondVersion = `let
    Source = Json.Document(Web.Contents(GraphUrl & "groups",[Headers = [Authorization = "Bearer " & fx_AuthToken]]))
    in
    Source
`

// M Code example with Authorization header using "Bearer" and a different token variable
const headersTokenUsageThirdVersion = `let
    RecordCount = Json.Document(
        Web.Contents(
            GraphUrl & "groups/" & GroupID & "/datasets/" & DatasetID & "/tables/" & TableName & "/rows",
            [Headers = [Authorization = "Bearer " & fx_AuthToken(),
            ConsistencyLevel = "eventual"]]
)
)
    in
    RecordCount
`

// M Code example with Authorization header but without "Bearer"
const headersTokenUsageNoBearer = `let
    Source = (GroupID) as text =>
   let 
   Token = GetTokenPPU(AuthorityURL,ClientID,ClientSecret,UserName,Password,ResourceURL,TenantID),
   Params =
        [ 
            Headers = [#"Content-Type"="application/json",#"Authorization"="xxxx"],
            RelativePath = "v1.0/myorg/groups/" & GroupID & "/datasets"
        ],
    // Get Pages
    // Hard-coded Base URL because Power BI Service won't recognize parameter despite numerous attempts 
    WebSource = Web.Contents("https://api.powerbi.com",Params),
    // Convert to Json
    Result = Text.FromBinary(WebSource)
in
Result
in
    Source
`

describe('noPlainTextClientSecret Rule', () => {
    it('should return the expected RuleResult for Authorization with Bearer', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(headersTokenUsage);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noPlainTextClientSecretForWebContents]);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(7);
        });
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);
    });   

    it('should return the expected RuleResult for Authorization with Bearer (Version 2)', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(headersTokenUsageSecondVersion);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noPlainTextClientSecretForWebContents]);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(2);
        });
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);
    });    

    it('should return the expected RuleResult for Authorization with Bearer (Version 3)', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(headersTokenUsageThirdVersion);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noPlainTextClientSecretForWebContents]);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(5);
        });
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);
    });     

    it('should return the expected RuleResult for Authorization No Bearer', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(headersTokenUsageNoBearer);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noPlainTextClientSecretForWebContents]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });      
    
 
});