import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useParametersForConnectionsAndPaths } from 'src/lint/pq/use-parameters-for-connections-and-paths';
import * as path from 'path';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { ParseResult } from 'src/parser/pq/parse-types';
import { RuleResult } from 'src/lint/rule-types';
import { logDebug } from 'src/lint/rule-assistance';
import * as fs from 'fs';


describe('use-parameters-for-connections-and-paths Rule', () => {
   it('should return the expected RuleResult for File_Path_Literal_Fail.tmdl (File Path hardcoded)', async () => {
        const parsedCode = await parseHelper(_LOCAL_TEXT_LITERAL_PATH_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useParametersForConnectionsAndPaths]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });
    });

    it('should return the expected RuleResult for _SP_HTTP_Fail (SharePoint hardcoded)', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(_SP_HTTP_Fail);
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useParametersForConnectionsAndPaths]);

        // Check if the results match the expected RuleResult
        logDebug('Results:', JSON.stringify(results));
        expect(results.length).toBe(1);
        
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(3);
    });

    it('should return the expected RuleResult for a Parameter', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(pathParameter);
        //logDebug(JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useParametersForConnectionsAndPaths]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });

    it('should return the expected RuleResult for DateDim', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(_DateDim);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useParametersForConnectionsAndPaths]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });  
    
    it('should return the expected RuleResult for sqlTest', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(sqlTest);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useParametersForConnectionsAndPaths]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(4);        
    });  

    it('should return the expected RuleResult for sqlTestWithParam', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(sqlTestWithParam);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useParametersForConnectionsAndPaths]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);      
    });      

    it('should return the expected RuleResult for sqlTestWithParam2', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(sqlTestWithParam2);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useParametersForConnectionsAndPaths]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);      
    });       
    
    it('should return the expected RuleResult for webContents', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(webContentsTest);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useParametersForConnectionsAndPaths]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(3);        
    });   
    
    it('should return the expected RuleResult for functionTest', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(functionTest);
        console.log('Parsed Code:', JSON.stringify(parsedCode));
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useParametersForConnectionsAndPaths],true);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);      
    });     
    
    it('should return the expected RuleResult for webUrlTest', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(webURLTest);
        console.log('Parsed Code:', JSON.stringify(parsedCode));
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useParametersForConnectionsAndPaths],true);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);      
    }); 
    
    it('should return the expected RuleResult for oracleTest', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(oracleTest);
        // Create directory if it doesn't exist
        const outputDir = path.resolve('./src/lint/parsed_files');
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }
        
        // Save parsed code to JSON file
        const outputPath = path.join(outputDir, 'oracletest.json');
        fs.writeFileSync(outputPath, JSON.stringify(parsedCode.ast, null, 2));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useParametersForConnectionsAndPaths],true);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);      
    });     

    it('should return the expected RuleResult for Azure Databricks Test', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(azureDatabricksTest);
        // Create directory if it doesn't exist
        const outputDir = path.resolve('./src/lint/parsed_files');
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }
        
        // Save parsed code to JSON file
        const outputPath = path.join(outputDir, 'databrickstest.json');
        fs.writeFileSync(outputPath, JSON.stringify(parsedCode.ast, null, 2));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useParametersForConnectionsAndPaths],true);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);      
    });      

    it('should return the expected RuleResult for non-Azure Databricks Test', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(nonAzureDatabricksTest);
        // Create directory if it doesn't exist
        const outputDir = path.resolve('./src/lint/parsed_files');
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }
        
        // Save parsed code to JSON file
        const outputPath = path.join(outputDir, 'nonAzureDatabrickstest.json');
        fs.writeFileSync(outputPath, JSON.stringify(parsedCode.ast, null, 2));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useParametersForConnectionsAndPaths],true);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);      
    });    
    
    it('should return the expected RuleResult for non-Azure Databricks Test Pass', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(nonAzureDatabricksTestPass);
        // Create directory if it doesn't exist
        const outputDir = path.resolve('./src/lint/parsed_files');
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }
        
        // Save parsed code to JSON file
        const outputPath = path.join(outputDir, 'nonAzureDatabrickstestPass.json');
        fs.writeFileSync(outputPath, JSON.stringify(parsedCode.ast, null, 2));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useParametersForConnectionsAndPaths],true);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);      
    });  
    
    it('should return the expected RuleResult for Foundry Test Pass', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(foundryTestPass);
        // Create directory if it doesn't exist
        const outputDir = path.resolve('./src/lint/parsed_files');
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }
        
        // Save parsed code to JSON file
        const outputPath = path.join(outputDir, 'foundryTestPass.json');
        fs.writeFileSync(outputPath, JSON.stringify(parsedCode.ast, null, 2));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useParametersForConnectionsAndPaths],true);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);      
    });    
    
    it('should return the expected RuleResult for Foundry Test Fail', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(foundryTestFail);
        // Create directory if it doesn't exist
        const outputDir = path.resolve('./src/lint/parsed_files');
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }
        
        // Save parsed code to JSON file
        const outputPath = path.join(outputDir, 'foundryTestFail.json');
        fs.writeFileSync(outputPath, JSON.stringify(parsedCode.ast, null, 2));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useParametersForConnectionsAndPaths],true);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);      
        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(3);
    });     

});


// use-parameters-for-connections-and-paths Rule
const _LOCAL_TEXT_LITERAL_PATH_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/File_Path_Literal_Fail.tmdl');
const _SP_HTTP_Fail = `
    let
        Source = SharePoint.Tables("https://kerski.sharepoint.com/sites/SPRefreshTest", [Implementation="2.0", ViewMode="All"]),
        #"ab6cbd60-18de-42ea-b2a6-dc9fdb7e34c5" = Source{[Id="ab6cbd60-18de-42ea-b2a6-dc9fdb7e34c5"]}[Items],
        #"Renamed Columns" = Table.RenameColumns(#"ab6cbd60-18de-42ea-b2a6-dc9fdb7e34c5",{{"ID", "ID.1"}})
    in
        #"Renamed Columns"
`

const pathParameter = `
"https://oai-pbix.openai.azure.com/openai/deployments/pbi-4o/chat/completions?api-version=2023-07-01-preview" meta [IsParameterQuery = true, IsParameterQueryRequired = true, Type = type text]
`
const _DateDim = `
let
    Source = MarvelSource,
    #"Removed Other Columns" = Table.SelectColumns(Source,{"FIRST APPEARANCE", "Year"}),
    #"Split Column by Delimiter" = Table.SplitColumn(#"Removed Other Columns", "FIRST APPEARANCE", Splitter.SplitTextByDelimiter("-", QuoteStyle.Csv), {"FIRST APPEARANCE.1", "FIRST APPEARANCE.2"}),
    #"Changed Type1" = Table.TransformColumnTypes(#"Split Column by Delimiter",{{"FIRST APPEARANCE.1", type text}, {"FIRST APPEARANCE.2", Int64.Type}}),
    #"Added Custom" = Table.AddColumn(#"Changed Type1", "Date", each Date.FromText([FIRST APPEARANCE.1]&" 1, "&Text.From([Year]))),
    #"Filtered Rows" = Table.SelectRows(#"Added Custom", each ([Date] <> null)),
    #"Sorted Rows" = Table.Sort(#"Filtered Rows",{{"Date", Order.Ascending}}),
    #"Removed Columns" = Table.RemoveColumns(#"Sorted Rows",{"FIRST APPEARANCE.1", "FIRST APPEARANCE.2", "Year"}),
    #"Added Custom1" = Table.AddColumn(#"Removed Columns", "EndDate", each Date.From(DateTime.LocalNow())),
    #"Filtered Rows1" = Table.SelectRows(#"Added Custom1", let earliest = List.Min(#"Added Custom1"[Date]) in each [Date] = earliest),
    #"Removed Duplicates" = Table.Distinct(#"Filtered Rows1", {"Date"}),
    #"Renamed Columns" = Table.RenameColumns(#"Removed Duplicates",{{"Date", "StartDate"}}),
    #"Added Custom2" = Table.AddColumn(#"Renamed Columns", "Dates", each {Number.From([StartDate])..Number.From([EndDate])}),
    #"Expanded Dates" = Table.ExpandListColumn(#"Added Custom2", "Dates"),
    #"Changed Type2" = Table.TransformColumnTypes(#"Expanded Dates",{{"Dates", type date}}),
    #"Filter1stMonth" = Table.SelectRows(#"Changed Type2", each Date.Day([Dates]) = 1),
    #"Removed Columns1" = Table.RemoveColumns(#"Filter1stMonth",{"StartDate", "EndDate"}),
    #"Added Index" = Table.AddIndexColumn(#"Removed Columns1", "Index", 1, 1, Int64.Type),
    #"Reordered Columns" = Table.ReorderColumns(#"Added Index",{"Index", "Dates"}),
    #"Added Custom3" = Table.AddColumn(#"Reordered Columns", "DateKey", each Date.ToText([Dates],"MMM-yyyy")),
    #"Renamed Columns1" = Table.RenameColumns(#"Added Custom3",{{"Dates", "Date"}, {"Index", "DateID"}}),
    #"Appended Query" = Table.Combine({#"Renamed Columns1", DateDimBlank}),
    #"Sorted Rows1" = Table.Sort(#"Appended Query",{{"DateID", Order.Ascending}}),
    #"Replaced Value" = Table.ReplaceValue(#"Sorted Rows1","","Jan-0001",Replacer.ReplaceValue,{"DateKey"}),
    #"Added Custom4" = Table.AddColumn(#"Replaced Value", "MonthYearSort", each Date.Year([Date])*100 + Date.Month([Date]))
in
    #"Added Custom4"`

const sqlTest = `
let
    // Define the SQL Server connection details
    Source = Sql.Database("your-server-name.database.windows.net", "your-database-name", [
        CreateNavigationProperties = true,
        Query = "SELECT TOP 100 * FROM your_table_name"
    ])
in
    Source
`

const sqlTestWithParam = `
let
    // Define the SQL Server connection details
    Source = Sql.Database(#"SQL Connection", "your-database-name", [
        CreateNavigationProperties = true,
        Query = "SELECT TOP 100 * FROM your_table_name"
    ])
in
    Source
`

const sqlTestWithParam2 = `
let
    // Define the SQL Server connection details
    Source = Sql.Database(SQLConnection, "your-database-name", [
        CreateNavigationProperties = true,
        Query = "SELECT TOP 100 * FROM your_table_name"
    ])
in
    Source
`

const webContentsTest = `
    let
        Source = Json.Document(Web.Contents("https://graph.microsoft.com/v1.0/planner/plans/o0F8dLRD302lGhJbE3K2q2UADy3v/tasks")),
        #"Converted to Table" = Table.FromRecords({Source}),
        #"Expanded value" = Table.ExpandListColumn(#"Converted to Table", "value"),
        #"Expanded value1" = Table.ExpandRecordColumn(#"Expanded value", "value", {"@odata.etag", "planId", "bucketId", "title", "orderHint", "assigneePriority", "percentComplete", "startDateTime", "createdDateTime", "dueDateTime", "hasDescription", "previewType", "completedDateTime", "referenceCount", "checklistItemCount", "activeChecklistItemCount", "conversationThreadId", "priority", "id", "completedBy", "createdBy", "appliedCategories", "assignments"}, {"value.@odata.etag", "value.planId", "value.bucketId", "value.title", "value.orderHint", "value.assigneePriority", "value.percentComplete", "value.startDateTime", "value.createdDateTime", "value.dueDateTime", "value.hasDescription", "value.previewType", "value.completedDateTime", "value.referenceCount", "value.checklistItemCount", "value.activeChecklistItemCount", "value.conversationThreadId", "value.priority", "value.id", "value.completedBy", "value.createdBy", "value.appliedCategories", "value.assignments"}),
        #"Expanded value.createdBy" = Table.ExpandRecordColumn(#"Expanded value1", "value.createdBy", {"application", "user"}, {"value.createdBy.application", "value.createdBy.user"}),
        #"Expanded value.createdBy.application" = Table.ExpandRecordColumn(#"Expanded value.createdBy", "value.createdBy.application", {"displayName", "id"}, {"value.createdBy.application.displayName", "value.createdBy.application.id"}),
        #"Expanded value.createdBy.user" = Table.ExpandRecordColumn(#"Expanded value.createdBy.application", "value.createdBy.user", {"displayName", "id"}, {"value.createdBy.user.displayName", "value.createdBy.user.id"}),
        #"Expanded value.appliedCategories" = Table.ExpandRecordColumn(#"Expanded value.createdBy.user", "value.appliedCategories", {"category5", "category3", "category2", "category1", "category11"}, {"value.appliedCategories.category5", "value.appliedCategories.category3", "value.appliedCategories.category2", "value.appliedCategories.category1", "value.appliedCategories.category11"}),
        #"Expanded value.assignments" = Table.ExpandRecordColumn(#"Expanded value.appliedCategories", "value.assignments", {}, {}),
        #"Changed Type" = Table.TransformColumnTypes(#"Expanded value.assignments",{{"@odata.context", type text}, {"@odata.count", Int64.Type}, {"value.@odata.etag", type text}, {"value.planId", type text}, {"value.bucketId", type text}, {"value.title", type text}, {"value.orderHint", type text}, {"value.assigneePriority", type any}, {"value.percentComplete", Int64.Type}, {"value.startDateTime", type any}, {"value.createdDateTime", type datetime}, {"value.dueDateTime", type any}, {"value.hasDescription", type logical}, {"value.previewType", type text}, {"value.completedDateTime", type any}, {"value.referenceCount", Int64.Type}, {"value.checklistItemCount", Int64.Type}, {"value.activeChecklistItemCount", Int64.Type}, {"value.conversationThreadId", type any}, {"value.priority", Int64.Type}, {"value.id", type text}, {"value.completedBy", type any}, {"value.createdBy.application.displayName", type any}, {"value.createdBy.application.id", type text}, {"value.createdBy.user.displayName", type any}, {"value.createdBy.user.id", type text}, {"value.appliedCategories.category5", type logical}, {"value.appliedCategories.category3", type logical}, {"value.appliedCategories.category2", type logical}, {"value.appliedCategories.category1", type logical}, {"value.appliedCategories.category11", type logical}})
    in
        #"Changed Type"
`

const functionTest = `
let
  Source = (ListName as text) =>
    let
      _X = (ListName) =>
        let

          // Define internal function                           
          _GetJsonFromSharePoint = (url) as any  =>
            let

              //Set Options and odata/json response                                     
              Options = [RelativePath = url, Headers = [Accept = "application/json;odata=verbose"]],
              RawData = Web.Contents(#"SharePoint URL", Options),
              Json = Json.Document(RawData)
            in
              Json,
          // Define Next Link internal function                                     
          _GetNextLink = (jsonResults) as text =>
            let
              #"Converted to Table" = Record.ToTable(jsonResults),
              #"Expanded Value" = Table.ExpandRecordColumn(
                #"Converted to Table",
                "Value",
                {"__next"},
                {"Value.__next"}
              ),
              #"Removed Columns" = Table.RemoveColumns(#"Expanded Value", {"Name"})
            in
              Table.FirstValue(#"Removed Columns"),
          //With the internal functions defined, get the data                                                   
          Json = _GetJsonFromSharePoint(
            "_api/lists/GetByTitle('"
              & ListName
              & "')/fields?$select=Title,Description,InternalName,SchemaXml,TypeAsString,Group,FromBaseType,IsDependentLookup,Id,PrimaryFieldId"
          ),
          // Convert to List                  
          Records = Json[d][results],
          #"Converted to Table" = Table.FromList(
            Records,
            Splitter.SplitByNothing(),
            null,
            null,
            ExtraValues.Error
          ),
          #"Expanded Column1" = Table.ExpandRecordColumn(
            #"Converted to Table",
            "Column1",
            {
              "Description",
              "InternalName",
              "SchemaXml",
              "Title",
              "TypeAsString",
              "Group",
              "FromBaseType",
              "IsDependentLookup",
              "Id",
              "PrimaryFieldId"
            },
            {
              "Description",
              "InternalName",
              "SchemaXml",
              "Title",
              "TypeAsString",
              "Group",
              "FromBaseType",
              "IsDependentLookup",
              "Id",
              "PrimaryFieldId"              
            }
          ),
          #"Removed Other Columns" = Table.SelectColumns(
            #"Expanded Column1",
            {
              "Description",
              "InternalName",
              "SchemaXml",
              "Title",
              "TypeAsString",
              "Group",
              "FromBaseType",
              "IsDependentLookup",
              "Id",
              "PrimaryFieldId"              
            }
          ),
          #"Reordered Columns" = Table.ReorderColumns(
            #"Removed Other Columns",
            {"Title", "Description", "InternalName", "SchemaXml", "TypeAsString"}
          ),
          #"Parsed XML" = Table.TransformColumns(#"Reordered Columns", {{"SchemaXml", Xml.Tables}}),
          // Filter out columns that don't make part of the custom list or will be difficult to query                                                                                           
          #"Filtered Rows1" = Table.SelectRows(
            #"Parsed XML",
            each (
              (
                [FromBaseType]
                  = false or [InternalName]
                  = "Author" or [InternalName]
                  = "Created" or [InternalName]
                  = "Editor" or [InternalName]
                  = "Modified" or [InternalName]
                  = "Title" or [InternalName]
                  = "ID" or [InternalName]
                  = "Attachments"
              )
            )
              and [InternalName]
              <> "_CommentFlags" and [InternalName]
              <> "_CommentCount"
          ),
          // Get Lookup column values                           
          #"Expanded SchemaXml" = Table.ExpandTableColumn(
            #"Filtered Rows1",
            "SchemaXml",
            {"Attribute:ShowField"},
            {"SchemaXml.Attribute:ShowField"}
          ),
          #"Renamed Columns" = Table.RenameColumns(
            #"Expanded SchemaXml",
            {{"SchemaXml.Attribute:ShowField", "Lookup Field"}}
          ),
          // Change IsDependentLookup to logical
          #"IsDependentLookup Change" = Table.TransformColumnTypes(#"Renamed Columns",{{"IsDependentLookup", type logical}}),
          // Get secondary lookup name
          #"Merged Queries" = Table.NestedJoin(#"IsDependentLookup Change", {"PrimaryFieldId"}, #"Renamed Columns", {"Id"}, "SecondaryLookup", JoinKind.LeftOuter),
          #"Expand Secondary Lookup" = Table.ExpandTableColumn(#"Merged Queries", "SecondaryLookup", {"InternalName"}, {"SecondaryLookup.InternalName"}),
          // Prepare column to represent the select parameter for an Odata query                                                                      
          #"Add Select Parameter" = Table.AddColumn(
            #"Expand Secondary Lookup",
            "Select Parameter",
            each
              // Handle secondary lookup first
              if ([TypeAsString] = "Lookup" or [TypeAsString] = "LookupMulti") and [IsDependentLookup] = true then 
                [SecondaryLookup.InternalName] & "/" & [Lookup Field] 
              else if [TypeAsString] = "Lookup" or [TypeAsString] = "LookupMulti" then
                [InternalName] & "/" & [Lookup Field]
              else if [TypeAsString] = "User" or [TypeAsString] = "UserMulti" then
                [InternalName] & "/EMail," & [InternalName] & "/Title"
              else if [TypeAsString] = "Attachments" then
                [InternalName] & ",AttachmentFiles"
              else
                [InternalName]
          ),
          // Prepare column to represent the expand parameter for lookup columns in an Odata query                                                                                        
          #"Added Expand Parameter" = Table.AddColumn(
            #"Add Select Parameter",
            "Expand Parameter",
            each
              // Handle secondary lookup
              if ([TypeAsString]
                = "Lookup" or [TypeAsString]
                = "LookupMulti" or [TypeAsString]
                = "User" or [TypeAsString] = "UserMulti") and [IsDependentLookup] = true then
                [SecondaryLookup.InternalName]
              else if ([TypeAsString]
                = "Lookup" or [TypeAsString]
                = "LookupMulti" or [TypeAsString]
                = "User" or [TypeAsString] = "UserMulti") then
                [InternalName]
              else if [TypeAsString] = "Attachments" then
                "AttachmentFiles"
              else
                null
          ),
          #"Added Table Expand Argument - Display Name" = Table.AddColumn(
            #"Added Expand Parameter",
            "Table Expand Argument - Display Name",
            each
              // Handle secondary lookup
              if ([TypeAsString]
                = "Lookup" or [TypeAsString]
                = "LookupMulti" or [TypeAsString]
                = "User" or [TypeAsString] = "UserMulti") and [IsDependentLookup] = true then
                null
              else if [TypeAsString] = "Attachments" then
                "AttachmentFiles"                
              else
                [Title]
          ), 
          #"Added Table Expand Argument - Internal Name" = Table.AddColumn(
            #"Added Table Expand Argument - Display Name",
            "Table Expand Argument - Internal Name",
            each
              // Handle secondary lookup
              if ([TypeAsString]
                = "Lookup" or [TypeAsString]
                = "LookupMulti" or [TypeAsString]
                = "User" or [TypeAsString] = "UserMulti") and [IsDependentLookup] = true then
                null
              else if [TypeAsString] = "Attachments" then
                "AttachmentFiles"                 
              else
                [InternalName]
          ),                    
          // Reduce columns to return
          #"Reduce Columns" = Table.SelectColumns(#"Added Table Expand Argument - Internal Name",{"Title", "Description", "TypeAsString", "InternalName", "Select Parameter", "Expand Parameter","Table Expand Argument - Display Name","Table Expand Argument - Internal Name"}),          
          Results = Table.AddColumn(#"Reduce Columns", "List Name", each ListName),
          #"Renamed columns" = Table.RenameColumns(Results, {{"TypeAsString", "Type As String"}, {"InternalName", "Internal Name"}}),
          TextFormattedResults = Table.TransformColumnTypes(#"Renamed columns",List.Transform(Table.ColumnNames(#"Renamed columns"), each {_, type text}))
        in
          TextFormattedResults
    in
      _X(ListName),
  documentation = [
    Documentation.Name = "fnGetFields ",
    Documentation.Description = "Returns curated list of fields for the SharePoint list provided.",
    Documentation.LongDescription
      = "This function accepts a list name and will retrieve a curated list of columns from the SharePoint site.  All custom columns from the SharePoint site are retrieved, along with the ID, Created, Created By, Modified, and Modified By fields. The additional columns that appear after calling this function are used to building the SharePoint REST API query so you don’t have to.",
    Documentation.Category = " SharePoint ",
    Documentation.Source = "https://github.com/kerski/power-query-sharepoint-faster-easier",
    Documentation.Version = "1",
    Documentation.Author = " John Kerski ",
    Documentation.Examples = {
      [Description = "  ", Code = "fnGetFields( ""List Name"") ", Result = " #table "]
    }
  ],
  Custom = Value.ReplaceType(Source, Value.ReplaceMetadata(Value.Type(Source), documentation))
in
  Custom`

let webURLTest = `"https://raw.githubusercontent.com/fivethirtyeight/data/master/comic-characters/marvel-wikia-data.csv" meta [IsParameterQuery=true, Type="Any", IsParameterQueryRequired=true]`

let oracleTest = `let
    Source = Oracle.Database("xyz11111.eu-dev.en:2222/test", [HierarchicalNavigation=true, CommandTimeout=#duration(0, 1, 0, 0)]),
    DB = Source{[Schema="POWER_BI"]}[Data],
    REPORTING = DB{[Name="FACT"]}[Data],
    #"Filtered Rows" = Table.SelectRows(REPORTING, each [REPORT_ID] = 1234)
in
    #"Filtered Rows"`

let azureDatabricksTest = `				let
				    Source = Databricks.Catalogs("adb-3064640522536671.11.azuredatabricks.net", "/sql/1.0/warehouses/98ceb408688023cf", [Catalog = "ws_ncvas", Database = "silver"]),
				    contract_and_investment_performance_silver_ws_ncvas = Source{[Item="contract_and_investment_performance",Schema="silver",Catalog="ws_ncvas"]}[Data],
				    #"Changed Type" = Table.TransformColumnTypes(contract_and_investment_performance_silver_ws_ncvas,{{"updatedTime", type datetime}}),
				    #"Removed Errors" = Table.RemoveRowsWithErrors(#"Changed Type", {"updatedTime"}),
				    #"Filtered Rows" = Table.SelectRows(#"Removed Errors", each [updatedTime] >= RangeStart and [updatedTime] < RangeEnd)
				in
				    #"Filtered Rows"`

let nonAzureDatabricksTest = `				let
    Source = DatabricksMultiCloud.Catalogs("adb-3064640522536671.cloud.databricks.net", "/sql/1.0/warehouses/<sql-warehouse-id>",
        [Catalog=null, Database=null, EnableAutomaticProxyDiscovery=null, Implementation="2.0"]),
    powerbi_Database = Source{[Name="powerbi",Kind="Database"]}[Data],
    default_Schema = powerbi_Database{[Name="default",Kind="Schema"]}[Data],
    dashboard_data_Table = default_Schema{[Name="dashboard_data",Kind="Table"]}[Data]
in
    dashboard_data_Table`

let nonAzureDatabricksTestPass = `				let
    Source = DatabricksMultiCloud.Catalogs(TEST, "/sql/1.0/warehouses/<sql-warehouse-id>",
        [Catalog=null, Database=null, EnableAutomaticProxyDiscovery=null, Implementation="2.0"]),
    powerbi_Database = Source{[Name="powerbi",Kind="Database"]}[Data],
    default_Schema = powerbi_Database{[Name="default",Kind="Schema"]}[Data],
    dashboard_data_Table = default_Schema{[Name="dashboard_data",Kind="Table"]}[Data]
in
    dashboard_data_Table`


let foundryTestFail = `
let
    Source = Foundry.Contents("https://xx.palantirgov.com/", "ri.foundry.main.dataset.f1b1fc07-f5bd-42e7-9d85-197d2822921b", null)
in
    Source
`

let foundryTestPass = `
let
    Source = Foundry.Contents(BASE_URL, "ri.foundry.main.dataset.f1b1fc07-f5bd-42e7-9d85-197d2822921b", null)
in
    Source`