import { lintMCode } from 'src/lint/linter-module'  // Adjust the import path according to your project structure
import { ParseResult } from 'src/parser/pq/parse-types';
import { RuleResult } from 'src/lint/rule-types';
import { parseHelper, parseHelperForFunctions } from '../rule-testing-assistance';
import * as path from 'path';
import noTypeForParameterForFunction from 'src/lint/pq/no-type-for-parameter-for-function';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
// noTypeForParameterForFunction Rule
const _One_Parameter_Defined_DataFilePath = path.resolve('./test-files/Functions/One_Parameter_Defined.txt');
const _Complicated_Function_DataFilePath = path.resolve('./test-files/Functions/Complicated_Function.txt');
const _use_Type_With_Add_Column_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/HasFourthArgument.tmdl');


describe('noTypeForParameterForFunction Rule', () => {
    it('should return the expected RuleResult for One Parameter Defined', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parseHelperForFunctions(_One_Parameter_Defined_DataFilePath);
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noTypeForParameterForFunction]);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);
    }); 
    
    it('should return the expected RuleResult for Complicated_Function', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parseHelperForFunctions(_Complicated_Function_DataFilePath);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [noTypeForParameterForFunction]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(3);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });     

    it('should return the expected RuleResult for HasFourthArgument.tmdl', async () => {
        const parsedCode = await parseHelper(_use_Type_With_Add_Column_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [noTypeForParameterForFunction]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });      

    it('should return the expected RuleResult for has nullable parameter', async () => {
        const parsedCode = await parsePowerQueryText(hasNullableParameter);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [noTypeForParameterForFunction]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });   

    it('should return the expected RuleResult for has nullable parameter 2', async () => {
        const parsedCode = await parsePowerQueryText(hasNullableParameter2);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [noTypeForParameterForFunction]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });   
    
    it('should return the expected RuleResult for has nullable parameter 3', async () => {
        const parsedCode = await parsePowerQueryText(hasNullableParameter3);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [noTypeForParameterForFunction]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);
    });       
});


const hasNullableParameter = `let
    DecimalToBinary = (x as number) as text =>
        let
            Source = Number.Abs(Number.RoundTowardZero(x)),
            BinFunc = (n as number, acc as nullable text) as any =>
                if n = 0 then acc 
                else @BinFunc(Number.IntegerDivide(n, 2), Text.Combine({Text.From(Number.Mod(n, 2)), acc})),
            Binary = if x = 0 then "0" else BinFunc(Source, null),
            Result = if x < 0 then "-" & Binary else Binary
        in
            Result
in
    DecimalToBinary`

const hasNullableParameter2 = `let
    DecimalToBinary = (x as nullable record) as text =>
        let
            Source = Number.Abs(Number.RoundTowardZero(x)),
            BinFunc = (n as number, acc as nullable text) as any =>
                if n = 0 then acc 
                else @BinFunc(Number.IntegerDivide(n, 2), Text.Combine({Text.From(Number.Mod(n, 2)), acc})),
            Binary = if x = 0 then "0" else BinFunc(Source, null),
            Result = if x < 0 then "-" & Binary else Binary
        in
            Result
in
    DecimalToBinary`

const hasNullableParameter3 = `let
    DecimalToBinary = (x as nullable record) as text =>
        let
            Source = Number.Abs(Number.RoundTowardZero(x)),
            BinFunc = (n as number, acc) as any =>
                if n = 0 then acc 
                else @BinFunc(Number.IntegerDivide(n, 2), Text.Combine({Text.From(Number.Mod(n, 2)), acc})),
            Binary = if x = 0 then "0" else BinFunc(Source, null),
            Result = if x < 0 then "-" & Binary else Binary
        in
            Result
in
    DecimalToBinary`