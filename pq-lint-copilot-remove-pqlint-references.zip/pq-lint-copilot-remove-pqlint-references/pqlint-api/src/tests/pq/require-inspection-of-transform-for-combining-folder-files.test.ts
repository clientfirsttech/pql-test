import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { requireInspectionOfTransformForCombiningFolderFiles } from 'src/lint/pq/require-inspection-of-transform-for-combining-folder-files';
import * as path from 'path';

// requireInspectionOfTransformForCombiningFolderFiles.test
const _Fail_Content_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/ManipulatingFilesLinter.SemanticModel/definition/tables/Files_Fail.tmdl');
const _Fail_Content_Success_DataFilePath = path.resolve('./test-files/test_tmdl/ManipulatingFilesLinter.SemanticModel/definition/tables/Files_Success.tmdl');

describe('requireInspectionOfTransformForCombiningFolderFiles.test Rule', () => {
    it('should return the expected RuleResult for Files_Fail.tmdl', async () => {
        const parsedCode = await parseHelper(_Fail_Content_Fail_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireInspectionOfTransformForCombiningFolderFiles]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);
    });     

    it('should return the expected RuleResult for Files_Success.tmdl', async () => {
        const parsedCode = await parseHelper(_Fail_Content_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireInspectionOfTransformForCombiningFolderFiles]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });            
});