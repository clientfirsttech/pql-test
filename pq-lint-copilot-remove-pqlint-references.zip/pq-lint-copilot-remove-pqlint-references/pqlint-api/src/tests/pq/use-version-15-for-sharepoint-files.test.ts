import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useVersion15ForSharePointFiles } from 'src/lint/pq/use-version-15-for-sharepoint-files';
import * as path from 'path';

// use-distinct-source-name-for-referencing-table
const _Uses_API_14_DataFilePath = path.resolve('./test-files/Files/use-version-15-for-sharepoint-tables.SemanticModel/definition/tables/Uses_Files_API_Version_14.tmdl');
const _Uses_API_15_DataFilePath = path.resolve('./test-files/Files/use-version-15-for-sharepoint-tables.SemanticModel/definition/tables/Uses_Files_API_Version_15.tmdl');
const _SharePoint_Online_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SharePoint_Fail.tmdl');

describe('useVersion15ForSharePointFiles Rule', () => {
    it('should return the expected RuleResult for Uses_Files_API_Version_14.tmdl', async () => {
        const parsedCode = await parseHelper(_Uses_API_14_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useVersion15ForSharePointFiles]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();

            // Check if the error location is correct
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(2);            
        });        
    });
    
    it('should return the expected RuleResult for Uses_Files_API_Version_15.tmdl', async () => {
        const parsedCode = await parseHelper(_Uses_API_15_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useVersion15ForSharePointFiles]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);       
    });    

    it('should return the expected RuleResult for avoiding a False Positive', async () => {
        const parsedCode = await parseHelper(_SharePoint_Online_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useVersion15ForSharePointFiles]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });         
});