import { testAIFix } from '../rule-testing-assistance';
import { useDistinctStepNames } from 'src/lint/pq/use-distinct-step-names';
import * as path from 'path';
import * as fs from 'fs';

const _use_distinct_step_names_DataFilePath = path.resolve('./test-files/Files/use-distinct-step-names.SemanticModel/definition/tables/MultipleCustomColumns.tmdl');

describe('AI: Rewrite use-distinct-step-names Rule', () => {
    it('should fix RuleResult for MultipleCustomColumns.tmdl', async () => {
        const tmdlContent = fs.readFileSync(_use_distinct_step_names_DataFilePath, 'utf8');
        await testAIFix(
            tmdlContent,
            useDistinctStepNames,
            5,
            { debug: true, fileName: 'MultipleCustomColumns' }
        );
    }, 60000);
});
