import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useTableBufferForTableGroup } from 'src/lint/pq/use-table-buffer-for-table-group';
import * as path from 'path';

// use-distinct-source-name-for-referencing-table
const _Table_Group_Without_Buffer_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Table_Group_Without_Buffer.tmdl');
const _Table_Group_With_Buffer_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Table_Group_With_Buffer.tmdl');
const _Sort_Check_With_Buffer_Fail_2_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Sort_Check_With_Buffer_Fail_2.tmdl');
const _Table_Group_Without_Buffer_No_Sort_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Table_Group_Without_Buffer_No_Sort.tmdl');

describe('useTableBufferForTableGroup Rule', () => {
    it('should return the expected RuleResult for Table_Group_Without_Buffer.tmdl', async () => {
        const parsedCode = await parseHelper(_Table_Group_Without_Buffer_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableBufferForTableGroup]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    }); 

    it('should return the expected RuleResult for Table_Group_With_Buffer.tmdl', async () => {
        const parsedCode = await parseHelper(_Table_Group_With_Buffer_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableBufferForTableGroup]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });
    
    it('should return the expected RuleResult for Sort_Check_With_Buffer_Fail_2.tmdl (No False Positive)', async () => {
        const parsedCode = await parseHelper(_Sort_Check_With_Buffer_Fail_2_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableBufferForTableGroup]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });    

    it('should return the expected RuleResult for Table_Group_Without_Buffer_No_Sort.tmdl (No False Positive)', async () => {
        const parsedCode = await parseHelper(_Table_Group_Without_Buffer_No_Sort_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableBufferForTableGroup]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });        
});