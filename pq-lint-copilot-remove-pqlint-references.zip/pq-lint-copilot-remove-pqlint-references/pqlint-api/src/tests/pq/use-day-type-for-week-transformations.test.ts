import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useDayTypeForWeekTransformations } from 'src/lint/pq/use-day-type-for-week-transformations';
import * as path from 'path';

// use-distinct-source-name-for-referencing-table
const _all_Should_Pass_DataFilePath = path.resolve('./test-files/Files/use-day-type-for-week-transformations.SemanticModel/definition/tables/All_Should_Pass.tmdl');
const _two_Should_Fail_DataFilePath = path.resolve('./test-files/Files/use-day-type-for-week-transformations.SemanticModel/definition/tables/Two_Should_Fail.tmdl');
const _all_Should_Fail_DataFilePath = path.resolve('./test-files/Files/use-day-type-for-week-transformations.SemanticModel/definition/tables/All_Should_Fail.tmdl');

describe('useDayTypeForWeekTransformations Rule', () => {
    it('should return the expected RuleResult for All_Should_Fail.tmdl', async () => {
        const parsedCode = await parseHelper(_all_Should_Fail_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useDayTypeForWeekTransformations]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(5);
        let i = 0;
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();

            // Check if the error location is correct
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(6 + (3* i));
            i++;            
        });        
    });

    it('should return the expected RuleResult for Two_Should_Fail.tmdl', async () => {
        const parsedCode = await parseHelper(_two_Should_Fail_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useDayTypeForWeekTransformations]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(2);
        
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();   
        });

        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(6);
        expect(results[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(12);
        
    });   
    
    it('should return the expected RuleResult for All_Should_Pass.tmdl', async () => {
        const parsedCode = await parseHelper(_all_Should_Pass_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useDayTypeForWeekTransformations]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
        
    });             
});