import { testAIFix } from '../rule-testing-assistance';
import { useEnableFoldingWithNativeQueries } from 'src/lint/pq/use-enable-folding-with-native-queries';
import * as path from 'path';
import * as fs from 'fs';

describe('AI: Rewrite use-enable-folding-with-native-queries Rule', () => {
    it('should fix native query folding violations for SQL Server', async () => {
        await testAIFix(
            sqlServerNativeQueryTest,
            useEnableFoldingWithNativeQueries,
            1, // Expected number of violations
            { debug: true, fileName: 'use-enable-folding-sql-server' }
        );
    }, 60000);

   it('should fix native query folding violations for Oracle', async () => {
        await testAIFix(
            oracleNativeQueryTest,
            useEnableFoldingWithNativeQueries,
            1, // Expected number of violations
            { debug: true, fileName: 'use-enable-folding-oracle' }
        );
    }, 60000);

    it('should fix native query folding violations for SQL Server', async () => {
        await testAIFix(
            secondSQLFailTest,
            useEnableFoldingWithNativeQueries,
            1, // Expected number of violations
            { debug: true, fileName: 'use-enable-folding-sql-server' }
        );
    }, 60000);

    it('should fix native query folding violations for Value Native Query Fail', async () => {
        await testAIFix(
            valeuNativeyQueryFail,
            useEnableFoldingWithNativeQueries,
            1, // Expected number of violations
            { debug: true, fileName: 'use-enable-folding-sql-server' }
        );
    }, 60000);   
});

const sqlServerNativeQueryTest = `createOrReplace

	table SQLServer_NativeQuery_Folding_Fail
		lineageTag: 250e5031-f8df-4f24-9109-a7c75afe8af4

		column Field
			dataType: string
			lineageTag: 6c8d8ae8-80ab-498d-8a4b-26279201ac45
			summarizeBy: none
			sourceColumn: Field

		column Value
			dataType: dateTime
			lineageTag: 2887c593-b7bc-45f5-b9db-556fc60f6da4
			summarizeBy: none
			sourceColumn: Value

		partition SQLServer_NativeQuery_Folding_Fail = m
			mode: import
			source =
					let
					    Source = Sql.Database("server", "database", [Query="SELECT * FROM Table"])
					in
					    Source
`;

const oracleNativeQueryTest = `createOrReplace
	table Oracle_NativeQuery_Folding_Fail
		lineageTag: 250e5031-f8df-4f24-9109-a7c75afe8af4

		column Field
			dataType: string
			lineageTag: 6c8d8ae8-80ab-498d-8a4b-26279201ac45
			summarizeBy: none
			sourceColumn: Field

		column Value
			dataType: date
			lineageTag: 2887c593-b7bc-45f5-b9db-556fc60f6da4
			summarizeBy: none
			sourceColumn: Value

		column Check
			dataType: int64
			lineageTag: 93af3e85-ae8b-4629-9be8-1ffd6a4a7b56
			summarizeBy: none
			sourceColumn: Check

		partition Oracle_NativeQuery_Folding_Fail = m
			mode: import
			source =
				let
					Source = Oracle.Database("test", [HierarchicalNavigation=true, Query="select 'dt' ""Field"",max(FULL_DA) ""Value"" from (Select * from (SELECT FULL_DA FROM CAL_DY WHERE FULL_DA>='01-JAN-19') where WORKINGDAY=1)", CommandTimeout=#duration(0, 2, 0, 0)]),
					#"Changed Type" = Table.TransformColumnTypes(Source,{{"Value", type date}}),
					#"Added Custom" = Table.AddColumn(#"Changed Type", "Check", each if [#"Value"]=Date.From(DateTime.LocalNow()) then 1 else 0)
				in
					#"Added Custom"
`;


const secondSQLFailTest = `table SQLServer_NativeQuery_Folding_Fail
	lineageTag: eaa66f70-f316-4a9f-9a11-be99399b3888

	column SaleID
		dataType: int64
		formatString: 0
		lineageTag: 5a4d8454-c7c3-46f9-bb5a-87629d4f26a0
		summarizeBy: count
		sourceColumn: SaleID

		annotation SummarizationSetBy = Automatic

	column CustomerName
		dataType: string
		lineageTag: 2cf17943-5004-48df-836c-f11a8cd31995
		summarizeBy: none
		sourceColumn: CustomerName

		annotation SummarizationSetBy = Automatic

	partition SQLServer_NativeQuery_Folding_Fail = m
		mode: import
		queryGroup: use-enable-folding-with-native-queries
		source =
				let
				    Source = Sql.Database("azure-sql-db-jk.database.windows.net", "azure-sql-db-jk", [Query="SELECT SaleID, CustomerName FROM FakeSales"]),
				    #"Sorted Rows" = Table.Sort(Source,{{"SaleID", Order.Descending}})
				in
				    #"Sorted Rows"

	annotation PBI_NavigationStepName = Navigation

	annotation PBI_ResultType = Table
`

const valeuNativeyQueryFail = `createOrReplace

	expression ServerName = "azure-sql-db-jk.database.windows.net" meta [IsParameterQuery=true, Type="Text"]
	expression DatabaseName = "azure-sql-db-jk" meta [IsParameterQuery=true, Type="Text"]

	table SQLServer_NativeQuery_Folding_Fail
		lineageTag: eaa66f70-f316-4a9f-9a11-be99399b3888

		column SaleID
			dataType: int64
			formatString: 0
			lineageTag: 5a4d8454-c7c3-46f9-bb5a-87629d4f26a0
			summarizeBy: count
			sourceColumn: SaleID

			annotation SummarizationSetBy = Automatic

		column CustomerName
			dataType: string
			lineageTag: 2cf17943-5004-48df-836c-f11a8cd31995
			summarizeBy: none
			sourceColumn: CustomerName

			annotation SummarizationSetBy = Automatic

		partition SQLServer_NativeQuery_Folding_Fail = m
			mode: import
			queryGroup: use-enable-folding-with-native-queries
			source =
				let
					Source = Sql.Database(ServerName, DatabaseName),
					NativeQuery = Value.NativeQuery(Source, "SELECT SaleID, CustomerName FROM FakeSales"),
					#"Sorted Rows" = Table.Sort(NativeQuery,{{"SaleID", Order.Descending}})
				in
					#"Sorted Rows"

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = Table`