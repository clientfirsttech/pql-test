import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useMissingFieldParameterForTableReorderColumns } from 'src/lint/pq/use-missing-field-parameter-for-table-reorder-columns';
import * as path from 'path';

// use-distinct-source-name-for-referencing-table
const _Table_Reorder_Columns_Argument_Present_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Table_Reorder_Columns_Argument_Present.tmdl');
const _Table_Reorder_Columns_MissingArgument_Once_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Table_Reorder_Columns_MissingArgument_Once.tmdl');
const _Table_Reorder_Columns_MissingArgument_Twice_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Table_Reorder_Columns_MissingArgument_Twice.tmdl');
const _Table_Reorder_Columns_MissingArgument_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Table_Reorder_Columns_MissingArgument.tmdl');

describe('useMissingFieldParameterForTableReorderColumns Rule', () => {
    it('should return the expected RuleResult for Table_Reorder_Columns_Argument_Present.tmdl', async () => {
        const parsedCode = await parseHelper(_Table_Reorder_Columns_Argument_Present_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useMissingFieldParameterForTableReorderColumns]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    }); 

    it('should return the expected RuleResult for Table_Reorder_Columns_MissingArgument_Once.tmdl', async () => {
        const parsedCode = await parseHelper(_Table_Reorder_Columns_MissingArgument_Once_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useMissingFieldParameterForTableReorderColumns]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    }); 
    
    it('should return the expected RuleResult for Table_Reorder_Columns_MissingArgument_Twice.tmdl', async () => {
        const parsedCode = await parseHelper(_Table_Reorder_Columns_MissingArgument_Twice_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useMissingFieldParameterForTableReorderColumns]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(2);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });  
    
    it('should return the expected RuleResult for _Table_Reorder_Columns_MissingArgument.tmdl', async () => {
        const parsedCode = await parseHelper(_Table_Reorder_Columns_MissingArgument_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useMissingFieldParameterForTableReorderColumns]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });      
           
});