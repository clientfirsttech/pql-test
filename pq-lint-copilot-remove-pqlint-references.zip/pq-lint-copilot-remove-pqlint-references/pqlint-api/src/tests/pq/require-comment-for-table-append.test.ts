import { lintMCode } from 'src/lint/linter-module'  // Adjust the import path according to your project structure
import { ParseResult } from 'src/parser/pq/parse-types';
import { RuleResult } from 'src/lint/rule-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { parseHelper, parseHelperForFunctions } from '../rule-testing-assistance';
import { logDebug } from 'src/lint/rule-assistance';
import * as path from 'path';
import * as fs from 'fs';
import requireCommentForTableAppend from 'src/lint/pq/require-comment-for-table-append';

// requireCommentForTableAppend
const _Append_Comment_HasComment_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Append_Comment_HasComment.tmdl');
const _Append_Comment_HasNoComment_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Append_Comment_HasNoComment.tmdl');

describe('requireCommentForTableAppendRule', () => {
    it('should return the expected RuleResult for Append_Comment_HasComment.tmdl', async () => {
        const parsedCode = await parseHelper(_Append_Comment_HasComment_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireCommentForTableAppend]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });    
    
    it('should return the expected RuleResult for Append_Comment_HasNoComment.tmdl', async () => {
        const parsedCode = await parseHelper(_Append_Comment_HasNoComment_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [requireCommentForTableAppend]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });       
});