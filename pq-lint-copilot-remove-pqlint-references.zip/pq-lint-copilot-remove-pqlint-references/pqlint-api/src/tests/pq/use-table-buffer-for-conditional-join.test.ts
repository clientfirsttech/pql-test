

import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { RuleResult } from 'src/lint/rule-types';
import { useTableBufferForConditionalJoin } from 'src/lint/pq/use-table-buffer-for-conditional-join';
import * as path from 'path';

// useTableBufferForConditionalJoin
const _Table_SelectRows__DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Table_SelectRows.tmdl');
const _Table_SelectRows_With_Buffer_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Table_SelectRows_With_Buffer.tmdl');
const _Table_SelectRows_With_One_Sucess_One_Failure_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Table_SelectRows_With_One_Sucess_One_Failure.tmdl');

describe('useTableBufferForConditionalJoin Rule', () => {
    it('should return the expected RuleResult for Table_SelectRows.tmdl', async () => {
        const parsedCode = await parseHelper(_Table_SelectRows__DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableBufferForConditionalJoin]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        

        //console.log(results[0].ErrorInformation.errorLocation.positionStart);

    }); 

    it('should return the expected RuleResult for Table_SelectRows_With_Buffer.tmdl', async () => {
        const parsedCode = await parseHelper(_Table_SelectRows_With_Buffer_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableBufferForConditionalJoin]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });
    
    it('should return the expected RuleResult for Table_SelectRows_With_One_Sucess_One_Failure.tmdl', async () => {
        const parsedCode = await parseHelper(_Table_SelectRows_With_One_Sucess_One_Failure_DataFilePath);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useTableBufferForConditionalJoin]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });    
});