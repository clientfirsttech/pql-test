import { lintMCode } from 'src/lint/linter-module'  // Adjust the import path according to your project structure
import { ParseResult } from 'src/parser/pq/parse-types';
import { parseHelperForFunctions } from '../rule-testing-assistance';
import { parseHelper } from '../rule-testing-assistance';
import { RuleResult } from 'src/lint/rule-types';
import * as path from 'path';
import noReturnTypeForFunction from 'src/lint/pq/no-return-type-for-function';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { logDebug } from 'src/lint/rule-assistance';
// no-return-type-for-function Rule
const _No_Return_Type_DataFilePath = path.resolve('./test-files/Functions/No_Return_Type.txt');
const _Has_Return_Type_DataFilePath = path.resolve('./test-files/Functions/Has_Return_Type.txt');
const _Complicated_Function_DataFilePath = path.resolve('./test-files/Functions/Complicated_Function.txt');
const _Complicated_Function2_DataFilePath = path.resolve('./test-files/Functions/Complicated_Function2.txt');
const _use_type_with_add_column_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/HasFourthArgument.tmdl');
const basicFunction = `(x) => x + 1`;

describe('no-return-type-for-function Rule', () => {
    it('should return the expected RuleResult for No_Return_Type', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parseHelperForFunctions(_No_Return_Type_DataFilePath);
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noReturnTypeForFunction]);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);
    }); 

    it('should return the expected RuleResult for Has_Return_Type', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parseHelperForFunctions(_Has_Return_Type_DataFilePath);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [noReturnTypeForFunction]);
        
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    }); 
    
    it('should return the expected RuleResult for Complicated_Function', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parseHelperForFunctions(_Complicated_Function_DataFilePath);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [noReturnTypeForFunction]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(4);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });     

    it('should return the expected RuleResult for Complicated_Function_2', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parseHelperForFunctions(_Complicated_Function2_DataFilePath);
        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [noReturnTypeForFunction]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(2);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });    
    
    it('should return the expected RuleResult for HasFourthArgument.tmdl', async () => {
        const parsedCode = await parseHelper(_use_type_with_add_column_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [noReturnTypeForFunction]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });     

    it('should return the expected RuleResult for basicFunction', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(basicFunction);
        logDebug('Parsed Code:', JSON.stringify(parsedCode));
        const results: RuleResult[] = await lintMCode(parsedCode, [noReturnTypeForFunction]);
        expect(results.length).toBe(1);
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });
        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(1);
    });    
    
    
});
