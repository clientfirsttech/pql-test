import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useEnableFoldingWithNativeQueries } from 'src/lint/pq/use-enable-folding-with-native-queries';
import * as path from 'path';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';

// useEnableFoldingWithNativeQueries
const _SQLServer_NativeQuery_Folding_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SQLServer_NativeQuery_Folding_Fail.tmdl');
const _SQLServer_NativeQuery_Folding_Success_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/SQLServer_NativeQuery_Folding_Success.tmdl');

describe(' useEnableFoldingWithNativeQueries_DataFilePath Rule', () => {
    it('should return the expected RuleResult for SQLServer_NativeQuery_Folding_Fail.tmdl', async () => {
        const parsedCode = await parseHelper(_SQLServer_NativeQuery_Folding_Fail_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useEnableFoldingWithNativeQueries]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });    

    it('should return the expected RuleResult for SQLServer_NativeQuery_Folding_Success.tmdl', async () => {
        const parsedCode = await parseHelper(_SQLServer_NativeQuery_Folding_Success_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useEnableFoldingWithNativeQueries]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });     

    it('should return the expected RuleResult for Oracle Example', async () => {
        const parsedCode = await parsePowerQueryText(oracleExample);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useEnableFoldingWithNativeQueries]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });   

    it('should return the expected RuleResult for Value.NativeQuery without EnableFolding', async () => {
        const parsedCode = await parsePowerQueryText(valeuNativeyQueryFail);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useEnableFoldingWithNativeQueries]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(4);
    });

    it('should return the expected RuleResult for Value.NativeQuery with EnableFolding', async () => {
        const parsedCode = await parsePowerQueryText(valueNativeQuerySuccess);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useEnableFoldingWithNativeQueries]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });    

});

const oracleExample = `let
    Source = Oracle.Database("test", [HierarchicalNavigation=true, Query="select 'dt' ""Field"",max(FULL_DA) ""Value"" from#(lf)(Select * from#(lf)(#(lf)SELECT#(lf)FULL_DA,#(lf)DY_OF_CAL_WK_NO,#(lf)WKDY_IND,#(lf)CAL_WK_BEG_DA,#(lf)case when WKDY_IND='Y' and ISO_CTRY_CD IS NULL then 1 else 0 end as WORKINGDAY#(lf)FROM (#(lf)SELECT *#(lf)FROM CAL_DY CAL#(lf)LEFT JOIN#(lf)(#(lf)SELECT * from CAL_HOLDY_DY where ISO_CTRY_CD = 'US'#(lf)) HLDY#(lf)ON CAL.DA_ID = HLDY.DA_ID#(lf)WHERE#(lf)1=1#(lf)and CAL.FULL_DA>='01-JAN-19' and#(lf)CAL.FULL_DA<=sysdate#(lf)order by CAL.FULL_DA asc#(lf))#(lf))#(lf)where WORKINGDAY=1#(lf)and trunc(FULL_DA)<=trunc(sysdate)#(lf)order by FULL_DA DESC#(lf))", CommandTimeout=#duration(0, 2, 0, 0)]),
    #"Changed Type" = Table.TransformColumnTypes(Source,{{"Value", type date}}),
    #"Added Custom" = Table.AddColumn(#"Changed Type", "Check", each if [#"Value"]=Date.From(DateTime.LocalNow()) then 1 else 0),
    #"Removed Other Columns" = Table.SelectColumns(#"Added Custom",{"Check"}),
    #"Changed Type1" = Table.TransformColumnTypes(#"Removed Other Columns",{{"Check", Int64.Type}})
in
    #"Changed Type1"`

const valeuNativeyQueryFail = `
				let
					Source = Sql.Database(ServerName, DatabaseName),
					NativeQuery = Value.NativeQuery(Source, "SELECT SaleID, CustomerName FROM FakeSales"),
					#"Sorted Rows" = Table.Sort(NativeQuery,{{"SaleID", Order.Descending}})
				in
					#"Sorted Rows"
`

const valueNativeQuerySuccess = `
					let
						Source = Sql.Database(ServerName, DatabaseName),
						Query = "SELECT SaleID, CustomerName FROM FakeSales",
						NativeResult = Value.NativeQuery(Source, Query, null, [EnableFolding=true]),
						#"Sorted Rows" = Table.Sort(NativeResult, {{"SaleID", Order.Descending}})
					in
						#"Sorted Rows"
`