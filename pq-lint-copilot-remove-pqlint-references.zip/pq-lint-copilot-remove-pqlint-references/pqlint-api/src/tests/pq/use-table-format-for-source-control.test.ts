import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { parseHelper } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useTableFormatForSourceControl } from 'src/lint/pq/use-table-format-for-source-control';
import * as path from 'path';

// BINARY_FROMTEXT Rule
const _use_table_format_for_source_control_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/TableBinary.tmdl');
const _NO_use_table_format_for_source_control_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/TableNotBinary.tmdl');
const _NO_DEFINED_use_table_format_for_source_control_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/DefinedTable.tmdl');

describe('use-table-format-for-source-control Rule', () => {
    it('should return the expected RuleResult for TableBinary.tmdl', async () => {
        const parsedCode = await parseHelper(_use_table_format_for_source_control_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableFormatForSourceControl]);
        
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });        
    });

    it('should NOT return the expected RuleResult for TableNotBinary.tmdl', async () => {
        const parsedCode = await parseHelper(_NO_use_table_format_for_source_control_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableFormatForSourceControl]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });

    it('should return the expected RuleResult for DefinedTable.tmdl', async () => {
        const parsedCode = await parseHelper(_NO_DEFINED_use_table_format_for_source_control_DataFilePath);

        // Lint the file using the actual rule
        const results = await lintMCode(parsedCode, [useTableFormatForSourceControl]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });    
    
});