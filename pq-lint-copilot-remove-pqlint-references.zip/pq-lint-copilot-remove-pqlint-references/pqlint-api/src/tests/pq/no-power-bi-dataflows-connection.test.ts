import { lintMCode } from 'src/lint/linter-module'  // Adjust the import path according to your project structure
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';
import noPowerBIDataflowsConnection from 'src/lint/pq/no-power-bi-dataflows-connection';

let legacyMCode = `let
  Source = PowerBI.Dataflows([]),
  #"Navigation 1" = Source{[workspaceId = "a0c85f01-e65f-44b5-a5c0-e202c9db0dda"]}[Data],
  #"Navigation 2" = #"Navigation 1"{[dataflowId = "f8b66524-5738-4189-ac24-6027575a33dd"]}[Data],
  #"Navigation 3" = #"Navigation 2"{[entity = "Source Table"]}[Data]
in
  #"Navigation 3"`

let nonLegacyMCode = `let
  Source = PowerPlatform.Dataflows([]),
  #"Navigation 1" = Source{[Id = "Workspaces"]}[Data],
  #"Navigation 2" = #"Navigation 1"{[workspaceId = "a0c85f01-e65f-44b5-a5c0-e202c9db0dda"]}[Data],
  #"Navigation 3" = #"Navigation 2"{[dataflowId = "f8b66524-5738-4189-ac24-6027575a33dd"]}[Data],
  #"Navigation 4" = #"Navigation 3"{[entity = "Source Table", version = ""]}[Data]
in
  #"Navigation 4"`

describe('noPowerBIDataflowsConnection Rule', () => {
    it('should return the expected RuleResult for Legacy Source', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(legacyMCode);
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noPowerBIDataflowsConnection]);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(2);
        });
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);
    }); 

    it('should return the expected RuleResult for Non Legacy Source', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(nonLegacyMCode);
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noPowerBIDataflowsConnection]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });      

    
    
});
