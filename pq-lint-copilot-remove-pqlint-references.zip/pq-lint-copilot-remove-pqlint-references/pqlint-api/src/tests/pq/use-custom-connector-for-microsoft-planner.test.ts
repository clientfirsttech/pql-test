import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useCustomConnectorForMicrosoftPlanner } from 'src/lint/pq/use-custom-connector-for-microsoft-planner';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';

let plannerUse = `
let
    Source = Json.Document(Web.Contents("https://graph.microsoft.com/v1.0/planner/plans/o0F8dLRD302lGhJbE3K2q2UADy3v/tasks")),
    #"Converted to Table" = Table.FromRecords({Source}),
    #"Expanded value" = Table.ExpandListColumn(#"Converted to Table", "value"),
    #"Expanded value1" = Table.ExpandRecordColumn(#"Expanded value", "value", {"@odata.etag", "planId", "bucketId", "title", "orderHint", "assigneePriority", "percentComplete", "startDateTime", "createdDateTime", "dueDateTime", "hasDescription", "previewType", "completedDateTime", "referenceCount", "checklistItemCount", "activeChecklistItemCount", "conversationThreadId", "priority", "id", "completedBy", "createdBy", "appliedCategories", "assignments"}, {"value.@odata.etag", "value.planId", "value.bucketId", "value.title", "value.orderHint", "value.assigneePriority", "value.percentComplete", "value.startDateTime", "value.createdDateTime", "value.dueDateTime", "value.hasDescription", "value.previewType", "value.completedDateTime", "value.referenceCount", "value.checklistItemCount", "value.activeChecklistItemCount", "value.conversationThreadId", "value.priority", "value.id", "value.completedBy", "value.createdBy", "value.appliedCategories", "value.assignments"}),
    #"Expanded value.createdBy" = Table.ExpandRecordColumn(#"Expanded value1", "value.createdBy", {"application", "user"}, {"value.createdBy.application", "value.createdBy.user"}),
    #"Expanded value.createdBy.application" = Table.ExpandRecordColumn(#"Expanded value.createdBy", "value.createdBy.application", {"displayName", "id"}, {"value.createdBy.application.displayName", "value.createdBy.application.id"}),
    #"Expanded value.createdBy.user" = Table.ExpandRecordColumn(#"Expanded value.createdBy.application", "value.createdBy.user", {"displayName", "id"}, {"value.createdBy.user.displayName", "value.createdBy.user.id"}),
    #"Expanded value.appliedCategories" = Table.ExpandRecordColumn(#"Expanded value.createdBy.user", "value.appliedCategories", {"category5", "category3", "category2", "category1", "category11"}, {"value.appliedCategories.category5", "value.appliedCategories.category3", "value.appliedCategories.category2", "value.appliedCategories.category1", "value.appliedCategories.category11"}),
    #"Expanded value.assignments" = Table.ExpandRecordColumn(#"Expanded value.appliedCategories", "value.assignments", {}, {}),
    #"Changed Type" = Table.TransformColumnTypes(#"Expanded value.assignments",{{"@odata.context", type text}, {"@odata.count", Int64.Type}, {"value.@odata.etag", type text}, {"value.planId", type text}, {"value.bucketId", type text}, {"value.title", type text}, {"value.orderHint", type text}, {"value.assigneePriority", type any}, {"value.percentComplete", Int64.Type}, {"value.startDateTime", type any}, {"value.createdDateTime", type datetime}, {"value.dueDateTime", type any}, {"value.hasDescription", type logical}, {"value.previewType", type text}, {"value.completedDateTime", type any}, {"value.referenceCount", Int64.Type}, {"value.checklistItemCount", Int64.Type}, {"value.activeChecklistItemCount", Int64.Type}, {"value.conversationThreadId", type any}, {"value.priority", Int64.Type}, {"value.id", type text}, {"value.completedBy", type any}, {"value.createdBy.application.displayName", type any}, {"value.createdBy.application.id", type text}, {"value.createdBy.user.displayName", type any}, {"value.createdBy.user.id", type text}, {"value.appliedCategories.category5", type logical}, {"value.appliedCategories.category3", type logical}, {"value.appliedCategories.category2", type logical}, {"value.appliedCategories.category1", type logical}, {"value.appliedCategories.category11", type logical}})
in
    #"Changed Type"`;

let noPlannerUse = `
let
    Source = Web.Contents("https://app.powerbi.com")
in
    Source
`


describe('useCustomConnectorForMicrosoftPlanner', () => {
  it('should return the expected RuleResult for plannerUse', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(plannerUse);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useCustomConnectorForMicrosoftPlanner ]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(3);
    });    
  });

  it('should return the expected RuleResult for noPlannerUse', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(noPlannerUse);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useCustomConnectorForMicrosoftPlanner]);
    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });
});
