import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useCoalesceForRecordFieldCount} from 'src/lint/pq/use-coalesce-for-record-field-count';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';
import { logDebug } from 'src/lint/rule-assistance';

let recordFieldCountPass = `
let
    Source = SharePoint.Tables("https://kerski.sharepoint.com", [Implementation="2.0", ViewMode="All"]),
    #"7f7eeb54-b2af-4f76-9f49-d89e5147ce73" = Source{[Id="7f7eeb54-b2af-4f76-9f49-d89e5147ce73"]}[Items],
    #"Removed Other Columns" = Table.SelectColumns(#"7f7eeb54-b2af-4f76-9f49-d89e5147ce73",{"Title", "Single User", "Multi_User", "Created By", "Modified By"}),
    #"Expanded Single User" = Table.ExpandListColumn(#"Removed Other Columns", "Single User"),
    #"Removed Other Columns1" = Table.SelectColumns(#"Expanded Single User",{"Single User", "Title"}),
    #"Reordered Columns" = Table.ReorderColumns(#"Removed Other Columns1",{"Title", "Single User"}),
    #"Added Custom" = Table.AddColumn(#"Reordered Columns", "Record_FieldCount", each Record.FieldCount([Single User]??[])),
    #"Added Custom1" = Table.AddColumn(#"Added Custom", "Record_SingleUser", each Record.FieldOrDefault([Single User],"title"))
in
    #"Added Custom1"
`

let recordFieldCountFail = `
let
    Source = SharePoint.Tables("https://kerski.sharepoint.com", [Implementation="2.0", ViewMode="All"]),
    #"7f7eeb54-b2af-4f76-9f49-d89e5147ce73" = Source{[Id="7f7eeb54-b2af-4f76-9f49-d89e5147ce73"]}[Items],
    #"Removed Other Columns" = Table.SelectColumns(#"7f7eeb54-b2af-4f76-9f49-d89e5147ce73",{"Title", "Single User", "Multi_User", "Created By", "Modified By"}),
    #"Expanded Single User" = Table.ExpandListColumn(#"Removed Other Columns", "Single User"),
    #"Removed Other Columns1" = Table.SelectColumns(#"Expanded Single User",{"Single User", "Title"}),
    #"Reordered Columns" = Table.ReorderColumns(#"Removed Other Columns1",{"Title", "Single User"}),
    #"Added Custom" = Table.AddColumn(#"Reordered Columns", "Record_FieldCount", each Record.FieldCount([Single User])),
    #"Added Custom1" = Table.AddColumn(#"Added Custom", "Record_SingleUser", each Record.FieldOrDefault([Single User],"title"))
in
    #"Added Custom1"
`


describe('useCoalesceForRecordFieldCount Rule', () => {
  it('should return the expected RuleResult for recordFieldCountPass', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(recordFieldCountPass );
    logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useCoalesceForRecordFieldCount]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  }); 

  it('should return the expected RuleResult for recordFieldCountFail', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(recordFieldCountFail);
    //logDebug('Parsed Code:', JSON.stringify(parsedCode));
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useCoalesceForRecordFieldCount]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
        expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
        expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      });    
  
      expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(9);    

  }); 

});
