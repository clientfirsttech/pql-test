import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { consolidateMultipleTableReplaceValueCalls } from 'src/lint/pq/consolidate-multiple-table-replace-value-calls';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';
import { logDebug } from 'src/lint/rule-assistance';

const lessThanThree = `let
    // 1. Grab the data (an Excel table named "Table1" in this example)
    Source =
        Excel.CurrentWorkbook(){[Name = "Table1"]}[Content],

    // 2. Replace empty strings in Column1 with null
    ReplaceBlanks =
        Table.ReplaceValue(
            Source,
            "",                          // old value
            null,                        // new value
            Replacer.ReplaceValue,
            {"Column1"}                  // columns to search
        ),

    // 3. Replace the text "N/A" with null in two columns at once
    ReplaceNA =
        Table.ReplaceValue(
            ReplaceBlanks,
            "N/A",
            null,
            Replacer.ReplaceText,
            {"Column2", "Column3"}
        ),

    // 4. Convert the flag column’s “Yes” to logical true
    ReplaceYes =
        Table.ReplaceValue(
            ReplaceNA,
            "Yes",
            true,
            Replacer.ReplaceText,
            {"Flag"}
        ),

    // 5. …and “No” to logical false
    ReplaceNo =
        Table.ReplaceValue(
            ReplaceYes,
            "No",
            false,
            Replacer.ReplaceText,
            {"Flag"}
        )
in
    ReplaceNo

`

const atFiveCalls = `
let
    // 1. Load sample data from an Excel table named "Table1"
    Source =
        Excel.CurrentWorkbook(){[Name = "Table1"]}[Content],

    // 2. Replace empty string with null in Column1
    ReplaceBlanks =
        Table.ReplaceValue(
            Source,
            "", null,
            Replacer.ReplaceValue,
            {"Column1"}
        ),

    // 3. Replace "N/A" with null in Column2 and Column3
    ReplaceNA =
        Table.ReplaceValue(
            ReplaceBlanks,
            "N/A", null,
            Replacer.ReplaceText,
            {"Column2", "Column3"}
        ),

    // 4. Replace "Yes" with true in Flag column
    ReplaceYes =
        Table.ReplaceValue(
            ReplaceNA,
            "Yes", true,
            Replacer.ReplaceText,
            {"Flag"}
        ),

    // 5. Replace "No" with false in Flag column
    ReplaceNo =
        Table.ReplaceValue(
            ReplaceYes,
            "No", false,
            Replacer.ReplaceText,
            {"Flag"}
        ),

    // 6. Replace the string "Unknown" with "Unspecified" in Column3
    ReplaceUnknown =
        Table.ReplaceValue(
            ReplaceNo,
            "Unknown", "Unspecified",
            Replacer.ReplaceText,
            {"Column3"}
        )
in
    ReplaceUnknown
`;

const replaceFunction = `
let
    ApplyMultipleReplacements = (SourceTable as table, ReplacementTable as table) as table =>
        let
            Result =
                List.Accumulate(
                    List.Zip({ ReplacementTable[Old], ReplacementTable[New] }),
                    SourceTable,
                    (state, current) =>
                        Table.ReplaceValue(
                            state,
                            current{0},
                            current{1},
                            Replacer.ReplaceText,
                            {"Value"}
                        )
                )
        in
            Result
in
    ApplyMultipleReplacements
`

const noFalsePositive = `
let
    Source = SharePoint.Tables("https://kerski.sharepoint.com/sites/SPRefreshTest", [Implementation="2.0", ViewMode="All"]),
    #"ab6cbd60-18de-42ea-b2a6-dc9fdb7e34c5" = Source{[Id="ab6cbd60-18de-42ea-b2a6-dc9fdb7e34c5"]}[Items],
    #"Renamed Columns" = Table.RenameColumns(#"ab6cbd60-18de-42ea-b2a6-dc9fdb7e34c5",{{"ID", "ID.1"}}),
    #"Changed Type" = Table.TransformColumnTypes(#"Renamed Columns",{{"id", type text}}),
    #"Renamed Columns1" = Table.RenameColumns(#"Changed Type",{{"Title", "Title Change"}}),
    #"Changed Type1" = Table.TransformColumnTypes(#"Renamed Columns1",{{"Title Change", type text}}),
    #"Sorted Rows" = Table.Sort(#"Changed Type1",{{"Modified", Order.Ascending}}),
    #"Renamed Columns2" = Table.RenameColumns(#"Sorted Rows",{{"gender", "Gender"}, {"ipaddress", "IP Address"}}),
    #"Sorted Rows1" = Table.Sort(#"Renamed Columns2",{{"when", Order.Descending}}),
    #"Renamed Columns3" = Table.RenameColumns(#"Sorted Rows1",{{"when", "When"}})
in
    #"Renamed Columns3"
`;

describe('consolidateMultipleTableReplaceValueCalls Rule', () => {
    it('should return the expected RuleResult for lessThanThree', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(lessThanThree);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [consolidateMultipleTableReplaceValueCalls]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });

    it('should return the expected RuleResult for atFiveCalls', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(atFiveCalls);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [consolidateMultipleTableReplaceValueCalls]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(5);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        // Check if the error messages are as expected
        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(9);
        expect(results[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(18);
        expect(results[2].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(27);
        expect(results[3].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(36);
        expect(results[4].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(45);
    });    


    it('should return the expected RuleResult for replaceFunction', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(replaceFunction);
        logDebug('Parsed Code:', JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [consolidateMultipleTableReplaceValueCalls]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });

    it('should return the expected RuleResult for noFalsePositive', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(noFalsePositive);
        logDebug('Parsed Code:', JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [consolidateMultipleTableReplaceValueCalls]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });    

});
