import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useComparerParameterTextFunctions } from 'src/lint/pq/use-comparer-parameter-for-text-functions.'; // Adjust the import path according to your project structure
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';
import { log } from 'console';
import { logDebug } from 'src/lint/rule-assistance';


describe('useComparerParameterTextFunctions Rule', () => {
   it('should return the expected RuleResult for allTextFail', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(allTextFail);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useComparerParameterTextFunctions]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(4);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(12);
        expect(results[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(15);
        expect(results[2].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(18);
        expect(results[3].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(21);
    });

    it('should return the expected RuleResult for allTextSomeFail', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(allTextSomeFail);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useComparerParameterTextFunctions]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(2);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(12);
        expect(results[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(18);
    });

    it('should return the expected RuleResult for allTextSomeFail2', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(allTextSomeFail2);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useComparerParameterTextFunctions]);
        logDebug('Results:', JSON.stringify(results));
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(2);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });
        
        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(16);
        expect(results[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(18);
    });    

    it('should return the expected RuleResult for allTextPass', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(allTextPass);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useComparerParameterTextFunctions]);
        log('Results:', JSON.stringify(results));
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });

    it('should return the expected RuleResult for allTextPass2', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(allTextPass2);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useComparerParameterTextFunctions]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });

    it('should return the expected RuleResult for allTextPass3', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(allTextPass3);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [useComparerParameterTextFunctions]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });    

});

const allTextFail = `let
    // Sample table
    Source = Table.FromRecords({
        [ID = 1, TextValue = "Power BI is amazing"],
        [ID = 2, TextValue = "Start with Power BI"],
        [ID = 3, TextValue = "Amazing end to a day"],
        [ID = 4, TextValue = "This contains Power BI"],
        [ID = 5, TextValue = "Random text"]
    }),

    // Add column: Does the text start with "Power"
    AddStartsWith = Table.AddColumn(Source, "StartsWith_Power", each Text.StartsWith([TextValue], "Power")),

    // Add column: Does the text end with "day"
    AddEndsWith = Table.AddColumn(AddStartsWith, "EndsWith_day", each Text.EndsWith([TextValue], "day")),

    // Add column: Does the text contain "Power BI"
    AddContains = Table.AddColumn(AddEndsWith, "Contains_PowerBI", each Text.Contains([TextValue], "Power BI")),

    // Add column: Position of the word "Power" (-1 if not found)
    AddPositionOf = Table.AddColumn(AddContains, "PositionOf_Power", each Text.PositionOf([TextValue], "Power"))

in
    AddPositionOf
`

const allTextSomeFail = `let
    // Sample table
    Source = Table.FromRecords({
        [ID = 1, TextValue = "Power BI is amazing"],
        [ID = 2, TextValue = "start with Power BI"],
        [ID = 3, TextValue = "Amazing end to a day"],
        [ID = 4, TextValue = "this contains POWER bi"],
        [ID = 5, TextValue = "Random text"]
    }),

    // Case-insensitive: Does the text start with "power" (ignore case)
    AddStartsWith = Table.AddColumn(Source, "StartsWith_power", each Text.StartsWith([TextValue], "power")),

    // Culture-aware: Does the text end with "day" using en-US culture
    AddEndsWith = Table.AddColumn(AddStartsWith, "EndsWith_day", each Text.EndsWith([TextValue], "day", Comparer.FromCulture("en-US"))),

    // Case-insensitive: Does the text contain "Power BI" (ignore case)
    AddContains = Table.AddColumn(AddEndsWith, "Contains_PowerBI", each Text.Contains([TextValue], "Power BI")),

    // Case-insensitive: Position of "power" (returns -1 if not found)
    AddPositionOf = Table.AddColumn(AddContains, "PositionOf_power", each Text.PositionOf([TextValue], "power", Occurrence.First, Comparer.OrdinalIgnoreCase))

in
    AddPositionOf
`

const allTextSomeFail2 = `let
    // Sample table
    Source = Table.FromRecords({
        [ID = 1, TextValue = "Power BI is amazing"],
        [ID = 2, TextValue = "start with Power BI"],
        [ID = 3, TextValue = "Amazing end to a day"],
        [ID = 4, TextValue = "this contains POWER bi"],
        [ID = 5, TextValue = "Random text"]
    }),

    // Transform each row into a new record with computed values
    TransformedRows = Table.TransformRows(Source, each [
        ID = [ID],
        TextValue = [TextValue],
        StartsWith_power = Text.StartsWith([TextValue], "power", Comparer.OrdinalIgnoreCase),
        EndsWith_day = Text.EndsWith([TextValue], "day"),
        Contains_PowerBI = Text.Contains([TextValue], "Power BI", Comparer.OrdinalIgnoreCase),
        PositionOf_power = Text.PositionOf([TextValue], "power", Occurrence.First)
    ]),

    // Convert list of records back into a table
    Result = Table.FromRecords(TransformedRows)

in
    Result
`

const allTextPass = `let
    // Sample table
    Source = Table.FromRecords({
        [ID = 1, TextValue = "Power BI is amazing"],
        [ID = 2, TextValue = "start with Power BI"],
        [ID = 3, TextValue = "Amazing end to a day"],
        [ID = 4, TextValue = "this contains POWER bi"],
        [ID = 5, TextValue = "Random text"]
    }),

    // Case-insensitive: Does the text start with "power" (ignore case)
    AddStartsWith = Table.AddColumn(Source, "StartsWith_power", each Text.StartsWith([TextValue], "power", Comparer.OrdinalIgnoreCase)),

    // Culture-aware: Does the text end with "day" using en-US culture
    AddEndsWith = Table.AddColumn(AddStartsWith, "EndsWith_day", each Text.EndsWith([TextValue], "day", Comparer.FromCulture("en-US"))),

    // Case-insensitive: Does the text contain "Power BI" (ignore case)
    AddContains = Table.AddColumn(AddEndsWith, "Contains_PowerBI", each Text.Contains([TextValue], "Power BI", Comparer.OrdinalIgnoreCase)),

    // Case-insensitive: Position of "power" (returns -1 if not found)
    AddPositionOf = Table.AddColumn(AddContains, "PositionOf_power", each Text.PositionOf([TextValue], "power", Occurrence.First, Comparer.OrdinalIgnoreCase))

in
    AddPositionOf
`
const allTextPass2 = `let
    // Sample table
    Source = Table.FromRecords({
        [ID = 1, TextValue = "Power BI is amazing"],
        [ID = 2, TextValue = "start with Power BI"],
        [ID = 3, TextValue = "Amazing end to a day"],
        [ID = 4, TextValue = "this contains POWER bi"],
        [ID = 5, TextValue = "Random text"]
    }),

    // Case-insensitive: Does the text start with "power" (ignore case)
    AddStartsWith = Table.AddColumn(Source, "StartsWith_power", each Text.StartsWith([TextValue], "power", Comparer.OrdinalIgnoreCase)),

    // Culture-aware: Does the text end with "day" using en-US culture
    AddEndsWith = Table.AddColumn(AddStartsWith, "EndsWith_day", each Text.EndsWith([TextValue], "day", Comparer.FromCulture("en-US"))),

    // Case-insensitive: Does the text contain "Power BI" (ignore case)
    AddContains = Table.AddColumn(AddEndsWith, "Contains_PowerBI", each Text.Contains([TextValue], "Power BI", Comparer.OrdinalIgnoreCase)),

    // Case-insensitive: Position of "power" (returns -1 if not found)
    AddPositionOf = Table.AddColumn(AddContains, "PositionOf_power", each Text.PositionOf([TextValue], "power", Occurrence.First, Comparer.FromCulture("en-US")))

in
    AddPositionOf
`

const allTextPass3 = `let
    // Sample table
    Source = Table.FromRecords({
        [ID = 1, TextValue = "Power BI is amazing"],
        [ID = 2, TextValue = "start with Power BI"],
        [ID = 3, TextValue = "Amazing end to a day"],
        [ID = 4, TextValue = "this contains POWER bi"],
        [ID = 5, TextValue = "Random text"]
    }),

    // Transform each row into a new record with computed values
    TransformedRows = Table.TransformRows(Source, each [
        ID = [ID],
        TextValue = [TextValue],
        StartsWith_power = Text.StartsWith([TextValue], "power", Comparer.OrdinalIgnoreCase),
        EndsWith_day = Text.EndsWith([TextValue], "day", Comparer.FromCulture("en-US")),
        Contains_PowerBI = Text.Contains([TextValue], "Power BI", Comparer.OrdinalIgnoreCase),
        PositionOf_power = Text.PositionOf([TextValue], "power", Occurrence.First, Comparer.FromCulture("en-US"))
    ]),

    // Convert list of records back into a table
    Result = Table.FromRecords(TransformedRows)

in
    Result
`