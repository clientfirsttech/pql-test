import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';
import useFolderContentsForFiles from 'src/lint/pq/use-folder-contents-for-files';


const _FolderFileUse = `
let
    Source = Folder.Files("C:\Users\"),
    #"Filtered Rows" = Table.SelectRows(Source, each ([Folder Path] = "C:\Users\All Users\Caphyon\Advanced Installer\{C5BD2A0F-A859-4234-9B25-2949CE747BCD}\"))
in
    #"Filtered Rows"
`

const _FolderFilesNoFolderPathFilter = `let
    Source = Folder.Files("C:\Users\")
in
    Source`

const _MultipleFilters = `let
    Source = Folder.Files("C:\Users\"),
    #"Filtered Rows" = Table.SelectRows(Source, each ([Folder Path] = "C:\Users\All Users\Caphyon\Advanced Installer\{C5BD2A0F-A859-4234-9B25-2949CE747BCD}\")),
    #"Filtered Rows1" = Table.SelectRows(#"Filtered Rows", each [Extension] = ".exe"),
    #"Filtered Rows2" = Table.SelectRows(#"Filtered Rows1", each Text.StartsWith([Name], "t"))
in
    #"Filtered Rows2"`

const _MultipleFilters2 = `let
    Source = Folder.Files("C:\Users\"),
    #"Filtered Rows" = Table.SelectRows(Source, each ([Folder Path] = "C:\Users\All Users\Caphyon\Advanced Installer\{C5BD2A0F-A859-4234-9B25-2949CE747BCD}\")),
    #"Filtered Rows1" = Table.SelectRows(#"Filtered Rows", each [Extension] = ".exe"),
    Custom1 = Folder.Files("C:\Users"),
    #"Filtered Rows2" = Table.SelectRows(Custom1, each Text.StartsWith([Name], "t"))
in
    #"Filtered Rows2"`

const testNoFalsePositive = `let
    Source = Folder.Contents("C:\Users\"),
    #"Filtered Rows3" = Table.SelectRows(Source, each ([Name] = "Default")),
    #"Filtered Rows4" = Table.SelectRows(#"Filtered Rows3", each Text.Contains([Folder Path], "C"))
in
    #"Filtered Rows4"`

describe('useFolderContentsForFiles Rule', () => {
    it('should return the expected RuleResult for _FolderFilesUse ', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(_FolderFileUse);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        const results: RuleResult[] = await lintMCode(parsedCode, [useFolderContentsForFiles]);
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(3);

    });

    it('should return the expected RuleResult for (_FolderFilesNoFolderPathFilter', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(_FolderFilesNoFolderPathFilter);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        const results: RuleResult[] = await lintMCode(parsedCode, [useFolderContentsForFiles]);
        expect(results.length).toBe(0);
    }); 

    it('should return the expected RuleResult for __MultipleFilters ', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(_MultipleFilters);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        const results: RuleResult[] = await lintMCode(parsedCode, [useFolderContentsForFiles]);
        expect(results.length).toBe(1);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(2);
    });

    it('should return the expected RuleResult for __MultipleFilters2', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(_MultipleFilters2);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        const results: RuleResult[] = await lintMCode(parsedCode, [useFolderContentsForFiles]);
        expect(results.length).toBe(2);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        expect(results[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(2);
        expect(results[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(5);
    });

    it('should return the expected RuleResult for testNoFalsePositive', async () => {
        const parsedCode: ParseResult = await parsePowerQueryText(testNoFalsePositive);
        //logDebug('Parsed Code:', JSON.stringify(parsedCode));
        const results: RuleResult[] = await lintMCode(parsedCode, [useFolderContentsForFiles]);
        expect(results.length).toBe(0);

    });
});

