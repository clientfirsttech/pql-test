import { lintMCode } from 'src/lint/linter-module'  // Adjust the import path according to your project structure
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';

import { noPlainTextClientForParameter } from 'src/lint/pq/no-plain-text-client-secret-as-parameter';

// Client Secret for API Key
const apiKeyParameter  = `"c2794109a09344baa34d455f95d09e22" meta [IsParameterQuery = true, IsParameterQueryRequired = true, Type = type text]
`

// URL for Parameter
const urlParameter = `
    "powerbi://api.powerbi.com/v1.0/myorg/Custom%20Connector%20Test" meta [IsParameterQuery = true, IsParameterQueryRequired = true, Type = type text]
`

// URL for SharePoint
const sharePointURL = `"https://kerski.sharepoint.com" meta [IsParameterQuery=true, Type="Any", IsParameterQueryRequired=true]`


const clientSecretParameter = `
    "PfY8Q~jmPJ2si69HsBo.rzZbbxY9z_hUc1vwVa1D" meta [IsParameterQuery = true, IsParameterQueryRequired = true, Type = type text]
`

const guidParameter = `
    // WorkspaceID
"9658004c-8083-4630-a7f4-3cb30c95db23" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]
`

// M Code example with Authorization header but without "Bearer"
const headersTokenUsageNoBearer = `let
    Source = (GroupID) as text =>
   let 
   Token = GetTokenPPU(AuthorityURL,ClientID,ClientSecret,UserName,Password,ResourceURL,TenantID),
   Params =
        [ 
            Headers = [#"Content-Type"="application/json",#"Authorization"="xxxx"],
            RelativePath = "v1.0/myorg/groups/" & GroupID & "/datasets"
        ],
    // Get Pages
    // Hard-coded Base URL because Power BI Service won't recognize parameter despite numerous attempts 
    WebSource = Web.Contents("https://api.powerbi.com",Params),
    // Convert to Json
    Result = Text.FromBinary(WebSource)
in
Result
in
    Source
`

const azureDatabricksHost = `// Host
"adb-3064640522536671.11.azuredatabricks.net" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]`


describe('noPlainTextClientForParameter Rule', () => {
    it('should return the expected RuleResult for API Key', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(apiKeyParameter);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noPlainTextClientForParameter]);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(1);
        });
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);
    }); 
    
    it('should return the expected RuleResult for Client Secret', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(clientSecretParameter);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noPlainTextClientForParameter]);

        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(2);
        });
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);
    });     

    it('should return the expected RuleResult for URL', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(urlParameter);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noPlainTextClientForParameter]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });    
    
    it('should return the expected RuleResult for headersTokenUsageNoBearer', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(headersTokenUsageNoBearer);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noPlainTextClientForParameter]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });   
    
    it('should return the expected RuleResult for SharePoint URL', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(sharePointURL);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noPlainTextClientForParameter]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });

    it('should return the expected RuleResult for Azure Databricks Host', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(azureDatabricksHost);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noPlainTextClientForParameter]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });    

    it('should return the expected RuleResult for Workspace GUID', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(guidParameter);

        // Lint the file using the actual rule
        const results: RuleResult[] = await lintMCode(parsedCode, [noPlainTextClientForParameter]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
    });    

});