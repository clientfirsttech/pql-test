import { testAIFix } from '../rule-testing-assistance'; // Adjust the import path according to your project structure
import { useTableFormatForSourceControl } from 'src/lint/pq/use-table-format-for-source-control';
import * as fs from 'fs';
import * as path from 'path';

describe('AI: Rewrite use-table-format-for-source-control Rule', () => {
    it('should fix table format violations for TableBinary (single violation)', async () => {
        await testAIFix(
            tableBinaryTest,
            useTableFormatForSourceControl,
            1, // Expected number of violations
            { debug: true, fileName: 'use-table-format-binary' }
        );
    }, 120000);
    
    it('should fix table format violations for TableBinary (double violations)', async () => {
        await testAIFix(
            doubleBinaryTest,
            useTableFormatForSourceControl,
            2, // Expected number of violations
            { debug: false, fileName: 'use-table-format-double-binary' }
        );
    }, 120000);

    it('should fix table format violations for Table Binary 2 file', async () => {
        await testAIFix(
            tableBinaryTest2,
            useTableFormatForSourceControl,
            1, // Expected number of violations
            { debug: false, fileName: 'use-table-format-binary-2' }
        );
    }, 120000);

const tableBinaryTest = `createOrReplace

	table Table
		lineageTag: be099d44-8c02-45bf-a644-f498bc13e088

		column Column1
			dataType: int64
			formatString: 0
			lineageTag: 2651a31d-c703-4f19-bfd6-f15950e029bb
			summarizeBy: sum
			sourceColumn: Column1

			annotation SummarizationSetBy = Automatic

		column Column2
			dataType: dateTime
			formatString: Long Date
			lineageTag: 3fd24e09-28bd-4457-9e94-d3e964daab81
			summarizeBy: none
			sourceColumn: Column2

			annotation SummarizationSetBy = Automatic

			annotation UnderlyingDateTimeDataType = Date

		column Column3
			dataType: string
			lineageTag: fd1f61a2-e641-4e35-b86b-6d5f2156d551
			summarizeBy: none
			sourceColumn: Column3

			annotation SummarizationSetBy = Automatic

		column Column4
			dataType: double
			lineageTag: bb295ee0-aee7-4939-8f68-4ae07ad0b637
			summarizeBy: sum
			sourceColumn: Column4

			annotation SummarizationSetBy = Automatic

			annotation PBI_FormatHint = {"isGeneralNumber":true}

		partition Table = m
			mode: import
			source =
					let
					    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i45WMlTSUTLUN9Q3MjAyBTI9UnNy8kFCekBubCwA", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [Column1 = _t, Column2 = _t, Column3 = _t, Column4 = _t]),
					    #"Changed Type" = Table.TransformColumnTypes(Source,{{"Column1", Int64.Type}, {"Column2", type date}, {"Column3", type text}, {"Column4", type number}})
					in
					    #"Changed Type"

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = Table
`;

const doubleBinaryTest = `createOrReplace

	table Table
		lineageTag: be099d44-8c02-45bf-a644-f498bc13e088

		column Column1
			dataType: int64
			formatString: 0
			lineageTag: 2651a31d-c703-4f19-bfd6-f15950e029bb
			summarizeBy: sum
			sourceColumn: Column1

			annotation SummarizationSetBy = Automatic

		column Column2
			dataType: dateTime
			formatString: Long Date
			lineageTag: 3fd24e09-28bd-4457-9e94-d3e964daab81
			summarizeBy: none
			sourceColumn: Column2

			annotation SummarizationSetBy = Automatic

			annotation UnderlyingDateTimeDataType = Date

		column Column3
			dataType: string
			lineageTag: fd1f61a2-e641-4e35-b86b-6d5f2156d551
			summarizeBy: none
			sourceColumn: Column3

			annotation SummarizationSetBy = Automatic

		column Column4
			dataType: double
			lineageTag: bb295ee0-aee7-4939-8f68-4ae07ad0b637
			summarizeBy: sum
			sourceColumn: Column4

			annotation SummarizationSetBy = Automatic

			annotation PBI_FormatHint = {"isGeneralNumber":true}

		partition Table = m
			mode: import
			source =
					let
					    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i45WMlTSUTLUN9Q3MjAyBTI9UnNy8kFCekBubCwA", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [Column1 = _t, Column2 = _t, Column3 = _t, Column4 = _t]),
					    #"Changed Type" = Table.TransformColumnTypes(Source,{{"Column1", Int64.Type}, {"Column2", type date}, {"Column3", type text}, {"Column4", type number}})
					in
					    #"Changed Type"

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = Table

	table 'Table (2)'
		lineageTag: 18d3ac49-d403-4213-87b1-f24600ec06b1

		column #
			dataType: string
			lineageTag: 391487ef-baa4-4ecf-bcfc-3e26ec3a91b5
			summarizeBy: none
			sourceColumn: #

			annotation SummarizationSetBy = Automatic

		column Word
			dataType: string
			lineageTag: 82b4a8af-7494-4eba-b8c2-b7872f99b045
			summarizeBy: none
			sourceColumn: Word

			annotation SummarizationSetBy = Automatic

		column Category
			dataType: string
			lineageTag: b597038d-b1c4-4f08-92f9-3e04f9ccdcf9
			summarizeBy: none
			sourceColumn: Category

			annotation SummarizationSetBy = Automatic

		partition 'Table (2)' = m
			mode: import
			source =
					let
					    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("lZVbTyM5EIX/SpTneQiQCzwSCDOMuEQkAo3QPNR0TLeF22657WWz4sevTxnYdHW/bEAJfY5T1Fcul5+fx0fjb+PzpjEqfV75qMP497fn8XF6WpJNPx35JD1dVMr7fUeeQibvXUh/PKpSBfqTAsKaIZB3ReGM7pnzpKxdoOB61iIp9/Sa3rdeZekUq7VVh9pZerilnP2XeDRJT5euBJnVNZmsHnGWQaggXRnVVGSlBdob7ayQQbvVpfJCB+qKSs5lqf0uq2DcNCjOW0cH4FrZMmrb0UG5qcgD/Uq3VVbBuSFTczJf8vGEsV0MHRWgD5HTLgLyZxWgP2PdCBmQmzddCxmQD4p2Qgbjk9dBCR2U20rbV6GDchm1kXFAealaXcosAXrhdiL+yYRrTWb/j3QA+4OaBh25qt1/xjGXbCflE45U+t56EK/+LhJb7zsz7hxTSx3UV4r8SzTSAviFcRGxnhSFdGiyAfIH4k3v6LzDlpvkUJ+C/ElbGWcK7k2UYaZMHZyvpQHuW2d3BPDL9M4q93JUrZB5m9XO9oy8z9FLfcHzQAuVe5lC9EI/y7l31dmEW27HDWBcTnsGzKWJqquC8ns67rYrg/GXMoareKCD8t6TLUUYYK6jz+PjQAflDTXB4bBsVVHZ5JUfaQJ1U5MPTeXyMBILQL3FIAsDJqMr/xdPD2HOeW5RGoLUDgSeHx30lPRQkfP19YDDDW9Kl05tVQ/4049/OmChPncqvDmeRtKd82VAGiRX0VudNvpjri8+S9C3uCfcC/UdlGbJ+981FpM8LF77Th7pSOBRVbr4vDuOeSzG4lUaJzxqi33BmXUsPgk+H8yOgSKc69QkZHtfQgmWjoLUwX/pinQO0WHevai2/RwNC+4PRUWlhlxUYWXLdM8N2acTbs23/aDJ5ajUy4CFktylc6sGvDwaog2Z/o6+CnzK14DO3Xqooyj3hSK5fp63SvkgDB4QzqtWGqjGIxmj9sLgm0AHyGtDxcd9D/5HbQzxWT4wmB0QXnwD5Ndt2r1dVwf1Ot+zByqAb2OrYt3VAbwpKucw6XGjsfw+OpuN3kfZGOH1PoI5yq/3tBa//2fp738B", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [#"#" = _t, Word = _t, Category = _t]),
					    #"Changed Type" = Table.TransformColumnTypes(Source,{{"#", type text}, {"Word", type text}, {"Category", type text}})
					in
					    #"Changed Type"

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = Table


`;

const tableBinaryTest2 = `createOrReplace
expression Report_Append =
				let
					Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i45W0jVU0lEK9fNWio0FAA==", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [id = _t, product = _t]),
					#"Changed Type" = Table.TransformColumnTypes(Source,{{"id", Int64.Type}, {"product", type text}})
				in
					#"Changed Type"
			lineageTag: bc82d7c7-482a-4b76-a40a-de15f12125bf
			queryGroup: 'No Load'

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Table
`;

});