import { lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useCustomConnectorForExchangeRecurringCalendarEvents } from 'src/lint/pq/use-custom-connector-for-exchange-recurring-calendar-events';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';
import { logDebug } from 'src/lint/rule-assistance';

let recurringUse = `
let
    Source = Exchange.Contents("jkerski@cftechnologiesllc.com"),
    Calendar1 = Source{[Name="Calendar"]}[Data],
    #"Expanded Attributes" = Table.ExpandRecordColumn(Calendar1, "Attributes", {"IsRecurring"}, {"Attributes.IsRecurring"})
in
    #"Expanded Attributes"`;

let noCalendarUse = `
let
    Source = Exchange.Contents("jkerski@cftechnologiesllc.com"),
    Mail = Source{[Name="Mail"]}[Data]
in
    Mail
`


describe('useCustomConnectorForExchangeRecurringCalendarEvents', () => {
  it('should return the expected RuleResult for recurringUse', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(recurringUse);
    logDebug(parsedCode);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useCustomConnectorForExchangeRecurringCalendarEvents]);

    // Check if the results match the expected RuleResult
    expect(results.length).toBe(1);

    // Validate that positionStart is not undefined in the results
    results.forEach(result => {
      expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
      expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(3);
    });    
  });

  it('should return the expected RuleResult for noCalendarUse', async () => {
    // Parse the M Code
    const parsedCode: ParseResult = await parsePowerQueryText(noCalendarUse);
    // Lint the file using the actual rule
    const results: RuleResult[] = await lintMCode(parsedCode, [useCustomConnectorForExchangeRecurringCalendarEvents]);
    // Check if the results match the expected RuleResult
    expect(results.length).toBe(0);
  });
});
