import { extractMCodeAndProperties, extractMCodePositions, parseTMDLLines } from 'src/parser/tmdl/tmdl-parser';
import { tmdlCodeSample1, tmdlCodeSample3, tmdlCodeSample5 } from '../hardcoded-tmdl';
import * as fs from 'fs';
import * as path from 'path';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { expandXorParent } from '@microsoft/powerquery-parser/lib/powerquery-parser/common/traversal';

const _TMDL_with_Ticks_DataFilePath = path.resolve('./test-files/tmdl_with_ticks.tmdl');
const _TMDL_with_Several_Funcs_DataFilePath = path.resolve('./test-files/tmdl_with_several_functions.tmdl');
const _TMDL_With_Several_R_Executes_DataFilePath = path.resolve('./test-files/scan_tmdl/R.tmdl');
const _TMDL_With_File_Folder_DataFilePath = path.resolve('./test-files/scan_tmdl/FileFolderAccess.tmdl');
const _TMDL_With_Calculated_Paritition_DataFilePath = path.resolve('./test-files/Calculated-Partition.tmdl');
const _TMDL_With_Calculated_Paritition2_DataFilePath  = path.resolve('./test-files/Calculated-Partition2.tmdl');
const _TMDL_With_Three_Types_DataFilePath  = path.resolve('./test-files/Three-Table-Types.tmdl');
const _TMDL_11_26_2025_Issue_DataFilePath = path.resolve('./test-files/11_26_2025_Issue.tmdl');
const _TMDL_Date_11_26_2025_Issue_DataFilePath = path.resolve('./test-files/Date_11_26_2025_Issue.tmdl');

// Definition Files
const _TMDL_Date_Culture_Fail_DataFilePath = path.resolve('./test-files/Files/SearchPowerQuery.SemanticModel/definition/tables/Date_Culture_Fail.tmdl');
const _TMDL_Functions_Table_DataFilePath = path.resolve('./test-files/Files/SearchPowerQuery.SemanticModel/definition/tables/Functions Table.tmdl');

// Expression Files
const _TMDL_Expressions1_DataFilePath = path.resolve('./test-files/test_tmdl/DuplicativeTest.SemanticModel/definition/expressions.tmdl');
const _TMDL_Expressions2_DataFilePath = path.resolve('./test-files/test_tmdl/ManipulatingFilesLinter.SemanticModel/definition/expressions.tmdl');

// Handle combined TMDL source from Azure DevOps/GitHub Actions flow
const _TMDL_Databricks_DataFilePath = path.resolve('./test-files/Databricks_API.tmdl');
const _TMDL_Databricks_Data = fs.readFileSync(_TMDL_Databricks_DataFilePath, 'utf-8');

const createOrReplaceTest = `    table Query1
        partition Query1 = m
                mode: import
                source =
                        let
                                Source = Excel.Workbook(File.Contents(DataFilePath), null, true),
                                Data = Source{[Name="Sheet1"]}[Content],
                                // Adds a new column "NewCol" with constant value 1
                                AddedCol = Table.AddColumn(Data, "NewCol", each 1)
                        in
                                AddedCol

    expression DataFilePath = "C:\data.xlsx" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]`

const foldingNativeQueryTMDL = `createOrReplace

	table SQLServer_NativeQuery_Folding_Fail
		lineageTag: 250e5031-f8df-4f24-9109-a7c75afe8af4

		column Field
			dataType: string
			lineageTag: 6c8d8ae8-80ab-498d-8a4b-26279201ac45
			summarizeBy: none
			sourceColumn: Field

		column Value
			dataType: dateTime
			lineageTag: 2887c593-b7bc-45f5-b9db-556fc60f6da4
			summarizeBy: none
			sourceColumn: Value

		partition SQLServer_NativeQuery_Folding_Fail = m
			mode: import
			source =
					let
					    DatabaseConnection = Sql.Database("server", "database"),
					    NativeQueryResult = Value.NativeQuery(DatabaseConnection, "SELECT * FROM Table", null, [EnableFolding=true])
					in
					    NativeQueryResult
`;

describe('parseLines', () => {
    it('should parse a single TMDL object with partition properties from _TMDL_With_Unicode_DataFilePath', () => {
        const fileContent = fs.readFileSync(_TMDL_With_Calculated_Paritition_DataFilePath, 'utf-8');
        const extractedData = parseTMDLLines(fileContent);        
        expect(extractedData).toBeDefined();

    });

    it('should parse a single TMDL object with partition properties from tmdlCodeSample1', () => {
        const result = parseTMDLLines(tmdlCodeSample1);
        console.log('Parsed TMDL:', JSON.stringify(result, null, 2)); // Log the parsed result for debugging

        expect(result).toBeDefined();

        // Extract partition properties
        const partitions = Object.keys(result).filter(key => key.toLowerCase().includes('partition'));
        expect(partitions.length).toBeGreaterThan(0); // Ensure at least one partition exists

        // Retrieve the first partition key
        const firstPartitionKey = partitions[0];
        expect(firstPartitionKey).toBeDefined();
        console.log(`First Partition Key: ${firstPartitionKey}`);

        // Validate the first partition
        const firstPartition = result[firstPartitionKey];
        expect(firstPartition).toBeDefined();
        console.log(`First Partition:`, JSON.stringify(firstPartition, null, 2));

        // Check if the first key is "PlannerTaskers" and has the correct startPositionLineNumber
        const firstKey = Object.keys(firstPartition)[0];
        expect(firstKey).toBe('PlannerTasks = m');
        const firstPartitionDetails = firstPartition[firstKey][0];
        expect(firstPartitionDetails.startPositionLineNumber).toBe(275);
        console.log(`First Key: ${firstKey}, Start Position Line Number: ${firstPartitionDetails.startPositionLineNumber}`);
    });
});

describe('extractMCodePositions', () => {
     it('should extract M code positions from TMDL code tmdlCodeSample1', () => {
        const positions = extractMCodePositions(tmdlCodeSample1);

        expect(positions).toBeDefined();
        console.log('Extracted M Code Positions:', JSON.stringify(positions, null, 2)); // Log the extracted positions for debugging

        // Check for the specific partition entry
        const targetPosition = positions.find(
            pos =>
                pos.key === 'partition' &&
                pos.value === 'PlannerTasks = m' &&
                pos.startPositionLineNumber === 275 &&
                pos.endPositionLineNumber === 291
        );

        expect(targetPosition).toBeDefined();
        expect(targetPosition?.key).toBe('partition');
        expect(targetPosition?.value).toBe('PlannerTasks = m');
        expect(targetPosition?.startPositionLineNumber).toBe(275);
        expect(targetPosition?.endPositionLineNumber).toBe(291);

        console.log('Target Position:', JSON.stringify(targetPosition, null, 2));
    });

    it('should extract M code positions from TMDL code', () => {
        const fileContent = fs.readFileSync(_TMDL_with_Ticks_DataFilePath, 'utf-8');
        const positions = extractMCodePositions(fileContent);

        expect(positions).toBeDefined();
        console.log('Extracted M Code Positions:', JSON.stringify(positions, null, 2)); // Log the extracted positions for debugging

                // Check for the specific expression entry
                const targetExpression = positions.find(
                    pos =>
                        pos.key === 'expression' &&
                        pos.value === "'Puzzle Two - Setup' = ```" &&
                        pos.startPositionLineNumber === 675 &&
                        pos.endPositionLineNumber === 696
                );
        
                expect(targetExpression).toBeDefined();
                expect(targetExpression?.key).toBe('expression');
                expect(targetExpression?.value).toBe("'Puzzle Two - Setup' = ```");
                expect(targetExpression?.startPositionLineNumber).toBe(675);
                expect(targetExpression?.endPositionLineNumber).toBe(696);
        
                console.log('Target Expression:', JSON.stringify(targetExpression, null, 2));
    });    

    it('should extract M code positions from TMDL code with parameters', () => {
        const positions = extractMCodePositions(tmdlCodeSample5);

        const expressions = positions.filter(item => item.key === 'expression');
        expect(positions).toBeDefined();
        console.log('Extracted M Code Positions:', JSON.stringify(positions, null, 2)); // Log the extracted positions for debugging

        expect(expressions.length).toBe(3);
        expect(expressions[0].startPositionLineNumber).toBe(81);
        expect(expressions[1].startPositionLineNumber).toBe(88);
        expect(expressions[2].startPositionLineNumber).toBe(95);
    });       
});

describe('extractMCodeAndProperties', () => {
    it('should parse a single TMDL object with partition properties from _TMDL_With_Calculated_Paritition_DataFilePath', () => {
        const fileContent = fs.readFileSync(_TMDL_With_Calculated_Paritition_DataFilePath, 'utf-8');
        const extractedData = extractMCodeAndProperties(fileContent);        
        expect(extractedData).toBeDefined();
        console.log('Extracted M Code and Properties:', JSON.stringify(extractedData, null, 2)); // Log the extracted data for debugging
        expect(extractedData.length).toBe(1); // Expect some data to be extracted
        expect(extractedData[0].properties.isCalculated).toBe(true);
    });

    it('should parse a single TMDL object with partition properties from _TMDL_With_Calculated_Paritition2_DataFilePath', () => {
        const fileContent = fs.readFileSync(_TMDL_With_Calculated_Paritition2_DataFilePath, 'utf-8');
        const extractedData = extractMCodeAndProperties(fileContent);        
        expect(extractedData).toBeDefined();
        console.log('Extracted M Code and Properties:', JSON.stringify(extractedData, null, 2)); // Log the extracted data for debugging
        expect(extractedData.length).toBe(1); // Expect some data to be extracted
        expect(extractedData[0].properties.isCalculated).toBe(true);
    });    

    it('should parse a single TMDL object with partition properties from _TMDL_With_Three_Types_DataFilePath', () => {
        const fileContent = fs.readFileSync(_TMDL_With_Three_Types_DataFilePath, 'utf-8');
        const extractedData = extractMCodeAndProperties(fileContent);        
        expect(extractedData).toBeDefined();
        expect(extractedData.length).toBe(3); // Expect some data to be extracted
        
        for (const item of extractedData) {
            console.log('Extracted Item:', item.name, item.resultType, item.properties.isCalculated); // Log the extracted item for debugging
            if (item.resultType === 'Partition') {
                if(item.name === "Calculated Table") {
                    expect(item.properties.isCalculated).toBe(true);
                }
                else{
                    expect(item.properties.isCalculated).toBe(false);
                }
            }

            if (item.resultType === 'Expression') {
                expect(item.properties.isCalculated).toBe(false); // Check if the expression is calculated
            }
        }
    });        

    it('should extract M code and properties from TMDL code', () => {
        const fileContent = fs.readFileSync(_TMDL_with_Ticks_DataFilePath, 'utf-8');
        const extractedData = extractMCodeAndProperties(fileContent);

        expect(extractedData).toBeDefined();
        console.log('Extracted M Code and Properties:', JSON.stringify(extractedData, null, 2)); // Log the extracted data for debugging

        // Check that there are 13 partitions
        const partitionCount = extractedData.filter(item => item.resultType === 'Partition').length;
        expect(partitionCount).toBe(13);
        console.log(`Number of Partitions: ${partitionCount}`);

        // Check that there are 13 expressions
        const expressionCount = extractedData.filter(item => item.resultType === 'Expression').length;
        expect(expressionCount).toBe(13);
        console.log(`Number of Expressions: ${expressionCount}`);

        // Ensure each name, code, and lineNumber is not null or empty
        extractedData.forEach(item => {
            expect(item.name).toBeDefined();
            expect(item.name).not.toBe('');
            expect(item.code).toBeDefined();
            expect(item.code).not.toBeNull();
            expect(item.code).not.toBe('');
            expect(item.lineNumber).toBeDefined();
            expect(item.lineNumber).toBeGreaterThan(0);
            expect(item.properties.isCalculated).toBe(false); // Check if the partition is not calculated

            // Ensure each code can be parsed without throwing
            if (item.code) {
                expect(() => parsePowerQueryText(item.code!)).not.toThrow();
            }
        });
    });

    it('should extract M code and properties from TMDL code with functions', () => {
        const fileContent = fs.readFileSync(_TMDL_with_Several_Funcs_DataFilePath, 'utf-8');
        const extractedData = extractMCodeAndProperties(fileContent);

        expect(extractedData).toBeDefined();
        console.log('Extracted M Code and Properties:', JSON.stringify(extractedData, null, 2)); // Log the extracted data for debugging

        // Check that there are 2 partitions
        const partitionCount = extractedData.filter(item => item.resultType === 'Partition').length;
        expect(partitionCount).toBe(2);
        console.log(`Number of Partitions: ${partitionCount}`);

        // Check that there are 5 expressions
        const expressionCount = extractedData.filter(item => item.resultType === 'Expression').length;
        expect(expressionCount).toBe(5);
        console.log(`Number of Expressions: ${expressionCount}`);

        // Ensure each name, code, and lineNumber is not null or empty
        extractedData.forEach(item => {
            expect(item.name).toBeDefined();
            expect(item.name).not.toBe('');
            expect(item.code).toBeDefined();
            expect(item.code).not.toBeNull();
            expect(item.code).not.toBe('');
            expect(item.lineNumber).toBeDefined();
            expect(item.lineNumber).toBeGreaterThan(0);
            expect(item.properties.isCalculated).toBe(false); // Check if the partition is not calculated

            // Ensure each code can be parsed without throwing
            if (item.code) {
                expect(() => parsePowerQueryText(item.code!)).not.toThrow();
            }
        });

        // Filter for the name "testCreateFunction"
        const filteredData = extractedData.filter(item => item.name === 'testCreateFunction');
        console.log('Filtered Data:', JSON.stringify(filteredData, null, 2)); // Log the filtered data for debugging
        expect(filteredData.length).toBeGreaterThan(0); // Ensure at least one match is found
        expect(filteredData[0].name).toBe('testCreateFunction');
        expect(filteredData[0].properties?.mAttributes).not.toBeNull();
        expect(filteredData[0].properties?.queryGroup).toBe("testCreateFunction");
    });    

    it('should extract M code and properties from TMDL code - tmdlCodeSample5', () => {
        const extractedData = extractMCodeAndProperties(tmdlCodeSample5);

        expect(extractedData).toBeDefined();
        console.log('Extracted M Code and Properties:', JSON.stringify(extractedData, null, 2)); // Log the extracted data for debugging

        // Check that there are 13 partitions
        const partitions = extractedData.filter(item => item.resultType === 'Partition');
        expect(partitions.length).toBe(2);
        console.log(`Number of Partitions: ${partitions.length}`);
        expect(partitions[0].lineNumber).toBe(41);
        expect(partitions[1].lineNumber).toBe(66);

        // Check that there are 13 expressions
        const expressions = extractedData.filter(item => item.resultType === 'Expression');
        expect(expressions.length).toBe(3);
        console.log(`Number of Expressions: ${expressions.length}`);
        expect(expressions[0].lineNumber).toBe(81);
        expect(expressions[1].lineNumber).toBe(88);    
        expect(expressions[2].lineNumber).toBe(95);
        
       // Ensure each name, code, and lineNumber is not null or empty
        extractedData.forEach(item => {
            expect(item.name).toBeDefined();
            expect(item.name).not.toBe('');
            expect(item.code).toBeDefined();
            expect(item.code).not.toBeNull();
            expect(item.code).not.toBe('');
            expect(item.lineNumber).toBeDefined();
            expect(item.lineNumber).toBeGreaterThan(0);
            expect(item.properties.isCalculated).toBe(false); // Check if the partition is not calculated

            // Ensure each code can be parsed without throwing
            if (item.code) {
                expect(() => parsePowerQueryText(item.code!)).not.toThrow();
            }
        });        
    });

    it('should extract M code and properties from code with R functions', () => {
        const fileContent = fs.readFileSync(_TMDL_With_Several_R_Executes_DataFilePath, 'utf-8');
        const extractedData = extractMCodeAndProperties(fileContent);

        expect(extractedData).toBeDefined();
        console.log('Extracted M Code and Properties:', JSON.stringify(extractedData, null, 2)); // Log the extracted data for debugging

        // Check that there are 2 partitions
        const partitionCount = extractedData.filter(item => item.resultType === 'Partition').length;
        expect(partitionCount).toBe(7);
        console.log(`Number of Partitions: ${partitionCount}`);

        // Check that there are 13 expressions
        const expressionCount = extractedData.filter(item => item.resultType === 'Expression').length;
        expect(expressionCount).toBe(2);
        console.log(`Number of Expressions: ${expressionCount}`);

        // Ensure each name, code, and lineNumber is not null or empty
        extractedData.forEach(item => {
            expect(item.name).toBeDefined();
            expect(item.name).not.toBe('');
            expect(item.code).toBeDefined();
            expect(item.code).not.toBeNull();
            expect(item.code).not.toBe('');
            expect(item.lineNumber).toBeDefined();
            expect(item.lineNumber).toBeGreaterThan(0);
            expect(item.properties.isCalculated).toBe(false); // Check if the partition is not calculated

            // Ensure each code can be parsed without throwing
            if (item.code) {
                expect(() => parsePowerQueryText(item.code!)).not.toThrow();
            }
        });

        // Filter for the name "testCreateFunction"
        const filteredData = extractedData.filter(item => item.name === 'fnRExample');
        console.log('Filtered Data:', JSON.stringify(filteredData, null, 2)); // Log the filtered data for debugging
        expect(filteredData.length).toBeGreaterThan(0); // Ensure at least one match is found  
        expect(filteredData[0].code?.startsWith('\nlet')).toBe(true); 
        expect(filteredData[0].lineNumber).toBe(324); // Check the line number
    });

    it('should extract M code and properties from TMDL code with back ticks', () => {
        const fileContent = fs.readFileSync(_TMDL_With_File_Folder_DataFilePath, 'utf-8');
        const extractedData = extractMCodeAndProperties(fileContent);

        expect(extractedData).toBeDefined();
        console.log('Extracted M Code and Properties:', JSON.stringify(extractedData, null, 2)); // Log the extracted data for debugging

        // Check that there are 13 partitions
        const partitions = extractedData.filter(item => item.resultType === 'Partition');
        expect(partitions.length).toBe(2);
        console.log(`Number of Partitions: ${partitions.length}`);
        expect(partitions[0].lineNumber).toBe(50);
        expect(partitions[1].lineNumber).toBe(83);
        
       // Ensure each name, code, and lineNumber is not null or empty
        extractedData.forEach(item => {
            expect(item.name).toBeDefined();
            expect(item.name).not.toBe('');
            expect(item.code).toBeDefined();
            expect(item.code).not.toBeNull();
            expect(item.code).not.toBe('');
            if (item.code) {
                expect(item.code.startsWith('```')).toBe(false);
                expect(item.code.endsWith('```')).toBe(false); // Check if the code ends with backticks
            }
            expect(item.lineNumber).toBeDefined();
            expect(item.lineNumber).toBeGreaterThan(0);
            expect(item.properties.isCalculated).toBe(false); // Check if the partition is not calculated

            // Ensure each code can be parsed without throwing
            if (item.code) {
                expect(() => parsePowerQueryText(item.code!)).not.toThrow();
            }
        });        
    });
});

describe('extractMCodeAndProperties with .tmdl files', () => {

    it('should extract M code and properties from TMDL code Date Culture Fail.tmdl', () => {
        const fileContent = fs.readFileSync(_TMDL_Date_Culture_Fail_DataFilePath, 'utf-8');
        const extractedData = extractMCodeAndProperties(fileContent);        

        expect(extractedData).toBeDefined();
        console.log('Extracted M Code and Properties:', JSON.stringify(extractedData, null, 2)); // Log the extracted data for debugging

        // Check that there are 13 partitions
        const partitions = extractedData.filter(item => item.resultType === 'Partition');
        expect(partitions.length).toBe(1);
        console.log(`Number of Partitions: ${partitions.length}`);
        expect(partitions[0].lineNumber).toBe(47);
        
       // Ensure each name, code, and lineNumber is not null or empty
        extractedData.forEach(item => {
            expect(item.name).toBeDefined();
            expect(item.name).not.toBe('');
            expect(item.code).toBeDefined();
            expect(item.code).not.toBeNull();
            expect(item.code).not.toBe('');
            expect(item.lineNumber).toBeDefined();
            expect(item.lineNumber).toBeGreaterThan(0);
            expect(item.properties.isCalculated).toBe(false); // Check if the partition is not calculated

            // Ensure each code can be parsed without throwing
            if (item.code) {
                expect(() => parsePowerQueryText(item.code!)).not.toThrow();
            }
        });        
    });

    it('should extract M code and properties from TMDL code Functions Table.tmdl', () => {
        const fileContent = fs.readFileSync(_TMDL_Functions_Table_DataFilePath, 'utf-8');
        const extractedData = extractMCodeAndProperties(fileContent);        

        expect(extractedData).toBeDefined();
        console.log('Extracted M Code and Properties:', JSON.stringify(extractedData, null, 2)); // Log the extracted data for debugging

        // Check that there are 13 partitions
        const partitions = extractedData.filter(item => item.resultType === 'Partition');
        expect(partitions.length).toBe(1);
        console.log(`Number of Partitions: ${partitions.length}`);
        expect(partitions[0].lineNumber).toBe(120);
        
       // Ensure each name, code, and lineNumber is not null or empty
        extractedData.forEach(item => {
            expect(item.name).toBeDefined();
            expect(item.name).not.toBe('');
            expect(item.code).toBeDefined();
            expect(item.code).not.toBeNull();
            expect(item.code).not.toBe('');
            expect(item.lineNumber).toBeDefined();
            expect(item.lineNumber).toBeGreaterThan(0);
            expect(item.properties.isCalculated).toBe(false); // Check if the partition is not calculated

            // Ensure each code can be parsed without throwing
            if (item.code) {
                expect(() => parsePowerQueryText(item.code!)).not.toThrow();
            }
        });        
    });   
    
    it('should extract M code and properties for expression.tmdl', () => {
        const fileContent = fs.readFileSync(_TMDL_Expressions1_DataFilePath, 'utf-8');
        const extractedData = extractMCodeAndProperties(fileContent);

        expect(extractedData).toBeDefined();
        console.log('Extracted M Code and Properties:', JSON.stringify(extractedData, null, 2)); // Log the extracted data for debugging

        // Check that there are 13 partitions
        const expressions = extractedData.filter(item => item.resultType === 'Expression');
        expect(expressions.length).toBe(2);
        console.log(`Number of Expressions: ${expressions.length}`);
        expect(expressions[0].lineNumber).toBe(1);
        expect(expressions[1].lineNumber).toBe(15);

        
       // Ensure each name, code, and lineNumber is not null or empty
        extractedData.forEach(item => {
            expect(item.name).toBeDefined();
            expect(item.name).not.toBe('');
            expect(item.code).toBeDefined();
            expect(item.code).not.toBeNull();
            expect(item.code).not.toBe('');
            expect(item.lineNumber).toBeDefined();
            expect(item.lineNumber).toBeGreaterThan(0);
            expect(item.properties.isCalculated).toBe(false); // Check if the partition is not calculated

            // Ensure each code can be parsed without throwing
            if (item.code) {
                expect(() => parsePowerQueryText(item.code!)).not.toThrow();
            }
        });        
    }); 
    
    it('should extract M code and properties for expression.tmdl 2', () => {
        const fileContent = fs.readFileSync(_TMDL_Expressions2_DataFilePath, 'utf-8');
        const extractedData = extractMCodeAndProperties(fileContent);

        expect(extractedData).toBeDefined();
        console.log('Extracted M Code and Properties:', JSON.stringify(extractedData, null, 2)); // Log the extracted data for debugging

        // Check that there are 13 partitions
        const expressions = extractedData.filter(item => item.resultType === 'Expression');
        expect(expressions.length).toBe(8);
        console.log(`Number of Expressions: ${expressions.length}`);
        expect(expressions[0].lineNumber).toBe(1);
        expect(expressions[1].lineNumber).toBe(9);
        expect(expressions[2].lineNumber).toBe(23);
        expect(expressions[3].lineNumber).toBe(37);
        expect(expressions[4].lineNumber).toBe(55);
        expect(expressions[5].lineNumber).toBe(67);
        expect(expressions[6].lineNumber).toBe(73);
        expect(expressions[7].lineNumber).toBe(84);

       // Ensure each name, code, and lineNumber is not null or empty
        extractedData.forEach(item => {
            expect(item.name).toBeDefined();
            expect(item.name).not.toBe('');
            expect(item.code).toBeDefined();
            expect(item.code).not.toBeNull();
            expect(item.code).not.toBe('');
            expect(item.lineNumber).toBeDefined();
            expect(item.lineNumber).toBeGreaterThan(0);
            expect(item.properties.isCalculated).toBe(false); // Check if the partition is not calculated

            // Ensure each code can be parsed without throwing
            if (item.code) {
                expect(() => parsePowerQueryText(item.code!)).not.toThrow();
            }
        });        
    });     
});

describe('extractMCodeAndProperties with combined files from Azure DevOps/GitHub Actions', () => {

    it('should extract M code and properties from TMDL code', () => {
        const fileContent = _TMDL_Databricks_Data
        const extractedData = extractMCodeAndProperties(fileContent);        

        expect(extractedData).toBeDefined();
        console.log('Extracted M Code and Properties:', JSON.stringify(extractedData, null, 2)); // Log the extracted data for debugging

        // Check that there are 11 partitions
        const partitions = extractedData.filter(item => item.resultType === 'Partition');
        expect(partitions.length).toBe(11);
        console.log(`Number of Partitions: ${partitions.length}`);      
    });   
});

describe('Parse createOrReplaceTest', () => {

    it('should extract M code and properties from TMDL code', () => {
        const extractedData = extractMCodeAndProperties(createOrReplaceTest);        

        expect(extractedData).toBeDefined();
        console.log('Extracted M Code and Properties:', JSON.stringify(extractedData, null, 2)); // Log the extracted data for debugging

        // Check that there are 11 partitions
        const partitions = extractedData.filter(item => item.resultType === 'Partition');
        expect(partitions.length).toBe(1);
        console.log(`Number of Partitions: ${partitions.length}`);      
    });   
});

describe('extractMCodeAndProperties with Value.NativeQuery', () => {

    it('should extract Value.NativeQuery partitions with EnableFolding option', () => {
        const extractedData = extractMCodeAndProperties(foldingNativeQueryTMDL);
        console.log('Extracted M Code and Properties:', JSON.stringify(extractedData, null, 2)); // Log the extracted data for debugging    
        expect(extractedData).toBeDefined();
        expect(extractedData.length).toBe(1);

        const partition = extractedData[0];
        expect(partition.resultType).toBe('Partition');
        expect(partition.name).toBe('SQLServer_NativeQuery_Folding_Fail');
        expect(partition.code).toContain('Value.NativeQuery');
        expect(partition.code).toContain('EnableFolding=true');
        expect(() => parsePowerQueryText(partition.code!)).not.toThrow();
    });
});

describe('extractMCodeAndProperties with 11_26_2025_Issue.tmdl', () => {

    it('should extract M code and properties from 11_26_2025_Issue.tmdl', async () => {
        const fileContent = fs.readFileSync(_TMDL_11_26_2025_Issue_DataFilePath, 'utf-8');
        const extractedData = extractMCodeAndProperties(fileContent);
        
        expect(extractedData).toBeDefined();
        console.log('Extracted M Code and Properties:', JSON.stringify(extractedData, null, 2));

        // Validate partitions
        const partitions = extractedData.filter(item => item.resultType === 'Partition');
        console.log(`Number of Partitions: ${partitions.length}`);
        expect(partitions.length).toBeGreaterThan(0);

        // Validate expressions
        const expressions = extractedData.filter(item => item.resultType === 'Expression');
        console.log(`Number of Expressions: ${expressions.length}`);

        // Identify items that should have parse errors (include keyword expressions)
        const expectedParseErrorNames = ['IssueTrackerCsvUrl', 'ReportInfoCsvUrl'];

        // Ensure each code block can be parsed without errors (except for include expressions)
        let parseErrorCount = 0;
        for (let index = 0; index < extractedData.length; index++) {
            const item = extractedData[index];
            expect(item.name).toBeDefined();
            expect(item.name).not.toBe('');
            
            const shouldHaveParseError = expectedParseErrorNames.includes(item.name);
            
            if(item.properties.isCalculated === false){
                expect(item.code).toBeDefined();
                expect(item.code).not.toBeNull();
                expect(item.code).not.toBe('');
                expect(item.lineNumber).toBeDefined();
                expect(item.lineNumber).toBeGreaterThan(0);
                
                if (item.code) {
                    try {
                        const parseResult = await parsePowerQueryText(item.code);
                        
                        // Check if parse result indicates an error
                        if (!parseResult || parseResult.error) {
                            if (shouldHaveParseError) {
                                console.log(`✓ Expected parse error in code block ${index + 1} (${item.name})`);
                            } else {
                                parseErrorCount++;
                                console.error(`✗ Unexpected parse error in code block ${index + 1} (${item.name}): Parse result contains error`);
                                if (parseResult.error) {
                                    console.error('Error details:', JSON.stringify(parseResult.error, null, 2));
                                }
                            }
                        } else {
                            if (shouldHaveParseError) {
                                parseErrorCount++;
                                console.error(`✗ Expected parse error but none found in code block ${index + 1} (${item.name})`);
                            } else {
                                console.log(`✓ Code block ${index + 1} (${item.name}) parsed successfully`);
                            }
                        }
                    } catch (err) {
                        if (shouldHaveParseError) {
                            console.log(`✓ Expected parse exception in code block ${index + 1} (${item.name})`);
                        } else {
                            parseErrorCount++;
                            console.error(`✗ Unexpected parse exception in code block ${index + 1} (${item.name}):`, err instanceof Error ? err.message : String(err));
                            console.error(`Problematic code:\n${item.code.substring(0, 300)}...`);
                        }
                    }
                }
            }
        }

        // Assert no unexpected parse errors occurred
        expect(parseErrorCount).toBe(0);
        console.log(`✓ All ${extractedData.length} code blocks validated (${expectedParseErrorNames.length} expected parse errors found)`);
    });

    it('should extract M code and properties from Date_11_26_2025_Issue.tmdl', async () => {
        const fileContent = fs.readFileSync(_TMDL_Date_11_26_2025_Issue_DataFilePath, 'utf-8');
        const extractedData = extractMCodeAndProperties(fileContent);
        
        expect(extractedData).toBeDefined();
        console.log('Extracted M Code and Properties:', JSON.stringify(extractedData, null, 2));

        // Validate partitions
        const partitions = extractedData.filter(item => item.resultType === 'Partition');
        console.log(`Number of Partitions: ${partitions.length}`);
        expect(partitions.length).toBeGreaterThan(0);

        // Validate expressions
        const expressions = extractedData.filter(item => item.resultType === 'Expression');
        console.log(`Number of Expressions: ${expressions.length}`);

        // Identify items that should have parse errors (include keyword expressions)
        const expectedParseErrorNames = [''];

        // Ensure each code block can be parsed without errors (except for include expressions)
        let parseErrorCount = 0;
        for (let index = 0; index < extractedData.length; index++) {
            const item = extractedData[index];
            expect(item.name).toBeDefined();
            expect(item.name).not.toBe('');
            
            const shouldHaveParseError = expectedParseErrorNames.includes(item.name);
            
            if(item.properties.isCalculated === false){
                expect(item.code).toBeDefined();
                expect(item.code).not.toBeNull();
                expect(item.code).not.toBe('');
                expect(item.lineNumber).toBeDefined();
                expect(item.lineNumber).toBeGreaterThan(0);
                
                if (item.code) {
                    try {
                        const parseResult = await parsePowerQueryText(item.code);
                        
                        // Check if parse result indicates an error
                        if (!parseResult || parseResult.error) {
                            if (shouldHaveParseError) {
                                console.log(`✓ Expected parse error in code block ${index + 1} (${item.name})`);
                            } else {
                                parseErrorCount++;
                                console.error(`✗ Unexpected parse error in code block ${index + 1} (${item.name}): Parse result contains error`);
                                if (parseResult.error) {
                                    console.error('Error details:', JSON.stringify(parseResult.error, null, 2));
                                }
                            }
                        } else {
                            if (shouldHaveParseError) {
                                parseErrorCount++;
                                console.error(`✗ Expected parse error but none found in code block ${index + 1} (${item.name})`);
                            } else {
                                console.log(`✓ Code block ${index + 1} (${item.name}) parsed successfully`);
                            }
                        }
                    } catch (err) {
                        if (shouldHaveParseError) {
                            console.log(`✓ Expected parse exception in code block ${index + 1} (${item.name})`);
                        } else {
                            parseErrorCount++;
                            console.error(`✗ Unexpected parse exception in code block ${index + 1} (${item.name}):`, err instanceof Error ? err.message : String(err));
                            console.error(`Problematic code:\n${item.code.substring(0, 300)}...`);
                        }
                    }
                }
            }
        }

        // Assert no unexpected parse errors occurred
        expect(parseErrorCount).toBe(0);
        console.log(`✓ All ${extractedData.length} code blocks validated (${expectedParseErrorNames.length} expected parse errors found)`);
    });
});
