import { parse } from "path";
import { logDebug } from 'src/lint/rule-assistance';
import parseCopiedPQ from 'src/parser/pq/parse-copied-pq';
import { M_Code_From_Copied_PQ } from 'src/parser/pq/parse-types';

describe("parseCopiedPQ", () => {
    it("should return an array of length 4 for multiple queries and parameters", async () => {

        const result: M_Code_From_Copied_PQ[] = await parseCopiedPQ(pqCode);
        logDebug("Result of parseCopiedPQ:", JSON.stringify(result, null, 2));
        expect(result.length).toBe(4);

        expect(result[0].lineNumber).toBe(1); // Check line number of first section
        expect(result[1].lineNumber).toBe(8); // Check line number of second section
        expect(result[2].lineNumber).toBe(15); // Check line number of third section
        expect(result[3].lineNumber).toBe(18); // Check line number of fourth section

    });

    it("should return an array of length 3 for multiple queries and parameters", async () => {

        const result = await parseCopiedPQ(pqCode2);
        expect(Array.isArray(result)).toBe(true);
        expect(result.length).toBe(3);

        expect(result[0].lineNumber).toBe(2); // Check line number of first section
        expect(result[1].lineNumber).toBe(5); // Check line number of second section 
        expect(result[2].lineNumber).toBe(13); // Check line number of third section
    });

    it("should return an array of length 9 for multiple queries and parameters", async () => {

        const result = await parseCopiedPQ(pqCode3);
        expect(Array.isArray(result)).toBe(true);
        expect(result.length).toBe(9);

        expect(result[0].lineNumber).toBe(2); // Check line number of first section
        expect(result[1].lineNumber).toBe(5); // Check line number of second section
        expect(result[2].lineNumber).toBe(12); // Check line number of third section
        expect(result[3].lineNumber).toBe(42); // Check line number of fourth section
        expect(result[4].lineNumber).toBe(77); // Check line number of fifth section
        expect(result[5].lineNumber).toBe(80); // Check line number of sixth section
        expect(result[6].lineNumber).toBe(89); // Check line number of seventh section
        expect(result[7].lineNumber).toBe(104); // Check line number of eighth section
        expect(result[8].lineNumber).toBe(112); // Check line number of ninth section   
    });

    it("should return an array of length 7 for multiple queries and parameters", async () => {

        const result = await parseCopiedPQ(pqCode4);
        expect(result.length).toBe(7);

        expect(result[0].lineNumber).toBe(2); // Check line number of first section
        expect(result[1].lineNumber).toBe(9); // Check line number of second section
        expect(result[2].lineNumber).toBe(12); // Check line number of third section
        expect(result[3].lineNumber).toBe(23); // Check line number of fourth section
        expect(result[4].lineNumber).toBe(38); // Check line number of fifth section
        expect(result[5].lineNumber).toBe(45); // Check line number of sixth section
        expect(result[6].lineNumber).toBe(48); // Check line number of seventh section        
    });

    it("should return an array of length 1 for a single query", async () => {

        const result = await parseCopiedPQ(pqCode5);
        expect(result.length).toBe(1);

        expect(result[0].lineNumber).toBe(1); // Check line number of first section
    });

    it("should return an array of length 1 for a single query", async () => {

        const result = await parseCopiedPQ(pqCode6);
        expect(result.length).toBe(1);

        expect(result[0].lineNumber).toBe(1); // Check line number of first section
    });    

    it("should return an array of length 1 for a single query", async () => {

        const result = await parseCopiedPQ(pqCode7);
        console.log("Result of parseCopiedPQ for pqCode7:", JSON.stringify(result, null, 2));
        expect(result.length).toBe(1);

        expect(result[0].lineNumber).toBe(1); // Check line number of first section
    });  
    
    it("should return an array of length 2 for a single query with function", async () => {

        const result = await parseCopiedPQ(pqCode8);
        console.log("Result of parseCopiedPQ for pqCode8:", JSON.stringify(result, null, 2));
        expect(result.length).toBe(2);

        expect(result[0].lineNumber).toBe(1); // Check line number of first section
        expect(result[1].lineNumber).toBe(10); // Check line number of second section
    });      

});

const pqCode = `// Version2
let
    Source = SharePoint.Tables("https://kerski.sharepoint.com/sites/SPRefreshTest", [Implementation="2.0", ViewMode="Default"]),
    #"1840b176-e775-47e2-b542-32045f24f82d" = Source{[Id="1840b176-e775-47e2-b542-32045f24f82d"]}[Items]
in
    #"1840b176-e775-47e2-b542-32045f24f82d"

// Version2 (2)
let
    Source = Version2,
    #"Invoked Custom Function" = Table.AddColumn(Source, "Query1", each Query1(1))
in
    #"Invoked Custom Function"

// Parameter1
1 meta [IsParameterQuery=true, Type="Number", IsParameterQueryRequired=true]

// Query1
(x as number) => 
let
  x = Parameter1 + 1 
  in
  x`;

const pqCode2 = `
// WebURL
"https://raw.githubusercontent.com/fivethirtyeight/data/master/comic-characters/marvel-wikia-data.csv" meta [IsParameterQuery=true, Type="Any", IsParameterQueryRequired=true]

// MarvelSource
let
    Source = Csv.Document(Web.Contents(WebURL),[Delimiter=",", Columns=13, Encoding=65001, QuoteStyle=QuoteStyle.None]),
    #"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"page_id", Int64.Type}, {"name", type text}, {"urlslug", type text}, {"ID", type text}, {"ALIGN", type text}, {"EYE", type text}, {"HAIR", type text}, {"SEX", type text}, {"GSM", type text}, {"ALIVE", type text}, {"APPEARANCES", Int64.Type}, {"FIRST APPEARANCE", type text}, {"Year", Int64.Type}})
in
    #"Changed Type"

// AlignmentDim
let
    Source = MarvelSource,
    #"Removed Other Columns" = Table.SelectColumns(Source,{"ALIGN"}),
    #"Removed Duplicates" = Table.Distinct(#"Removed Other Columns"),
    #"Duplicated Column" = Table.DuplicateColumn(#"Removed Duplicates", "ALIGN", "ALIGN - Copy"),
    #"Renamed Columns" = Table.RenameColumns(#"Duplicated Column",{{"ALIGN - Copy", "AlignmentKey"}}),
    #"Split Column by Delimiter" = Table.SplitColumn(#"Renamed Columns", "ALIGN", Splitter.SplitTextByDelimiter(" ", QuoteStyle.Csv), {"ALIGN.1", "ALIGN.2"}),
    #"Changed Type" = Table.TransformColumnTypes(#"Split Column by Delimiter",{{"ALIGN.1", type text}, {"ALIGN.2", type text}}),
    #"Renamed Columns1" = Table.RenameColumns(#"Changed Type",{{"ALIGN.1", "Alignment"}}),
    #"Sorted Rows" = Table.Sort(#"Renamed Columns1",{{"Alignment", Order.Ascending}}),
    #"Replaced Value" = Table.ReplaceValue(#"Sorted Rows","","Not Available",Replacer.ReplaceValue,{"Alignment"}),
    #"Added Index" = Table.AddIndexColumn(#"Replaced Value", "Index", 0, 1, Int64.Type),
    #"Renamed Columns2" = Table.RenameColumns(#"Added Index",{{"Index", "AlignmentID"}}),
    #"Reordered Columns" = Table.ReorderColumns(#"Renamed Columns2",{"AlignmentID", "Alignment", "ALIGN.2", "AlignmentKey"}),
    #"Removed Columns" = Table.RemoveColumns(#"Reordered Columns",{"ALIGN.2"}),
    #"Renamed Columns3" = Table.RenameColumns(#"Removed Columns",{{"AlignmentKey", "AlignmentKey"}})
in
    #"Renamed Columns3"
`

const pqCode3 = `
// LocalHost
"localhost:55874" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]

// DatabaseID
let
    Source = AnalysisServices.Databases(LocalHost, [TypedMeasureColumns=true, Implementation="2.0"]),
    DatabaseID = Table.First(Source)[Name]
in
    DatabaseID

// MCode
let
    MCode = AnalysisServices.Database(LocalHost, DatabaseID, [Query="EVALUATE INFO.PARTITIONS()", Implementation="2.0"]),
    #"Filtered Rows" = Table.SelectRows(MCode, each Text.StartsWith([#"[Name]"], "Puzzle") and not Text.EndsWith([#"[Name]"], "Status") and not Text.EndsWith([#"[Name]"], "Test") and not Text.EndsWith([#"[Name]"], "- Setup")),
    #"Removed Other Columns" = Table.SelectColumns(#"Filtered Rows",{"[ID]", "[Name]", "[QueryDefinition]"}),
    #"Duplicated Column" = Table.DuplicateColumn(#"Removed Other Columns", "[Name]", "[Name] - Copy"),
    #"Renamed Columns1" = Table.RenameColumns(#"Duplicated Column",{{"[Name] - Copy", "Puzzle Name"}}),
    #"Split Column by Delimiter" = Table.SplitColumn(#"Renamed Columns1", "[Name]", Splitter.SplitTextByEachDelimiter({" "}, QuoteStyle.Csv, true), {"[Name].1", "[Name].2"}),
    #"Lowercased Text" = Table.TransformColumns(#"Split Column by Delimiter",{{"[Name].2", Text.Lower, type text}}),
    #"Renamed Columns" = Table.RenameColumns(#"Lowercased Text",{{"[Name].2", "LowerText"}}),
    #"Added Custom" = Table.AddColumn(#"Renamed Columns", "Puzzle Number", each if [LowerText] = "one" then 1
                else if [LowerText] = "two" then 2
                else if [LowerText] = "three" then 3
                else if [LowerText] = "four" then 4
                else if [LowerText] = "five" then 5
                else if [LowerText] = "six" then 6
                else if [LowerText] = "seven" then 7
                else if [LowerText] = "eight" then 8
                else if [LowerText] = "nine" then 9
                else if [LowerText] = "ten" then 10
                else _, Int16.Type),
    #"Invoked Custom Function" = Table.AddColumn(#"Added Custom", "fnCallEscapeRoom", each fnCallEscapeRoom(TeamName, [Puzzle Number], [#"[QueryDefinition]"])),
    #"Expanded fnCallEscapeRoom" = Table.ExpandRecordColumn(#"Invoked Custom Function", "fnCallEscapeRoom", {"puzzleNumber", "isPuzzleLocked"}, {"puzzleNumber", "isPuzzleLocked"}),
    #"Changed Type" = Table.TransformColumnTypes(#"Expanded fnCallEscapeRoom",{{"isPuzzleLocked", type logical}}),
    #"Replaced Value1" = Table.ReplaceValue(#"Changed Type",null,true,Replacer.ReplaceValue,{"isPuzzleLocked"}),
    #"Removed Errors" = Table.RemoveRowsWithErrors(#"Replaced Value1"),
    #"Changed Type1" = Table.TransformColumnTypes(#"Removed Errors",{{"isPuzzleLocked", Int64.Type}})
in
    #"Changed Type1"

// fnCallEscapeRoom
let
    CallEscapeRoom = (teamName as text, puzzle as number, mCode as text) as record =>
    let
        BaseURL = "https://pbi-days-dc-2025.azurewebsites.net/api/escapeRoom?code=ywlXudfGaDQ-KEGvQiUeoJGSPK9h8pXB66qZyTSfqNcuAzFuhoegZQ==",
        //BaseURL = "http://localhost:7071/api/escapeRoom?code=xyz",
        // Validate inputs
        ValidateInputs = 
            if Text.Length(teamName) = 0 then error "Team Name cannot be empty"
            else if puzzle < 1 or puzzle > 10 then error "Puzzle must be a number between 1 and 10"
            else null,

        // Construct the query string
        QueryString = "TeamName=" & Uri.EscapeDataString(teamName) & "&Puzzle=" & Number.ToText(puzzle),

        // Construct the full URL with query parameters
        FullUrl = BaseURL & "&" & QueryString,

        // Make the POST request
        Response = Web.Contents(
            FullUrl,
            [
                Headers = [
                ],
                Content = Text.ToBinary(mCode)
            ]
        ),

        // Parse the JSON response
        ParsedResponse = Json.Document(Response)
    in
        ParsedResponse
in
    CallEscapeRoom

// TeamName
"Team Charlie" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]

// Puzzle Status
let
    Source = MCode,
    #"Removed Other Columns" = Table.SelectColumns(Source,{"Puzzle Name", "Puzzle Number", "isPuzzleLocked"}),
    #"Renamed Columns" = Table.RenameColumns(#"Removed Other Columns",{{"isPuzzleLocked", "Is Puzzle Locked"}}),
    #"Sorted Rows" = Table.Sort(#"Renamed Columns",{{"Puzzle Number", Order.Ascending}})
in
    #"Sorted Rows"

// Puzzle Two - Setup
let
    /* Do Not Touch */
    Source = #"Puzzle Status",
    #"Filtered Rows" = Table.SelectRows(Source, each [Puzzle Number] <= 1),
    #"Grouped Rows" = Table.Group(#"Filtered Rows", {}, {{"LockedCount", each List.Sum([Is Puzzle Locked]), type nullable number}}),
    isPuzzleLocked = if #"Grouped Rows"{0}[LockedCount]? > 0 then true else false,
    PuzzleTwo = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("XY1BC4JQEAb/ytc7C2oW0Smojh2FDuZhy5UX+t7Cuir9+8jo0mVgYGCqyl09GRp6QVqYZ8zMHWYacBFtUBKp4eQ/vIvGA0qlOLSiYalvY5atd8enmseZjL+Oh/RjiDCB8sTUL22kwL/L33DlElek+SbNt/vC1fUb", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [Puzzle = _t, #"Birth Date" = _t]),
    // Right Click-->Transform-->Day-->Name of Day 🥧
    #"Changed Type" = Table.TransformColumnTypes(PuzzleTwo,{{"Puzzle", type text}, {"Birth Date", type date}}),
    
    #"--> Start Here" = if isPuzzleLocked or Table.First(#"Puzzle One")[Original Value] = 3.14 then #table({"Message"},{{"Unblock Previous Puzzle"}}) else  #"Changed Type"
in
    #"--> Start Here"

// Puzzle One
let
    // Do you think you have the Power to defeat me?🥧
    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i45Wck7MU6jML1UoSswsTlUoyUhVKEvMKU1VyE9TiCk1MDAy9y/KTM/MS8xRCAOJQ8QUSvLBStPyS4tKMhQK8stTi+wVPsxfulxJR8lQz9jY0NDMzNTS0tDEwEQpNhYA", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [Puzzle = _t, #"Original Value" = _t]),
    #"----> Start Here" = Table.TransformColumnTypes(Source,{{"Puzzle", type text}, {"Original Value", type number}})
in
    #"----> Start Here"

// Puzzle Two
let
    #"---->Start Here" = #"Puzzle Two - Setup"
in
    #"---->Start Here"`

const pqCode4 = `
// GetGroups
let
    Source = PBIRESTAPIComm.FunctionCatalog(),
    GetGroups1 = Source{[Key="GetGroups"]}[Data]
in
    GetGroups1

// Workspace(s) Query
"name eq 'monitor demo'" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=false]

// Workspaces
let
    Source = GetGroups(#"Workspace(s) Query", null, null),
    #"Parsed JSON" = Json.Document(Source),
    value = #"Parsed JSON"[value],
    #"Converted to Table" = Table.FromList(value, Splitter.SplitByNothing(), null, null, ExtraValues.Error),
    #"Expanded Column1" = Table.ExpandRecordColumn(#"Converted to Table", "Column1", {"id", "name"}, {"id", "name"}),
    #"Renamed Columns" = Table.RenameColumns(#"Expanded Column1",{{"id", "Workspace ID"}, {"name", "Workspace Name"}})
in
    #"Renamed Columns"

// Dataflows
let
    Source = Workspaces,
    #"Get Dataflows" = Table.AddColumn(Source, "GetDataflowsInGroup", each GetDataflowsInGroup([Workspace ID])),
    #"Parsed JSON1" = Table.TransformColumns(#"Get Dataflows",{{"GetDataflowsInGroup", Json.Document}}),
    #"Expanded GetDataflowsInGroup" = Table.ExpandRecordColumn(#"Parsed JSON1", "GetDataflowsInGroup", {"value"}, {"value"}),
    #"Expanded value" = Table.ExpandListColumn(#"Expanded GetDataflowsInGroup", "value"),
    #"Expanded value1" = Table.ExpandRecordColumn(#"Expanded value", "value", {"objectId", "name", "description"}, {"objectId", "name", "description"}),
    #"Standardize Names" = Table.RenameColumns(#"Expanded value1",{{"objectId", "Dataflow ID"}, {"name", "Name"}, {"description", "Description"}}),
    #"Remove Empty Dataflow IDs" = Table.SelectRows(#"Standardize Names", each [Dataflow ID] <> null and [Dataflow ID] <> ""),
    #"Add Web URL" = Table.AddColumn(#"Remove Empty Dataflow IDs", "Web URL", each #"Power BI Base URL" & "groups/" & [Workspace ID] & "/settings/dataflows/" & [Dataflow ID]),
    #"Removed Columns" = Table.RemoveColumns(#"Add Web URL",{"Workspace Name"})
in
    #"Removed Columns"

// GetDataflowsInGroup
let
    Source = PBIRESTAPIComm.FunctionCatalog(),
    GetDataflowInGroup1 = Source{[Key="GetDataflowsInGroup"]}[Data]
in
    GetDataflowInGroup1

// Power BI Base URL
"https://app.powerbi.com/" meta [IsParameterQuery=true, List={"https://app.powerbi.com/"}, DefaultValue="https://app.powerbi.com/", Type="Text", IsParameterQueryRequired=false]

// Number
1 meta [IsParameterQuery=true, Type="Number", IsParameterQueryRequired=false]
`

const pqCode5 = `
let
    Source = GetGroups(#"Workspace(s) Query", null, null),
    #"Parsed JSON" = Json.Document(Source),
    value = #"Parsed JSON"[value],
    #"Converted to Table" = Table.FromList(value, Splitter.SplitByNothing(), null, null, ExtraValues.Error),
    #"Expanded Column1" = Table.ExpandRecordColumn(#"Converted to Table", "Column1", {"id", "name"}, {"id", "name"}),
    #"Renamed Columns" = Table.RenameColumns(#"Expanded Column1",{{"id", "Workspace ID"}, {"name", "Workspace Name"}})
in
    #"Renamed Columns"`

const pqCode6 = `
"https://app.powerbi.com/" meta [IsParameterQuery=true, List={"https://app.powerbi.com/"}, DefaultValue="https://app.powerbi.com/", Type="Text", IsParameterQueryRequired=false]
`;

const pqCode7 = `// fnTest
(x) => x + 1`;

const pqCode8 = `// TestCopy
let
    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i45WMlSKjQUA", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [Column1 = _t]),
    #"Changed Type1" = Table.TransformColumnTypes(Source,{{"Column1", Int64.Type}}),
    #"Invoked Custom Function" = Table.AddColumn(#"Changed Type1", "fnTest", each fnTest([Column1])),
    #"Changed Type" = Table.TransformColumnTypes(#"Invoked Custom Function",{{"Column1", type text}})
in
    #"Changed Type"

// fnTest
(x) => x + 1`;