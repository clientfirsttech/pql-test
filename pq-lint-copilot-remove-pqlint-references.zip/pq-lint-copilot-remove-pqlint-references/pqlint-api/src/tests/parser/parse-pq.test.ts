import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';

// Mock input for testing
const validInput: string = `let
Source = Csv.Document(File.Contents("C:\\Users\\jkers\\Downloads\\MOCK_DATA (2).csv"),[Delimiter=",", Columns=6, Encoding=1252, QuoteStyle=QuoteStyle.None]),
#"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
#"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"id", Int64.Type}, {"first_name", type text}, {"last_name", type text}, {"email", type text}, {"gender", type text}, {"time", type time}}),
#"Added Custom1" = Table.AddColumn(#"Changed Type", "Custom Number", each 2),
#"Invoked Custom Function" = Table.AddColumn(#"Added Custom1", "fnTest", each fnTest([id], null),Int32.Type),
#"Added Custom" = Table.AddColumn(#"Invoked Custom Function", "Custom", each "Test", type text)
in
#"Added Custom"`;

// Mock input for testing
const validInput2: string = `let
Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i45WclSK1YlWcgKTzkqxsQA=", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [#"Column A" = _t]),
#"Changed Type" = Table.TransformColumnTypes(Source,{{"Column A", type text}})
in
#"Changed Type"`;

// Mock input for testing
const validInput3: string = `
let
Table1 = #table(
    {"Column1", "Column2", "Column3"}, 
    { {1, "Hello", #date(2024, 2, 18)} }
)
in
Table1`;

const validInput4: string = `
let
    Source = Csv.Document(Web.Contents("https://raw.githubusercontent.com",[RelativePath="fivethirtyeight/data/master/comic-characters/marvel-wikia-data.csv"]),[Delimiter=",", Columns=13, Encoding=65001, QuoteStyle=QuoteStyle.None]),
    #"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"page_id", Int64.Type}, {"name", type text}, {"urlslug", type text}, {"ID", type text}, {"ALIGN", type text}, {"EYE", type text}, {"HAIR", type text}, {"SEX", type text}, {"GSM", type text}, {"ALIVE", type text}, {"APPEARANCES", Int64.Type}, {"FIRST APPEARANCE", type text}, {"Year", Int64.Type}})
in
    #"Changed Type"
`

const validInput5: string = `let
    Source = SharePoint.Tables("https://kerski.sharepoint.com", [ApiVersion=15]),
    #"374f6408-6353-48ef-80f2-3115cd7d16e0" = Source{[Id="374f6408-6353-48ef-80f2-3115cd7d16e0"]}[Items]
    in
    #"374f6408-6353-48ef-80f2-3115cd7d16e0"`

const parameterInput: string = `"Team Alpha" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]`

const createFunctionUIInput: string = `let
				    Source = () => let
				        Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i44FAA==", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [Column1 = _t]),
				        #"Changed Type" = Table.TransformColumnTypes(Source,{{"Column1", type text}}),
				        #"Added Custom" = Table.AddColumn(#"Changed Type", "Custom", each [Parameter1])
				    in
				        #"Added Custom"
				in
				    Source()`;

describe('parsePowerQueryText', () => {
    test('should return a valid result for a valid input', async () => {
        const result: ParseResult = await parsePowerQueryText(validInput);
        expect(result).toBeDefined();
        expect(result.ast).toBeDefined();
        expect(result.lexed).toBeDefined();
        expect(result.error).toBeNull();
    });

    test('should return JSON formatted AST for valid input', async () => {
        const result: ParseResult = await parsePowerQueryText(validInput);
        expect((result.ast as unknown) instanceof Object).toBe(true);
        expect((result.error)).toBeNull();
    });

    test('should return JSON formatted lexed text for valid input', async () => {
        const result: ParseResult = await parsePowerQueryText(validInput);
        expect(result.lexed?.length).toBeGreaterThan(0);
        expect((result.error)).toBeNull();
    });

    test('should return JSON formatted AST for valid input 2', async () => {
        const result: ParseResult = await parsePowerQueryText(validInput2);
        expect((result.ast as unknown) instanceof Object).toBe(true);
        expect((result.error)).toBeNull();
    });

    test('should return JSON formatted lexed text for valid input 2', async () => {
        const result: ParseResult = await parsePowerQueryText(validInput2);
        expect(result.lexed?.length).toBeGreaterThan(0);
        expect((result.error)).toBeNull();
    });

    test('should return JSON formatted AST for valid input 3', async () => {
        const result: ParseResult = await parsePowerQueryText(validInput3);
        expect((result.ast as unknown) instanceof Object).toBe(true);
        expect((result.error)).toBeNull();
    });

    test('should return JSON formatted lexed text for valid input 3', async () => {
        const result: ParseResult = await parsePowerQueryText(validInput3);
        expect(result.lexed?.length).toBeGreaterThan(0);
        expect((result.error)).toBeNull();
    });    

    test('should return JSON formatted AST for valid input 3', async () => {
        const result: ParseResult = await parsePowerQueryText(validInput3);
        expect((result.ast as unknown) instanceof Object).toBe(true);
        expect((result.error)).toBeNull();
    });

    test('should return JSON formatted lexed text for valid input 4', async () => {
        const result: ParseResult = await parsePowerQueryText(validInput4);
        expect(result.lexed?.length).toBeGreaterThan(0);
        expect((result.error)).toBeNull();
    });  

    test('should return JSON formatted lexed text for valid input 5', async () => {
        const result: ParseResult = await parsePowerQueryText(validInput5);
        expect(result.lexed?.length).toBeGreaterThan(0);
        expect((result.error)).toBeNull();
    });      
    
    test('should return JSON formatted lexed text for valid parameter', async () => {
        const result: ParseResult = await parsePowerQueryText(parameterInput);
        expect(result.lexed?.length).toBeGreaterThan(0);
        expect((result.error)).toBeNull();
    });    
    
    test('should return JSON formatted lexed text for createFunctionUIInput', async () => {
        const result: ParseResult = await parsePowerQueryText(createFunctionUIInput);
        expect(result.lexed?.length).toBeGreaterThan(0);
        expect((result.error)).toBeNull();
    });      
      
});