import { extractRelationshipAndProperties } from 'src/parser/tmdl/tmdl-parser';
import { getPowerQueryPairingsForLinting } from 'src/lint/linter-module';
import { TMDL_Level_PowerQueryPairing } from 'src/lint/rule-types';

// Testing indivdual table scripted in TMDL View
describe('extractRelationships', () => {
    it('should matches several relationships for _TMDL_View_Relationship_Script', () => {
        const extractedData = extractRelationshipAndProperties(_TMDL_View_Relationship_Script);
        expect(extractedData).toBeDefined();
        expect(extractedData.length).toBeGreaterThan(0);
        console.log('Extracted Relationships:', JSON.stringify(extractedData, null, 2)); // Log the extracted relationships for debugging

        for (const relationship of extractedData) {
            expect(relationship).toHaveProperty('guid');
            expect(relationship).toHaveProperty('fromColumn');
            expect(relationship).toHaveProperty('toColumn');
            expect(relationship).toHaveProperty('fromTable');
            expect(relationship).toHaveProperty('toTable');
            expect(relationship).toHaveProperty('fromColumnName');
            expect(relationship).toHaveProperty('toColumnName');
            expect(relationship).toHaveProperty('isActive');
            expect(relationship).toHaveProperty('crossFilteringBehavior');
            expect(relationship).toHaveProperty('fromCardinality');
            expect(relationship).toHaveProperty('toCardinality');
            expect(relationship).toHaveProperty('lineNumber');
        }

        // Test specific relationship properties
        const specificRelationship = extractedData.find(rel => rel.guid === 'a7d15640-1fdf-d096-7007-2a8f85875763');
        expect(specificRelationship).toBeDefined();
        expect(specificRelationship).toMatchObject({
            guid: 'a7d15640-1fdf-d096-7007-2a8f85875763',
            fromColumn: "'Fact Table'.'Test ID'",
            toColumn: "'Dimension Table'.Test",
            fromTable: "Fact Table",
            toTable: "Dimension Table",
            fromColumnName: "Test ID",
            toColumnName: "Test",
            isActive: true,
            crossFilteringBehavior: "automatic",
            fromCardinality: "many",
            toCardinality: "one"
        });
        expect(specificRelationship?.lineNumber).toBeGreaterThan(0);

        // Test inactive relationship
        const inactiveRelationship = extractedData.find(rel => rel.guid === '90db0f4b-ba1e-38c5-4909-f130fe1c7ea6');
        expect(inactiveRelationship).toBeDefined();
        expect(inactiveRelationship?.isActive).toBe(false);

        // Test both directions relationship
        const bothDirectionsRelationship = extractedData.find(rel => rel.guid === '95910c9d-8c7a-5344-fb0d-7d56dc3c2804');
        expect(bothDirectionsRelationship).toBeDefined();
        expect(bothDirectionsRelationship?.crossFilteringBehavior).toBe('bothDirections');
        expect(bothDirectionsRelationship?.fromCardinality).toBe('one');

        // Verify we have all 4 relationships
        expect(extractedData.length).toBe(4);
    });

     it('should matches several relationships for _TMDL_View_No_Relationship_Script', () => {
        const extractedData = extractRelationshipAndProperties(_TMDL_View_No_Relationship_Script);
        expect(extractedData).toBeDefined();
        expect(extractedData.length).toBe(0);

     });
});

describe('test extractRelationshipAndProperties indirectly with getPowerQueryPairingsForLinting', () => {

    it('should extract relationships when extracting tables from _TMDL_View_Relationship_Script', async () => {
        const pairingResults: TMDL_Level_PowerQueryPairing[] = await getPowerQueryPairingsForLinting(_TMDL_View_Relationship_Script);
        expect(pairingResults).toBeDefined();
        expect(pairingResults.length).toBeGreaterThan(0);
        //console.log('Extracted Tables:', JSON.stringify(pairingResults, null, 2)); // Log the extracted tables for debugging

        // Filter out pairings that have associated tables (not expressions)
        const tablePairings = pairingResults.filter(pairing => pairing.AssociatedTable !== null);
        
        // Verify that each table has at least one relationship
        for (const pairing of tablePairings) {
            expect(pairing.AssociatedTable).toBeDefined();
            console.log('Table Pairing:', pairing.AssociatedTable?.name);
            expect(pairing.AssociatedTable?.relationships).toBeDefined();
			expect((pairing.AssociatedTable?.relationships ?? []).length).toBeGreaterThan(0);
            
            // Log table name and relationship count for debugging
			console.log(`Table: ${pairing.AssociatedTable?.name}, Relationships: ${(pairing.AssociatedTable?.relationships ?? []).length}`);
            
            // Verify relationships contain the expected properties
            for (const relationship of pairing.AssociatedTable?.relationships || []) {
                expect(relationship).toHaveProperty('guid');
                expect(relationship).toHaveProperty('fromTable');
                expect(relationship).toHaveProperty('toTable');
                
                // Verify the relationship involves this table
                expect(
                    relationship.fromTable === pairing.AssociatedTable?.name || 
                    relationship.toTable === pairing.AssociatedTable?.name
                ).toBe(true);
            }
        }
        
        // Verify specific table relationships
        const dimensionTable = tablePairings.find(p => p.AssociatedTable?.name === 'Dimension Table');
		expect((dimensionTable?.AssociatedTable?.relationships ?? []).length).toBe(3); // Should be target of 3 relationships
        expect((dimensionTable?.AssociatedTable?.relationships ?? [])[0].guid).toBe('a7d15640-1fdf-d096-7007-2a8f85875763');
		expect((dimensionTable?.AssociatedTable?.relationships ?? [])[0].toTable).toBe('Dimension Table');
		expect((dimensionTable?.AssociatedTable?.relationships ?? [])[0].fromTable).toBe('Fact Table');
		expect((dimensionTable?.AssociatedTable?.relationships ?? [])[1].guid).toBe('90db0f4b-ba1e-38c5-4909-f130fe1c7ea6');
		expect((dimensionTable?.AssociatedTable?.relationships ?? [])[1].toTable).toBe('Dimension Table');
		expect((dimensionTable?.AssociatedTable?.relationships ?? [])[1].fromTable).toBe('Fact Table 2');
		expect((dimensionTable?.AssociatedTable?.relationships ?? [])[1].isActive).toBe(false); // This relationship is inactive
		expect((dimensionTable?.AssociatedTable?.relationships ?? [])[2].guid).toBe('95910c9d-8c7a-5344-fb0d-7d56dc3c2804');
		expect((dimensionTable?.AssociatedTable?.relationships ?? [])[2].toTable).toBe('Dimension Table');
		expect((dimensionTable?.AssociatedTable?.relationships ?? [])[2].fromTable).toBe('OneToOne');
		expect((dimensionTable?.AssociatedTable?.relationships ?? [])[2].crossFilteringBehavior).toBe('bothDirections');
		expect((dimensionTable?.AssociatedTable?.relationships ?? [])[2].fromCardinality).toBe('one');

        const factTable = tablePairings.find(p => p.AssociatedTable?.name === 'Fact Table');
		expect((factTable?.AssociatedTable?.relationships ?? []).length).toBe(2); // Should have 2 relationships
		expect((factTable?.AssociatedTable?.relationships ?? [])[0].guid).toBe('a7d15640-1fdf-d096-7007-2a8f85875763');
		expect((factTable?.AssociatedTable?.relationships ?? [])[0].toTable).toBe('Dimension Table');
		expect((factTable?.AssociatedTable?.relationships ?? [])[0].fromTable).toBe('Fact Table');
		expect((factTable?.AssociatedTable?.relationships ?? [])[1].guid).toBe('fbf3cbbc-142e-004b-9aab-be6337177038');
		expect((factTable?.AssociatedTable?.relationships ?? [])[1].toTable).toBe('Snowflake Filter');
		expect((factTable?.AssociatedTable?.relationships ?? [])[1].fromTable).toBe('Fact Table');
        
        const oneToOneTable = tablePairings.find(p => p.AssociatedTable?.name === 'OneToOne');
		expect((oneToOneTable?.AssociatedTable?.relationships ?? []).length).toBe(1); // Should have 1 relationship
        expect((oneToOneTable?.AssociatedTable?.relationships ?? [])[0].crossFilteringBehavior).toBe('bothDirections');
		expect((oneToOneTable?.AssociatedTable?.relationships ?? [])[0].fromCardinality).toBe('one');
		expect((oneToOneTable?.AssociatedTable?.relationships ?? [])[0].guid).toBe('95910c9d-8c7a-5344-fb0d-7d56dc3c2804');
		expect((oneToOneTable?.AssociatedTable?.relationships ?? [])[0].fromTable).toBe('OneToOne');
		expect((oneToOneTable?.AssociatedTable?.relationships ?? [])[0].toTable).toBe('Dimension Table');

        const snowflakeTable = tablePairings.find(p => p.AssociatedTable?.name === 'Snowflake Filter');
		expect((snowflakeTable?.AssociatedTable?.relationships ?? []).length).toBe(1); // Should have 1 relationship
		expect((snowflakeTable?.AssociatedTable?.relationships ?? [])[0].guid).toBe('fbf3cbbc-142e-004b-9aab-be6337177038');
		expect((snowflakeTable?.AssociatedTable?.relationships ?? [])[0].toTable).toBe('Snowflake Filter');
		expect((snowflakeTable?.AssociatedTable?.relationships ?? [])[0].fromTable).toBe('Fact Table');
        
        const factTable2 = tablePairings.find(p => p.AssociatedTable?.name === 'Fact Table 2');
		expect((factTable2?.AssociatedTable?.relationships ?? []).length).toBe(1); // Should have 1 relationship
		expect((factTable2?.AssociatedTable?.relationships ?? [])[0].isActive).toBe(false); // This relationship is inactive
		expect((factTable2?.AssociatedTable?.relationships ?? [])[0].guid).toBe('90db0f4b-ba1e-38c5-4909-f130fe1c7ea6');
		expect((factTable2?.AssociatedTable?.relationships ?? [])[0].toTable).toBe('Dimension Table');
		expect((factTable2?.AssociatedTable?.relationships ?? [])[0].fromTable).toBe('Fact Table 2');
    });

    it('should extract tables with no relationships from _TMDL_View_No_Relationship_Script', async () => {
        const pairingResults: TMDL_Level_PowerQueryPairing[] = await getPowerQueryPairingsForLinting(_TMDL_View_No_Relationship_Script);
        expect(pairingResults).toBeDefined();
        expect(pairingResults.length).toBeGreaterThan(0);
        
        // Filter out pairings that have associated tables (not expressions)
        const tablePairings = pairingResults.filter(pairing => pairing.AssociatedTable !== null);
        
        // Verify that tables have empty relationships arrays when no relationships exist
        for (const pairing of tablePairings) {
            expect(pairing.AssociatedTable).toBeDefined();
            expect(pairing.AssociatedTable?.relationships).toBeDefined();
			expect((pairing.AssociatedTable?.relationships ?? []).length).toBe(0);
            
			console.log(`Table: ${pairing.AssociatedTable?.name}, Relationships: ${(pairing.AssociatedTable?.relationships ?? []).length}`);
        }
    });
});

const _TMDL_View_No_Relationship_Script = `
createOrReplace

	table 'Dimension Table'
		lineageTag: 7c59e265-308d-4829-bf10-63a72f41b08d

		column Test
			dataType: string
			lineageTag: 2411bd3d-7390-4eff-aa84-8e2c5ff49b6b
			summarizeBy: none
			sourceColumn: Test

			annotation SummarizationSetBy = Automatic

		partition 'Dimension Table' = m
			mode: import
			source =
					let
					    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i45WclSK1YlWcgKTzmDSRSk2FgA=", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [Test = _t]),
					    #"Changed Type" = Table.TransformColumnTypes(Source,{{"Test", type text}})
					in
					    #"Changed Type"

		annotation PBI_ResultType = Table

	table 'Fact Table'
		lineageTag: 0351759f-2dfd-406a-bdf5-b03ee1db2703

		column 'Test ID'
			dataType: string
			lineageTag: e198ad69-6fde-41e3-a77e-e621459c3f7a
			summarizeBy: none
			sourceColumn: Test ID

			annotation SummarizationSetBy = Automatic

		partition 'Fact Table' = m
			mode: import
			source =
					let
					    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i45WclSK1YGRTkikc0yeM4QBJl1i8lwgDDDpCiNjAQ==", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [#"Test ID" = _t]),
					    #"Changed Type" = Table.TransformColumnTypes(Source,{{"Test ID", type text}})
					in
					    #"Changed Type"

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = Table

	table 'Fact Table 2'
		lineageTag: dd4257f9-18af-46db-abb3-4fab05fb3b95

		column 'Test ID'
			dataType: string
			lineageTag: 807c75f5-5daa-41f3-8597-a4fd3f31b042
			summarizeBy: none
			sourceColumn: Test ID

			annotation SummarizationSetBy = Automatic

		partition 'Fact Table 2' = m
			mode: import
			source =
					let
					    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i45WclSK1YGRTkikc0yeM4QBJl1i8lwgDDDpCiNjAQ==", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [#"Test ID" = _t]),
					    #"Changed Type" = Table.TransformColumnTypes(Source,{{"Test ID", type text}})
					in
					    #"Changed Type"

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = Table

	table OneToOne
		lineageTag: 8ec713f6-bf4f-43cf-85c5-b3de22758baa

		column Test
			dataType: string
			lineageTag: 56497bc8-6d0d-48a4-9d61-3602b0e570cb
			summarizeBy: none
			sourceColumn: Test

			annotation SummarizationSetBy = Automatic

		partition OneToOne = m
			mode: import
			source =
					let
					    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i45WclSK1YlWcgKTzmDSRSk2FgA=", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [Test = _t]),
					    #"Changed Type" = Table.TransformColumnTypes(Source,{{"Test", type text}})
					in
					    #"Changed Type"

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = Table

	table 'Snowflake Filter'
		lineageTag: c5798fa6-5f8c-4956-89e2-7fb152e0b0bb

		column Test
			dataType: string
			lineageTag: 5fd1caeb-2809-41e0-a2ba-684489bca8da
			summarizeBy: none
			sourceColumn: Test

			annotation SummarizationSetBy = Automatic

		partition 'Snowflake Filter' = m
			mode: import
			source =
					let
					    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i45WclSK1YlWclKKjQUA", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [Test = _t]),
					    #"Changed Type" = Table.TransformColumnTypes(Source,{{"Test", type text}})
					in
					    #"Changed Type"

		changedProperty = Name

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = Table


`

const _TMDL_View_Relationship_Script = `
createOrReplace

	model Model
		culture: en-US
		defaultPowerBIDataSourceVersion: powerBI_V3
		sourceQueryCulture: en-US
		dataAccessOptions
			legacyRedirects
			returnErrorValuesAsNull

		table 'Dimension Table'
			lineageTag: 7c59e265-308d-4829-bf10-63a72f41b08d

			column Test
				dataType: string
				lineageTag: 2411bd3d-7390-4eff-aa84-8e2c5ff49b6b
				summarizeBy: none
				sourceColumn: Test

				annotation SummarizationSetBy = Automatic

			partition 'Dimension Table' = m
				mode: import
				source =
						let
						    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i45WclSK1YlWcgKTzmDSRSk2FgA=", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [Test = _t]),
						    #"Changed Type" = Table.TransformColumnTypes(Source,{{"Test", type text}})
						in
						    #"Changed Type"

			annotation PBI_ResultType = Table

		table 'Fact Table'
			lineageTag: 0351759f-2dfd-406a-bdf5-b03ee1db2703

			column 'Test ID'
				dataType: string
				lineageTag: e198ad69-6fde-41e3-a77e-e621459c3f7a
				summarizeBy: none
				sourceColumn: Test ID

				annotation SummarizationSetBy = Automatic

			partition 'Fact Table' = m
				mode: import
				source =
						let
						    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i45WclSK1YGRTkikc0yeM4QBJl1i8lwgDDDpCiNjAQ==", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [#"Test ID" = _t]),
						    #"Changed Type" = Table.TransformColumnTypes(Source,{{"Test ID", type text}})
						in
						    #"Changed Type"

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Table

		table OneToOne
			lineageTag: 8ec713f6-bf4f-43cf-85c5-b3de22758baa

			column Test
				dataType: string
				lineageTag: 56497bc8-6d0d-48a4-9d61-3602b0e570cb
				summarizeBy: none
				sourceColumn: Test

				annotation SummarizationSetBy = Automatic

			partition OneToOne = m
				mode: import
				source =
						let
						    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i45WclSK1YlWcgKTzmDSRSk2FgA=", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [Test = _t]),
						    #"Changed Type" = Table.TransformColumnTypes(Source,{{"Test", type text}})
						in
						    #"Changed Type"

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Table

		table 'Snowflake Filter'
			lineageTag: c5798fa6-5f8c-4956-89e2-7fb152e0b0bb

			column Test
				dataType: string
				lineageTag: 5fd1caeb-2809-41e0-a2ba-684489bca8da
				summarizeBy: none
				sourceColumn: Test

				annotation SummarizationSetBy = Automatic

			partition 'Snowflake Filter' = m
				mode: import
				source =
						let
						    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i45WclSK1YlWclKKjQUA", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [Test = _t]),
						    #"Changed Type" = Table.TransformColumnTypes(Source,{{"Test", type text}})
						in
						    #"Changed Type"

			changedProperty = Name

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Table

		table 'Fact Table 2'
			lineageTag: dd4257f9-18af-46db-abb3-4fab05fb3b95

			column 'Test ID'
				dataType: string
				lineageTag: 807c75f5-5daa-41f3-8597-a4fd3f31b042
				summarizeBy: none
				sourceColumn: Test ID

				annotation SummarizationSetBy = Automatic

			partition 'Fact Table 2' = m
				mode: import
				source =
						let
						    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i45WclSK1YGRTkikc0yeM4QBJl1i8lwgDDDpCiNjAQ==", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [#"Test ID" = _t]),
						    #"Changed Type" = Table.TransformColumnTypes(Source,{{"Test ID", type text}})
						in
						    #"Changed Type"

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Table

		relationship a7d15640-1fdf-d096-7007-2a8f85875763
			fromColumn: 'Fact Table'.'Test ID'
			toColumn: 'Dimension Table'.Test

		relationship 90db0f4b-ba1e-38c5-4909-f130fe1c7ea6
			isActive: false
			fromColumn: 'Fact Table 2'.'Test ID'
			toColumn: 'Dimension Table'.Test

		relationship 95910c9d-8c7a-5344-fb0d-7d56dc3c2804
			crossFilteringBehavior: bothDirections
			fromCardinality: one
			fromColumn: OneToOne.Test
			toColumn: 'Dimension Table'.Test

		relationship fbf3cbbc-142e-004b-9aab-be6337177038
			fromColumn: 'Fact Table'.'Test ID'
			toColumn: 'Snowflake Filter'.Test

		cultureInfo en-US

			linguisticMetadata = {"Version":"1.0.0","Language":"en-US"}
				contentType: json

		annotation __PBI_TimeIntelligenceEnabled = 0

		annotation PBI_QueryOrder = ["Dimension Table","Fact Table","OneToOne","Snowflake Filter","Fact Table 2"]

		annotation PBI_ProTooling = ["DevMode","TMDLView_Desktop"]


`


