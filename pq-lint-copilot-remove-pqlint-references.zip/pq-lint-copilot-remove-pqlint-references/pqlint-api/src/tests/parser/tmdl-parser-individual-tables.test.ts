import { extractColumnPositions, extractMCodeAndProperties, extractMCodePositions, extractTableAndProperties, extractTablePositions, parseTMDLLines, TMDL_Position } from 'src/parser/tmdl/tmdl-parser';
import { tmdlCodeSample1, tmdlCodeSample3, tmdlCodeSample5 } from '../hardcoded-tmdl';
import * as fs from 'fs';
import * as path from 'path';
import { table } from 'console';

const _TMDL_with_One_Table_Incremental_Refresh_DataFilePath = path.resolve('./test-files/tmdl_with_one_table_incremental_refresh.tmdl');
const _TMDL_with_One_Table_Incremental_Refresh_PBIP_DataFilePath = path.resolve('./test-files/tmdl_with_one_table_incremental_refresh_pbip.tmdl');
const _TMDL_with_One_Table_With_Back_Ticks_DataFilePath = path.resolve('./test-files/tmdl_with_one_table_with_back_ticks.tmdl');
const _TMDL_with_One_Table_Incremental_Refresh_Kusto_DataFilePath = path.resolve('./test-files/tmdl_with_one_table_incremental_refresh_kusto.tmdl');
const _TMDL_with_One_Table_Calendar_DataFilePath = path.resolve('./test-files/calendar.tmdl');
const _TMDL_with_One_Table_DateTimeCheck_DataFilePath = path.resolve('./test-files/DateTimeCheck.tmdl');
const _TMDL_User_Agg_DataFilePath = path.resolve('./test-files/Databricks_UserAgg.tmdl');
const _TMDL_Start_Scripts_DataFilePath = path.resolve('./test-files/StarterScript.tmdl');

// Testing indivdual table scripted in TMDL View
describe('extractTableAndProperties', () => {
    it('should parse a single TMDL object with partition properties from _TMDL_with_One_Table_Incremental_Refresh_DataFilePath', () => {
        const fileContent = fs.readFileSync(_TMDL_with_One_Table_Incremental_Refresh_DataFilePath, 'utf-8');
        const extractedData = parseTMDLLines(fileContent);
        expect(extractedData).toBeDefined();

        const tablePositions = extractTablePositions(fileContent);
        expect(tablePositions).toBeDefined();
        expect(tablePositions.length).toBe(1);
        console.log('Extracted Table Positions:', JSON.stringify(tablePositions, null, 2)); // Log the extracted positions for debugging

        const extractTableProperties = extractTableAndProperties(fileContent);
        expect(extractTableProperties).toBeDefined();

        expect(extractTableProperties.length).toBe(1); // Expect some data to be extracted
        expect(extractTableProperties[0].lineNumber).toBe(3);
        expect(extractTableProperties[0].name).toBe("incremental refresh");
        expect(extractTableProperties[0].properties.isIncremental).toBe(true);
        expect(extractTableProperties[0].resultType).toBe('table');

        // Check partitions
        expect(extractTableProperties[0].partitions.length).toBe(1); // Should include the M code lines
        expect(extractTableProperties[0].partitions[0].name).toBe("incremental refresh");
        expect(extractTableProperties[0].partitions[0].code?.length).toBeGreaterThan(0); // Should include the partition code
        expect(extractTableProperties[0].partitions[0].lineNumber).toBe(2920);

        //expect(extractTableProperties[0].partitions.length).toBe(1); // Should include the partition code
        console.log('Extracted Table Properties:', JSON.stringify(extractTableProperties, null, 2)); // Log the extracted data for debugging

    });

    it('should parse a single TMDL object with partition properties from _TMDL_with_One_Table_Incremental_Refresh_PBIP_DataFilePath', () => {
        const fileContent = fs.readFileSync(_TMDL_with_One_Table_Incremental_Refresh_PBIP_DataFilePath, 'utf-8');
        const extractedData = parseTMDLLines(fileContent);
        expect(extractedData).toBeDefined();

        const tablePositions = extractTablePositions(fileContent);
        expect(tablePositions).toBeDefined();
        expect(tablePositions.length).toBe(1);
        console.log('Extracted Table Positions:', JSON.stringify(tablePositions, null, 2)); // Log the extracted positions for debugging

        const extractTableProperties = extractTableAndProperties(fileContent);
        expect(extractTableProperties).toBeDefined();

        expect(extractTableProperties.length).toBe(1); // Expect some data to be extracted
        expect(extractTableProperties[0].lineNumber).toBe(1);
        expect(extractTableProperties[0].name).toBe("incremental refresh");
        expect(extractTableProperties[0].properties.isIncremental).toBe(true);
        expect(extractTableProperties[0].resultType).toBe('table');

        // Check partitions
        console.log('Extracted Table Properties:', JSON.stringify(extractTableProperties, null, 2)); // Log the extracted data for debugging

        expect(extractTableProperties[0].partitions.length).toBe(1); // Should include the M code lines
        expect(extractTableProperties[0].partitions[0].name).toBe("incremental refresh");
        expect(extractTableProperties[0].partitions[0].code?.length).toBeGreaterThan(0); // Should include the partition code
        expect(extractTableProperties[0].partitions[0].lineNumber).toBe(2918);


    });

    it('should parse a single TMDL object with backticks in table name from _TMDL_with_One_Table_With_Back_Ticks_DataFilePath', () => {
        const fileContent = fs.readFileSync(_TMDL_with_One_Table_With_Back_Ticks_DataFilePath, 'utf-8');
        const extractedData = parseTMDLLines(fileContent);
        expect(extractedData).toBeDefined();

        const tablePositions = extractTablePositions(fileContent);
        expect(tablePositions).toBeDefined();
        expect(tablePositions.length).toBe(1);
        //console.log('Extracted Table Positions:', JSON.stringify(tablePositions, null, 2)); // Log the extracted positions for debugging

        const extractTableProperties = extractTableAndProperties(fileContent);
        expect(extractTableProperties).toBeDefined();

        expect(extractTableProperties.length).toBe(1); // Expect some data to be extracted
        expect(extractTableProperties[0].lineNumber).toBe(1);
        expect(extractTableProperties[0].name).toBe("`ws_ncvas` `silver` `contract_and_investment_performance`");
        expect(extractTableProperties[0].properties.isIncremental).toBe(false);
        expect(extractTableProperties[0].resultType).toBe('table');

        // Check partitions
        //console.log('Extracted Table Properties:', JSON.stringify(extractTableProperties, null, 2)); // Log the extracted data for debugging

        expect(extractTableProperties[0].partitions.length).toBe(1); // Should include the M code lines
        expect(extractTableProperties[0].partitions[0].name).toBe("`ws_ncvas` `silver` `contract_and_investment_performance`");
        expect(extractTableProperties[0].partitions[0].code?.length).toBeGreaterThan(0); // Should include the partition code
        expect(extractTableProperties[0].partitions[0].lineNumber).toBe(2902);
    });
});

describe('extractTableAndProperties with Columns', () => {
    it('should parse a single TMDL object with partition properties from _TMDL_with_One_Table_Incremental_Refresh_Kusto_DataFilePath', () => {
        const fileContent = fs.readFileSync(_TMDL_with_One_Table_Incremental_Refresh_Kusto_DataFilePath, 'utf-8');
        const extractedData = parseTMDLLines(fileContent);
        expect(extractedData).toBeDefined();

        const columnPositions = extractColumnPositions(fileContent);
        console.log('Extracted Column Positions:', JSON.stringify(columnPositions, null, 2)); // Log the extracted positions for debugging
        expect(columnPositions).toBeDefined();
        expect(columnPositions.length).toBe(10);
        expect(columnPositions[0].startPositionLineNumber).toBe(18);
        expect(columnPositions[0].endPositionLineNumber).toBe(26);
        expect(columnPositions[0].value).toBe("Id");

        const tablePositions = extractTablePositions(fileContent);
        expect(tablePositions).toBeDefined();
        expect(tablePositions.length).toBe(1);
        console.log('Extracted Table Positions:', JSON.stringify(tablePositions, null, 2)); // Log the extracted positions for debugging

        const extractTableProperties = extractTableAndProperties(fileContent);
        expect(extractTableProperties).toBeDefined();

        expect(extractTableProperties.length).toBe(1); // Expect some data to be extracted
        expect(extractTableProperties[0].lineNumber).toBe(1);
        expect(extractTableProperties[0].name).toBe("TestResults");
        expect(extractTableProperties[0].properties.isIncremental).toBe(true);
        expect(extractTableProperties[0].resultType).toBe('table');

        // Check columns
        console.log('Extracted Columns:', JSON.stringify(extractTableProperties[0].columns, null, 2)); // Log the extracted columns for debugging
        expect(extractTableProperties[0].columns).toBeDefined();
        expect(extractTableProperties[0].columns?.length).toBe(10); // Expecting 5 columns as per the M code

        // Check partitions
        expect(extractTableProperties[0].partitions.length).toBe(1); // Should include the M code lines
        expect(extractTableProperties[0].partitions[0].name).toBe("TestResults");
        expect(extractTableProperties[0].partitions[0].code?.length).toBeGreaterThan(0); // Should include the partition code
        expect(extractTableProperties[0].partitions[0].lineNumber).toBe(109);

        
        console.log('Extracted Table Properties:', JSON.stringify(extractTableProperties, null, 2)); // Log the extracted data for debugging

    });
});

describe('extractTableAndProperties with TmdlCodeSample5', () => {
    it('should parse a single TMDL object with partition properties from TMDLCodeSample5', () => {
        const extractedData = parseTMDLLines(tmdlCodeSample5);
        expect(extractedData).toBeDefined();

        const tablePositions = extractTableAndProperties(tmdlCodeSample5);
        console.log('Extracted Table Positions:', JSON.stringify(tablePositions, null, 2)); // Log the extracted positions for debugging
        expect(tablePositions).toBeDefined();
        expect(tablePositions.length).toBe(2);
        
        // Check first table
        expect(tablePositions[0].name).toBe("ProblemList");
        expect(tablePositions[0].columns?.[0].name).toBe('Title');
        expect(tablePositions[0].columns?.[1].name).toBe("'A Lookup Column'");
        expect(tablePositions[0].columns?.[2].name).toBe("'A Lookup Column:Date Received'");
        expect(tablePositions[0].partitions?.[0].lineNumber).toBe(41);
        
        // Check second table
        expect(tablePositions[1].name).toBe("Fake Data");
        expect(tablePositions[1].columns?.[0].name).toBe('Column1');
        expect(tablePositions[1].partitions?.[0].lineNumber).toBe(66);

    });
});

describe('extractTableAndProperties with TmdlCodeSample3', () => {
    it('should parse a single TMDL object with partition properties from TMDLCodeSample3', () => {
        const extractedData = parseTMDLLines(tmdlCodeSample3);
        expect(extractedData).toBeDefined();

        const tablePositions = extractTableAndProperties(tmdlCodeSample3);
        console.log('Extracted Table Positions:', JSON.stringify(tablePositions, null, 2)); // Log the extracted positions for debugging
        expect(tablePositions).toBeDefined();
        expect(tablePositions.length).toBe(9);
        
        // Check first table
        expect(tablePositions[0].name).toBe("Date_Culture_Fail");
        expect(tablePositions[0].columns?.[0].name).toBe('OriginalDate');
        expect(tablePositions[0].columns?.[1].name).toBe("DayOfWeekName");
        expect(tablePositions[0].columns?.[2].name).toBe("DateFrom");
        expect(tablePositions[0].partitions?.[0].lineNumber).toBe(57);
        
        // Check second table
        expect(tablePositions[1].name).toBe("Date_Culture_Pass");
        expect(tablePositions[1].columns?.[0].name).toBe('OriginalDate');
        expect(tablePositions[1].columns?.[1].name).toBe("DayOfWeekName");
        expect(tablePositions[1].columns?.[2].name).toBe("DateFrom");
        expect(tablePositions[1].partitions?.[0].lineNumber).toBe(124);

        // Check third table
        expect(tablePositions[2].name).toBe("Date_Culture_SomeFail");
        expect(tablePositions[2].columns?.[0].name).toBe('OriginalDate');
        expect(tablePositions[2].columns?.[1].name).toBe("DayOfWeekName");
        expect(tablePositions[2].columns?.[2].name).toBe("DateFrom");
        expect(tablePositions[2].partitions?.[0].lineNumber).toBe(194);

        // Check fourth table
        expect(tablePositions[3].name).toBe("Date_Culture_DateTimeFail");
        expect(tablePositions[3].columns?.[0].name).toBe('OriginalDate');
        expect(tablePositions[3].columns?.[1].name).toBe("DayOfWeekName");
        expect(tablePositions[3].columns?.[2].name).toBe("DateFrom");
        expect(tablePositions[3].partitions?.[0].lineNumber).toBe(269);

        // Check fifth table
        expect(tablePositions[4].name).toBe("Functions Table");

        // Check sixth table
        expect(tablePositions[5].name).toBe("Has <code>Culture</code>");
    });
});

describe('extractTableAndProperties with Calendar.tmdl', () => {
    it('should parse a single TMDL object with partition properties from _TMDL_with_One_Table_Calendar_DataFilePath', () => {
        const fileContent = fs.readFileSync(_TMDL_with_One_Table_Calendar_DataFilePath, 'utf-8');
        const extractedData = parseTMDLLines(fileContent);
        expect(extractedData).toBeDefined();

        const tablePositions = extractTableAndProperties(fileContent);
        console.log('Extracted Table Positions:', JSON.stringify(tablePositions, null, 2)); // Log the extracted positions for debugging
        expect(tablePositions).toBeDefined();
        expect(tablePositions.length).toBe(1);

        // Check first table
        expect(tablePositions[0].name).toBe("Calendar");
        expect(tablePositions[0].properties.dataCategory).toBe("Time");
        expect(tablePositions[0].columns?.[0].name).toBe('CalendarID');
        expect(tablePositions[0].columns?.[0].isAvailableInMdx).toBe(false);
        expect(tablePositions[0].columns?.[0].isHidden).toBe(true);
        expect(tablePositions[0].columns?.[0].isKey).toBe(false);
        expect(tablePositions[0].columns?.[0].sourceProviderType).toBe('int');
        
        // Check second column
        expect(tablePositions[0].columns?.[1].name).toBe('Date');
        expect(tablePositions[0].columns?.[1].isKey).toBe(true);
        expect(tablePositions[0].partitions?.[0].lineNumber).toBe(92);
    });
});

describe('extractTableAndProperties with DateTimeCheck.tmdl', () => {
    it('should parse a single TMDL object with partition properties from _TMDL_with_One_Table_DateTimeCheck_DataFilePath', () => {
        const fileContent = fs.readFileSync(_TMDL_with_One_Table_DateTimeCheck_DataFilePath, 'utf-8');
        const extractedData = parseTMDLLines(fileContent);
        expect(extractedData).toBeDefined();

        const tablePositions = extractTableAndProperties(fileContent);
        console.log('Extracted Table Positions:', JSON.stringify(tablePositions, null, 2)); // Log the extracted positions for debugging
        expect(tablePositions).toBeDefined();
        expect(tablePositions.length).toBe(1);
        expect(tablePositions[0].columns?.length).toBe(4);
        // Check for presence of date time column after having the unknown issue
        expect(tablePositions[0].columns?.[3].name).toBe("o_orderdate");
        expect(tablePositions[0].columns?.[3].dataType).toBe("dateTime");
    });
});

describe('extractTableAndProperties with User Aggregation', () => {

    it('should extract M code and properties from TMDL code', () => {
        const fileContent = fs.readFileSync(_TMDL_User_Agg_DataFilePath, 'utf-8');

        // Use table-level extraction to validate partition hidden flags
        const tables = extractTableAndProperties(fileContent);
        expect(tables).toBeDefined();
        console.log('Extracted Tables and Partitions:', JSON.stringify(tables, null, 2));

        // Find the target partition and assert hidden flag
        const targetPartition = tables.find(p => p.name === 'lineitem_by_nation_agg');
        expect(targetPartition).toBeDefined();
        expect(targetPartition?.properties).toBeDefined();
        expect(targetPartition?.properties?.isHidden).toBe(true);

        // Ensure all other partitions are not hidden
        tables.forEach(p => {
            if (p.name !== 'lineitem_by_nation_agg') {
                expect(p.properties?.isHidden).toBe(false);
            }
        });
    });
});

describe('extractTableAndProperties with StarterScript.tmdl', () => {

    it('should extract M code and properties from TMDL code', () => {
        const fileContent = fs.readFileSync(_TMDL_Start_Scripts_DataFilePath, 'utf-8');

        // Use table-level extraction to validate partition hidden flags
        const tables = extractTableAndProperties(fileContent);
        expect(tables).toBeDefined();
        console.log('Extracted Tables and Partitions:', JSON.stringify(tables, null, 2));
    });
});