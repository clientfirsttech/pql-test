/**
 * License Filter Tests
 *
 * Validates that filterRulesByLicense correctly restricts rules by tier and that
 * isTMDLLintingAllowed enforces the PRO gate for TMDL linting.
 */

import { LicenseLevel } from 'src/lint/rule-types';
import {
    filterRulesByLicense,
    isTMDLLintingAllowed,
    TMDL_PRO_UPGRADE_MESSAGE,
} from 'src/lint/license-filter';
import {
    allPQRules,
    allTMDLLevelPQRules,
    allTMDLSecurityLevelPQRules,
    allTMDLSecurityLevelRules,
} from 'src/lint/all-rules';

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const allRules = [
    ...allPQRules,
    ...allTMDLLevelPQRules,
    ...allTMDLSecurityLevelPQRules,
    ...allTMDLSecurityLevelRules,
];

// ---------------------------------------------------------------------------
// filterRulesByLicense — FREE tier
// ---------------------------------------------------------------------------

describe('filterRulesByLicense – FREE tier', () => {
    let freeRules: typeof allRules;

    beforeEach(() => {
        freeRules = filterRulesByLicense(allRules, LicenseLevel.Free);
    });

    test('should return at least one rule for the FREE tier', () => {
        expect(freeRules.length).toBeGreaterThan(0);
    });

    test('every returned rule should have MinLicenseLevel === Free (0)', () => {
        freeRules.forEach(rule => {
            expect(rule.MinLicenseLevel).toBe(LicenseLevel.Free);
        });
    });

    test('should NOT include any PRO-only rules', () => {
        const proRulesInFreeSet = freeRules.filter(
            rule => rule.MinLicenseLevel === LicenseLevel.Pro
        );
        expect(proRulesInFreeSet.length).toBe(0);
    });

    test('should return fewer rules than the full rule set', () => {
        expect(freeRules.length).toBeLessThan(allRules.length);
    });

    test('FREE set should be a strict subset of the PRO set', () => {
        const proRules = filterRulesByLicense(allRules, LicenseLevel.Pro);
        const proIds = new Set(proRules.map(r => r.ID));
        freeRules.forEach(rule => {
            expect(proIds.has(rule.ID)).toBe(true);
        });
    });
});

// ---------------------------------------------------------------------------
// filterRulesByLicense — PRO tier
// ---------------------------------------------------------------------------

describe('filterRulesByLicense – PRO tier', () => {
    let proRules: typeof allRules;

    beforeEach(() => {
        proRules = filterRulesByLicense(allRules, LicenseLevel.Pro);
    });

    test('should return more rules than the FREE tier', () => {
        const freeRules = filterRulesByLicense(allRules, LicenseLevel.Free);
        expect(proRules.length).toBeGreaterThan(freeRules.length);
    });

    test('every returned rule should have MinLicenseLevel <= Pro (1)', () => {
        proRules.forEach(rule => {
            expect(rule.MinLicenseLevel).toBeLessThanOrEqual(LicenseLevel.Pro);
        });
    });

    test('should include Free-tier rules', () => {
        const freeIds = filterRulesByLicense(allRules, LicenseLevel.Free).map(r => r.ID);
        const proIds = new Set(proRules.map(r => r.ID));
        freeIds.forEach(id => {
            expect(proIds.has(id)).toBe(true);
        });
    });

    test('should include PRO-only rules', () => {
        const proOnlyRules = proRules.filter(r => r.MinLicenseLevel === LicenseLevel.Pro);
        expect(proOnlyRules.length).toBeGreaterThan(0);
    });
});

// ---------------------------------------------------------------------------
// filterRulesByLicense — TMDL rule arrays
// ---------------------------------------------------------------------------

describe('filterRulesByLicense – TMDL rule arrays', () => {
    test('PRO tier should include at least some TMDL level PQ rules', () => {
        const filtered = filterRulesByLicense(allTMDLLevelPQRules, LicenseLevel.Pro);
        expect(filtered.length).toBeGreaterThan(0);
    });

    test('FREE tier should NOT receive PRO-gated TMDL level PQ rules', () => {
        const proOnlyTMDLRules = allTMDLLevelPQRules.filter(
            r => r.MinLicenseLevel === LicenseLevel.Pro
        );
        const freeFiltered = filterRulesByLicense(allTMDLLevelPQRules, LicenseLevel.Free);
        const freeFilteredIds = new Set(freeFiltered.map(r => r.ID));
        proOnlyTMDLRules.forEach(rule => {
            expect(freeFilteredIds.has(rule.ID)).toBe(false);
        });
    });

    test('PRO tier should receive PRO-gated TMDL level PQ rules', () => {
        const proOnlyTMDLRules = allTMDLLevelPQRules.filter(
            r => r.MinLicenseLevel === LicenseLevel.Pro
        );
        const proFiltered = filterRulesByLicense(allTMDLLevelPQRules, LicenseLevel.Pro);
        const proFilteredIds = new Set(proFiltered.map(r => r.ID));
        proOnlyTMDLRules.forEach(rule => {
            expect(proFilteredIds.has(rule.ID)).toBe(true);
        });
    });
});

// ---------------------------------------------------------------------------
// isTMDLLintingAllowed
// ---------------------------------------------------------------------------

describe('isTMDLLintingAllowed', () => {
    test('should return false for FREE tier', () => {
        expect(isTMDLLintingAllowed(LicenseLevel.Free)).toBe(false);
    });

    test('should return true for PRO tier', () => {
        expect(isTMDLLintingAllowed(LicenseLevel.Pro)).toBe(true);
    });

    test('should return true for PREMIUM tier', () => {
        expect(isTMDLLintingAllowed(LicenseLevel.Premium)).toBe(true);
    });
});

// ---------------------------------------------------------------------------
// TMDL_PRO_UPGRADE_MESSAGE
// ---------------------------------------------------------------------------

describe('TMDL_PRO_UPGRADE_MESSAGE', () => {
    test('should be a non-empty string', () => {
        expect(typeof TMDL_PRO_UPGRADE_MESSAGE).toBe('string');
        expect(TMDL_PRO_UPGRADE_MESSAGE.length).toBeGreaterThan(0);
    });

    test('should reference the PRO tier', () => {
        expect(TMDL_PRO_UPGRADE_MESSAGE.toLowerCase()).toContain('pro');
    });
});
