/**
 * License Integration Tests
 *
 * End-to-end tests that validate the complete license-check flow:
 *
 *   1. LicenseManager reads / validates a license payload
 *   2. filterRulesByLicense restricts rules to the active tier
 *   3. isTMDLLintingAllowed gates TMDL access
 *   4. Keygen helper functions correctly map API responses
 *
 * These tests simulate real-world scenarios:
 *   - A FREE user tries to lint with PRO rules
 *   - A PRO user activates, lints, then deactivates
 *   - A license expires mid-session
 *   - A Keygen API response is mapped to a LicensePayload
 *   - Machine fingerprint generation is deterministic
 *
 * No real Keygen API calls are made — all tests use local mocks.
 */

import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { LicenseManager, LicensePayload } from 'src/lint/license-manager';
import { LicenseLevel } from 'src/lint/rule-types';
import { filterRulesByLicense, isTMDLLintingAllowed, TMDL_PRO_UPGRADE_MESSAGE } from 'src/lint/license-filter';
import {
    allPQRules,
    allTMDLLevelPQRules,
    allTMDLSecurityLevelPQRules,
    allTMDLSecurityLevelRules,
} from 'src/lint/all-rules';
import {
    keygenTierToLicenseLevel,
    keygenResponseToPayload,
    generateMachineFingerprint,
    KeygenValidationResponse,
} from 'src/lint/keygen-integration';

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function createTempLicenseFile(): string {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pqlint-integ-'));
    return path.join(dir, '.pqlintrc');
}

function makePayload(tier: LicenseLevel, extraHours: number = 8760): LicensePayload {
    return {
        key: `test-key-${LicenseLevel[tier]}`,
        tier,
        expiresAt: new Date(Date.now() + extraHours * 60 * 60 * 1000).toISOString(),
        signature: 'integration-test-sig',
    };
}

/** Build a mock Keygen validation response. */
function makeKeygenResponse(
    valid: boolean,
    tier: string,
    code: string = 'VALID',
    expiry?: string
): KeygenValidationResponse {
    return {
        meta: { code, valid },
        data: {
            id: 'lic_abc123',
            attributes: {
                key: 'XXXX-XXXX-XXXX-XXXX',
                status: valid ? 'ACTIVE' : 'EXPIRED',
                expiry: expiry ?? new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
                metadata: { tier },
            },
        },
    };
}

// All rule arrays combined
const allRules = [
    ...allPQRules,
    ...allTMDLLevelPQRules,
    ...allTMDLSecurityLevelPQRules,
    ...allTMDLSecurityLevelRules,
];

// ---------------------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------------------

let tempFile: string;
let mgr: LicenseManager;

beforeEach(() => {
    tempFile = createTempLicenseFile();
    mgr = LicenseManager.createForTesting(tempFile);
    delete process.env['PQL_LICENSE_KEY'];
});

afterEach(() => {
    try {
        if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
        const dir = path.dirname(tempFile);
        if (fs.existsSync(dir)) fs.rmdirSync(dir);
    } catch { /* best-effort */ }
    LicenseManager.resetInstance();
});

// ===========================================================================
// Integration: Full license-check flow
// ===========================================================================

describe('Integration: FREE user – full flow', () => {
    test('no license → FREE tier → limited rules → no TMDL', () => {
        // Step 1: LicenseManager reports FREE
        const license = mgr.getCurrentLicense();
        expect(license.valid).toBe(false);
        expect(license.tier).toBe(LicenseLevel.Free);

        // Step 2: filterRulesByLicense returns only FREE rules
        const availableRules = filterRulesByLicense(allRules, license.tier);
        availableRules.forEach(rule => {
            expect(rule.MinLicenseLevel).toBe(LicenseLevel.Free);
        });

        // Step 3: TMDL linting is blocked
        expect(isTMDLLintingAllowed(license.tier)).toBe(false);
    });

    test('FREE user gets upgrade message when attempting TMDL', () => {
        const license = mgr.getCurrentLicense();
        expect(isTMDLLintingAllowed(license.tier)).toBe(false);
        expect(TMDL_PRO_UPGRADE_MESSAGE.toLowerCase()).toContain('pro');
    });

    test('FREE user gets fewer rules than PRO user', () => {
        const freeRules = filterRulesByLicense(allRules, LicenseLevel.Free);
        const proRules = filterRulesByLicense(allRules, LicenseLevel.Pro);
        expect(freeRules.length).toBeLessThan(proRules.length);
    });
});

describe('Integration: PRO user – activate → lint → deactivate', () => {
    test('activate PRO → full rules → TMDL allowed → deactivate → back to FREE', () => {
        // Step 1: Activate PRO license
        mgr.activate(makePayload(LicenseLevel.Pro));
        const proLicense = mgr.getCurrentLicense();
        expect(proLicense.valid).toBe(true);
        expect(proLicense.tier).toBe(LicenseLevel.Pro);

        // Step 2: PRO rules include both FREE and PRO rules
        const proRules = filterRulesByLicense(allRules, proLicense.tier);
        const proOnlyRules = proRules.filter(r => r.MinLicenseLevel === LicenseLevel.Pro);
        const freeRules = proRules.filter(r => r.MinLicenseLevel === LicenseLevel.Free);
        expect(proOnlyRules.length).toBeGreaterThan(0);
        expect(freeRules.length).toBeGreaterThan(0);

        // Step 3: TMDL linting is allowed
        expect(isTMDLLintingAllowed(proLicense.tier)).toBe(true);
        expect(mgr.canLintTMDL()).toBe(true);

        // Step 4: Version label shows PRO
        expect(mgr.getTierLabel()).toBe('PRO');

        // Step 5: Deactivate
        mgr.deactivate();
        const afterDeactivate = mgr.getCurrentLicense();
        expect(afterDeactivate.valid).toBe(false);
        expect(afterDeactivate.tier).toBe(LicenseLevel.Free);
        expect(mgr.canLintTMDL()).toBe(false);
        expect(mgr.getTierLabel()).toBe('FREE');
    });
});

describe('Integration: PREMIUM user – full flow', () => {
    test('PREMIUM tier gets all rules and TMDL access', () => {
        mgr.activate(makePayload(LicenseLevel.Premium));
        const license = mgr.getCurrentLicense();
        expect(license.valid).toBe(true);
        expect(license.tier).toBe(LicenseLevel.Premium);

        const premiumRules = filterRulesByLicense(allRules, license.tier);
        // PREMIUM gets everything PRO gets and potentially more
        const proRules = filterRulesByLicense(allRules, LicenseLevel.Pro);
        expect(premiumRules.length).toBeGreaterThanOrEqual(proRules.length);

        expect(isTMDLLintingAllowed(license.tier)).toBe(true);
        expect(mgr.getTierLabel()).toBe('PREMIUM');
    });
});

describe('Integration: license expiry mid-session', () => {
    test('expired PRO license → falls back to FREE rules', () => {
        // Activate with an already-expired license
        const expired = makePayload(LicenseLevel.Pro, -1); // expired 1 hour ago
        mgr.activate(expired);

        const license = mgr.getCurrentLicense();
        expect(license.valid).toBe(false);
        expect(license.tier).toBe(LicenseLevel.Free);

        // Even though the payload says PRO, the filter gets FREE
        const rules = filterRulesByLicense(allRules, license.tier);
        rules.forEach(rule => {
            expect(rule.MinLicenseLevel).toBe(LicenseLevel.Free);
        });
        expect(isTMDLLintingAllowed(license.tier)).toBe(false);
    });
});

describe('Integration: env var license with rule filtering', () => {
    test('PQL_LICENSE_KEY env var with PRO tier → full rules', () => {
        const payload = makePayload(LicenseLevel.Pro);
        process.env['PQL_LICENSE_KEY'] = JSON.stringify(payload);

        const envMgr = LicenseManager.createForTesting('/tmp/nonexistent-integ/.pqlintrc');
        const license = envMgr.getCurrentLicense();
        expect(license.valid).toBe(true);
        expect(license.tier).toBe(LicenseLevel.Pro);

        const rules = filterRulesByLicense(allRules, license.tier);
        const proOnly = rules.filter(r => r.MinLicenseLevel === LicenseLevel.Pro);
        expect(proOnly.length).toBeGreaterThan(0);
    });
});

describe('Integration: file takes precedence over env var', () => {
    test('file-based PREMIUM overrides env-based PRO', () => {
        // Set env var to PRO
        process.env['PQL_LICENSE_KEY'] = JSON.stringify(makePayload(LicenseLevel.Pro));

        // Activate file-based PREMIUM
        mgr.activate(makePayload(LicenseLevel.Premium));

        const license = mgr.getCurrentLicense();
        // File should win since LicenseManager checks file first
        expect(license.tier).toBe(LicenseLevel.Premium);
    });
});

// ===========================================================================
// Integration: Keygen helper functions
// ===========================================================================

describe('Integration: keygenTierToLicenseLevel', () => {
    test.each([
        ['free', LicenseLevel.Free],
        ['pro', LicenseLevel.Pro],
        ['premium', LicenseLevel.Premium],
        ['PRO', LicenseLevel.Pro],
        ['Premium', LicenseLevel.Premium],
        ['FREE', LicenseLevel.Free],
        [undefined, LicenseLevel.Free],
        ['unknown', LicenseLevel.Free],
        ['', LicenseLevel.Free],
    ])('tier string "%s" → LicenseLevel.%s', (input, expected) => {
        expect(keygenTierToLicenseLevel(input)).toBe(expected);
    });
});

describe('Integration: keygenResponseToPayload', () => {
    test('valid PRO Keygen response → PRO LicensePayload', () => {
        const response = makeKeygenResponse(true, 'pro');
        const payload = keygenResponseToPayload(response);

        expect(payload.key).toBe('XXXX-XXXX-XXXX-XXXX');
        expect(payload.tier).toBe(LicenseLevel.Pro);
        expect(payload.signature).toBe('keygen-validated');
        expect(new Date(payload.expiresAt).getTime()).toBeGreaterThan(Date.now());
        expect(payload.lastSyncAt).toBeDefined();
    });

    test('valid PREMIUM Keygen response → PREMIUM LicensePayload', () => {
        const response = makeKeygenResponse(true, 'premium');
        const payload = keygenResponseToPayload(response);
        expect(payload.tier).toBe(LicenseLevel.Premium);
    });

    test('null expiry → defaults to 1 year from now', () => {
        const response = makeKeygenResponse(true, 'pro');
        response.data.attributes.expiry = null;
        const payload = keygenResponseToPayload(response);

        const expectedMin = Date.now() + 364 * 24 * 60 * 60 * 1000;
        expect(new Date(payload.expiresAt).getTime()).toBeGreaterThan(expectedMin);
    });

    test('Keygen payload can be activated in LicenseManager', () => {
        const response = makeKeygenResponse(true, 'pro');
        const payload = keygenResponseToPayload(response);

        mgr.activate(payload);
        const license = mgr.getCurrentLicense();
        expect(license.valid).toBe(true);
        expect(license.tier).toBe(LicenseLevel.Pro);
        expect(mgr.canLintTMDL()).toBe(true);
    });

    test('expired Keygen response payload → rejected by LicenseManager', () => {
        const response = makeKeygenResponse(true, 'pro', 'VALID',
            new Date(Date.now() - 1000).toISOString()  // expired
        );
        const payload = keygenResponseToPayload(response);

        mgr.activate(payload);
        const license = mgr.getCurrentLicense();
        expect(license.valid).toBe(false);
        expect(license.tier).toBe(LicenseLevel.Free);
    });
});

describe('Integration: generateMachineFingerprint', () => {
    test('returns a 64-character hex string (SHA-256)', () => {
        const fp = generateMachineFingerprint();
        expect(typeof fp).toBe('string');
        expect(fp.length).toBe(64);
        expect(/^[0-9a-f]{64}$/.test(fp)).toBe(true);
    });

    test('is deterministic (same machine → same fingerprint)', () => {
        const fp1 = generateMachineFingerprint();
        const fp2 = generateMachineFingerprint();
        expect(fp1).toBe(fp2);
    });
});

// ===========================================================================
// Integration: Rule counts by tier (sanity checks)
// ===========================================================================

describe('Integration: rule count sanity checks', () => {
    test('total rule count across all arrays is > 0', () => {
        expect(allRules.length).toBeGreaterThan(0);
    });

    test('FREE rules < PRO rules ≤ total rules', () => {
        const freeCount = filterRulesByLicense(allRules, LicenseLevel.Free).length;
        const proCount = filterRulesByLicense(allRules, LicenseLevel.Pro).length;
        const premiumCount = filterRulesByLicense(allRules, LicenseLevel.Premium).length;

        expect(freeCount).toBeGreaterThan(0);
        expect(proCount).toBeGreaterThan(freeCount);
        expect(premiumCount).toBeGreaterThanOrEqual(proCount);
        expect(premiumCount).toBeLessThanOrEqual(allRules.length);
    });

    test('every rule has a valid MinLicenseLevel', () => {
        allRules.forEach(rule => {
            expect([LicenseLevel.Free, LicenseLevel.Pro, LicenseLevel.Premium])
                .toContain(rule.MinLicenseLevel);
        });
    });
});

// ===========================================================================
// Integration: corrupt data resilience
// ===========================================================================

describe('Integration: resilience – corrupt license still allows FREE linting', () => {
    test('corrupt file on disk → FREE tier → still has FREE rules', () => {
        fs.writeFileSync(tempFile, 'garbage-data!!!', 'utf-8');

        const license = mgr.getCurrentLicense();
        expect(license.valid).toBe(false);
        expect(license.tier).toBe(LicenseLevel.Free);

        // FREE rules are still available
        const rules = filterRulesByLicense(allRules, license.tier);
        expect(rules.length).toBeGreaterThan(0);
    });

    test('missing signature → FREE tier → no TMDL', () => {
        const noSig: LicensePayload = {
            key: 'key',
            tier: LicenseLevel.Pro,
            expiresAt: new Date(Date.now() + 86400000).toISOString(),
            signature: '',
        };
        mgr.activate(noSig);

        const license = mgr.getCurrentLicense();
        expect(license.tier).toBe(LicenseLevel.Free);
        expect(isTMDLLintingAllowed(license.tier)).toBe(false);
    });
});
