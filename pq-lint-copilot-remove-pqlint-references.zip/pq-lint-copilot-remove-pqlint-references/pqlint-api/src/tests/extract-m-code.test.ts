import * as fs from 'fs';
import * as path from 'path';
import { extractNamedExpressionMCode, extractPartitionMCode, extractDataflowMCode } from 'src/lint/extract-m-code';
import { logDebug } from 'src/lint/rule-assistance';
import { tmdlCodeSample3, tmdlCodeSample4 } from './hardcoded-tmdl';

// File paths for test cases
const _useRelativePathWithWebContents_Fail_DataFilePath = path.resolve('./test-files/Files/use-relative-path-with-web-contents.SemanticModel/definition/tables/use-relative-path-with-web-contents_fail.tmdl');
const _JoinMissingComment_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Join_MissingComment.tmdl');
const _MyData2_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/MyData (2).tmdl');
const _SorCheck_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Sort_Check_Without_Buffer_Fail.tmdl');
const _Expression_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/expressions.tmdl');
const _TMDL_with_Ticks_DataFilePath = path.resolve('./test-files/tmdl_with_ticks.tmdl');
const _Gen2_DataFilePath = path.resolve('./test-files/test_dfgen2/mashup.pq');

describe('extractPartitionMCode', () => {
    it('should extract M code from use-relative-path-with-web-contents_fail.tmdl files in ', () => {
        const fileContent = fs.readFileSync(_useRelativePathWithWebContents_Fail_DataFilePath, 'utf-8');
        const result = extractPartitionMCode(fileContent);
        // Ensure the result contains a partition with the specified properties
        const expectedPartition = result.find(partition =>
            partition.name === 'use-relative-path-with-web-contents_fail-9b980f40-8504-413c-98b2-7be27f4146c9' &&
            partition.resultType === 'Table' &&
            partition.mCode.startsWith('let') &&
            partition.lineNumber !== null
        );
        logDebug(result);
        expect(expectedPartition).toBeDefined();
        //logDebug(result);

        // Ensure the last line of the mCode does not start with annotation
        if (expectedPartition) {
            const mCodeLines = expectedPartition.mCode.split('\n');
            const lastLine = mCodeLines[mCodeLines.length - 1].trim();
            expect(lastLine.startsWith('annotation')).toBe(false);
            expect(lastLine.startsWith('changedProperty')).toBe(false);
        }
    });


    it('should extract M code from .tmdl files in tests/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables with underscore in name', () => {
        const fileContent = fs.readFileSync(_JoinMissingComment_DataFilePath, 'utf-8');
        const result = extractPartitionMCode(fileContent);
        // Ensure the result contains a partition with the specified properties
        const expectedPartition = result.find(partition =>
            partition.name === 'Join_MissingComment' &&
            partition.resultType === 'Table' &&
            partition.mCode.startsWith('let') &&
            partition.lineNumber !== null
        );
        //logDebug(result);
        expect(expectedPartition).toBeDefined();
        //logDebug(result);

        // Ensure the last line of the mCode does not start with annotation
        if (expectedPartition) {
            const mCodeLines = expectedPartition.mCode.split('\n');
            const lastLine = mCodeLines[mCodeLines.length - 1].trim();
            expect(lastLine.startsWith('annotation')).toBe(false);
            expect(lastLine.startsWith('changedProperty')).toBe(false);
        }
    });


    it('should extract M code from .tmdl files in tests/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables with spaces in name', () => {
        const fileContent = fs.readFileSync(_MyData2_DataFilePath, 'utf-8');
        const result = extractPartitionMCode(fileContent);
        // Ensure the result contains a partition with the specified properties
        const expectedPartition = result.find(partition =>
            partition.name === 'MyData (2)' &&
            partition.resultType === 'Table' &&
            partition.mCode.startsWith('let') &&
            partition.lineNumber !== null
        );
        //logDebug(result);
        expect(expectedPartition).toBeDefined();

        // Ensure the last line of the mCode does not start with annotation
        if (expectedPartition) {
            const mCodeLines = expectedPartition.mCode.split('\n');
            const lastLine = mCodeLines[mCodeLines.length - 1].trim();
            expect(lastLine.startsWith('annotation')).toBe(false);
        }
    });


    it('should extract M code from .tmdl files in tests/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables with underscore in name', () => {
        const fileContent = fs.readFileSync(_SorCheck_DataFilePath, 'utf-8');
        const result = extractPartitionMCode(fileContent);
        // Ensure the result contains a partition with the specified properties
        const expectedPartition = result.find(partition =>
            partition.name === 'Sort_Check_Without_Buffer_Fail' &&
            partition.resultType === 'Table' &&
            partition.mCode.startsWith('let') &&
            partition.lineNumber !== null
        );
        //logDebug(result);
        expect(expectedPartition).toBeDefined();
        //logDebug(result);

        // Ensure the last line of the mCode does not start with annotation
        if (expectedPartition) {
            const mCodeLines = expectedPartition.mCode.split('\n');
            const lastLine = mCodeLines[mCodeLines.length - 1].trim();
            expect(lastLine.startsWith('annotation')).toBe(false);
        }
    });

    it('should extract M code from .tmdl file TMDL Code Sample 3', () => {
        const result = extractPartitionMCode(tmdlCodeSample3);
        expect(result.length).toBe(9);
    });

});

describe('extractNamedExpressionMCode and extractPartitionCode', () => {
    it('should extract M code from .tmdl file TMDL with Ticks and Functions and Parameters', () => {
        const fileContent = fs.readFileSync(_TMDL_with_Ticks_DataFilePath, 'utf-8');
        const partitions = extractPartitionMCode(fileContent);
        const expressions = extractNamedExpressionMCode(fileContent);
        expect(partitions.length).toBe(13);
        expect(expressions.length).toBe(13);
    });

    it('should extract M code from .tmdl file TMDL that has a parameter and one table', () => {
        const partitions = extractPartitionMCode(tmdlCodeSample4);
        const expressions = extractNamedExpressionMCode(tmdlCodeSample4);
        expect(partitions.length).toBe(1);
        expect(expressions.length).toBe(1);
        // Test that the expression has M code
        expect(expressions[0].mCode!.length).toBeGreaterThan(0);
        expect(expressions[0].mCode!.trim().startsWith('=')).toEqual(false);
    });    
});

describe('extractNamedExpressionMCode Function', () => {
    it('should extract M code from expression.tmdl files in expression.tmdl', () => {
        const fileContent = fs.readFileSync(_Expression_DataFilePath, 'utf-8');
        const result = extractNamedExpressionMCode(fileContent);
        //logDebug(result);

        // Ensure the result has at least 4 objects
        expect(result.length).toBeGreaterThanOrEqual(4);
        let previousLineNumber = 0;

        result.forEach((expression, index) => {
            //logDebug(expression);
            expect(expression.mCode).toBeDefined();
            expect(expression.name).toBeDefined();
            expect(expression.lineNumber).toBeDefined();
            expect(expression.resultType).toBeDefined();

            if (expression.resultType === 'Table') {
                expect(expression.mCode?.startsWith('let')).toEqual(true);


                if (index > 0) {
                    //logDebug(expression);
                    expect(expression.lineNumber).toBeGreaterThan(previousLineNumber);
                }
                previousLineNumber = expression.lineNumber!;
            }// end if
        });
    });
});


describe('extractDataflowMCode', () => {
    it('should extract M code from mashup.pq files in test/test_dfgen2', () => {
        const fileContent = fs.readFileSync(_Gen2_DataFilePath, 'utf-8');
        const result = extractDataflowMCode(fileContent);

        // Ensure the result has at least 4 objects
        expect(result.length).toBeGreaterThanOrEqual(4);
        let previousLineNumber = 0;

        result.forEach((expression, index) => {
            //logDebug(expression);
            expect(expression.mCode).toBeDefined();
            expect(expression.name).toBeDefined();
            expect(expression.lineNumber).toBeDefined();
            expect(expression.resultType).toBeDefined();

            if (expression.resultType === 'Table') {
                logDebug(expression);
                expect(expression.mCode?.startsWith('let')).toEqual(true);

                if (index > 0) {
                    //logDebug(expression);
                    expect(expression.lineNumber).toBeGreaterThan(previousLineNumber);
                }
                previousLineNumber = expression.lineNumber!;
            }// end if
        });
    });
});