/**
 * License Manager Tests
 *
 * Unit tests for the hybrid license manager (Option C).
 * Tests cover:
 *   - Local file-based validation
 *   - Environment variable fallback
 *   - Expiry checking
 *   - Signature verification (placeholder)
 *   - Tier resolution for FREE / PRO / PREMIUM
 *   - Activation and deactivation flows
 *   - TMDL gating via canLintTMDL
 *   - getTierLabel display strings
 */

import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { LicenseManager, LicensePayload } from 'src/lint/license-manager';
import { LicenseLevel } from 'src/lint/rule-types';

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Unique temp directory per test run to avoid collisions. */
function createTempLicenseFile(): string {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pqlint-test-'));
    return path.join(dir, '.pqlintrc');
}

/** Build a valid PRO payload that expires far in the future. */
function makeProPayload(overrides?: Partial<LicensePayload>): LicensePayload {
    return {
        key: 'test-pro-key-12345',
        tier: LicenseLevel.Pro,
        expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(), // +1 year
        signature: 'valid-sig-placeholder',
        ...overrides,
    };
}

/** Build a valid FREE payload. */
function makeFreePayload(overrides?: Partial<LicensePayload>): LicensePayload {
    return {
        key: 'test-free-key-00000',
        tier: LicenseLevel.Free,
        expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
        signature: 'valid-sig-placeholder',
        ...overrides,
    };
}

/** Build a PREMIUM payload. */
function makePremiumPayload(overrides?: Partial<LicensePayload>): LicensePayload {
    return {
        key: 'test-premium-key-99999',
        tier: LicenseLevel.Premium,
        expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
        signature: 'valid-sig-placeholder',
        ...overrides,
    };
}

// ---------------------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------------------

let tempFile: string;
let mgr: LicenseManager;

beforeEach(() => {
    tempFile = createTempLicenseFile();
    mgr = LicenseManager.createForTesting(tempFile);
    // Clean env
    delete process.env['PQL_LICENSE_KEY'];
});

afterEach(() => {
    // Clean up temp file
    try {
        if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
        const dir = path.dirname(tempFile);
        if (fs.existsSync(dir)) fs.rmdirSync(dir);
    } catch { /* best-effort */ }

    LicenseManager.resetInstance();
});

// ---------------------------------------------------------------------------
// No license present
// ---------------------------------------------------------------------------

describe('LicenseManager – no license present', () => {
    test('getCurrentLicense returns FREE when no file exists and no env var', () => {
        const result = mgr.getCurrentLicense();
        expect(result.valid).toBe(false);
        expect(result.tier).toBe(LicenseLevel.Free);
        expect(result.message).toContain('No license found');
    });

    test('canLintTMDL returns false when no license', () => {
        expect(mgr.canLintTMDL()).toBe(false);
    });

    test('getTierLabel returns FREE when no license', () => {
        expect(mgr.getTierLabel()).toBe('FREE');
    });
});

// ---------------------------------------------------------------------------
// File-based activation
// ---------------------------------------------------------------------------

describe('LicenseManager – file-based license', () => {
    test('activate writes payload to disk and getCurrentLicense resolves PRO', () => {
        const payload = makeProPayload();
        mgr.activate(payload);

        expect(fs.existsSync(tempFile)).toBe(true);
        const onDisk = JSON.parse(fs.readFileSync(tempFile, 'utf-8'));
        expect(onDisk.tier).toBe(LicenseLevel.Pro);

        const result = mgr.getCurrentLicense();
        expect(result.valid).toBe(true);
        expect(result.tier).toBe(LicenseLevel.Pro);
    });

    test('activate with FREE tier resolves as FREE', () => {
        mgr.activate(makeFreePayload());
        const result = mgr.getCurrentLicense();
        expect(result.valid).toBe(true);
        expect(result.tier).toBe(LicenseLevel.Free);
    });

    test('activate with PREMIUM tier resolves as PREMIUM', () => {
        mgr.activate(makePremiumPayload());
        const result = mgr.getCurrentLicense();
        expect(result.valid).toBe(true);
        expect(result.tier).toBe(LicenseLevel.Premium);
    });

    test('deactivate removes file and falls back to FREE', () => {
        mgr.activate(makeProPayload());
        expect(fs.existsSync(tempFile)).toBe(true);

        mgr.deactivate();
        expect(fs.existsSync(tempFile)).toBe(false);

        const result = mgr.getCurrentLicense();
        expect(result.valid).toBe(false);
        expect(result.tier).toBe(LicenseLevel.Free);
    });
});

// ---------------------------------------------------------------------------
// Environment variable fallback
// ---------------------------------------------------------------------------

describe('LicenseManager – env var fallback', () => {
    test('reads license from PQL_LICENSE_KEY when no file exists', () => {
        const payload = makeProPayload();
        process.env['PQL_LICENSE_KEY'] = JSON.stringify(payload);

        // New manager with no file
        const envMgr = LicenseManager.createForTesting('/tmp/nonexistent/.pqlintrc');
        const result = envMgr.getCurrentLicense();
        expect(result.valid).toBe(true);
        expect(result.tier).toBe(LicenseLevel.Pro);
    });

    test('returns FREE when env var is malformed JSON', () => {
        process.env['PQL_LICENSE_KEY'] = 'not-valid-json';
        const envMgr = LicenseManager.createForTesting('/tmp/nonexistent/.pqlintrc');
        const result = envMgr.getCurrentLicense();
        expect(result.valid).toBe(false);
        expect(result.tier).toBe(LicenseLevel.Free);
    });
});

// ---------------------------------------------------------------------------
// Expiry validation
// ---------------------------------------------------------------------------

describe('LicenseManager – expiry checking', () => {
    test('expired license falls back to FREE', () => {
        const expired = makeProPayload({
            expiresAt: new Date(Date.now() - 1000).toISOString(), // 1 second ago
        });
        mgr.activate(expired);

        const result = mgr.getCurrentLicense();
        expect(result.valid).toBe(false);
        expect(result.tier).toBe(LicenseLevel.Free);
        expect(result.message).toContain('expired');
    });

    test('license expiring far in the future is valid', () => {
        const farFuture = makeProPayload({
            expiresAt: new Date(Date.now() + 10 * 365 * 24 * 60 * 60 * 1000).toISOString(),
        });
        mgr.activate(farFuture);

        const result = mgr.getCurrentLicense();
        expect(result.valid).toBe(true);
        expect(result.tier).toBe(LicenseLevel.Pro);
    });

    test('invalid date string falls back to FREE', () => {
        const badDate = makeProPayload({ expiresAt: 'not-a-date' });
        mgr.activate(badDate);

        const result = mgr.getCurrentLicense();
        expect(result.valid).toBe(false);
        expect(result.tier).toBe(LicenseLevel.Free);
    });
});

// ---------------------------------------------------------------------------
// Signature verification (placeholder)
// ---------------------------------------------------------------------------

describe('LicenseManager – signature verification', () => {
    test('empty signature fails validation', () => {
        const noSig = makeProPayload({ signature: '' });
        mgr.activate(noSig);

        const result = mgr.getCurrentLicense();
        expect(result.valid).toBe(false);
        expect(result.tier).toBe(LicenseLevel.Free);
        expect(result.message).toContain('signature');
    });

    test('valid non-empty signature passes', () => {
        mgr.activate(makeProPayload({ signature: 'abc123' }));
        const result = mgr.getCurrentLicense();
        expect(result.valid).toBe(true);
    });
});

// ---------------------------------------------------------------------------
// TMDL gating
// ---------------------------------------------------------------------------

describe('LicenseManager – canLintTMDL', () => {
    test('FREE tier cannot lint TMDL', () => {
        mgr.activate(makeFreePayload());
        expect(mgr.canLintTMDL()).toBe(false);
    });

    test('PRO tier can lint TMDL', () => {
        mgr.activate(makeProPayload());
        expect(mgr.canLintTMDL()).toBe(true);
    });

    test('PREMIUM tier can lint TMDL', () => {
        mgr.activate(makePremiumPayload());
        expect(mgr.canLintTMDL()).toBe(true);
    });

    test('expired PRO license cannot lint TMDL', () => {
        mgr.activate(makeProPayload({
            expiresAt: new Date(Date.now() - 1000).toISOString(),
        }));
        expect(mgr.canLintTMDL()).toBe(false);
    });
});

// ---------------------------------------------------------------------------
// Tier labels
// ---------------------------------------------------------------------------

describe('LicenseManager – getTierLabel', () => {
    test('no license → FREE', () => {
        expect(mgr.getTierLabel()).toBe('FREE');
    });

    test('FREE payload → FREE', () => {
        mgr.activate(makeFreePayload());
        expect(mgr.getTierLabel()).toBe('FREE');
    });

    test('PRO payload → PRO', () => {
        mgr.activate(makeProPayload());
        expect(mgr.getTierLabel()).toBe('PRO');
    });

    test('PREMIUM payload → PREMIUM', () => {
        mgr.activate(makePremiumPayload());
        expect(mgr.getTierLabel()).toBe('PREMIUM');
    });
});

// ---------------------------------------------------------------------------
// Corrupt / edge-case files
// ---------------------------------------------------------------------------

describe('LicenseManager – corrupt license file', () => {
    test('corrupt JSON file falls back to FREE', () => {
        fs.writeFileSync(tempFile, '{{not valid json}}', 'utf-8');
        const result = mgr.getCurrentLicense();
        expect(result.valid).toBe(false);
        expect(result.tier).toBe(LicenseLevel.Free);
    });

    test('empty file falls back to FREE', () => {
        fs.writeFileSync(tempFile, '', 'utf-8');
        const result = mgr.getCurrentLicense();
        expect(result.valid).toBe(false);
        expect(result.tier).toBe(LicenseLevel.Free);
    });
});

// ---------------------------------------------------------------------------
// Singleton behaviour
// ---------------------------------------------------------------------------

describe('LicenseManager – singleton', () => {
    test('getInstance returns the same instance', () => {
        const a = LicenseManager.getInstance();
        const b = LicenseManager.getInstance();
        expect(a).toBe(b);
    });

    test('resetInstance clears the singleton', () => {
        const a = LicenseManager.getInstance();
        LicenseManager.resetInstance();
        const b = LicenseManager.getInstance();
        expect(a).not.toBe(b);
    });
});
