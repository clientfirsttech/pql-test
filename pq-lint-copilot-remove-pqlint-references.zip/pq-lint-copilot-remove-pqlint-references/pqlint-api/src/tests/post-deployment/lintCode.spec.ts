import { test, expect } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import { getTestingConfig } from './get-testing-config';

// Declare variables at a higher scope
let BASE_URL: string;
let CODE: string;

test.beforeAll(async () => {
    // Load environment variables from local.settings.json
    const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
    if (fs.existsSync(localSettingsPath)) {
        const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
        Object.entries(localSettings.Values).forEach(([key, value]) => {
            process.env[key] = value as string;
        });
    }

    // Initialize BASE_URL
    const testingConfig = getTestingConfig();
    const BASE_URL_PREFIX = testingConfig.baseUrlPrefix;
    CODE = testingConfig.code || '';
    BASE_URL = BASE_URL_PREFIX + '/api/lintCode'; // Replace with your local function URL
});

test.describe('lintCode API Tests', () => {
    test('should return 200 for valid M Code payload', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE, {
            headers: {
                'Content-Type': 'text/plain',
            },
            data: `
                let
                    Source = Sql.Database("azure-sql-db-jk.database.windows.net", "escape-room", [CreateNavigationProperties=false]),
                    dbo_PieData = Source{[Schema="dbo",Item="PieData"]}[Data],
                    #"---> Fix this so you DON'T Break Query Folding" = Table.TransformColumns(dbo_PieData ,{{"SlicesRemainingAsPerc",Number.From, Percentage.Type}})
                in
                    #"---> Fix this so you DON'T Break Query Folding"
            `,
        });

        // Validate response status
        expect(response.status()).toBe(200);

        // Validate response body
        const responseBody = await response.json();
        console.log("Response Body:", responseBody);
        expect(Array.isArray(responseBody)).toBe(true);
        responseBody.forEach((result: any) => {
            expect(result).toHaveProperty('ID');
            expect(result).toHaveProperty('Name');
            expect(result).toHaveProperty('Category');
            expect(result).toHaveProperty('Description');
            expect(result).toHaveProperty('Severity');
            expect(result).toHaveProperty('ErrorInformation');
        });
    });

    test('should return 200 for valid M Code payload that is a parameter', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE, {
            headers: {
                'Content-Type': 'text/plain',
            },
            data: `"Team Alpha" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]`,
        });

        // Validate response status
        expect(response.status()).toBe(200);

        // Validate response body
        const responseBody = await response.json();
        expect(Array.isArray(responseBody)).toBe(true);
        responseBody.forEach((result: any) => {
            expect(result).toHaveProperty('ID');
            expect(result).toHaveProperty('Name');
            expect(result).toHaveProperty('Category');
            expect(result).toHaveProperty('Description');
            expect(result).toHaveProperty('Severity');
            expect(result).toHaveProperty('ErrorInformation');
        });
    });    

    test('should return 400 for empty payload', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE, {
            headers: {
                'Content-Type': 'text/plain',
            },
            data: '', // Empty payload
        });

        // Validate response status
        expect(response.status()).toBe(400);
    });

    test('should return 400 for bad M Code payload', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE, {
            headers: {
                'Content-Type': 'text/plain',
            },
            data: 'let x = 1, y = 2, in y', // bad M code with extra comma
        });

        // Validate response status
        expect(response.status()).toBe(400);
       // Validate response body
        const responseBody = await response.json();
        expect(responseBody).toHaveProperty('error');
        expect(responseBody.error).toMatch(/Parse/);
    }); 
    
    test('should return 200 for function M Code payload', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE, {
            headers: {
                'Content-Type': 'text/plain',
            },
            data: '(x) => x + 1', // bad M code with extra comma
        });

        // Validate response status
        expect(response.status()).toBe(200);
    });     
});