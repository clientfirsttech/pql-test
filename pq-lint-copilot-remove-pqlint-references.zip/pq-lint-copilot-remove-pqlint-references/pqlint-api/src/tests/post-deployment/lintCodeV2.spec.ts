import { test, expect } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import { LintRequest } from 'src/helpers/http-request-types';
import { SeverityLevel } from 'src/lint/rule-types';
import { getTestingConfig } from './get-testing-config';

// Declare variables at a higher scope
let BASE_URL: string;
let CODE: string;
let FREE_LINT_V2_INTERNAL_API_QUERY: string;
let PRO_LINT_V2_INTERNAL_API_QUERY: string;

// Handle combined TMDL source from Azure DevOps/GitHub Actions flow
const _TMDL_Databricks_DataFilePath = path.resolve('./test-files/Databricks_API.tmdl');
const _TMDL_Databricks_Data = fs.readFileSync(_TMDL_Databricks_DataFilePath, 'utf-8');


test.beforeAll(async () => {
    // Load environment variables from local.settings.json
    const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
    if (fs.existsSync(localSettingsPath)) {
        const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
        Object.entries(localSettings.Values).forEach(([key, value]) => {
            process.env[key] = value as string;
        });
    }

    // Initialize BASE_URL
	const testingConfig = getTestingConfig();
	const BASE_URL_PREFIX = testingConfig.baseUrlPrefix;
	FREE_LINT_V2_INTERNAL_API_QUERY = testingConfig.freeLintV2InternalAPIQQuery;
	PRO_LINT_V2_INTERNAL_API_QUERY = testingConfig.proLintV2InternalAPIQuery;
	CODE = testingConfig.code || '';
	BASE_URL = BASE_URL_PREFIX + '/api/lintCodeV2'; // Use lintCodeV2 endpoint
});

test.describe('lintCodeV2 API Tests', () => {
    test('should return 200 for valid LintRequest payload', async ({ request }) => {
        const lintRequest: LintRequest = {
            code: `let\n    Source = Sql.Database(\"azure-sql-db-jk.database.windows.net\", \"escape-room\", [CreateNavigationProperties=false]),\n    dbo_PieData = Source{[Schema=\"dbo\",Item=\"PieData\"]}[Data],\n    #\"---> Fix this so you DON\'T Break Query Folding\" = Table.TransformColumns(dbo_PieData ,{{\"SlicesRemainingAsPerc\",Number.From, Percentage.Type}})\nin\n    #\"---> Fix this so you DON\'T Break Query Folding\"`,
            rules: ["use-table-transform-columns-for-query-folding"],
            options: { severity: SeverityLevel.Error }
        };
        const response = await request.post(BASE_URL + "?code=" + CODE + PRO_LINT_V2_INTERNAL_API_QUERY, {
            headers: {
                'Content-Type': 'application/json',
            },
            data: JSON.stringify(lintRequest),
        });

        expect(response.status()).toBe(200);
        const responseBody = await response.json();
        expect(Array.isArray(responseBody)).toBe(true);
        responseBody.forEach((result: any) => {
            expect(result).toHaveProperty('ID');
            expect(result).toHaveProperty('Name');
            expect(result).toHaveProperty('Category');
            expect(result).toHaveProperty('Description');
            expect(result).toHaveProperty('Severity');
            expect(result).toHaveProperty('ErrorInformation');
        });
    });

    test('should return 400 for empty payload', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + PRO_LINT_V2_INTERNAL_API_QUERY, {
            headers: {
                'Content-Type': 'application/json',
            }
        });
        expect(response.status()).toBe(400);
    });

    test('should return 400 for empty payload with empty string', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + PRO_LINT_V2_INTERNAL_API_QUERY, {
            headers: {
                'Content-Type': 'application/json',
            },
            data: ''
        });
        expect(response.status()).toBe(400);
    });    

    test('should return 403 for missing subscription key', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE, {
            headers: {
                'Content-Type': 'application/json',
            },
            data: '{ bad json }', // Invalid JSON
        });
        expect(response.status()).toBe(403);
    });

    test('should return 403 for missing subscription id', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&subscription-key=abc123test", {
            headers: {
                'Content-Type': 'application/json',
            },
            data: '{ bad json }', // Invalid JSON
        });
        expect(response.status()).toBe(403);
    });	

    test('should return 403 for missing product id', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&subscription-key=abc123test&subscription-id=test-user", {
            headers: {
                'Content-Type': 'application/json',
            },
            data: '{ bad json }', // Invalid JSON
        });
        expect(response.status()).toBe(403);
    });		

    test('should return 400 for bad LintRequest payload', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + PRO_LINT_V2_INTERNAL_API_QUERY, {
            headers: {
                'Content-Type': 'application/json',
            },
            data: JSON.stringify({ bad: 1 }), // Invalid JSON
        });
        expect(response.status()).toBe(400);
    });

    test('should return 400 for LintRequest with empty code', async ({ request }) => {
        const lintRequest: LintRequest = { code: "" };
        const response = await request.post(BASE_URL + "?code=" + CODE + PRO_LINT_V2_INTERNAL_API_QUERY, {
            headers: {
                'Content-Type': 'application/json',
            },
            data: JSON.stringify(lintRequest),
        });
        expect(response.status()).toBe(400);
    });

    test('should return 200 for function LintRequest payload', async ({ request }) => {
        const lintRequest: LintRequest = { code: '(x) => x + 1' };
        const response = await request.post(BASE_URL + "?code=" + CODE + PRO_LINT_V2_INTERNAL_API_QUERY, {
            headers: {
                'Content-Type': 'application/json',
            },
            data: JSON.stringify(lintRequest),
        });
        expect(response.status()).toBe(200);
    });

    test('should return 200 for valid LintRequest payload using TMDL', async ({ request }) => {
        const lintRequest: LintRequest = {
            code: JSON.stringify(tmdlDefintionRequest),
            rules: [],
            options: { severity: SeverityLevel.Error, format: 'tmdl' }
        };
        const response = await request.post(BASE_URL + "?code=" + CODE + PRO_LINT_V2_INTERNAL_API_QUERY , {
            headers: {
                'Content-Type': 'application/json',
            },
            data: JSON.stringify(lintRequest),
        });

        expect(response.status()).toBe(200);
        const responseBody = await response.json();
        expect(Array.isArray(responseBody)).toBe(true);
        responseBody.forEach((result: any) => {
            expect(result).toHaveProperty('ID');
            expect(result).toHaveProperty('Name');
            expect(result).toHaveProperty('Category');
            expect(result).toHaveProperty('Description');
            expect(result).toHaveProperty('Severity');
            expect(result).toHaveProperty('ErrorInformation');
        });
    });    

    test('should return 200 for function LintRequest payload under free account', async ({ request }) => {
        const lintRequest: LintRequest = { code: incrementalIssuePQ };
        const response = await request.post(BASE_URL + "?code=" + CODE + FREE_LINT_V2_INTERNAL_API_QUERY, {
            headers: {
                'Content-Type': 'application/json',
            },
            data: JSON.stringify(lintRequest),
        });
        expect(response.status()).toBe(200);
        const responseBody = await response.json();
        expect(Array.isArray(responseBody)).toBe(true);
        expect(responseBody.length).toBe(0); // Expecting no linting issues for free account
    });

    test('should return 200 for valid TMDL Databricks payload and contain specific rule ID', async ({ request }) => {
        const lintRequest: LintRequest = {
            code: _TMDL_Databricks_Data,
            options: { format: 'tmdl', severity: SeverityLevel.Info }
        };

        const response = await request.post(BASE_URL + "?code=" + CODE + PRO_LINT_V2_INTERNAL_API_QUERY, {
            headers: {
                'Content-Type': 'application/json',
            },
            data: JSON.stringify(lintRequest),
        });

        // Validate response status
        expect(response.status()).toBe(200);

        // Validate response body
        const responseBody = await response.json();
        console.log("Databricks Response Body:", responseBody);
        expect(Array.isArray(responseBody)).toBe(true);
        expect(responseBody.length).toBeGreaterThan(0);
        
        // Check that at least one result has the specific rule ID
        const hasTargetRule = responseBody.some((result: any) => 
            result.ID === 'use-dual-mode-with-dimension-table-databricks'
        );
        expect(hasTargetRule).toBe(true);
        
        responseBody.forEach((result: any) => {
            expect(result).toHaveProperty('ID');
            expect(result).toHaveProperty('Name');
            expect(result).toHaveProperty('Category');
            expect(result).toHaveProperty('Description');
            expect(result).toHaveProperty('Severity');
            expect(result).toHaveProperty('ErrorInformation');
        }); // end forEach validation
    }); // end Databricks test
}); // end describe

const incrementalIssuePQ = `let
    Source = Upstream,

    // Filters rows by created date to keep records in the specified range
    #"Filtered Rows By Created Date Range" = Table.SelectRows(Source, each [Created] >= RangeStart and RangeEnd >= [Created])

    in #"Filtered Rows By Created Date Range"`

const tmdlDefintionRequest = `table Uses_API_Version_15
	lineageTag: 1c8eff3a-5bd3-4c79-a6d7-9cee52b97be4

	column FileSystemObjectType
		dataType: string
		lineageTag: e2b03eae-6722-4755-a3ba-6b77cb146d5c
		summarizeBy: none
		sourceColumn: FileSystemObjectType

		annotation SummarizationSetBy = Automatic

	column Id
		dataType: string
		lineageTag: 406a080c-f855-41a5-8505-24eb59f41538
		summarizeBy: none
		sourceColumn: Id

		annotation SummarizationSetBy = Automatic

	column ServerRedirectedEmbedUri
		dataType: string
		lineageTag: 9349c779-c486-4319-9781-c50f7de4c12c
		summarizeBy: none
		sourceColumn: ServerRedirectedEmbedUri

		annotation SummarizationSetBy = Automatic

	column ServerRedirectedEmbedUrl
		dataType: string
		lineageTag: 498f62a5-c7ec-44c3-9c77-0ea7095fb584
		summarizeBy: none
		sourceColumn: ServerRedirectedEmbedUrl

		annotation SummarizationSetBy = Automatic

	column ContentTypeId
		dataType: string
		lineageTag: f1c0a0d0-f817-40bc-b2be-7b3190274683
		summarizeBy: none
		sourceColumn: ContentTypeId

		annotation SummarizationSetBy = Automatic

	column Title
		dataType: string
		lineageTag: 00c91371-b444-48ef-8374-092b9e9978e0
		summarizeBy: none
		sourceColumn: Title

		annotation SummarizationSetBy = Automatic

	column ComplianceAssetId
		dataType: string
		lineageTag: f8defa06-2d14-4e25-b23d-1ea2c0c973f2
		summarizeBy: none
		sourceColumn: ComplianceAssetId

		annotation SummarizationSetBy = Automatic

	column Name
		dataType: string
		lineageTag: 9880fcef-a5f7-4401-9190-a40871ea09c4
		summarizeBy: none
		sourceColumn: Name

		annotation SummarizationSetBy = Automatic

	column EMail
		dataType: string
		lineageTag: 1dd8b8d4-6a87-4813-af16-1be6f25239b2
		summarizeBy: none
		sourceColumn: EMail

		annotation SummarizationSetBy = Automatic

	column OtherMail
		dataType: string
		lineageTag: be144b81-2609-4825-a1d2-8da9c6582b97
		summarizeBy: none
		sourceColumn: OtherMail

		annotation SummarizationSetBy = Automatic

	column UserExpiration
		dataType: string
		lineageTag: bc5c3e2c-5171-46d7-b779-32eb4dc531ba
		summarizeBy: none
		sourceColumn: UserExpiration

		annotation SummarizationSetBy = Automatic

	column UserLastDeletionTime
		dataType: string
		lineageTag: 75f598cc-6307-4f82-88d5-9b89807984e2
		summarizeBy: none
		sourceColumn: UserLastDeletionTime

		annotation SummarizationSetBy = Automatic

	column MobilePhone
		dataType: string
		lineageTag: cd6bdf97-7a23-4a52-85f0-f302b834a1c1
		summarizeBy: none
		sourceColumn: MobilePhone

		annotation SummarizationSetBy = Automatic

	column Notes
		dataType: string
		lineageTag: c89be873-e3e2-4eb3-a5d1-92e95a96616c
		summarizeBy: none
		sourceColumn: Notes

		annotation SummarizationSetBy = Automatic

	column SipAddress
		dataType: string
		lineageTag: 5610cc75-b47e-4f4e-b03b-9d4a602ef20c
		summarizeBy: none
		sourceColumn: SipAddress

		annotation SummarizationSetBy = Automatic

	column IsSiteAdmin
		dataType: string
		lineageTag: 6f755886-f8d0-4723-ace4-2be0635f0800
		summarizeBy: none
		sourceColumn: IsSiteAdmin

		annotation SummarizationSetBy = Automatic

	column Deleted
		dataType: string
		lineageTag: afc8f4f1-a470-4c5f-b4a4-fb3f72850f62
		summarizeBy: none
		sourceColumn: Deleted

		annotation SummarizationSetBy = Automatic

	column UserInfoHidden
		dataType: string
		lineageTag: db71c05c-0530-435f-b2db-cc44352d2690
		summarizeBy: none
		sourceColumn: UserInfoHidden

		annotation SummarizationSetBy = Automatic

	column Picture
		dataType: string
		lineageTag: c8e69eac-b3f6-4e0b-8401-b09eecf6de05
		summarizeBy: none
		sourceColumn: Picture

		annotation SummarizationSetBy = Automatic

	column Department
		dataType: string
		lineageTag: 7950ccac-09c8-45ad-b7a6-c97adbe6101d
		summarizeBy: none
		sourceColumn: Department

		annotation SummarizationSetBy = Automatic

	column JobTitle
		dataType: string
		lineageTag: f6569f93-454f-4b7e-9095-1b9270887363
		summarizeBy: none
		sourceColumn: JobTitle

		annotation SummarizationSetBy = Automatic

	column FirstName
		dataType: string
		lineageTag: d418e10a-f18a-47b3-af8c-cc901a839b1c
		summarizeBy: none
		sourceColumn: FirstName

		annotation SummarizationSetBy = Automatic

	column LastName
		dataType: string
		lineageTag: 55e5bf76-a346-457d-9164-287285adc766
		summarizeBy: none
		sourceColumn: LastName

		annotation SummarizationSetBy = Automatic

	column WorkPhone
		dataType: string
		lineageTag: 06137fdc-49e2-4353-8765-9153a2400e1e
		summarizeBy: none
		sourceColumn: WorkPhone

		annotation SummarizationSetBy = Automatic

	column UserName
		dataType: string
		lineageTag: 7fd65714-c500-46b6-9ba4-893c0a00e2a7
		summarizeBy: none
		sourceColumn: UserName

		annotation SummarizationSetBy = Automatic

	column WebSite
		dataType: string
		lineageTag: 99b78b6f-29e4-4a25-aa62-f60fe0855b93
		summarizeBy: none
		sourceColumn: WebSite

		annotation SummarizationSetBy = Automatic

	column SPSResponsibility
		dataType: string
		lineageTag: f0422979-7ef1-44ef-9cb2-9346969cbe93
		summarizeBy: none
		sourceColumn: SPSResponsibility

		annotation SummarizationSetBy = Automatic

	column Office
		dataType: string
		lineageTag: 0856de46-223c-4a74-aca3-a68e7c0e047f
		summarizeBy: none
		sourceColumn: Office

		annotation SummarizationSetBy = Automatic

	column SPSPictureTimestamp
		dataType: string
		lineageTag: 1eaff5c9-87bd-4e8d-b667-037d4a95dbaf
		summarizeBy: none
		sourceColumn: SPSPictureTimestamp

		annotation SummarizationSetBy = Automatic

	column SPSPicturePlaceholderState
		dataType: string
		lineageTag: 7b6f807e-7d78-4325-be9f-27b342e4c3fb
		summarizeBy: none
		sourceColumn: SPSPicturePlaceholderState

		annotation SummarizationSetBy = Automatic

	column SPSPictureExchangeSyncState
		dataType: string
		lineageTag: 4c803918-4772-4f40-a642-f2380c989b80
		summarizeBy: none
		sourceColumn: SPSPictureExchangeSyncState

		annotation SummarizationSetBy = Automatic

	column OData__ColorTag
		dataType: string
		lineageTag: 8c7c2f97-4c4e-4c2a-9cb5-ed12f93e9253
		summarizeBy: none
		sourceColumn: OData__ColorTag

		annotation SummarizationSetBy = Automatic

	column 'ID 2'
		dataType: string
		lineageTag: da06f982-08e3-4ca8-ac1e-f6f190eea2b7
		summarizeBy: none
		sourceColumn: ID

		annotation SummarizationSetBy = Automatic

	column Modified
		dataType: string
		lineageTag: bbf0f7b8-f9af-4398-b76e-363c79b18656
		summarizeBy: none
		sourceColumn: Modified

		annotation SummarizationSetBy = Automatic

	column Created
		dataType: string
		lineageTag: c3e60fb0-8372-4e69-9015-07c7575dbc60
		summarizeBy: none
		sourceColumn: Created

		annotation SummarizationSetBy = Automatic

	column AuthorId
		dataType: string
		lineageTag: 8e061f5c-9337-45df-9498-9dbf9ac792db
		summarizeBy: none
		sourceColumn: AuthorId

		annotation SummarizationSetBy = Automatic

	column EditorId
		dataType: string
		lineageTag: 610f4db9-3915-4117-ab08-76e293f021fd
		summarizeBy: none
		sourceColumn: EditorId

		annotation SummarizationSetBy = Automatic

	column OData__UIVersionString
		dataType: string
		lineageTag: 81b63774-6eb9-4610-92e0-6ae5290c636e
		summarizeBy: none
		sourceColumn: OData__UIVersionString

		annotation SummarizationSetBy = Automatic

	column Attachments
		dataType: string
		lineageTag: 72c7f8e6-6903-4487-8b25-9854aecec38d
		summarizeBy: none
		sourceColumn: Attachments

		annotation SummarizationSetBy = Automatic

	column GUID
		dataType: string
		lineageTag: cc8d8ca8-414d-49a4-b43d-71fba775d806
		summarizeBy: none
		sourceColumn: GUID

		annotation SummarizationSetBy = Automatic

	partition Uses_API_Version_15 = m
		mode: import
		source =
				let
				    Source = SharePoint.Tables("https://kerski.sharepoint.com", [ApiVersion=15]),
				    #"374f6408-6353-48ef-80f2-3115cd7d16e0" = Source{[Id="374f6408-6353-48ef-80f2-3115cd7d16e0"]}[Items]
				in
				    #"374f6408-6353-48ef-80f2-3115cd7d16e0"

	annotation PBI_NavigationStepName = Navigation

	annotation PBI_ResultType = Table

`;