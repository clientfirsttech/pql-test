import { test, expect } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import { getTestingConfig } from './get-testing-config';
import { formatEmailForSubscription} from 'src/helpers/format-subscription-ids';

// Declare variables at a higher scope
let BASE_URL: string;
let CODE: string;
let testTimestamp: string; // <-- Ensure this is declared at the top scope

test.beforeAll(async () => {
    // Load environment variables from local.settings.json
    const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
    if (fs.existsSync(localSettingsPath)) {
        const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
        Object.entries(localSettings.Values).forEach(([key, value]) => {
            process.env[key] = value as string;
        });
    }

    // Generate unique stripe-id with timestamp
    const now = new Date();
    testTimestamp = now.getFullYear().toString() +
                        (now.getMonth() + 1).toString().padStart(2, '0') +
                        now.getDate().toString().padStart(2, '0') +
                        now.getHours().toString().padStart(2, '0') +
                        now.getMinutes().toString().padStart(2, '0') +
                        now.getSeconds().toString().padStart(2, '0');    

    // Initialize BASE_URL
    const testingConfig = getTestingConfig();
    const BASE_URL_PREFIX = testingConfig.baseUrlPrefix;
    CODE = testingConfig.code || '';
    BASE_URL = BASE_URL_PREFIX + '/api/createAPISubscription';
});

test.describe('createAPISubscription API Tests', () => {
    test('should return 200 for valid request with new subscription for paid account', async ({ request }) => {

        const uniquesubscriptionId = `new-test-user-dev-${testTimestamp}`;

        const response = await request.post(BASE_URL + "?code=" + CODE + `&stripe-id=${uniquesubscriptionId}&email=test@example.com`, {
            headers: {
                'Content-Type': 'application/json',
            }
        });

        // Validate response status
        expect(response.status()).toBe(200);

        // Validate response body
        const responseBody = await response.json();
        console.log("Response Body:", responseBody);
        expect(responseBody).toHaveProperty('subscriptionId');
        expect(responseBody).toHaveProperty('subscriptionKey');
        expect(responseBody.subscriptionId).toBe(uniquesubscriptionId);
        expect(typeof responseBody.subscriptionKey).toBe('string');
    });

    test('should return 200 for existing subscription for paid account', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&stripe-id=test-user-dev&email=test@example.com", {
            headers: {
                'Content-Type': 'application/json',
            }
        });

        // Validate response status
        expect(response.status()).toBe(200);

        // Validate response body
        const responseBody = await response.json();
        console.log("Response Body:", responseBody);
        expect(responseBody).toHaveProperty('subscriptionId');
        expect(responseBody).toHaveProperty('subscriptionKey');
    });

    test('should return 200 for valid request with new subscription for free account', async ({ request }) => {

        const uniquesubscriptionId = `test-free-${testTimestamp}@example.com`;

        const response = await request.post(BASE_URL + "?code=" + CODE + `&email=${uniquesubscriptionId}`, {
            headers: {
                'Content-Type': 'application/json',
            }
        });

        // Validate response status
        expect(response.status()).toBe(200);

        // Validate response body
        const responseBody = await response.json();
        console.log("Response Body:", responseBody);
        expect(responseBody).toHaveProperty('subscriptionId');
        expect(responseBody).toHaveProperty('subscriptionKey');
        expect(responseBody.subscriptionId).toBe(formatEmailForSubscription(uniquesubscriptionId));
        expect(typeof responseBody.subscriptionKey).toBe('string');
    });

    test('should return 200 for existing subscription for free account', async ({ request }) => {

        const uniquesubscriptionId = `test-free-${testTimestamp}@example.com`;

        const response = await request.post(BASE_URL + "?code=" + CODE + `&email=${uniquesubscriptionId}`, {
            headers: {
                'Content-Type': 'application/json',
            }
        });

        // Validate response status
        expect(response.status()).toBe(200);

        // Validate response body
        const responseBody = await response.json();
        console.log("Response Body:", responseBody);
        expect(responseBody).toHaveProperty('subscriptionId');
        expect(responseBody).toHaveProperty('subscriptionKey');
    });    

    test('should return 400 for missing email', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&stripe-id=test-user-dev", {
            headers: {
                'Content-Type': 'application/json',
            }
        });

        // Validate response status
        expect(response.status()).toBe(400);
    });
});
