import { test, expect } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import { getTestingConfig } from './get-testing-config';
import { RuleResult } from 'src/lint/rule-types';
import { lintTMDLCode } from 'src/lint/linter-module';
import { allPQRules } from 'src/lint/all-rules';

// Declare variables at a higher scope
let BASE_URL: string;
let PRO_CODE: string;

test.beforeAll(async () => {
    // Load environment variables from local.settings.json
    const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
    if (fs.existsSync(localSettingsPath)) {
        const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
        Object.entries(localSettings.Values).forEach(([key, value]) => {
            process.env[key] = value as string;
        });
    }

    // Initialize BASE_URL
    const testingConfig = getTestingConfig();
    const BASE_URL_PREFIX = testingConfig.baseUrlPrefix;
    PRO_CODE = testingConfig.code || "";
    BASE_URL = BASE_URL_PREFIX + '/api/fixTMDLStreaming';
});

const sampleTMDLCode = `createOrReplace

	table SQLServer_NativeQuery_Folding_Fail
		lineageTag: 250e5031-f8df-4f24-9109-a7c75afe8af4

		column Field
			dataType: string
			lineageTag: 6c8d8ae8-80ab-498d-8a4b-26279201ac45
			summarizeBy: none
			sourceColumn: Field

		column Value
			dataType: dateTime
			lineageTag: 2887c593-b7bc-45f5-b9db-556fc60f6da4
			summarizeBy: none
			sourceColumn: Value

		partition SQLServer_NativeQuery_Folding_Fail = m
			mode: import
			source =
					let
					    Source = Sql.Database("server", "database", [Query="SELECT * FROM Table"])
					in
					    Source`;

test.describe('fixTMDLStreaming API Tests', () => {
    test('should return SSE streamed TMDL fixes', async ({ request }) => {
        const mockRuleResults: RuleResult[] = await lintTMDLCode(sampleTMDLCode, allPQRules,[],[],false);

        const response = await request.fetch(BASE_URL + `?code=${PRO_CODE}&mode=pro`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            data: JSON.stringify({
                code: sampleTMDLCode,
                rulesResults: mockRuleResults
            }),
            timeout: 180000, // 3 minute timeout for streaming
        });

        expect(response.status()).toBe(200);
        
        // Verify SSE streaming headers
        expect(response.headers()['content-type']).toBe('text/event-stream');

        // NOTE: Playwright buffers the entire response, so we can't test true streaming
        // We can only verify the final result contains SSE formatted messages
        const buffer = await response.body();
        const finalContent = buffer.toString('utf8');

        // Verify we received SSE formatted content
        expect(finalContent).toBeTruthy();
        expect(finalContent.length).toBeGreaterThan(0);
        
        // Should contain SSE formatting
        expect(finalContent).toContain('data: ');
        expect(finalContent).toContain('[DONE]');
        expect(finalContent).toContain('"type":"delta"');
        expect(finalContent).toContain('"type":"final"');
        
        // Extract final TMDL from last SSE message
        const lines = finalContent.split('\n');
        const dataLines = lines.filter(line => line.startsWith('data: ') && !line.includes('[DONE]'));
        expect(dataLines.length).toBeGreaterThan(0);
        
        // Parse final message to verify TMDL content
        const lastDataLine = dataLines[dataLines.length - 1];
        const finalMessage = JSON.parse(lastDataLine.substring(6)); // Remove 'data: '
        expect(finalMessage.type).toBe('final');
        expect(finalMessage.content).toContain('createOrReplace');
        expect(finalMessage.content).toMatch(/table\s+\w+/);
        expect(finalMessage.content).toMatch(/partition\s+\w+/);

        console.log(`✓ Received SSE formatted response with ${dataLines.length} data messages`);
    });

    test('should handle request with no active rules', async ({ request }) => {
        const mockRuleResults = [
            {
                ID: 'inactive-rule',
                Name: 'Inactive Rule',
                Category: 'Test',
                Description: 'Test description',
                Passed: false,
                References: [],
                Severity: 2,
                ErrorInformation: {
                    errorLocation: {
                        positionStart: { codeUnit: 0, lineCodeUnit: 0, lineNumber: 1 },
                        positionEnd: { codeUnit: 0, lineCodeUnit: 0, lineNumber: 1 }
                    },
                    filePath: null
                },
                AIFixInstructions: {
                    Description: "Test fix",
                    IsActive: false
                }
            }
        ];

        const response = await request.fetch(BASE_URL + `?code=${PRO_CODE}&mode=pro`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            data: JSON.stringify({
                code: sampleTMDLCode,
                rulesResults: mockRuleResults
            })
        });

        expect(response.status()).toBe(200);
        expect(response.headers()['content-type']).toBe('text/event-stream');

        const buffer = await response.body();
        const finalContent = buffer.toString('utf8');

        // Should return original TMDL code in SSE format (no active rules to fix)
        expect(finalContent).toBeTruthy();
        expect(finalContent.length).toBeGreaterThan(0);
        
        // Should contain SSE formatting
        expect(finalContent).toContain('data: ');
        expect(finalContent).toContain('[DONE]');
        expect(finalContent).toContain('"type":"final"');
        
        // Extract final TMDL from SSE message
        const lines = finalContent.split('\n');
        const dataLines = lines.filter(line => line.startsWith('data: ') && !line.includes('[DONE]'));
        const lastDataLine = dataLines[dataLines.length - 1];
        const finalMessage = JSON.parse(lastDataLine.substring(6));
        
        expect(finalMessage.content).toContain('createOrReplace');
        expect(finalMessage.content).toContain('Sql.Database');
        
        console.log(`No active rules test: Received SSE formatted response`);
    });

    test('should return 401 for non-pro mode', async ({ request }) => {
        const response = await request.post(BASE_URL + `?code=${PRO_CODE}&mode=free`, {
            headers: { 'Content-Type': 'application/json' },
            data: JSON.stringify({
                code: sampleTMDLCode,
                rulesResults: []
            })
        });

        expect(response.status()).toBe(401);
        const body = await response.text();
        expect(body).toBe('Not Authorized');
    });

    test('should return 400 for empty TMDL code', async ({ request }) => {
        const response = await request.post(BASE_URL + `?code=${PRO_CODE}&mode=pro`, {
            headers: { 'Content-Type': 'application/json' },
            data: JSON.stringify({
                code: '',
                rulesResults: []
            })
        });

        expect(response.status()).toBe(400);
        const body = await response.text();
        expect(body).toBe('Bad Request: TMDL Code payload is required');
    });

    test('should return 400 for invalid TMDL code', async ({ request }) => {
        const response = await request.post(BASE_URL + `?code=${PRO_CODE}&mode=pro`, {
            headers: { 'Content-Type': 'application/json' },
            data: JSON.stringify({
                code: 'invalid tmdl code',
                rulesResults: []
            })
        });

        expect(response.status()).toBe(400);
        const body = await response.text();
        expect(body).toBe('Bad Request: TMDL Code could not be parsed or contains no M code.');
    });

    test('should return 404 for non-POST requests', async ({ request }) => {
        console.log("Testing GET request to", BASE_URL + `?code=${PRO_CODE}&mode=pro`);
        const response = await request.get(BASE_URL + `?code=${PRO_CODE}&mode=pro`);

        expect(response.status()).toBe(404);
        const body = await response.text();
    });

    // Enhanced test to analyze delta chunk timing and distribution using native fetch
    test('should receive delta chunks with proper timing analysis', async ({ request }) => {
        const complexTMDL = `createOrReplace

	model Model
		table Sales
			partition Sales-Data = m
				mode: import
				source =
					let
					    Source = #"hardcoded-url-1-needs-fixing",
					    Source2 = #"hardcoded-url-2-needs-fixing", 
					    Source3 = #"hardcoded-url-3-needs-fixing",
					    TransformData = Table.TransformColumns(Source, {"Column1", each Text.Upper(_)}),
					    FilteredData = Table.SelectRows(TransformData, each [Column2] <> null),
					    FinalData = Table.AddColumn(FilteredData, "NewColumn", each "Test")
					in
					    FinalData`;

        const mockRuleResults: RuleResult[] = await lintTMDLCode(complexTMDL, allPQRules,[],[],false);

        // Use native fetch to get true streaming support
        const url = BASE_URL + `?code=${PRO_CODE}&mode=pro`;
        const fetchResponse = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                code: complexTMDL,
                rulesResults: mockRuleResults
            }),
        });

        expect(fetchResponse.status).toBe(200);
        expect(fetchResponse.headers.get('content-type')).toContain('text/event-stream');
        
        const body = fetchResponse.body!;
        const reader = body.getReader();
        const decoder = new TextDecoder();

        const deltaMessages: Array<{content: string, timestamp: number, chunkIndex: number}> = [];
        const allChunks: Array<{content: string, timestamp: number, size: number}> = [];
        let buffer = '';
        const startTime = Date.now();
        let firstDeltaTime: number | null = null;
        let lastDeltaTime: number | null = null;
        let hasStatusMessage = false;
        let hasFinalMessage = false;
        let hasCompletion = false;
        let chunkIndex = 0;

        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                const chunk = decoder.decode(value, { stream: true });
                const timestamp = Date.now() - startTime;
                chunkIndex++;
                
                allChunks.push({
                    content: chunk,
                    timestamp,
                    size: chunk.length
                });
                
                console.log(`Chunk ${chunkIndex} at ${timestamp}ms (${chunk.length} bytes)`);
                buffer += chunk;

                // Parse complete SSE messages from buffer
                const lines = buffer.split('\n');
                buffer = lines.pop() || ''; // Keep incomplete line in buffer

                for (const line of lines) {
                    if (line.startsWith('data: ') && !line.includes('[DONE]')) {
                        try {
                            const data = JSON.parse(line.substring(6));
                            if (data.type === 'status') {
                                hasStatusMessage = true;
                                console.log(`  Status at ${timestamp}ms: ${data.message}`);
                            } else if (data.type === 'delta' && data.content) {
                                deltaMessages.push({
                                    content: data.content,
                                    timestamp,
                                    chunkIndex
                                });
                                if (firstDeltaTime === null) firstDeltaTime = timestamp;
                                lastDeltaTime = timestamp;
                                console.log(`  Delta ${deltaMessages.length} at ${timestamp}ms: "${data.content.substring(0, 30)}..."`);
                            } else if (data.type === 'final') {
                                hasFinalMessage = true;
                                console.log(`  Final message at ${timestamp}ms (${data.content?.length || 0} chars)`);
                            }
                        } catch (e) {
                            // Skip malformed JSON
                        }
                    }
                    if (line.includes('[DONE]')) {
                        hasCompletion = true;
                        console.log(`  Stream completed at ${timestamp}ms`);
                        break;
                    }
                }
            }
        } finally {
            reader.releaseLock();
        }

        // Enhanced validations and analysis
        console.log(`\n=== Streaming Analysis ===`);
        console.log(`Total network chunks: ${allChunks.length}`);
        console.log(`Total delta messages: ${deltaMessages.length}`);
        console.log(`First delta at: ${firstDeltaTime}ms`);
        console.log(`Last delta at: ${lastDeltaTime}ms`);
        console.log(`Streaming duration: ${(lastDeltaTime || 0) - (firstDeltaTime || 0)}ms`);

        // Verify we received delta messages
        expect(deltaMessages.length).toBeGreaterThan(0); // Expect at least 1 delta chunk
        
        // Verify timing spread - deltas should arrive over time for true streaming
        if (firstDeltaTime !== null && lastDeltaTime !== null && deltaMessages.length > 1) {
            const streamingDuration = lastDeltaTime - firstDeltaTime;
            console.log(`Delta spread: ${streamingDuration}ms`);
            
            // For true streaming, expect some time between first and last delta
            expect(streamingDuration).toBeGreaterThan(0); // At least some time difference
        }

        // Verify delta content is substantial and incremental
        const combinedDeltaContent = deltaMessages.map(d => d.content).join('');
        expect(combinedDeltaContent.length).toBeGreaterThan(50); // Substantial content streamed
        console.log(`Combined delta content: ${combinedDeltaContent.length} characters`);

        // Analyze chunk distribution
        const chunkSizes = allChunks.map(c => c.size);
        const avgChunkSize = chunkSizes.reduce((a, b) => a + b, 0) / chunkSizes.length;
        console.log(`Chunk sizes: ${chunkSizes.join(', ')}`);
        console.log(`Average chunk size: ${avgChunkSize.toFixed(1)} bytes`);

        // Verify completion
        expect(hasCompletion).toBeTruthy();
        expect(hasStatusMessage || deltaMessages.length > 0 || hasFinalMessage).toBeTruthy();

        console.log('=== Analysis Complete ===\n');
    }, 180000); // 3 minute timeout
});
