import { test, expect } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import { getTestingConfig } from './get-testing-config';
import { formatEmailForSubscription } from 'src/helpers/format-subscription-ids';

// Declare variables at a higher scope
let BASE_URL: string;
let CODE: string;
let FREE_USER_EXISTING: string;

test.beforeAll(async () => {
    // Load environment variables from local.settings.json
    const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
    if (fs.existsSync(localSettingsPath)) {
        const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
        Object.entries(localSettings.Values).forEach(([key, value]) => {
            process.env[key] = value as string;
        });
    }

    // Initialize BASE_URL
    const testingConfig = getTestingConfig();
    const BASE_URL_PREFIX = testingConfig.baseUrlPrefix;
    CODE = testingConfig.code || '';
    BASE_URL = BASE_URL_PREFIX + '/api/renewAPISubscription';
    FREE_USER_EXISTING = testingConfig.getSubscriptionFreeUser;
});

test.describe('renewAPISubscription API Tests', () => {
    test('should return 200 for valid renewal request', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&stripe-id=test-user-dev&email=test@example.com", {
            headers: {
                'Content-Type': 'application/json',
            }
        });

        // Validate response status
        expect(response.status()).toBe(200);

        // Validate response body
        const responseBody = await response.json();
        console.log("Response Body:", responseBody);
        expect(responseBody).toHaveProperty('subscriptionId');
        expect(responseBody).toHaveProperty('subscriptionKey');
        expect(responseBody.subscriptionId).toBe('test-user-dev');
        expect(typeof responseBody.subscriptionKey).toBe('string');
    });

    test('should return 200 for valid renewal request (free account)', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&email=" + FREE_USER_EXISTING, {
            headers: {
                'Content-Type': 'application/json',
            }
        });

        // Validate response status
        expect(response.status()).toBe(200);

        // Validate response body
        const responseBody = await response.json();
        console.log("Response Body:", responseBody);
        expect(responseBody).toHaveProperty('subscriptionId');
        expect(responseBody).toHaveProperty('subscriptionKey');
        expect(responseBody.subscriptionId).toBe(formatEmailForSubscription(FREE_USER_EXISTING));
        expect(typeof responseBody.subscriptionKey).toBe('string');
    });

    test('should return 404 for non-existent subscription', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&stripe-id=non-existent-user&email=test@example.com", {
            headers: {
                'Content-Type': 'application/json',
            }
        });

        // Validate response status
        expect(response.status()).toBe(404);
    });

    test('should return 404 for inactive subscription', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&stripe-id=disabled-account-test-user&email=test@example.com", {
            headers: {
                'Content-Type': 'application/json',
            }
        });

        // Validate response status
        expect(response.status()).toBe(404);
    });

    test('should return 400 for missing email', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&stripe-id=test-user-dev", {
            headers: {
                'Content-Type': 'application/json',
            }
        });

        // Validate response status
        expect(response.status()).toBe(400);
    });
});
