import { test, expect } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import { LintRequest } from 'src/helpers/http-request-types';
import { SeverityLevel } from 'src/lint/rule-types';
import { getTestingConfig } from './get-testing-config';

// Declare variables at a higher scope
let BASE_URL: string;
let CODE: string;

test.beforeAll(async () => {
    // Load environment variables from local.settings.json
    const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
    if (fs.existsSync(localSettingsPath)) {
        const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
        Object.entries(localSettings.Values).forEach(([key, value]) => {
            process.env[key] = value as string;
        });
    }

    // Initialize BASE_URL
    const testingConfig = getTestingConfig();
    const BASE_URL_PREFIX = testingConfig.apiBaseUrlPrefix;
    CODE = testingConfig.apiCode;
    BASE_URL = BASE_URL_PREFIX + '/lint/rules'; // Use lintCodeV2 endpoint
});

test.describe('lintRules API Tests', () => {
    test('should return 200 for valid lint rules', async ({ request }) => {
        console.log(BASE_URL + "?subscription-key=" + CODE)
        const response = await request.get(BASE_URL + "?subscription-key=" + CODE, {
            headers: {
                'Content-Type': 'application/json',
            }
        });
        expect(response.status()).toBe(200);
        const responseBody = await response.json();
        expect(Array.isArray(responseBody)).toBe(true);
        console.log(responseBody);
        responseBody.forEach((result: any) => {
            expect(result).toHaveProperty('ID');
            expect(result).toHaveProperty('Name');
            expect(result).toHaveProperty('Category');
            expect(result).toHaveProperty('Description');
            expect(result).toHaveProperty('Severity');
            expect(result).toHaveProperty('AIFixInstructions');
            expect(result.AIFixInstructions).toHaveProperty('Description');
            expect(result.AIFixInstructions).toHaveProperty('Prompt');
            expect(result.AIFixInstructions).toHaveProperty('IsWholeQueryFix');
            expect(result.AIFixInstructions).toHaveProperty('IsActive');
        });
    });

    test('should return 401 for missing subscription key', async ({ request }) => {
        const response = await request.get(BASE_URL, {
            headers: {
                'Content-Type': 'application/json',            },
        });
        expect(response.status()).toBe(401);
    });
});
