import { get } from "lodash";

// Helper function to get testing configuration based on environment
export function getTestingConfig() {
    const testingEnvironment = (process.env.TEST_ENVIRONMENT || "dev").toLowerCase();
    
    switch (testingEnvironment) {
        case "uat":
        case "test":
            return {
                baseUrlPrefix: process.env.UAT_TESTING_PREFIX|| "",
                apiBaseUrlPrefix: process.env.API_UAT_TESTING_PREFIX || "",
                apiMgmtInternalUrlPreifix: process.env.API_MANAGEMENT_UAT_INTERNAL_API_BASE_URL || "",
                apiMgmtInternalCode: process.env.API_MANAGEMENT_UAT_INTERNAL_API_CODE || "",
                code: process.env.UAT_TESTING_CODE || "",
                apiCode: process.env.API_UAT_TESTING_CODE || "",
                freeApiCode: process.env.API_UAT_FREE_TESTING_CODE || "",
                freeLintV2InternalAPIQQuery: "&subscription-key=abc123&subscription-id=free-user&product-id=free-api-uat",
                proLintV2InternalAPIQuery: "&subscription-key=abc123&subscription-id=pro-user&product-id=api-uat",
                getSubscriptionFreeUser: process.env.API_UAT_FREE_USER || ""                 
            };
        case "prod":
        case "production":
            return {
                baseUrlPrefix: process.env.PROD_TESTING_PREFIX|| "",
                apiBaseUrlPrefix: process.env.API_PROD_TESTING_PREFIX || "",
                apiMgmtInternalUrlPreifix: process.env.API_MANAGEMENT_PROD_INTERNAL_API_BASE_URL || "",
                apiMgmtInternalCode: process.env.API_MANAGEMENT_PROD_INTERNAL_API_CODE || "",
                code: process.env.PROD_TESTING_CODE || "",
                apiCode: process.env.API_PROD_TESTING_CODE || "",
                freeApiCode: process.env.API_PROD_FREE_TESTING_CODE || "",
                freeLintV2InternalAPIQQuery: "&subscription-key=abc123&subscription-id=free-user&product-id=free-api-prod",
                proLintV2InternalAPIQuery: "&subscription-key=abc123&subscription-id=pro-user&product-id=api-prod",
                getSubscriptionFreeUser: process.env.API_PROD_FREE_USER || ""                  
            };
        case "dev":
        case "development":
        default:
            return {
                baseUrlPrefix: process.env.DEV_TESTING_PREFIX || "",
                apiBaseUrlPrefix: process.env.API_DEV_TESTING_PREFIX || "",
                apiMgmtInternalUrlPreifix: process.env.API_MANAGEMENT_DEV_INTERNAL_API_BASE_URL || "",
                apiMgmtInternalCode: process.env.API_MANAGEMENT_DEV_INTERNAL_API_CODE || "",
                code: process.env.DEV_TESTING_CODE || "",
                apiCode: process.env.API_DEV_TESTING_CODE || "",
                freeApiCode: process.env.API_DEV_FREE_TESTING_CODE || "",
                freeLintV2InternalAPIQQuery: "&subscription-key=abc123&subscription-id=free-user&product-id=free-api-dev",
                proLintV2InternalAPIQuery: "&subscription-key=abc123&subscription-id=pro-user&product-id=api-dev",
                getSubscriptionFreeUser: process.env.API_DEV_FREE_USER || ""
            };
    }
}