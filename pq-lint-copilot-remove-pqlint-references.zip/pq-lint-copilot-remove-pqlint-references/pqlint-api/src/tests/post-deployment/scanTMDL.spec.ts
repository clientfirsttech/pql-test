import { test, expect } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import { tmdlCodeSample1 } from "../hardcoded-tmdl";
import { getTestingConfig } from './get-testing-config';

// Declare variables at a higher scope
let BASE_URL: string;
let CODE: string;

const _TMDL_With_Several_Web_Contents_Executes_DataFilePath = path.resolve('./test-files/scan_tmdl/WebContents.tmdl');
const fileContent = fs.readFileSync(_TMDL_With_Several_Web_Contents_Executes_DataFilePath, 'utf-8');

test.beforeAll(async () => {
    // Load environment variables from local.settings.json
    const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
    if (fs.existsSync(localSettingsPath)) {
        const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
        Object.entries(localSettings.Values).forEach(([key, value]) => {
            process.env[key] = value as string;
        });
    }

    // Initialize BASE_URL
    const testingConfig = getTestingConfig();
    const BASE_URL_PREFIX = testingConfig.baseUrlPrefix;
    CODE = testingConfig.code || '';
    BASE_URL = BASE_URL_PREFIX + '/api/scanTMDL'; // Replace with your local function URL
});

test.describe('scanTMDL API Tests', () => {
    test('should return 200 for valid TMDL code payload', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&mode=pro", {
            headers: {
                'Content-Type': 'text/plain',
            },
            data: fileContent,
        });

        // Validate response status
        expect(response.status()).toBe(200);

        // Validate response body
        const responseBody = await response.json();
        console.log("Response Body:", responseBody);
        expect(Array.isArray(responseBody)).toBe(true);
        responseBody.forEach((result: any) => {
            expect(result).toHaveProperty('ID');
            expect(result).toHaveProperty('Name');
            expect(result).toHaveProperty('Category');
            expect(result).toHaveProperty('Description');
            expect(result).toHaveProperty('Severity');
            expect(result).toHaveProperty('ErrorInformation');
        });
    });

    test('should return 404 for get', async ({ request }) => {
        const response = await request.get(BASE_URL + "?code=" + CODE + "&mode=pro", {
            headers: {
                'Content-Type': 'text/plain',
            }
        });

        // Validate response status
        expect(response.status()).toBe(404);
    });   
});