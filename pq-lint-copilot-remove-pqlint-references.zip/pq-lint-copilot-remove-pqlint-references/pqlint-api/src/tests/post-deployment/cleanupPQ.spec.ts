import { test, expect } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import { getTestingConfig } from './get-testing-config';

// Declare variables at a higher scope for use in all tests
let BASE_URL: string;
let CODE: string;

// Load environment variables and set up the base URL before all tests run
test.beforeAll(async () => {
    // Load environment variables from local.settings.json if it exists
    const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
    if (fs.existsSync(localSettingsPath)) {
        const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
        Object.entries(localSettings.Values).forEach(([key, value]) => {
            process.env[key] = value as string;
        });
    }

    // Set BASE_URL and CODE from environment variables
    const testingConfig = getTestingConfig();
    const BASE_URL_PREFIX = testingConfig.baseUrlPrefix;
    CODE = testingConfig.code || '';
    BASE_URL = BASE_URL_PREFIX + '/api/cleanupPQ'; // API endpoint for cleanupPQ Azure Function
});

test.describe('cleanupPQ API Tests', () => {
    // Test that a non-pro mode request returns 401 Unauthorized
    test('should return 401 for non-pro mode', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&mode=free", {
            headers: {
                'Content-Type': 'text/plain',
            },
            data: `let x = 1 in x`,
        });

        expect(response.status()).toBe(401);
    });

    // Test that an empty payload in pro mode returns 400 Bad Request
    test('should return 400 for empty payload in pro mode', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&mode=pro", {
            headers: {
                'Content-Type': 'text/plain',
            },
            data: '', // Empty payload
        });

        expect(response.status()).toBe(400);
    });

    // Test that a valid pro request returns 202 and a jobId in the response
    test('should return 202 and jobId for valid pro request', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&mode=pro&email=test@example.com", {
            headers: {
                'Content-Type': 'text/plain',
            },
            data: `let x = 1 in x`,
        });
        const responseBody = await response.json();
        expect(response.status()).toBe(202);
        expect(responseBody).toHaveProperty('jobId');
        expect(responseBody).toHaveProperty('message');
        expect(responseBody.message).toMatch(/Job submitted successfully/i);
    });

    // Test that invalid Power Query code returns 500 Internal Server Error
    test('should return 400 for invalid Power Query code in pro mode', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&mode=pro", {
            headers: {
                'Content-Type': 'text/plain',
            },
            data: `let x = #bad in x`, // Invalid M code
        });

        expect(response.status()).toBe(400);

    });
});