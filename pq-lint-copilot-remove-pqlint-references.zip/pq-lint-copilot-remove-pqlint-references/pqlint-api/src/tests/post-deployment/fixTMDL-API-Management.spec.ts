import { test, expect } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import { getTestingConfig } from './get-testing-config';

// Declare variables at a higher scope for use in all tests
let BASE_URL: string;
let PRO_CODE: string;
let FREE_CODE: string;

// Load environment variables and set up the base URL before all tests run
test.beforeAll(async () => {
    // Load environment variables from local.settings.json if it exists
    const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
    if (fs.existsSync(localSettingsPath)) {
        const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
        Object.entries(localSettings.Values).forEach(([key, value]) => {
            process.env[key] = value as string;
        });
    }

    // Initialize BASE_URL
    const testingConfig = getTestingConfig();
    const BASE_URL_PREFIX = testingConfig.apiMgmtInternalUrlPreifix
    PRO_CODE = testingConfig.apiMgmtInternalCode;
    FREE_CODE = testingConfig.freeApiCode;
    BASE_URL = BASE_URL_PREFIX + '/fixTMDLStreaming';
});

test.describe('fixTMDLStreaming API Tests', () => {
    // Test that a non-pro mode request returns 401 Unauthorized (Free mode specifically)
    test('should return 401 for free mode', async ({ request }) => {
        const tmdlPayload = {
            code: `createOrReplace

	model Model
		table Sales
			partition Sales-Data = m
				mode: import
				source =
					let
						Source = Excel.Workbook(File.Contents("data.xlsx"))
					in
						Source`
        };
        const response = await request.post(BASE_URL + "?subscription-key=" + FREE_CODE + "&mode=free", {
            headers: {
                'Content-Type': 'application/json',
            },
            data: JSON.stringify(tmdlPayload),
        });

        expect(response.status()).toBe(401);
    });

    // Test that an empty payload in pro mode returns 400 Bad Request
    test('should return 400 for empty payload in pro mode', async ({ request }) => {
        const response = await request.post(BASE_URL + "?subscription-key=" + PRO_CODE + "&mode=pro", {
            headers: {
                'Content-Type': 'application/json',
            },
            data: '', // Empty payload
        });

        expect(response.status()).toBe(400);
    });

    // Test that null or undefined payload returns 400 Bad Request
    test('should return 400 for null payload in pro mode', async ({ request }) => {
        const response = await request.post(BASE_URL + "?subscription-key=" + PRO_CODE + "&mode=pro", {
            headers: {
                'Content-Type': 'application/json',
            },
            data: null, // Null payload
        });

        expect(response.status()).toBe(500);
    });

    // Test that invalid JSON returns 400 Bad Request
    test('should return 400 for invalid JSON in pro mode', async ({ request }) => {
        const response = await request.post(BASE_URL + "?subscription-key=" + PRO_CODE + "&mode=pro", {
            headers: {
                'Content-Type': 'application/json',
            },
            data: 'invalid json', // Invalid JSON
        });

        expect(response.status()).toBe(400);
    });

    // Test that empty TMDL code returns 400 Bad Request
    test('should return 400 for empty TMDL code in pro mode', async ({ request }) => {
        const tmdlPayload = {
            code: '' // Empty TMDL code
        };

        const response = await request.post(BASE_URL + "?subscription-key=" + PRO_CODE + "&mode=pro", {
            headers: {
                'Content-Type': 'application/json',
            },
            data: JSON.stringify(tmdlPayload),
        });

        expect(response.status()).toBe(400);
    });

    // Test that a valid pro request returns 200 with streaming response
    test('should return 200 with streaming response for valid pro request', async ({ request }) => {
        const tmdlPayload = {
            code: `createOrReplace

	model Model
		culture: en-US

		table Sales
			lineageTag: 6f52c7a5-5ceb-4afe-901d-9f87992e6a0e

			column CustomerKey
				dataType: int64
				summarizeBy: none
				sourceColumn: CustomerKey

			partition Sales-Data = m
				mode: import
				source =
					let
						Source = Excel.Workbook(File.Contents("data.xlsx")),
						Data = Source{[Item="Sheet1"]}[Data]
					in
						Data`,
            rulesResults: []
        };
        
        console.log(BASE_URL + "?subscription-key=" + PRO_CODE + "&mode=pro&email=test@example.com");
        const response = await request.post(BASE_URL + "?subscription-key=" + PRO_CODE + "&mode=pro&email=test@example.com", {
            headers: {
                'Content-Type': 'application/json',
            },
            data: JSON.stringify(tmdlPayload),
        });
        
        expect(response.status()).toBe(200);
        expect(response.headers()['content-type']).toContain('text/event-stream');
        
        // Read the streaming response
        const responseBody = await response.text();
        expect(responseBody).toBeTruthy();
        
        // Verify we received SSE formatted data
        expect(responseBody).toContain('data:');
        
        // Look for completion marker
        expect(responseBody).toContain('[DONE]');
    });

    // Test that TMDL code with no M code returns 400 Bad Request
    test('should return 400 for TMDL code with no M code in pro mode', async ({ request }) => {
        const tmdlPayload = {
            code: `createOrReplace

	model Model
		culture: en-US` // TMDL with no M code/partitions
        };

        const response = await request.post(BASE_URL + "?subscription-key=" + PRO_CODE + "&mode=pro", {
            headers: {
                'Content-Type': 'application/json',
            },
            data: JSON.stringify(tmdlPayload),
        });

        expect(response.status()).toBe(400);
    });

    // Test streaming with actual lint rules
    test('should stream fixes for TMDL with lint issues', async ({ request }) => {
        const tmdlPayload = {
            code: `createOrReplace

	model Model
		table Sales
			partition Sales-Data = m
				mode: import
				source =
					let
					    Source = #"use-relative-path-with-web-contents_fail",
					in
					    Source`,
            rulesResults: [
                {
                    ID: 'PQ_USE_PARAMETERS_FOR_URLS',
                    Name: 'Use parameters for URLs',
                    Passed: false,
                    Severity: 2,
                    AIFixInstructions: {
                        IsActive: true,
                        Prompt: 'Replace hardcoded URL with a parameter'
                    }
                }
            ]
        };

        // Use native fetch to get true streaming support
        const url = BASE_URL + "?subscription-key=" + PRO_CODE + "&mode=pro";
        const fetchResponse = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(tmdlPayload),
        });

        expect(fetchResponse.status).toBe(200);
        expect(fetchResponse.headers.get('content-type')).toContain('text/event-stream');
        
        // Verify true streaming by consuming chunks as they arrive
        const body = fetchResponse.body;
        if (!body) {
            throw new Error('Response body is not readable');
        }

        const chunks: string[] = [];
        const chunkTimestamps: number[] = [];
        let hasStatusMessage = false;
        let hasDeltaMessage = false;
        let hasFinalMessage = false;
        let hasCompletion = false;

        // Read chunks as they arrive
        const reader = body.getReader();
        const decoder = new TextDecoder();
        const startTime = Date.now();

        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                const chunk = decoder.decode(value, { stream: true });
                const timestamp = Date.now() - startTime;
                
                chunks.push(chunk);
                chunkTimestamps.push(timestamp);
                console.log(`Received chunk at ${timestamp}ms:`, chunk);
                // Check for message types in this chunk
                if (chunk.includes('"type":"status"')) hasStatusMessage = true;
                if (chunk.includes('"type":"delta"')) hasDeltaMessage = true;
                if (chunk.includes('"type":"final"')) hasFinalMessage = true;
                if (chunk.includes('[DONE]')) {
                    hasCompletion = true;
                    break;
                }
            }
        } finally {
            reader.releaseLock();
        }

        // Verify we received at least one chunk with SSE content
        expect(chunks.length).toBeGreaterThanOrEqual(1);
        console.log(`Received ${chunks.length} chunks over ${chunkTimestamps[chunkTimestamps.length - 1]}ms`);

        // Combine all chunks to validate the complete SSE stream
        const fullContent = chunks.join('');
        expect(fullContent).toContain('data: ');
        expect(fullContent).toContain('"type"');
        
        // Verify streaming message types
        expect(hasStatusMessage || hasDeltaMessage || hasFinalMessage).toBeTruthy();
        expect(hasCompletion).toBeTruthy();

        // Log chunk timing for debugging
        console.log('Chunk timestamps:', chunkTimestamps);
    }, 120000); // Longer timeout for AI processing
});