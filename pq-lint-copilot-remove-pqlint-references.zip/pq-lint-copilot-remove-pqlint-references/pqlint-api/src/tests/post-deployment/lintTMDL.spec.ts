import { test, expect } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import { tmdlCodeSample1 } from "../hardcoded-tmdl";
import { getTestingConfig } from './get-testing-config';

// Declare variables at a higher scope
let BASE_URL: string;
let CODE: string;

// Handle past situations where errors occurred
const _TMDL_With_Calculated_Partition_DataFilePath = path.resolve('./test-files/Calculated-Partition.tmdl');
const calculatedPartitionfileContent = fs.readFileSync(_TMDL_With_Calculated_Partition_DataFilePath, 'utf-8');

// Sample TMDL code with M code blocks and back ticks
const _TMDL_Sample_Model_DataFilePath = path.resolve('./test-files/harcoded-sample-model.tmdl');
const _TMDL_Sample_Model = fs.readFileSync(_TMDL_Sample_Model_DataFilePath, 'utf-8');

// Handle combined TMDL source from Azure DevOps/GitHub Actions flow
const _TMDL_Databricks_DataFilePath = path.resolve('./test-files/Databricks_API.tmdl');
const _TMDL_Databricks_Data = fs.readFileSync(_TMDL_Databricks_DataFilePath, 'utf-8');

// Handle start script TMDL file
const _TMDL_Start_Scripts_DataFilePath = path.resolve('./test-files/StarterScript.tmdl');
const _TMDL_Start_Scripts_FileContent = fs.readFileSync(_TMDL_Start_Scripts_DataFilePath, 'utf-8');

test.beforeAll(async () => {
    // Load environment variables from local.settings.json
    const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
    if (fs.existsSync(localSettingsPath)) {
        const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
        Object.entries(localSettings.Values).forEach(([key, value]) => {
            process.env[key] = value as string;
        });
    }

    // Initialize BASE_URL
    const testingConfig = getTestingConfig();
    const BASE_URL_PREFIX = testingConfig.baseUrlPrefix;
    CODE = testingConfig.code ?? '';
    BASE_URL = BASE_URL_PREFIX + '/api/lintTMDL'; // Replace with your local function URL
});

test.describe('lintTMDL API Tests', () => {
    test('should return 200 for valid TMDL code payload', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&mode=pro", {
            headers: {
                'Content-Type': 'text/plain',
            },
            data: tmdlCodeSample1,
        });

        // Validate response status
        expect(response.status()).toBe(200);

        // Validate response body
        const responseBody = await response.json();
        console.log("Response Body:", responseBody);
        expect(Array.isArray(responseBody)).toBe(true);
        responseBody.forEach((result: any) => {
            expect(result).toHaveProperty('ID');
            expect(result).toHaveProperty('Name');
            expect(result).toHaveProperty('Category');
            expect(result).toHaveProperty('Description');
            expect(result).toHaveProperty('Severity');
            expect(result).toHaveProperty('ErrorInformation');
        });
    });

    test('should return 200 for valid TMDL code payload (Starter Script)', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&mode=pro", {
            headers: {
                'Content-Type': 'text/plain',
            },
            data: _TMDL_Start_Scripts_FileContent,
        });

        // Validate response status
        expect(response.status()).toBe(200);

        // Validate response body
        const responseBody = await response.json();
        console.log("Response Body:", responseBody);
        expect(Array.isArray(responseBody)).toBe(true);
        responseBody.forEach((result: any) => {
            expect(result).toHaveProperty('ID');
            expect(result).toHaveProperty('Name');
            expect(result).toHaveProperty('Category');
            expect(result).toHaveProperty('Description');
            expect(result).toHaveProperty('Severity');
            expect(result).toHaveProperty('ErrorInformation');
        });
    });

    test('should return 200 for valid TMDL code payload with Unicode', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&mode=pro", {
            headers: {
                'Content-Type': 'text/plain',
            },
            data: calculatedPartitionfileContent,
        });

        // Validate response status
        expect(response.status()).toBe(200);

        // Validate response body
        const responseBody = await response.json();
        console.log("Response Body:", responseBody);
        expect(Array.isArray(responseBody)).toBe(true);
        responseBody.forEach((result: any) => {
            expect(result).toHaveProperty('ID');
            expect(result).toHaveProperty('Name');
            expect(result).toHaveProperty('Category');
            expect(result).toHaveProperty('Description');
            expect(result).toHaveProperty('Severity');
            expect(result).toHaveProperty('ErrorInformation');
        });
    });

    test('should return 200 for valid TMDL code payload with backticks', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&mode=pro", {
            headers: {
                'Content-Type': 'text/plain',
            },
            data: _TMDL_Sample_Model,
        });

        // Validate response status
        expect(response.status()).toBe(200);

        // Validate response body
        const responseBody = await response.json();
        console.log("Response Body:", responseBody);
        expect(Array.isArray(responseBody)).toBe(true);
        responseBody.forEach((result: any) => {
            expect(result).toHaveProperty('ID');
            expect(result).toHaveProperty('Name');
            expect(result).toHaveProperty('Category');
            expect(result).toHaveProperty('Description');
            expect(result).toHaveProperty('Severity');
            expect(result).toHaveProperty('ErrorInformation');
        });
    });    

    test('should return 400 for empty payload', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&mode=pro", {
            headers: {
                'Content-Type': 'text/plain',
            },
            data: '', // Empty payload
        });

        // Validate response status
        expect(response.status()).toBe(400);
    });

    test('should return 401 for mode != pro', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE, {
            headers: {
                'Content-Type': 'text/plain',
            },
            data: `
                createOrReplace
                    model Model
                        expression DatabaseID =
                            let
                                DatabaseID = Table.First(Source)[Name]
                            in
                                DatabaseID
                        lineageTag: 3349bfaf-04fe-4ae7-9e7e-74edb57c5a40
                        queryGroup: 'Setup'
            `,
        });

        // Validate response status
        expect(response.status()).toBe(401);
    });

    test('should return 200 for valid TMDL code payload from Azure DevOPs/GitHub Actions example', async ({ request }) => {
        const response = await request.post(BASE_URL + "?code=" + CODE + "&mode=pro", {
            headers: {
                'Content-Type': 'text/plain',
            },
            data: _TMDL_Databricks_Data
        });

        // Validate response status
        expect(response.status()).toBe(200);

        // Validate response body
        const responseBody = await response.json();
        console.log("Response Body:", responseBody);
        expect(Array.isArray(responseBody)).toBe(true);
        expect(responseBody.length).toBeGreaterThan(0);
        
        // Check that at least one result has the specific rule ID
        const hasTargetRule = responseBody.some((result: any) => 
            result.ID === 'use-dual-mode-with-dimension-table-databricks'
        );
        expect(hasTargetRule).toBe(true);
        
        responseBody.forEach((result: any) => {
            expect(result).toHaveProperty('ID');
            expect(result).toHaveProperty('Name');
            expect(result).toHaveProperty('Category');
            expect(result).toHaveProperty('Description');
            expect(result).toHaveProperty('Severity');
            expect(result).toHaveProperty('ErrorInformation');
        }); // end forEach validation
    });       
});