import { test, expect } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import { LintRequest } from 'src/helpers/http-request-types';
import { SeverityLevel } from 'src/lint/rule-types';
import { getTestingConfig } from './get-testing-config';

// Declare variables at a higher scope
let BASE_URL: string;
let PRO_CODE: string;
let FREE_CODE: string;

test.beforeAll(async () => {
    // Load environment variables from local.settings.json
    const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
    if (fs.existsSync(localSettingsPath)) {
        const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
        Object.entries(localSettings.Values).forEach(([key, value]) => {
            process.env[key] = value as string;
        });
    }

    // Initialize BASE_URL
    const testingConfig = getTestingConfig();
    const BASE_URL_PREFIX = testingConfig.apiBaseUrlPrefix
    PRO_CODE = testingConfig.apiCode;
    FREE_CODE = testingConfig.freeApiCode;
    BASE_URL = BASE_URL_PREFIX + '/pq/lint'; // Use lintCodeV2 endpoint
});

test.describe('lintCodeV2 API Tests', () => {
    test('should return 200 for valid LintRequest payload', async ({ request }) => {
        const lintRequest: LintRequest = {
            code: `let\n    Source = Sql.Database(\"azure-sql-db-jk.database.windows.net\", \"escape-room\", [CreateNavigationProperties=false]),\n    dbo_PieData = Source{[Schema=\"dbo\",Item=\"PieData\"]}[Data],\n    #\"---> Fix this so you DON\'T Break Query Folding\" = Table.TransformColumns(dbo_PieData ,{{\"SlicesRemainingAsPerc\",Number.From, Percentage.Type}})\nin\n    #\"---> Fix this so you DON\'T Break Query Folding\"`,
            rules: ["use-table-transform-columns-for-query-folding"],
            options: { severity: SeverityLevel.Error }
        };
        const response = await request.post(BASE_URL + "?subscription-key=" + PRO_CODE, {
            headers: {
                'Content-Type': 'application/json',
            },
            data: JSON.stringify(lintRequest),
        });
        console.log("BASE_URL:", BASE_URL);
        expect(response.status()).toBe(200);
        const responseBody = await response.json();
        expect(Array.isArray(responseBody)).toBe(true);
        responseBody.forEach((result: any) => {
            expect(result).toHaveProperty('ID');
            expect(result).toHaveProperty('Name');
            expect(result).toHaveProperty('Category');
            expect(result).toHaveProperty('Description');
            expect(result).toHaveProperty('Severity');
            expect(result).toHaveProperty('ErrorInformation');
        });
    });

    test('should return 400 for empty payload', async ({ request }) => {
        const response = await request.post(BASE_URL + "?subscription-key=" + PRO_CODE, {
            headers: {
                'Content-Type': 'application/json'
            }
        });
        expect(response.status()).toBe(400);
    });

    test('should return 400 for empty payload with empty string', async ({ request }) => {
        const response = await request.post(BASE_URL + "?subscription-key=" + PRO_CODE, {
            headers: {
                'Content-Type': 'application/json'
            },
            data: ''
        });
        expect(response.status()).toBe(400);
    });    

    test('should return 401 for missing subscription key', async ({ request }) => {
        const response = await request.post(BASE_URL, {
            headers: {
                'Content-Type': 'application/json',            },
            data: '{ bad json }', // Invalid JSON
        });
        expect(response.status()).toBe(401);
    });

    test('should return 400 for bad LintRequest payload', async ({ request }) => {
        const response = await request.post(BASE_URL + "?subscription-key=" + PRO_CODE, {
            headers: {
                'Content-Type': 'application/json',
            },
            data: JSON.stringify({ bad: 1 }), // Invalid JSON
        });
        expect(response.status()).toBe(400);
    });

    test('should return 400 for LintRequest with empty code', async ({ request }) => {
        const lintRequest: LintRequest = { code: "" };
        const response = await request.post(BASE_URL + "?subscription-key=" + PRO_CODE, {
            headers: {
                'Content-Type': 'application/json'
            },
            data: JSON.stringify(lintRequest),
        });
        expect(response.status()).toBe(400);
    });

    test('should return 200 for function LintRequest payload', async ({ request }) => {
        const lintRequest: LintRequest = { code: '(x) => x + 1' };
        const response = await request.post(BASE_URL + "?subscription-key=" + PRO_CODE, {
            headers: {
                'Content-Type': 'application/json'
            },
            data: JSON.stringify(lintRequest),
        });
        expect(response.status()).toBe(200);
    });

    test('should return 200 for function LintRequest payload under free account with no issues', async ({ request }) => {
        const lintRequest: LintRequest = { code: incrementalIssuePQ };
        const response = await request.post(BASE_URL + "?subscription-key=" + FREE_CODE, {
            headers: {
                'Content-Type': 'application/json'
            },
            data: JSON.stringify(lintRequest),
        });
        expect(response.status()).toBe(200);
        const responseBody = await response.json();
        expect(Array.isArray(responseBody)).toBe(true);
        expect(responseBody.length).toBe(0); // Expecting no linting issues for free account
    }); 
    
    test('should return 200 for function LintRequest payload under pro account with two issues', async ({ request }) => {
        const lintRequest: LintRequest = { code: incrementalIssuePQ };
        const response = await request.post(BASE_URL + "?subscription-key=" + PRO_CODE, {
            headers: {
                'Content-Type': 'application/json'
            },
            data: JSON.stringify(lintRequest),
        });
        expect(response.status()).toBe(200);
        const responseBody = await response.json();
        expect(Array.isArray(responseBody)).toBe(true);
        expect(responseBody.length).toBe(2); // Expecting two linting issues for pro account
    });     
});


const incrementalIssuePQ = `let
    Source = Upstream,

    // Filters rows by created date to keep records in the specified range
    #"Filtered Rows By Created Date Range" = Table.SelectRows(Source, each [Created] >= RangeStart and RangeEnd >= [Created])

    in #"Filtered Rows By Created Date Range"`