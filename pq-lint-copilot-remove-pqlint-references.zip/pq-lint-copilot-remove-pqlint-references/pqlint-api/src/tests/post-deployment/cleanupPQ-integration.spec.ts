import { test, expect } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import { JobStatus } from 'src/helpers/queue-types';
import { getTestingConfig } from './get-testing-config';
// Declare variables at a higher scope for use in all tests
let BASE_URL: string;
let CODE: string;
let JOB_STATUS_BASE_URL: string;

// Define test cases with different file paths and descriptions
const testCases = [
    {
        description: "Test with version2-1.pq",
        pqFilePath: '../../../test-files/rewrite/version2.pq',
    },   
    {
        description: "Test with version3-1.pq",
        pqFilePath: '../../../test-files/rewrite/version3.pq',
    },
    {
        description: "Test with version5.pq",
        pqFilePath: '../../../test-files/rewrite/version5.pq',
    }    
];

// Load environment variables and set up the base URL before all tests run
test.beforeAll(async () => {
    // Load environment variables from local.settings.json if it exists
    const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
    if (fs.existsSync(localSettingsPath)) {
        const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
        Object.entries(localSettings.Values).forEach(([key, value]) => {
            process.env[key] = value as string;
        });
    }

    // Set BASE_URL and CODE from environment variables using helper function
    const testingConfig = getTestingConfig();
    const BASE_URL_PREFIX = testingConfig.baseUrlPrefix;
    CODE = testingConfig.code || '';
    BASE_URL = BASE_URL_PREFIX + '/api/cleanupPQ'; // API endpoint for cleanupPQ Azure Function
    JOB_STATUS_BASE_URL = BASE_URL_PREFIX + '/api/getJobStatus'; // API endpoint for getJobStatus Azure Function
});

// Get Job Status 401 Unauthorized Test
test.describe('Test for 401 with Get Job Status', () => {
        test('should return 401 and jobId for invalid pro request with other user', async ({ request }) => {
            const fileContentBefore = fs.readFileSync(path.resolve(__dirname, testCases[0].pqFilePath), 'utf-8');
            const response = await request.post(BASE_URL + "?code=" + CODE + "&mode=pro&email=testClean@example.com", {
                headers: {
                    'Content-Type': 'text/plain',
                },
                data: fileContentBefore,
            });
            const responseBody = await response.json();
            expect(response.status()).toBe(202);
            expect(responseBody).toHaveProperty('jobId');
            expect(responseBody).toHaveProperty('message');
            expect(responseBody.message).toMatch(/Job submitted successfully/i);

            // Check that the jobId status
            let statusCheckDone: boolean = false;
            let retries = 2;
            const maxRetries = 5;

            do {
                const statusResponse = await request.get(
                    JOB_STATUS_BASE_URL + "/" + responseBody.jobId + "?code=" + CODE + "&mode=pro&email=otherUser@example.com"
                );
                console.log("Status Response: ", JOB_STATUS_BASE_URL + "/" + responseBody.jobId + "?code=" + CODE + "&mode=pro&email=otherUser@example.com");

                expect(statusResponse.status()).toBe(401);
                statusCheckDone = true;
                break;                
                retries++;

            } while (retries < maxRetries && statusCheckDone === false);
        });
});

// Run each test case in parallel using test.describe.parallel
testCases.forEach(({ description, pqFilePath }) => {
    test.describe.parallel(description, () => {
        test('should return 202 and jobId for valid pro request', async ({ request }) => {
            const fileContentBefore = fs.readFileSync(path.resolve(__dirname, pqFilePath), 'utf-8');
            const response = await request.post(BASE_URL + "?code=" + CODE + "&mode=pro&email=testClean@example.com", {
                headers: {
                    'Content-Type': 'text/plain',
                },
                data: fileContentBefore,
            });
            const responseBody = await response.json();
            expect(response.status()).toBe(202);
            expect(responseBody).toHaveProperty('jobId');
            expect(responseBody).toHaveProperty('message');
            expect(responseBody.message).toMatch(/Job submitted successfully/i);

            // Check that the jobId status
            let statusCheckDone: boolean = false;
            let retries = 2;
            const maxRetries = 5;

            do {
                const statusResponse = await request.get(
                    JOB_STATUS_BASE_URL + "/" + responseBody.jobId + "?code=" + CODE + "&mode=pro&email=testClean@example.com"
                );
                console.log("Status Response: ", JOB_STATUS_BASE_URL + "/" + responseBody.jobId + "?code=" + CODE + "&mode=pro&email=testClean@example.com");

                expect(statusResponse.status()).toBe(200);

                const statusBody: JobStatus = await statusResponse.json();
                expect(statusBody).toHaveProperty('jobId');
                expect(statusBody).toHaveProperty('status');

                console.log("Job ID: ", statusBody.jobId);
                console.log("Status: ", statusBody.status);
                if (statusBody.status === "Completed" || statusBody.status === "Failed") {
                    expect(statusBody).toHaveProperty('result');
                    //console.log(statusBody.result);
                    statusCheckDone = true;
                    break;
                }

                // iterate retries
                await new Promise(resolve => setTimeout(resolve, retries * 1000)); // Wait before retrying
                retries++;

            } while (retries < maxRetries && statusCheckDone === false);
        });
    });
});