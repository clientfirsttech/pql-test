import { test, expect } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import { tmdlCodeSample1 } from "../hardcoded-tmdl";
import { getTestingConfig } from './get-testing-config';

// Declare variables at a higher scope
let BASE_URL: string;
let CODE: string;
let FREE_USER_EXISTING: string;

test.beforeAll(async () => {
    // Load environment variables from local.settings.json
    const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
    if (fs.existsSync(localSettingsPath)) {
        const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
        Object.entries(localSettings.Values).forEach(([key, value]) => {
            process.env[key] = value as string;
        });
    }

    // Initialize BASE_URL
    const testingConfig = getTestingConfig();
    const BASE_URL_PREFIX = testingConfig.baseUrlPrefix;
    CODE = testingConfig.code || '';
    BASE_URL = BASE_URL_PREFIX + '/api/getAPISubscription'; // Replace with your local function URL
    FREE_USER_EXISTING = testingConfig.getSubscriptionFreeUser;
});

test.describe('getAPISubscription API Tests', () => {
    test('should return 200 valid request for PAID account', async ({ request }) => {
        const response = await request.get(BASE_URL + "?code=" + CODE + "&stripe-id=test-user-dev" , {
            headers: {
                'Content-Type': 'application/json',
            }
        });

        // Validate response status
        expect(response.status()).toBe(200);

        // Validate response body
        const responseBody = await response.json();
        console.log("Response Body:", responseBody);
        expect(Array.isArray(responseBody)).toBe(true);
        responseBody.forEach((result: any) => {
            expect(result).toHaveProperty('subscriptionId');
            expect(result).toHaveProperty('subscriptionKey');
        });
    });

    test('should return 200 valid request for Free Account', async ({ request }) => {
        const response = await request.get(BASE_URL + "?code=" + CODE + "&email=" + FREE_USER_EXISTING , {
            headers: {
                'Content-Type': 'application/json',
            }
        });

        // Validate response status
        expect(response.status()).toBe(200);

        // Validate response body
        const responseBody = await response.json();
        console.log("Response Body:", responseBody);
        expect(Array.isArray(responseBody)).toBe(true);
        responseBody.forEach((result: any) => {
            expect(result).toHaveProperty('subscriptionId');
            expect(result).toHaveProperty('subscriptionKey');
        });
    });    

    /*test('should return 200 valid request, multiple accounts', async ({ request }) => {
        const response = await request.get(BASE_URL + "?code=" + CODE + "&stripe-id=cus-SWXH1sQMdg54vJ" , {
            headers: {
                'Content-Type': 'application/json',
            }
        });

        // Validate response status
        expect(response.status()).toBe(200);

        // Validate response body
        const responseBody = await response.json();
        console.log("Response Body:", responseBody);
        expect(Array.isArray(responseBody)).toBe(true);
        expect(responseBody.length).toBeGreaterThan(1); // Expecting multiple accounts
        responseBody.forEach((result: any) => {
            expect(result).toHaveProperty('subscriptionId');
            expect(result).toHaveProperty('subscriptionKey');
        });
    }); */   

    test('should return 404 for invalid stripe-id', async ({ request }) => {
        const response = await request.get(BASE_URL + "?code=" + CODE + "&stripe-id=invalid" , {
            headers: {
                'Content-Type': 'application/json',
            }
        });

        // Validate response status
        expect(response.status()).toBe(404);
    });    

    test('should return 403 for invalid stripe-id', async ({ request }) => {
        const response = await request.get(BASE_URL + "?code=" + CODE + "&stripe-id=disabled-account-test-user" , {
            headers: {
                'Content-Type': 'application/json',
            }
        });

        // Validate response status
        expect(response.status()).toBe(403);
    });

    test('should return 404 valid request for Free Account that is missing subscription', async ({ request }) => {
        const response = await request.get(BASE_URL + "?code=" + CODE + "&email=missing-test-free-20250902134420@example.com" , {
            headers: {
                'Content-Type': 'application/json',
            }
        });

        // Validate response status
        expect(response.status()).toBe(404);
    });      

});