import { HttpRequest, InvocationContext } from "@azure/functions";
import { lintTMDL } from "../../functions/lintTMDL";
import { extractMCodeAndProperties } from 'src/parser/tmdl/tmdl-parser';
import { lintMCode, lintTMDLCode } from 'src/lint/linter-module';
import { RuleResult } from 'src/lint/rule-types';
import * as fs from "fs";
import * as path from "path";
import * as dotenv from "dotenv";
import { tmdlCodeSample1 } from "../hardcoded-tmdl";
// Mock the imported functions
jest.mock("src/parser/tmdl/tmdl-parser");
jest.mock("src/lint/linter-module");
jest.mock("src/parser/pq/parse-pq");
// Mock dependencies
jest.mock("@azure/storage-blob");
jest.mock("@azure/storage-queue");
jest.mock("../../../src/helpers/event-hub", () => ({
    sendEventToEventHub: jest.fn().mockResolvedValue(undefined)
}));


// Load environment variables from local.settings.json
const localSettingsPath = path.resolve(__dirname, "../../local.settings.json");
if (fs.existsSync(localSettingsPath)) {
    const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
    Object.entries(localSettings.Values).forEach(([key, value]) => {
        process.env[key] = value as string;
    });
}

// Mock file paths
const _TMDL_With_Unicode_DataFilePath = path.resolve('./test-files/Calculated-Partition.tmdl');
const _TMDL_Unicode_FileContent = fs.readFileSync(_TMDL_With_Unicode_DataFilePath, 'utf-8');

// Sample TMDL code with M code blocks and back ticks
const _TMDL_Sample_Model_DataFilePath = path.resolve('./test-files/harcoded-sample-model.tmdl');
const _TMDL_Sample_Model = fs.readFileSync(_TMDL_Sample_Model_DataFilePath, 'utf-8');

// Start Script TMDL file
const _TMDL_Start_Scripts_DataFilePath = path.resolve('./test-files/StarterScript.tmdl');
const _TMDL_Start_Scripts_FileContent = fs.readFileSync(_TMDL_Start_Scripts_DataFilePath, 'utf-8');

describe("lintTMDL function", () => {
    let context: InvocationContext;

    beforeEach(() => {
        context = {
            log: jest.fn(),
        } as unknown as InvocationContext;
    });

    it("should return 200 and lint results if TMDL payload is provided", async () => {
        const lintResults = [/* mock lint results */] as RuleResult[];

        (lintTMDLCode as jest.Mock).mockResolvedValue(lintResults);

        const request = {
            method: "POST",
            url: "http://localhost",
            text: jest.fn().mockResolvedValue(tmdlCodeSample1),
            query: new Map([["mode", "pro"]]),
        } as unknown as HttpRequest;

        const response = await lintTMDL(request, context);
        expect(response.status).toBe(200);
        expect(response.headers).toEqual({ "Content-Type": "application/json" });
        expect(response.body).toBe(JSON.stringify(lintResults));
    });

    it("should return 200 and lint results if TMDL payload (Starter Script) is provided", async () => {
        const lintResults = [/* mock lint results */] as RuleResult[];

        (lintTMDLCode as jest.Mock).mockResolvedValue(lintResults);

        const request = {
            method: "POST",
            url: "http://localhost",
            text: jest.fn().mockResolvedValue(_TMDL_Start_Scripts_FileContent),
            query: new Map([["mode", "pro"]]),
        } as unknown as HttpRequest;

        const response = await lintTMDL(request, context);
        expect(response.status).toBe(200);
        expect(response.headers).toEqual({ "Content-Type": "application/json" });
        expect(response.body).toBe(JSON.stringify(lintResults));
    });    

    it("should return 200 and lint results if TMDL payload is provided (tmdlSampleModel) with multiple tick marks", async () => {
        const lintResults = [/* mock lint results */] as RuleResult[];

        (lintTMDLCode as jest.Mock).mockResolvedValue(lintResults);

        const request = {
            method: "POST",
            url: "http://localhost",
            text: jest.fn().mockResolvedValue(_TMDL_Sample_Model),
            query: new Map([["mode", "pro"]]),
        } as unknown as HttpRequest;

        const response = await lintTMDL(request, context);
        expect(response.status).toBe(200);
        expect(response.headers).toEqual({ "Content-Type": "application/json" });
        expect(response.body).toBe(JSON.stringify(lintResults));
    });    

    it("should return 200 and lint results for Unicode TMDL payload provided", async () => {
        const lintResults = [/* mock lint results */] as RuleResult[];

        (lintTMDLCode as jest.Mock).mockResolvedValue(lintResults);

        const request = {
            method: "POST",
            url: "http://localhost",
            text: jest.fn().mockResolvedValue(_TMDL_Unicode_FileContent),
            query: new Map([["mode", "pro"]]),
        } as unknown as HttpRequest;

        const response = await lintTMDL(request, context);
        expect(response.status).toBe(200);
        expect(response.headers).toEqual({ "Content-Type": "application/json" });
        expect(response.body).toBe(JSON.stringify(lintResults));
    });    

    it("should return 401 if mode is not pro", async () => {
        const tmdlCode = tmdlTest;
        const extractedBlocks = tmdlCodeSample1;
        const lintResults = [/* mock lint results */] as RuleResult[];

        (extractMCodeAndProperties as jest.Mock).mockReturnValue(extractedBlocks);
        (lintMCode as jest.Mock).mockResolvedValue(lintResults);

        const request = {
            method: "POST",
            url: "http://localhost",
            text: jest.fn().mockResolvedValue(tmdlCode),
        } as unknown as HttpRequest;

        const response = await lintTMDL(request, context);
        expect(response.status).toBe(401);
    });    

    it("should return 405 if mode is not POST", async () => {
        const tmdlCode = tmdlTest;
        const extractedBlocks = tmdlCodeSample1;
        const lintResults = [/* mock lint results */] as RuleResult[];

        (extractMCodeAndProperties as jest.Mock).mockReturnValue(extractedBlocks);
        (lintMCode as jest.Mock).mockResolvedValue(lintResults);

        const request = {
            method: "GET",
            url: "http://localhost",
            text: jest.fn().mockResolvedValue(tmdlCode),
        } as unknown as HttpRequest;

        const response = await lintTMDL(request, context);
        expect(response.status).toBe(405);
    });     
});


const tmdlTest = `
createOrReplace
    model Model
        expression DatabaseID =
            let
                DatabaseID = Table.First(Source)[Name]
            in
                DatabaseID
        lineageTag: 3349bfaf-04fe-4ae7-9e7e-74edb57c5a40
        queryGroup: 'Setup'
`;
