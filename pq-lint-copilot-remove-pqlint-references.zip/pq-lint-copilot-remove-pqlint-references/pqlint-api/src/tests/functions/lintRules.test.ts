import { HttpRequest, InvocationContext } from "@azure/functions";
import { lintRules } from "../../functions/lintRules";
import * as fs from "fs";
import * as path from "path";
// Mock dependencies
jest.mock("@azure/storage-blob");
jest.mock("@azure/storage-queue");
jest.mock("../../../src/helpers/event-hub", () => ({
    sendEventToEventHub: jest.fn().mockResolvedValue(undefined)
}));


// Load environment variables from local.settings.json
const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
if (fs.existsSync(localSettingsPath)) {
    const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
    Object.entries(localSettings.Values).forEach(([key, value]) => {
        process.env[key] = value as string;
    });
}
describe("lintRules function", () => {
    let context: InvocationContext;

    beforeEach(() => {
        context = {
            log: jest.fn(),
        } as unknown as InvocationContext;
    });

    it("should return 200 and all linting rules as JSON", async () => {
        const request = {
            method: "GET",
            headers: new Map(),
            query: new Map()
        } as unknown as HttpRequest;

        const response = await lintRules(request, context);

        expect(response.status).toBe(200);
        expect(response.headers).toEqual({ "Content-Type": "application/json" });
        // If result.body is a JSON string, parse it first
        const body = typeof response.body === "string" ? JSON.parse(response.body) : response.body;
        // Optionally check that at least one rule is present
        expect(body.length).toBeGreaterThan(70);
    });

    it("should return 405 for non-GET methods", async () => {
        const request = {
            method: "POST",
            headers: new Map(),
            query: new Map()
        } as unknown as HttpRequest;

        const response = await lintRules(request, context);

        expect(response.status).toBe(405);
        expect(response.body).toContain("Method Not Allowed");
    });
});