import { HttpRequest, InvocationContext } from "@azure/functions";
import { lintCodeV2 } from "../../functions/lintCodeV2";
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { lintMCode as lintCodeFunction } from 'src/lint/linter-module';
import { ParseResult } from 'src/parser/pq/parse-types';
import { RuleResult, SeverityLevel } from 'src/lint/rule-types';
import * as fs from "fs";
import * as path from "path";
import * as dotenv from "dotenv";
import { LintRequest } from "src/helpers/http-request-types";
import { allPQRules } from 'src/lint/all-rules';

// Mock dependencies
jest.mock("@azure/storage-blob");
jest.mock("@azure/storage-queue");
jest.mock("../../../src/helpers/event-hub", () => ({
    sendEventToEventHub: jest.fn().mockResolvedValue(undefined)
}));



// Load environment variables from local.settings.json
const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
if (fs.existsSync(localSettingsPath)) {
    const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
    Object.entries(localSettings.Values).forEach(([key, value]) => {
        process.env[key] = value as string;
    });
}



describe("lintCodeV2 function", () => {
    let context: InvocationContext;

    beforeEach(() => {
        context = {
            log: jest.fn(),
        } as unknown as InvocationContext;
    });

    it("should return 403 if subscription-key is not provided in the query string", async () => {
        const request = {
            method: "POST",
            query: new Map([["product-id","api-dev"],["subscription-id", "test-user"]]), // No subscription-key
            headers: new Map(),
            text: jest.fn().mockResolvedValue(JSON.stringify(fullLintRequestPayload))
        } as unknown as HttpRequest;

        const response = await lintCodeV2(request, context);
        expect(response.status).toBe(403);
    });

    it("should return 400 if an empty payload is provided in the post request", async () => {
        const request = {
            method: "POST",
            query: new Map([["subscription-key", "abc123"],["product-id","api-dev"],["subscription-id", "test-user"]]),
            headers: new Map(),
            text: jest.fn().mockResolvedValue("")
        } as unknown as HttpRequest;

        const response = await lintCodeV2(request, context);
        expect(response.status).toBe(400);
    });

    it("should return 400 if a payload is provided with a code property that is empty", async () => {
        const request = {
            method: "POST",
            query: new Map([["subscription-key", "abc123"],["product-id","api-dev"],["subscription-id", "test-user"]]),
            headers: new Map(),
            text: jest.fn().mockResolvedValue(JSON.stringify({ code: "" }))
        } as unknown as HttpRequest;

        const response = await lintCodeV2(request, context);
        expect(response.status).toBe(400);
    });

    it("should only test the rules provided in the payload", async () => {
        const rules = ["no-type-for-parameter-for-function"];
        const request = {
            method: "POST",
            query: new Map([["subscription-key", "abc123"],["product-id","api-dev"],["subscription-id", "test-user"]]),
            headers: new Map(),
            text: jest.fn().mockResolvedValue(JSON.stringify({ code: "(x) => x + 1", rules }))
        } as unknown as HttpRequest;

        const response = await lintCodeV2(request, context);
        expect(response.status).toBe(200);
        // If result.body is a JSON string, parse it first
        const body = typeof response.body === "string" ? JSON.parse(response.body) : response.body;
        expect(body.every((r: any) => rules.includes(r.ID))).toBe(true);
    });

    it("should test all rules if no rules are provided in the payload", async () => {
        const request = {
            method: "POST",
            query: new Map([["subscription-key", "abc123"],["product-id","api-dev"],["subscription-id", "test-user"]]),
            headers: new Map(),
            text: jest.fn().mockResolvedValue(JSON.stringify({ code: "(x) => x + 1" }))
        } as unknown as HttpRequest;

        const response = await lintCodeV2(request, context);
        expect(response.status).toBe(200);
        // If result.body is a JSON string, parse it first
        const body = typeof response.body === "string" ? JSON.parse(response.body) : response.body;
        expect(body.length).toBe(2);
    });

    it("should only return results of severity level 3 if specified", async () => {
        const request = {
            method: "POST",
            query: new Map([["subscription-key", "abc123"],["product-id","api-dev"],["subscription-id", "test-user"]]),
            headers: new Map(),
            text: jest.fn().mockResolvedValue(JSON.stringify({ code: "(x) => x + 1", options: { severity: 3 } }))
        } as unknown as HttpRequest;

        const response = await lintCodeV2(request, context);
        expect(response.status).toBe(200);
        // If result.body is a JSON string, parse it first
        const body = typeof response.body === "string" ? JSON.parse(response.body) : response.body;
        expect(body.every((r: any) => r.Severity === SeverityLevel.Error)).toBe(true);
    });

    it("should return all results of any level if no severity is specified", async () => {
        const request = {
            method: "POST",
            query: new Map([["subscription-key", "abc123"],["product-id","api-dev"],["subscription-id", "test-user"]]),
            headers: new Map(),
            text: jest.fn().mockResolvedValue(JSON.stringify({ code: "(x) => x + 1" }))
        } as unknown as HttpRequest;

        const response = await lintCodeV2(request, context);
        expect(response.status).toBe(200);
        // If result.body is a JSON string, parse it first
        const body = typeof response.body === "string" ? JSON.parse(response.body) : response.body;
        expect(body.length).toBe(2);
    });

    it("should return 400 and an error message containing 'Parse' if LintRequest JSON cannot be parsed", async () => {
        const invalidLintRequest = "code: let x = 1, y = 2, in y"; // Invalid JSON
        const request = {
            method: "POST",
            query: new Map([["subscription-key", "abc123"],["product-id","api-dev"],["subscription-id", "test-user"]]),
            headers: new Map(),
            text: jest.fn().mockResolvedValue(JSON.stringify({ code: invalidLintRequest }))
        } as unknown as HttpRequest;

        const response = await lintCodeV2(request, context);
        expect(response.status).toBe(400);
        expect(response.body).toContain("Parse");
    });

    it("should test return no results for a calculated table definition file", async () => {
        const request = {
            method: "POST",
            query: new Map([["subscription-key", "abc123"],["product-id","api-dev"],["subscription-id", "test-user"]]),
            headers: new Map(),
            text: jest.fn().mockResolvedValue(JSON.stringify({ code: tmdlCalculatedTable, options: { format: "tmdl" } }))
        } as unknown as HttpRequest;

        const response = await lintCodeV2(request, context);
        expect(response.status).toBe(200);
        // If result.body is a JSON string, parse it first
        const body = typeof response.body === "string" ? JSON.parse(response.body) : response.body;
        expect(body.length).toBe(0);
    });     

    it("should test TMDL All rules for a definition file", async () => {
        const request = {
            method: "POST",
            query: new Map([["subscription-key", "abc123"],["product-id","api-dev"],["subscription-id", "test-user"]]),
            headers: new Map(),
            text: jest.fn().mockResolvedValue(JSON.stringify({ code: tmdlDefintionRequest, options: { format: "tmdl" } }))
        } as unknown as HttpRequest;

        const response = await lintCodeV2(request,context);
        expect(response.status).toBe(200);
        // If result.body is a JSON string, parse it first
        const body = typeof response.body === "string" ? JSON.parse(response.body) : response.body;
        expect(body.length).toBe(3);
    });    

    it("should test TMDL All rules for a definition file with header key", async () => {
        const request = {
            method: "POST",
            query: new Map(),
            headers: new Map([["Ocp-Apim-Subscription-Key", "abc123"],["product-id","api-dev"],["subscription-id", "test-user"]]),
            text: jest.fn().mockResolvedValue(JSON.stringify({ code: tmdlDefintionRequest, options: { format: "tmdl" } }))
        } as unknown as HttpRequest;

        const response = await lintCodeV2(request,context);
        expect(response.status).toBe(200);
        // If result.body is a JSON string, parse it first
        const body = typeof response.body === "string" ? JSON.parse(response.body) : response.body;
        expect(body.length).toBe(3);
    });   	

    it("should only return results of severity level 3 if specified under verbose mode", async () => {
        const request = {
            method: "POST",
            query: new Map([["subscription-key", "abc123"],["product-id","api-dev"],["subscription-id", "test-user"]]),
            headers: new Map(),
            text: jest.fn().mockResolvedValue(JSON.stringify({ code: "(x) => x + 1", options: { severity: 3, verbose: true } }))
        } as unknown as HttpRequest;

        const response = await lintCodeV2(request, context);
		
        expect(response.status).toBe(200);
        // If result.body is a JSON string, parse it first
        const body = typeof response.body === "string" ? JSON.parse(response.body) : response.body;

		// Check entries have passed for true and false
		expect(body.filter((r: any) => r.Passed === false).length).toBeGreaterThan(0);
		const severeErrorCount = allPQRules.filter((r: any) => r.Severity === SeverityLevel.Error)
		expect(body.length).toBeGreaterThanOrEqual(severeErrorCount.length);
		// Check if all entries have the correct severity level
		expect(body.every((r: any) => r.Severity === SeverityLevel.Error)).toBe(true);
    });	

    it("should return all results of any level if no severity is specified under verbose mode", async () => {
        const request = {
            method: "POST",
            query: new Map([["subscription-key", "abc123"],["product-id","api-dev"],["subscription-id", "test-user"]]),
            headers: new Map(),
            text: jest.fn().mockResolvedValue(JSON.stringify({ code: "(x) => x + 1", options: { verbose: true } }))
        } as unknown as HttpRequest;

        const response = await lintCodeV2(request, context);
        expect(response.status).toBe(200);
        // If result.body is a JSON string, parse it first
        const body = typeof response.body === "string" ? JSON.parse(response.body) : response.body;

		// Check entries have passed for true and false
		expect(body.filter((r: any) => r.Passed === false).length).toBe(2);
		const ruleCount = allPQRules.length;
		expect(body.length).toBeGreaterThanOrEqual(ruleCount);
    });	

    it("should return results of any level if no severity is specified under verbose mode with combined data from Azure DevOps or GitHub Actions", async () => {
        const request = {
            method: "POST",
            query: new Map([["subscription-key", "abc123"],["product-id","api-dev"],["subscription-id", "test-user"]]),
            headers: new Map(),
            text: jest.fn().mockResolvedValue(JSON.stringify({ code: _TMDL_Databricks_Data, options: { verbose: true, format: 'tmdl', severity: 2 } }))
        } as unknown as HttpRequest;

        const response = await lintCodeV2(request, context);
        expect(response.status).toBe(200);
        // If result.body is a JSON string, parse it first
        const body = typeof response.body === "string" ? JSON.parse(response.body) : response.body;

		// Check entries have passed for true and false
		expect(body.filter((r: any) => r.Passed === false).length).toBeGreaterThan(20);
		// Check that at least one result has the specific rule ID
		const hasTargetRule = body.some((result: any) => 
			result.ID === 'use-dual-mode-with-dimension-table-databricks'
		);
		expect(hasTargetRule).toBe(true);
    });		
});


const fullLintRequestPayload: LintRequest = {
    code: `
let
    Source = Pdf.Tables(File.Contents("C:\\Users\\JohnKerski\\Downloads\\documentation-2025-05-01T12-30-07.pdf"), [Implementation="1.3"])
in
    Source`,
    rules: ["rule-1", "rule-2"],
    options: { severity: SeverityLevel.Error }
};

const withSpecifcRulesAndNoOptionsPayLoad: LintRequest = {
    code: `
let
    Source = Pdf.Tables(File.Contents("C:\\Users\\JohnKerski\\Downloads\\documentation-2025-05-01T12-30-07.pdf"), [Implementation="1.3"])
in
    Source`,
    rules: ["rule-1", "rule-2"],
};

const noRulesButOptionsRequest: LintRequest = {
    code: `
let
    Source = Pdf.Tables(File.Contents("C:\\Users\\JohnKerski\\Downloads\\documentation-2025-05-01T12-30-07.pdf"), [Implementation="1.3"])
in
    Source`,
    options: { severity: SeverityLevel.Error }
};

const tmdlDefintionRequest = `table Uses_API_Version_15
	lineageTag: 1c8eff3a-5bd3-4c79-a6d7-9cee52b97be4

	column FileSystemObjectType
		dataType: string
		lineageTag: e2b03eae-6722-4755-a3ba-6b77cb146d5c
		summarizeBy: none
		sourceColumn: FileSystemObjectType

		annotation SummarizationSetBy = Automatic

	column Id
		dataType: string
		lineageTag: 406a080c-f855-41a5-8505-24eb59f41538
		summarizeBy: none
		sourceColumn: Id

		annotation SummarizationSetBy = Automatic

	column ServerRedirectedEmbedUri
		dataType: string
		lineageTag: 9349c779-c486-4319-9781-c50f7de4c12c
		summarizeBy: none
		sourceColumn: ServerRedirectedEmbedUri

		annotation SummarizationSetBy = Automatic

	column ServerRedirectedEmbedUrl
		dataType: string
		lineageTag: 498f62a5-c7ec-44c3-9c77-0ea7095fb584
		summarizeBy: none
		sourceColumn: ServerRedirectedEmbedUrl

		annotation SummarizationSetBy = Automatic

	column ContentTypeId
		dataType: string
		lineageTag: f1c0a0d0-f817-40bc-b2be-7b3190274683
		summarizeBy: none
		sourceColumn: ContentTypeId

		annotation SummarizationSetBy = Automatic

	column Title
		dataType: string
		lineageTag: 00c91371-b444-48ef-8374-092b9e9978e0
		summarizeBy: none
		sourceColumn: Title

		annotation SummarizationSetBy = Automatic

	column ComplianceAssetId
		dataType: string
		lineageTag: f8defa06-2d14-4e25-b23d-1ea2c0c973f2
		summarizeBy: none
		sourceColumn: ComplianceAssetId

		annotation SummarizationSetBy = Automatic

	column Name
		dataType: string
		lineageTag: 9880fcef-a5f7-4401-9190-a40871ea09c4
		summarizeBy: none
		sourceColumn: Name

		annotation SummarizationSetBy = Automatic

	column EMail
		dataType: string
		lineageTag: 1dd8b8d4-6a87-4813-af16-1be6f25239b2
		summarizeBy: none
		sourceColumn: EMail

		annotation SummarizationSetBy = Automatic

	column OtherMail
		dataType: string
		lineageTag: be144b81-2609-4825-a1d2-8da9c6582b97
		summarizeBy: none
		sourceColumn: OtherMail

		annotation SummarizationSetBy = Automatic

	column UserExpiration
		dataType: string
		lineageTag: bc5c3e2c-5171-46d7-b779-32eb4dc531ba
		summarizeBy: none
		sourceColumn: UserExpiration

		annotation SummarizationSetBy = Automatic

	column UserLastDeletionTime
		dataType: string
		lineageTag: 75f598cc-6307-4f82-88d5-9b89807984e2
		summarizeBy: none
		sourceColumn: UserLastDeletionTime

		annotation SummarizationSetBy = Automatic

	column MobilePhone
		dataType: string
		lineageTag: cd6bdf97-7a23-4a52-85f0-f302b834a1c1
		summarizeBy: none
		sourceColumn: MobilePhone

		annotation SummarizationSetBy = Automatic

	column Notes
		dataType: string
		lineageTag: c89be873-e3e2-4eb3-a5d1-92e95a96616c
		summarizeBy: none
		sourceColumn: Notes

		annotation SummarizationSetBy = Automatic

	column SipAddress
		dataType: string
		lineageTag: 5610cc75-b47e-4f4e-b03b-9d4a602ef20c
		summarizeBy: none
		sourceColumn: SipAddress

		annotation SummarizationSetBy = Automatic

	column IsSiteAdmin
		dataType: string
		lineageTag: 6f755886-f8d0-4723-ace4-2be0635f0800
		summarizeBy: none
		sourceColumn: IsSiteAdmin

		annotation SummarizationSetBy = Automatic

	column Deleted
		dataType: string
		lineageTag: afc8f4f1-a470-4c5f-b4a4-fb3f72850f62
		summarizeBy: none
		sourceColumn: Deleted

		annotation SummarizationSetBy = Automatic

	column UserInfoHidden
		dataType: string
		lineageTag: db71c05c-0530-435f-b2db-cc44352d2690
		summarizeBy: none
		sourceColumn: UserInfoHidden

		annotation SummarizationSetBy = Automatic

	column Picture
		dataType: string
		lineageTag: c8e69eac-b3f6-4e0b-8401-b09eecf6de05
		summarizeBy: none
		sourceColumn: Picture

		annotation SummarizationSetBy = Automatic

	column Department
		dataType: string
		lineageTag: 7950ccac-09c8-45ad-b7a6-c97adbe6101d
		summarizeBy: none
		sourceColumn: Department

		annotation SummarizationSetBy = Automatic

	column JobTitle
		dataType: string
		lineageTag: f6569f93-454f-4b7e-9095-1b9270887363
		summarizeBy: none
		sourceColumn: JobTitle

		annotation SummarizationSetBy = Automatic

	column FirstName
		dataType: string
		lineageTag: d418e10a-f18a-47b3-af8c-cc901a839b1c
		summarizeBy: none
		sourceColumn: FirstName

		annotation SummarizationSetBy = Automatic

	column LastName
		dataType: string
		lineageTag: 55e5bf76-a346-457d-9164-287285adc766
		summarizeBy: none
		sourceColumn: LastName

		annotation SummarizationSetBy = Automatic

	column WorkPhone
		dataType: string
		lineageTag: 06137fdc-49e2-4353-8765-9153a2400e1e
		summarizeBy: none
		sourceColumn: WorkPhone

		annotation SummarizationSetBy = Automatic

	column UserName
		dataType: string
		lineageTag: 7fd65714-c500-46b6-9ba4-893c0a00e2a7
		summarizeBy: none
		sourceColumn: UserName

		annotation SummarizationSetBy = Automatic

	column WebSite
		dataType: string
		lineageTag: 99b78b6f-29e4-4a25-aa62-f60fe0855b93
		summarizeBy: none
		sourceColumn: WebSite

		annotation SummarizationSetBy = Automatic

	column SPSResponsibility
		dataType: string
		lineageTag: f0422979-7ef1-44ef-9cb2-9346969cbe93
		summarizeBy: none
		sourceColumn: SPSResponsibility

		annotation SummarizationSetBy = Automatic

	column Office
		dataType: string
		lineageTag: 0856de46-223c-4a74-aca3-a68e7c0e047f
		summarizeBy: none
		sourceColumn: Office

		annotation SummarizationSetBy = Automatic

	column SPSPictureTimestamp
		dataType: string
		lineageTag: 1eaff5c9-87bd-4e8d-b667-037d4a95dbaf
		summarizeBy: none
		sourceColumn: SPSPictureTimestamp

		annotation SummarizationSetBy = Automatic

	column SPSPicturePlaceholderState
		dataType: string
		lineageTag: 7b6f807e-7d78-4325-be9f-27b342e4c3fb
		summarizeBy: none
		sourceColumn: SPSPicturePlaceholderState

		annotation SummarizationSetBy = Automatic

	column SPSPictureExchangeSyncState
		dataType: string
		lineageTag: 4c803918-4772-4f40-a642-f2380c989b80
		summarizeBy: none
		sourceColumn: SPSPictureExchangeSyncState

		annotation SummarizationSetBy = Automatic

	column OData__ColorTag
		dataType: string
		lineageTag: 8c7c2f97-4c4e-4c2a-9cb5-ed12f93e9253
		summarizeBy: none
		sourceColumn: OData__ColorTag

		annotation SummarizationSetBy = Automatic

	column 'ID 2'
		dataType: string
		lineageTag: da06f982-08e3-4ca8-ac1e-f6f190eea2b7
		summarizeBy: none
		sourceColumn: ID

		annotation SummarizationSetBy = Automatic

	column Modified
		dataType: string
		lineageTag: bbf0f7b8-f9af-4398-b76e-363c79b18656
		summarizeBy: none
		sourceColumn: Modified

		annotation SummarizationSetBy = Automatic

	column Created
		dataType: string
		lineageTag: c3e60fb0-8372-4e69-9015-07c7575dbc60
		summarizeBy: none
		sourceColumn: Created

		annotation SummarizationSetBy = Automatic

	column AuthorId
		dataType: string
		lineageTag: 8e061f5c-9337-45df-9498-9dbf9ac792db
		summarizeBy: none
		sourceColumn: AuthorId

		annotation SummarizationSetBy = Automatic

	column EditorId
		dataType: string
		lineageTag: 610f4db9-3915-4117-ab08-76e293f021fd
		summarizeBy: none
		sourceColumn: EditorId

		annotation SummarizationSetBy = Automatic

	column OData__UIVersionString
		dataType: string
		lineageTag: 81b63774-6eb9-4610-92e0-6ae5290c636e
		summarizeBy: none
		sourceColumn: OData__UIVersionString

		annotation SummarizationSetBy = Automatic

	column Attachments
		dataType: string
		lineageTag: 72c7f8e6-6903-4487-8b25-9854aecec38d
		summarizeBy: none
		sourceColumn: Attachments

		annotation SummarizationSetBy = Automatic

	column GUID
		dataType: string
		lineageTag: cc8d8ca8-414d-49a4-b43d-71fba775d806
		summarizeBy: none
		sourceColumn: GUID

		annotation SummarizationSetBy = Automatic

	partition Uses_API_Version_15 = m
		mode: import
		source =
				let
				    Source = SharePoint.Tables("https://kerski.sharepoint.com", [ApiVersion=15]),
				    #"374f6408-6353-48ef-80f2-3115cd7d16e0" = Source{[Id="374f6408-6353-48ef-80f2-3115cd7d16e0"]}[Items]
				in
				    #"374f6408-6353-48ef-80f2-3115cd7d16e0"

	annotation PBI_NavigationStepName = Navigation

	annotation PBI_ResultType = Table

`;

const tmdlCalculatedTable = `		
	/// This table contains all Unicode Library from https://www.nudgebi.com/unicode-library
	table 'Unicode Measures'        
        column Value
			isHidden
			formatString: 0
			summarizeBy: none
			isNameInferred
			sourceColumn: [Value]

			annotation SummarizationSetBy = User

		partition UnicodeMeasures = 
            calculated
			mode: import
			source = { BLANK() }`

// Handle combined TMDL source from Azure DevOps/GitHub Actions flow
const _TMDL_Databricks_DataFilePath = path.resolve('./test-files/Databricks_API.tmdl');
const _TMDL_Databricks_Data = fs.readFileSync(_TMDL_Databricks_DataFilePath, 'utf-8');
