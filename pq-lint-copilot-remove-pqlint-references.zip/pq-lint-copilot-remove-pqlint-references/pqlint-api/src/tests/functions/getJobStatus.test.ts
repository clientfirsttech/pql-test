import { getJobStatus } from "../../functions/getJobStatus";
import { BlobServiceClient } from "@azure/storage-blob";

// Mock dependencies
jest.mock("@azure/storage-blob");
jest.mock("../../../src/helpers/event-hub", () => ({
  sendEventToEventHub: jest.fn().mockResolvedValue(undefined)
}));

jest.mock("../../../src/helpers/queue-assistance", () => ({
  readJobStatus: jest.fn().mockResolvedValue({ jobId: "123", status: "Completed", email: "test@example.com" })
}));

const mockContext = {
  log: jest.fn()
} as any;

describe("getJobStatus Azure Function", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    process.env.EVENT_HUB_CONNECTION_STRING = "test-connection-string";
    process.env.EVENT_HUB_NAME = "test-event-hub";
    process.env.ENVIRONMENT = "Test";
    process.env.AzureWebJobsStorage = "UseDevelopmentStorage=true";
  });

  it("returns 400 if required parameters are missing", async () => {
    const req = {
      method: "GET",
      url: "/api/getJobStatus/",
      query: new Map()
    } as any;

    const result = await getJobStatus(req, mockContext);
    expect(result.status).toBe(400);
    // If result.body is a JSON string, parse it first
    const body = typeof result.body === "string" ? JSON.parse(result.body) : result.body;    
    expect(body.error).toMatch(/Missing required parameters/i);
  });

  it("returns 401 if mode is not pro", async () => {
    const req = {
      method: "GET",
      url: "/api/getJobStatus/123",
      query: new Map([["mode", "free"], ["email", "test@example.com"]])
    } as any;

    const result = await getJobStatus(req, mockContext);
    expect(result.status).toBe(401);
  });

  it("returns 401 if emails do not match", async () => {
    const req = {
      method: "GET",
      url: "/api/getJobStatus/123",
      query: new Map([["mode", "free"], ["email", "test@example.com"]])
    } as any;

    // Mock Blob and Queue clients
    (BlobServiceClient.fromConnectionString as jest.Mock).mockReturnValue({
        getContainerClient: jest.fn().mockReturnValue({
            createIfNotExists: jest.fn().mockResolvedValue(undefined),
            getBlockBlobClient: jest.fn().mockReturnValue({
                upload: jest.fn().mockResolvedValue({
                    email: "otheruser@example.com",
                    jobId: "123",
                })
            })
        })
    });     

    const result = await getJobStatus(req, mockContext);
    expect(result.status).toBe(401);
  });  

  it("returns 200 and job status for valid request", async () => {
    const req = {
      method: "GET",
      url: "/api/getJobStatus/123",
      query: new Map([["mode", "pro"], ["email", "test@example.com"]])
    } as any;

    // Mock Blob and Queue clients
    (BlobServiceClient.fromConnectionString as jest.Mock).mockReturnValue({
        getContainerClient: jest.fn().mockReturnValue({
            createIfNotExists: jest.fn().mockResolvedValue(undefined),
            getBlockBlobClient: jest.fn().mockReturnValue({
                upload: jest.fn().mockResolvedValue({
                    email: "test@example.com",
                    jobId: "123",
                })
            })
        })
    }); 

    const result = await getJobStatus(req, mockContext);
    console.log(result);
    expect(result.status).toBe(200);
    expect(result.headers).toBeDefined();
    expect((result.headers as Record<string, string>)["Content-Type"]).toBe("application/json");
    // If result.body is a JSON string, parse it first
    const body = typeof result.body === "string" ? JSON.parse(result.body) : result.body;        
    expect(body).toHaveProperty("jobId", "123");
    expect(body).toHaveProperty("status", "Completed");
  });

  it("returns 500 on internal error", async () => {
    // Force readJobStatus to throw
    const { readJobStatus } = require("../../helpers/queue-assistance");
    readJobStatus.mockImplementationOnce(() => { throw new Error("fail"); });

    const req = {
      method: "GET",
      url: "/api/getJobStatus/123",
      query: new Map([["mode", "pro"], ["email", "test@example.com"]])
    } as any;

    const result = await getJobStatus(req, mockContext);
    expect(result.status).toBe(500);
    expect(result.body).toBe("Internal Server Error");
  });
});