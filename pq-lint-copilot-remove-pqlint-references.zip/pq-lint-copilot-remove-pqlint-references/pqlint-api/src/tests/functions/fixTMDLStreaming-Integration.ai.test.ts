import { fixTMDLStreaming } from '../../functions/fixTMDLStreaming';
import { HttpRequest, InvocationContext } from '@azure/functions';
import { loadApiCredentials } from '../rule-testing-assistance';
import * as fs from 'fs';
import * as path from 'path';
import { lintTMDLCode } from 'src/lint/linter-module';
import { allPQRules } from 'src/lint/all-rules';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { extractMCodeAndProperties } from 'src/parser/tmdl/tmdl-parser';

describe('AI Integration: fixTMDLStreaming with Complex Model', () => {
    beforeAll(() => {
        const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
        if (fs.existsSync(localSettingsPath)) {
            const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
            Object.entries(localSettings.Values).forEach(([key, value]) => {
                process.env[key] = value as string;
            });
        }
        
        loadApiCredentials();
        process.env.OPENAI_LOG = 'silent';
    });

    const mockContext = {
        invocationId: 'integration-test-id',
        functionName: 'fixTMDLStreaming',
        extraInputs: [] as any,
        extraOutputs: [] as any,
        retryContext: undefined,
        traceContext: { traceParent: '', traceState: '' },
        trace: undefined,
        options: { debug: false, stream: true },
        log: jest.fn(),
        debug: jest.fn(),
        info: jest.fn(),
        warn: jest.fn(),
        error: jest.fn()
    } as unknown as InvocationContext;

    function createMockRequest(method: string, body: any, queryParams: Record<string, string> = {}): HttpRequest {
        const req: any = {
            method,
            url: 'https://test.com/api/fixTMDLStreaming',
            headers: new Map([['content-type', 'application/json']]),
            query: new URLSearchParams(queryParams),
            params: {},
            user: null,
            text: async () => typeof body === 'string' ? body : JSON.stringify(body),
            json: async () => typeof body === 'string' ? JSON.parse(body) : body,
            formData: async () => new FormData(),
            arrayBuffer: async () => new ArrayBuffer(0),
            blob: async () => new Blob([]),
            body: typeof body === 'string' ? body : JSON.stringify(body),
            bodyUsed: false,
            clone: () => ({ ...req })
        };
        return req as unknown as HttpRequest;
    }

    /**
     * Helper function to handle different types of streaming responses
     * @param responseBody - The response body from Azure Functions
     * @param testName - Name of the test for logging purposes
     * @returns Promise<string> - The final accumulated content
     */
    async function handleStreamingResponse(responseBody: any, testName: string = 'integration-test'): Promise<string> {
        let finalContent = '';
        
        console.log(`[${testName}] Response body type:`, typeof responseBody);
        console.log(`[${testName}] Response body constructor:`, responseBody?.constructor?.name);
        
        if (typeof responseBody === 'string') {
            finalContent = responseBody;
            console.log(`[${testName}] Response is string:`, finalContent.length, 'characters');
        } else if (responseBody && typeof responseBody === 'object' && 'getReader' in responseBody) {
            // Type guard to check if it's actually a ReadableStream
            const maybeStream = responseBody as any;
            if (typeof maybeStream.getReader === 'function' && 
                typeof maybeStream.cancel === 'function' &&
                typeof maybeStream.locked !== 'undefined') {
                // Handle as Web ReadableStream
                const webStream = maybeStream as ReadableStream<Uint8Array>;
                const reader = webStream.getReader();
                const decoder = new TextDecoder();
                
                const timeout = setTimeout(() => {
                    reader.cancel();
                }, 120000); // 2 minute timeout for complex model
                
                try {
                    let done = false;
                    let chunkCount = 0;
                    
                    while (!done) {
                        const { value, done: streamDone } = await reader.read();
                        done = streamDone;
                        
                        if (value) {
                            const chunkStr = decoder.decode(value, { stream: true });
                            finalContent += chunkStr;
                            chunkCount++;
                            console.log(`[${testName}] Web stream chunk ${chunkCount}: ${chunkStr.length} bytes`);
                            if (chunkStr.length <= 100) {
                                console.log(`[${testName}] Chunk content: ${chunkStr}`);
                            } else {
                                console.log(`[${testName}] Chunk preview: ${chunkStr.substring(0, 50)}...${chunkStr.substring(chunkStr.length - 50)}`);
                            }
                        }
                    }
                    
                    console.log(`[${testName}] Web ReadableStream consumed: ${chunkCount} chunks, ${finalContent.length} characters`);
                    
                    // Verify we received content (may be single chunk in test environment)
                    if (chunkCount > 0) {
                        console.log(`[${testName}] ✓ Verified stream consumption: ${chunkCount} chunks received`);
                    }
                    
                } finally {
                    clearTimeout(timeout);
                    reader.releaseLock();
                }
            } else {
                console.log(`[${testName}] Object has getReader but not a proper ReadableStream`);
                finalContent = String(responseBody);
            }
        } else if (responseBody && typeof responseBody === 'object') {
            // Fallback for Node.js streams and other objects
            const { Readable } = require('stream');
            
            if (responseBody instanceof Readable) {
                const timeout = setTimeout(() => {
                    if (responseBody && 'destroy' in responseBody && typeof responseBody.destroy === 'function') {
                        responseBody.destroy();
                    }
                }, 120000);
                
                try {
                    for await (const chunk of responseBody as AsyncIterable<any>) {
                        const chunkStr = Buffer.isBuffer(chunk) ? chunk.toString('utf-8') : String(chunk);
                        finalContent += chunkStr;
                        console.log(`[${testName}] Node.js stream chunk: ${chunkStr.length} bytes`);
                    }
                    console.log(`[${testName}] Node.js stream consumed: ${finalContent.length} characters`);
                } finally {
                    clearTimeout(timeout);
                }
            } else if (Symbol.asyncIterator in responseBody) {
                console.log(`[${testName}] Response is async iterable, consuming...`);
                const asyncIterable = responseBody as AsyncIterable<any>;
                for await (const chunk of asyncIterable) {
                    const chunkStr = Buffer.isBuffer(chunk) ? chunk.toString('utf-8') : String(chunk);
                    finalContent += chunkStr;
                    console.log(`[${testName}] Async chunk: ${chunkStr.length} bytes`);
                }
            } else {
                finalContent = String(responseBody);
                console.log(`[${testName}] Converted body to string:`, finalContent.length, 'characters');
            }
        } else if (!responseBody) {
            throw new Error(`[${testName}] Response body is null or undefined`);
        } else {
            console.log(`[${testName}] Attempting to convert response body to string...`);
            finalContent = String(responseBody);
            console.log(`[${testName}] Converted response to string: ${finalContent.length} characters`);
        }
        
        return finalContent;
    }

    test('AI Integration: should successfully process complex TMDL model without parse errors', async () => {
        // Skip if no API credentials
        if (!process.env.REWRITE_API_URL || !process.env.REWRITE_API_KEY) {
            console.log('Skipping integration test: No API credentials configured');
            return;
        }

        // First, validate the input TMDL can be parsed
        const extractedMCode = extractMCodeAndProperties(complexTMDLModel);
        expect(extractedMCode).toBeDefined();
        expect(extractedMCode.length).toBeGreaterThan(0);

        // Validate each M code block can be parsed
        extractedMCode.forEach((block, index) => {
            if (block.code) {
                expect(() => parsePowerQueryText(block.code!)).not.toThrow();
                console.log(`Validated M code block ${index + 1}: ${block.code.substring(0, 50)}...`);
            }
        });

        // Run linting to get rule results
        const lintResults = await lintTMDLCode(complexTMDLModel, allPQRules, [], [], false);
        console.log(`Lint found ${lintResults.length} total issues`);
        
        const activeAIFixRules = lintResults.filter(r => 
            (r as any)?.AIFixInstructions?.IsActive === true
        );
        console.log(`Found ${activeAIFixRules.length} issues with active AI fixes`);

        // Create request with lint results
        const requestBody = {
            code: complexTMDLModel,
            rulesResults: lintResults
        };
        const request = createMockRequest('POST', requestBody, { mode: 'pro' });

        // Execute the streaming function
        const response = await fixTMDLStreaming(request, mockContext);

        // Verify response structure
        expect(response.status).toBe(200);
        const headers: any = response?.headers || {};
        expect(headers['Content-Type']).toBe('text/event-stream');
        expect(headers['Cache-Control']).toBe('no-cache');
        expect(headers['Connection']).toBe('keep-alive');
        expect(response.body).toBeDefined();

        // Use helper function to handle streaming response
        const sseContent = await handleStreamingResponse(response.body, 'complex-model-integration');

        // Verify we received SSE formatted content
        expect(sseContent).toBeTruthy();
        expect(sseContent.length).toBeGreaterThan(0);
        
        // Should contain SSE formatting
        expect(sseContent).toContain('data: ');
        expect(sseContent).toContain('[DONE]');
        expect(sseContent).toContain('"type":"final"');
        
        // Extract final TMDL from SSE messages
        const lines = sseContent.split('\n');
        const dataLines = lines.filter(line => line.startsWith('data: ') && !line.includes('[DONE]'));
        expect(dataLines.length).toBeGreaterThan(0);
        
        // Parse final message to get actual TMDL code
        const lastDataLine = dataLines[dataLines.length - 1];
        const finalMessage = JSON.parse(lastDataLine.substring(6)); // Remove 'data: '
        expect(finalMessage.type).toBe('final');
        const finalCode = finalMessage.content;

        // Critical validation: Parse the fixed TMDL code
        console.log('Validating fixed TMDL structure...');
        const fixedExtractedMCode = extractMCodeAndProperties(finalCode);
        expect(fixedExtractedMCode).toBeDefined();
        expect(fixedExtractedMCode.length).toBeGreaterThan(0);

        // Validate each M code block in the fixed TMDL can be parsed without errors
        let parseErrorCount = 0;
        fixedExtractedMCode.forEach((block, index) => {
            if (block.code && block.code.trim().length > 0 && !block.properties.isCalculated) {
                try {
                    parsePowerQueryText(block.code);
                    console.log(`✓ Fixed M code block ${index + 1} (${block.name}) parsed successfully`);
                } catch (err) {
                    parseErrorCount++;
                    console.error(`✗ Parse error in fixed M code block ${index + 1} (${block.name}):`, err instanceof Error ? err.message : String(err));
                    console.error(`Problematic code:\n${block.code.substring(0, 200)}...`);
                }
            }
        });

        // Assert no parse errors in the fixed code
        expect(parseErrorCount).toBe(0);

        // Verify the fixed code still contains key elements
        expect(finalCode).toContain('createOrReplace');
        expect(finalCode).toContain('model Model');
        expect(finalCode).toContain('table Date');
        expect(finalCode).toContain('fnCalculateFY');

        console.log('✓ Integration test completed successfully - No TMDL parse errors detected');
        console.log(`Final TMDL length: ${finalCode.length} characters`);
    }, 180000); // 3 minute timeout for the entire test

    afterAll(async () => {
        jest.clearAllTimers();
        jest.clearAllMocks();
        await new Promise(resolve => setTimeout(resolve, 100));
        if (global.gc) {
            global.gc();
        }
    });
});

const complexTMDLModel = `createOrReplace

	model Model
		culture: en-US
		defaultPowerBIDataSourceVersion: powerBI_V3
		sourceQueryCulture: en-US
		dataAccessOptions
			fastCombine
			legacyRedirects
			returnErrorValuesAsNull

		table Date
			lineageTag: ea68dfd3-5f82-4697-8a57-802a0ccf9562

			column DateID
				dataType: int64
				formatString: 0
				lineageTag: 1f613fe2-9047-4072-a7ae-4e6e6a70a843
				summarizeBy: none
				sourceColumn: DateID

				annotation SummarizationSetBy = Automatic

			column Date
				dataType: dateTime
				formatString: Long Date
				lineageTag: 2f24544a-9244-4bda-8ffb-556904f47f5a
				summarizeBy: none
				sourceColumn: Date

				annotation SummarizationSetBy = Automatic

				annotation UnderlyingDateTimeDataType = Date

			column Month
				dataType: int64
				formatString: 0
				lineageTag: 88d2100f-51df-44d2-9878-cea0295f996c
				summarizeBy: none
				sourceColumn: Month

				annotation SummarizationSetBy = Automatic

			column Day
				dataType: int64
				formatString: 0
				lineageTag: b5e467ff-0027-47e4-80a6-c999e30fa184
				summarizeBy: none
				sourceColumn: Day

				annotation SummarizationSetBy = Automatic

			column Year
				dataType: int64
				formatString: 0
				lineageTag: c6061b3d-41d0-44b9-a710-2c0d1925934f
				summarizeBy: none
				sourceColumn: Year

				annotation SummarizationSetBy = Automatic

			column 'Fiscal Year'
				dataType: int64
				formatString: 0
				lineageTag: 6468a0a1-481c-4dac-b520-2ce2dab54599
				summarizeBy: none
				sourceColumn: Fiscal Year

				annotation SummarizationSetBy = Automatic

			column 'Month Year'
				dataType: string
				lineageTag: 0a9e7083-5fd2-4bbd-a1d0-ee581e756691
				summarizeBy: none
				sourceColumn: Month Year
				sortByColumn: 'Month Year Sort'

				changedProperty = SortByColumn

				annotation SummarizationSetBy = Automatic

			column 'Month Year Sort' = 'Date'[Year]*100+'Date'[Month]
				formatString: 0
				lineageTag: d3e03d32-68d0-4415-9671-9e26a5c50c04
				summarizeBy: none

				annotation SummarizationSetBy = Automatic

			column DateTrue = "TRUE"
				lineageTag: 87fbf6c4-16db-437c-ae09-bcf8a02fcf69
				summarizeBy: none

				annotation SummarizationSetBy = Automatic

			hierarchy 'Fiscal Year Hierarchy'
				lineageTag: 3b6cb5cc-244e-4402-894a-f2c547353e04

				level 'Fiscal Year'
					lineageTag: 12229383-1a40-4968-b449-03d82848ab46
					column: 'Fiscal Year'

				level 'Month Year'
					lineageTag: af349a4a-bf85-445c-8914-80ec7f14d6e1
					column: 'Month Year'

				level Date
					lineageTag: bf8e8264-5a2b-4dd8-b37e-e9caa2b882b9
					column: Date

			partition Date = m
				mode: import
				queryGroup: Dims
				source =
						let
						    Source = Csv.Document(Web.Contents("https://raw.githubusercontent.com/clientfirsttech/sample-data/main/power-bi/Issue%20Tracker.csv"),[Delimiter=",", Columns=8, Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
						    #"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
						    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"id", Int64.Type}, {"first_name", type text}, {"last_name", type text}, {"email", type text}, {"status", type text}, {"created", type date}, {"associated_product", type text}, {"issue", type text}}),
						    #"Removed Other Columns1" = Table.SelectColumns(#"Changed Type",{"created"}),
						    #"Renamed Columns" = Table.RenameColumns(#"Removed Other Columns1",{{"created", "Date"}}),
						    #"Removed Duplicates" = Table.Distinct(#"Renamed Columns"),
						    #"Sorted Rows" = Table.Sort(#"Removed Duplicates",{{"Date", Order.Ascending}}),
						    #"Inserted Month" = Table.AddColumn(#"Sorted Rows", "Month", each Date.Month([Date]), Int64.Type),
						    #"Inserted Day" = Table.AddColumn(#"Inserted Month", "Day", each Date.Day([Date]), Int64.Type),
						    #"Inserted Year" = Table.AddColumn(#"Inserted Day", "Year", each Date.Year([Date]), Int64.Type),
						    #"Invoked Custom Function" = Table.AddColumn(#"Inserted Year", "Fiscal Year", each fnCalculateFY([Date])),
						    #"Changed Type1" = Table.TransformColumnTypes(#"Invoked Custom Function",{{"Fiscal Year", Int64.Type}}),
						    #"Added Custom" = Table.AddColumn(#"Changed Type1", "Month Year", each Text.Combine({Text.Start(Date.MonthName([Date]),3)," ",Text.From([Year])})),
						    #"Changed Type2" = Table.TransformColumnTypes(#"Added Custom",{{"Month Year", type text}}),
						    #"Added Index" = Table.AddIndexColumn(#"Changed Type2", "Index", 1, 1, Int64.Type),
						    #"Reordered Columns" = Table.ReorderColumns(#"Added Index",{"Index", "Date", "Month", "Day", "Year", "Fiscal Year", "Month Year"}),
						    #"Renamed Columns1" = Table.RenameColumns(#"Reordered Columns",{{"Index", "DateID"}})
						in
						    #"Renamed Columns1"

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Table

		expression fnCalculateFY =
				(inputDate as date) =>
				let
				    year = Date.Year(inputDate),
				    month = Date.Month(inputDate),
				    fiscalYear = if month >= 10 then year + 1 else year
				in
				    fiscalYear
			lineageTag: 343dacb8-7776-4fee-baea-42f17d237ef2
			queryGroup: Functions

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Function

		queryGroup Functions

			annotation PBI_QueryGroupOrder = 0`;
