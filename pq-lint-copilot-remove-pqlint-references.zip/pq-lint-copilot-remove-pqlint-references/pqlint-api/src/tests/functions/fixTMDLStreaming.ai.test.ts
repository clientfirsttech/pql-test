import { fixTMDLStreaming } from '../../functions/fixTMDLStreaming';
import { HttpRequest, InvocationContext } from '@azure/functions';
import { RuleResult, SeverityLevel } from 'src/lint/rule-types';
import { loadApiCredentials } from '../rule-testing-assistance';
import * as fs from 'fs';
import * as path from 'path';
import { lintTMDLCode } from 'src/lint/linter-module';
import { allPQRules } from 'src/lint/all-rules';

describe('AI: fixTMDLStreaming', () => {
    // Load environment variables from local.settings.json if it exists
    beforeAll(() => {
        const localSettingsPath = path.resolve(__dirname, "../../../local.settings.json");
        if (fs.existsSync(localSettingsPath)) {
            const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
            Object.entries(localSettings.Values).forEach(([key, value]) => {
                process.env[key] = value as string;
            });
        }
        
        // Load credentials using the helper
        loadApiCredentials();
        
        // Disable OpenAI debug logging to prevent after-test logs
        process.env.OPENAI_LOG = 'silent';
    });

    const sampleTMDLCode = `createOrReplace

	/// Use: https://raw.githubusercontent.com/fivethirtyeight/data/master/comic-characters/marvel-wikia-data.csv
	expression WebURL = "https://raw.githubusercontent.com/fivethirtyeight/data/master/comic-characters/marvel-wikia-data.csv" meta [IsParameterQuery=true, Type="Any", IsParameterQueryRequired=true]
		lineageTag: 82d1cfde-eee7-4ae8-9d6e-4e2d1c4d13b5
		queryGroup: Parameters

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = Text

	table MarvelCharacters
		lineageTag: a1b2c3d4-e5f6-7890-abcd-ef1234567890

		column Page
			dataType: string
			lineageTag: 12345678-1234-1234-1234-123456789012
			summarizeBy: none
			sourceColumn: Page

		column Name
			dataType: string
			lineageTag: 87654321-4321-4321-4321-210987654321
			summarizeBy: none
			sourceColumn: Name

		partition MarvelCharacters-Data = m
			mode: import
			source =
				let
					Source = Csv.Document(Web.Contents(WebURL),[Delimiter=",", Columns=13, Encoding=1252, QuoteStyle=QuoteStyle.None]),
					#"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
					#"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"page_id", Int64.Type}, {"name", type text}, {"urlslug", type text}, {"ID", type text}, {"ALIGN", type text}, {"EYE", type text}, {"HAIR", type text}, {"SEX", type text}, {"GSM", type text}, {"ALIVE", type text}, {"APPEARANCES", Int64.Type}, {"FIRST APPEARANCE", type text}, {"Year", Int64.Type}})
				in
					#"Changed Type"`;

    const mockContext = {
        invocationId: 'test-id',
        functionName: 'fixTMDLStreaming',
        extraInputs: [] as any,
        extraOutputs: [] as any,
        retryContext: undefined,
        traceContext: { traceParent: '', traceState: '' },
        trace: undefined,
        options: { debug: false, stream: true },

        log: jest.fn(),
        debug: jest.fn(),
        info: jest.fn(),
        warn: jest.fn(),
        error: jest.fn()
    } as unknown as InvocationContext;

    function createMockRequest(method: string, body: any, queryParams: Record<string, string> = {}): HttpRequest {
        const req: any = {
            method,
            url: 'https://test.com/api/fixTMDLStreaming',
            headers: new Map([['content-type', 'application/json']]),
            query: new URLSearchParams(queryParams),
            params: {},
            user: null,
            text: async () => typeof body === 'string' ? body : JSON.stringify(body),
            json: async () => typeof body === 'string' ? JSON.parse(body) : body,
            formData: async () => new FormData(),
            arrayBuffer: async () => new ArrayBuffer(0),
            blob: async () => new Blob([]),
            body: typeof body === 'string' ? body : JSON.stringify(body),
            bodyUsed: false,
            clone: () => ({ ...req })
        };
        return req as unknown as HttpRequest;
    }

    afterAll(async () => {
        // Force cleanup of any remaining handles
        jest.clearAllTimers();
        jest.clearAllMocks();
        
        // Wait a bit for any pending operations to complete
        await new Promise(resolve => setTimeout(resolve, 100));
        
        // Force garbage collection if available
        if (global.gc) {
            global.gc();
        }
    });

    test('AI: should return 405 for non-POST requests', async () => {
        const request = createMockRequest('GET', {});
        const response = await fixTMDLStreaming(request, mockContext);
        
        expect(response.status).toBe(405);
        expect(response.body).toBe('Method Not Allowed');
    }, 15000);

    test('AI: should return 401 for non-pro mode', async () => {
        const request = createMockRequest('POST', {}, { mode: 'free' });
        const response = await fixTMDLStreaming(request, mockContext);
        
        expect(response.status).toBe(401);
        expect(response.body).toBe('Not Authorized');
    }, 30000);

    test('AI: should return 400 for empty request body', async () => {
        const request = createMockRequest('POST', '', { mode: 'pro' });
        const response = await fixTMDLStreaming(request, mockContext);
        
        expect(response.status).toBe(400);
        expect(response.body).toBe('Bad Request: Empty request body');
    }, 30000);

    test('AI: should return 400 for empty POST payload with no data', async () => {
        const req: any = {
            method: 'POST',
            url: 'https://test.com/api/fixTMDLStreaming',
            headers: new Map([['content-type', 'application/json']]),
            query: new URLSearchParams({ mode: 'pro' }),
            params: {},
            user: null,
            text: async () => '', // Empty string
            json: async () => { throw new Error('Cannot parse empty body'); },
            formData: async () => new FormData(),
            arrayBuffer: async () => new ArrayBuffer(0),
            blob: async () => new Blob([]),
            body: null, // No body
            bodyUsed: false,
            clone: () => ({ ...req })
        };
        
        const response = await fixTMDLStreaming(req as unknown as HttpRequest, mockContext);
        
        expect(response.status).toBe(400);
        expect(response.body).toBe('Bad Request: Empty request body');
    }, 30000);

    test('AI: should return 400 for whitespace-only request body', async () => {
        const request = createMockRequest('POST', '   \n\t  ', { mode: 'pro' });
        const response = await fixTMDLStreaming(request, mockContext);
        
        expect(response.status).toBe(400);
        expect(response.body).toBe('Bad Request: Empty request body');
    }, 30000);

    test('AI: should return 400 for invalid JSON', async () => {
        const request = createMockRequest('POST', 'invalid json', { mode: 'pro' });
        const response = await fixTMDLStreaming(request, mockContext);
        
        expect(response.status).toBe(400);
        expect(response.body).toBe('Bad Request: Invalid JSON for FixTMDLRequest');
    }, 30000);

    test('AI: should return 400 for missing TMDL code', async () => {
        const requestBody = { code: '', rulesResults: [] };
        const request = createMockRequest('POST', requestBody, { mode: 'pro' });
        const response = await fixTMDLStreaming(request, mockContext);
        
        expect(response.status).toBe(400);
        expect(response.body).toBe('Bad Request: TMDL Code payload is required');
    }, 30000);

    test('AI: should return 400 for invalid TMDL code', async () => {
        const requestBody = { 
            code: 'invalid tmdl code without proper structure', 
            rulesResults: [] 
        };
        const request = createMockRequest('POST', requestBody, { mode: 'pro' });
        const response = await fixTMDLStreaming(request, mockContext);
        
        expect(response.status).toBe(400);
        expect(response.body).toBe('Bad Request: TMDL Code could not be parsed or contains no M code.');
    }, 30000);

    /**
     * Helper function to handle different types of streaming responses
     * @param responseBody - The response body from Azure Functions
     * @param testName - Name of the test for logging purposes
     * @returns Promise<string> - The final accumulated content
     */
    async function handleStreamingResponse(responseBody: any, testName: string = 'test'): Promise<string> {
        let finalContent = '';
        
        console.log(`[${testName}] Response body type:`, typeof responseBody);
        console.log(`[${testName}] Response body constructor:`, responseBody?.constructor?.name);
        
        if (typeof responseBody === 'string') {
            finalContent = responseBody;
            console.log(`[${testName}] Response is string:`, finalContent.length, 'characters');
        } else if (responseBody && typeof responseBody === 'object' && 'getReader' in responseBody) {
            // Type guard to check if it's actually a ReadableStream
            const maybeStream = responseBody as any;
            if (typeof maybeStream.getReader === 'function' && 
                typeof maybeStream.cancel === 'function' &&
                typeof maybeStream.locked !== 'undefined') {
                // Handle as Web ReadableStream
                const webStream = maybeStream as ReadableStream<Uint8Array>;
                const reader = webStream.getReader();
                const decoder = new TextDecoder();
                
                const timeout = setTimeout(() => {
                    reader.cancel();
                }, 120000); // 2 minute timeout
                
                try {
                    let done = false;
                    let chunkCount = 0;
                    const startTime = Date.now();
                    
                    while (!done) {
                        const { value, done: streamDone } = await reader.read();
                        done = streamDone;
                        
                        if (value) {
                            const chunkStr = decoder.decode(value, { stream: true });
                            finalContent += chunkStr;
                            chunkCount++;
                            const timestamp = Date.now() - startTime;
                            console.log(`[${testName}] Web stream chunk ${chunkCount} at ${timestamp}ms: ${chunkStr.length} bytes`);
                            if (chunkStr.length <= 100) {
                                console.log(`[${testName}] Chunk content at ${timestamp}ms: ${chunkStr}`);
                            } else {
                                console.log(`[${testName}] Chunk preview at ${timestamp}ms: ${chunkStr.substring(0, 50)}...${chunkStr.substring(chunkStr.length - 50)}`);
                            }
                        }
                    }
                    
                    console.log(`[${testName}] Web ReadableStream consumed: ${chunkCount} chunks, ${finalContent.length} characters`);
                    
                } finally {
                    clearTimeout(timeout);
                    reader.releaseLock();
                }
            } else {
                console.log(`[${testName}] Object has getReader but not a proper ReadableStream`);
                finalContent = String(responseBody);
            }
        } else if (responseBody && typeof responseBody === 'object') {
            // Fallback for Node.js streams
            const { Readable } = require('stream');
            
            if (responseBody instanceof Readable) {
                const timeout = setTimeout(() => {
                    if (responseBody && 'destroy' in responseBody && typeof responseBody.destroy === 'function') {
                        responseBody.destroy();
                    }
                }, 120000);
                
                try {
                    for await (const chunk of responseBody as AsyncIterable<any>) {
                        const chunkStr = Buffer.isBuffer(chunk) ? chunk.toString('utf-8') : String(chunk);
                        finalContent += chunkStr;
                        console.log(`[${testName}] Node.js stream chunk: ${chunkStr.length} bytes`);
                    }
                    console.log(`[${testName}] Node.js stream consumed: ${finalContent.length} characters`);
                } finally {
                    clearTimeout(timeout);
                }
            } else if (Symbol.asyncIterator in responseBody) {
                // Handle async iterable
                console.log(`[${testName}] Response is async iterable, consuming...`);
                const asyncIterable = responseBody as AsyncIterable<any>;
                for await (const chunk of asyncIterable) {
                    const chunkStr = Buffer.isBuffer(chunk) ? chunk.toString('utf-8') : String(chunk);
                    finalContent += chunkStr;
                    console.log(`[${testName}] Async chunk: ${chunkStr.length} bytes`);
                }
            } else {
                finalContent = String(responseBody);
                console.log(`[${testName}] Converted body to string:`, finalContent.length, 'characters');
            }
        } else if (!responseBody) {
            throw new Error(`[${testName}] Response body is null or undefined`);
        } else {
            // Final fallback
            console.log(`[${testName}] Attempting to convert response body to string...`);
            finalContent = String(responseBody);
            console.log(`[${testName}] Converted response to string: ${finalContent.length} characters`);
        }
        
        return finalContent;
    }

    test('AI: should return SSE streaming response for valid request', async () => {
        // Skip this test if no API credentials are available
        if (!process.env.REWRITE_API_URL || !process.env.REWRITE_API_KEY) {
            return;
        }

        // Prepare mock rule results
        const mockRuleResults: RuleResult[] = await lintTMDLCode(sampleTMDLCode,allPQRules,[],[],false);

        const requestBody = { 
            code: sampleTMDLCode, 
            rulesResults: mockRuleResults
        };
        const request = createMockRequest('POST', requestBody, { mode: 'pro' });
        
        const response = await fixTMDLStreaming(request, mockContext);
        
        expect(response.status).toBe(200);
        const headers: any = response?.headers || {};
        
        // Expect SSE streaming headers
        expect(headers['Content-Type']).toBe('text/event-stream');
        expect(headers['Cache-Control']).toBe('no-cache');
        expect(headers['Connection']).toBe('keep-alive');
        expect(response.body).toBeDefined();
        
        // Use helper function to handle streaming response
        const finalContent = await handleStreamingResponse(response.body, 'streaming-test');

        // Verify we received SSE formatted content
        expect(finalContent).toBeTruthy();
        expect(finalContent.length).toBeGreaterThan(0);
        
        // Should contain SSE formatting
        expect(finalContent).toContain('data: ');
        expect(finalContent).toContain('[DONE]');
        expect(finalContent).toContain('"type":"delta"');
        expect(finalContent).toContain('"type":"final"');
        
        // Extract final TMDL from SSE messages
        const lines = finalContent.split('\n');
        const dataLines = lines.filter(line => line.startsWith('data: ') && !line.includes('[DONE]'));
        expect(dataLines.length).toBeGreaterThan(0);
        
        // Parse final message to verify TMDL content
        const lastDataLine = dataLines[dataLines.length - 1];
        const finalMessage = JSON.parse(lastDataLine.substring(6)); // Remove 'data: '
        expect(finalMessage.type).toBe('final');
        expect(finalMessage.content).toContain('createOrReplace');
        expect(finalMessage.content).toContain('table');
        expect(finalMessage.content).toContain('partition');
        
        console.log('✓ SSE streaming test completed successfully');
        
        // Short wait for cleanup
        await new Promise(resolve => setTimeout(resolve, 100));
    }, 60000);

    test('AI: should handle request with no active rules', async () => {
        const mockRuleResults: RuleResult[] = [
            {
                ID: 'inactive-rule',
                Name: 'Inactive Rule',
                Category: 'Test',
                Description: 'Test description',
                Passed: false,
                References: [],
                Severity: SeverityLevel.Warning,
                ErrorInformation: {
                    errorLocation: {
                        positionStart: { codeUnit: 0, lineCodeUnit: 0, lineNumber: 3 },
                        positionEnd: { codeUnit: 0, lineCodeUnit: 0, lineNumber: 3 }
                    },
                    filePath: null
                },
                AIFixInstructions: {
                    Description: "Test fix",
                    IsActive: false // Not active
                }
            }
        ];

        const requestBody = { 
            code: sampleTMDLCode, 
            rulesResults: mockRuleResults 
        };
        const request = createMockRequest('POST', requestBody, { mode: 'pro' });
        const response = await fixTMDLStreaming(request, mockContext);
        
        expect(response.status).toBe(200);
        const headers: any = response?.headers || {};
        expect(headers['Content-Type']).toBe('text/event-stream');

        // Use helper function to handle streaming response
        const finalContent = await handleStreamingResponse(response.body, 'no-active-rules-test');

        // Should return original TMDL code in SSE format (no active rules to fix)
        expect(finalContent).toBeTruthy();
        expect(finalContent.length).toBeGreaterThan(0);
        
        // Should contain SSE formatting
        expect(finalContent).toContain('data: ');
        expect(finalContent).toContain('[DONE]');
        expect(finalContent).toContain('"type":"final"');
        
        // Extract final TMDL from SSE message
        const lines = finalContent.split('\n');
        const dataLines = lines.filter(line => line.startsWith('data: ') && !line.includes('[DONE]'));
        const lastDataLine = dataLines[dataLines.length - 1];
        const finalMessage = JSON.parse(lastDataLine.substring(6));
        
        expect(finalMessage.content).toContain('createOrReplace');
        expect(finalMessage.content).toContain('WebURL');
        expect(finalMessage.content).toContain('MarvelCharacters');
    }, 60000);

    test('AI: should return 500 if OpenAI credentials are missing', async () => {
        // Temporarily remove credentials
        const originalUrl = process.env.REWRITE_API_URL;
        const originalKey = process.env.REWRITE_API_KEY;
        delete process.env.REWRITE_API_URL;
        delete process.env.REWRITE_API_KEY;

        const requestBody = { 
            code: sampleTMDLCode, 
            rulesResults: [] 
        };
        const request = createMockRequest('POST', requestBody, { mode: 'pro' });
        const response = await fixTMDLStreaming(request, mockContext);
        
        expect(response.status).toBe(500);
        expect(response.body).toBe('OpenAI credentials not configured');

        // Restore credentials
        if (originalUrl) process.env.REWRITE_API_URL = originalUrl;
        if (originalKey) process.env.REWRITE_API_KEY = originalKey;
    }, 60000); // Add timeout*/
});
