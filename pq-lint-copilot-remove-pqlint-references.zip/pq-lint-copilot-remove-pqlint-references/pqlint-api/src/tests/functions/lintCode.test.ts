import { HttpRequest, InvocationContext } from "@azure/functions";
import { lintCode } from "../../functions/lintCode";
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { lintMCode as lintCodeFunction } from 'src/lint/linter-module';
import { ParseResult } from 'src/parser/pq/parse-types';
import { RuleResult } from 'src/lint/rule-types';
import * as fs from "fs";
import * as path from "path";
import * as dotenv from "dotenv";

// Mock the imported functions
jest.mock("src/parser/pq/parse-pq");
jest.mock("src/lint/linter-module");
// Mock dependencies
jest.mock("@azure/storage-blob");
jest.mock("@azure/storage-queue");
jest.mock("../../../src/helpers/event-hub", () => ({
    sendEventToEventHub: jest.fn().mockResolvedValue(undefined)
}));

jest.mock("src/parser/pq/parse-pq", () => ({
    parsePowerQueryText: jest.fn().mockResolvedValue({ })
}));


// Load environment variables from local.settings.json
const localSettingsPath = path.resolve(__dirname, "../../local.settings.json");
if (fs.existsSync(localSettingsPath)) {
    const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
    Object.entries(localSettings.Values).forEach(([key, value]) => {
        process.env[key] = value as string;
    });
}

const pdfTest = `
let
    Source = Pdf.Tables(File.Contents("C:\Users\JohnKerski\Downloads\documentation-2025-05-01T12-30-07.pdf"), [Implementation="1.3"])
in
    Source`

describe("lintCode function", () => {
    let context: InvocationContext;

    beforeEach(() => {
        context = {
            log: jest.fn(),
        } as unknown as InvocationContext;
    });


    it("should return 200 and lint results if M Code payload is provided with mode 'pro'", async () => {
        const request = {
            method: "POST",
            query: new Map([["mode", "pro"], ["email", "test@example.com"]]),
            headers: new Map(),
            text: jest.fn().mockResolvedValue(pdfTest)
        } as unknown as HttpRequest;

        const parsedCode = { /* mock parsed code */ } as ParseResult;
        const lintResults = [ /* mock lint results */ ] as RuleResult[];

        (parsePowerQueryText as jest.Mock).mockResolvedValue(parsedCode);
        (lintCodeFunction as jest.Mock).mockResolvedValue(lintResults);

        const response = await lintCode(request, context);
        expect(response.status).toBe(200);
        expect(response.headers).toEqual({ "Content-Type": "application/json" });
        expect(response.body).toBe(JSON.stringify(lintResults));
    });   

    it("should return 200 and lint results if function M Code payload is provided with mode 'free'", async () => {
        const request = {
            method: "POST",
            query: new Map([["mode", "free"], ["email", "test@example.com"]]),
            headers: new Map(),
            text: jest.fn().mockResolvedValue('(x) => x + 1')
        } as unknown as HttpRequest;

        const parsedCode = { /* mock parsed code */ } as ParseResult;
        const lintResults = [ /* mock lint results */ ] as RuleResult[];

        (parsePowerQueryText as jest.Mock).mockResolvedValue(parsedCode);
        (lintCodeFunction as jest.Mock).mockResolvedValue(lintResults);

        const response = await lintCode(request, context);
        expect(response.status).toBe(200);
        expect(response.headers).toEqual({ "Content-Type": "application/json" });
        expect(response.body).toBe(JSON.stringify(lintResults));
    });   
    

    it("should return 400 and an error message containing 'Parse' if M Code cannot be parsed", async () => {
        const request = {
            method: "POST",
            query: new Map([["mode", "pro"], ["email", "test@example.com"]]),
            headers: new Map(),
            text: jest.fn().mockResolvedValue("let x = 1, y = 2, in y")
        } as unknown as HttpRequest;

        const parsedCode = { error: 'bad' } as ParseResult;
        const lintResults = [ /* mock lint results */ ] as RuleResult[];

        (parsePowerQueryText as jest.Mock).mockResolvedValue(parsedCode);
        (lintCodeFunction as jest.Mock).mockResolvedValue(lintResults);

        const response = await lintCode(request, context);
        expect(response.status).toBe(400);
        expect(response.body).toContain("Parse");
    });    
});