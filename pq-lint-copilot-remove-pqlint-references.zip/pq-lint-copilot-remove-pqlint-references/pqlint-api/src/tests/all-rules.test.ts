import { log } from 'console';
import { getRulesAsJson } from 'src/lint/all-rules';

describe('All Rules Properties Validation', () => {

    test('should have at least one rule', () => {
        const allRules = getRulesAsJson();
        expect(allRules.length).toBeGreaterThan(0);
    });

    test('all rules should have required properties', () => {
        const allRules: any[] = getRulesAsJson();
        allRules.forEach((rule, index) => {
            // Test required string properties
            expect(rule.ID).toBeDefined();
            expect(typeof rule.ID).toBe('string');
            expect(rule.ID.length).toBeGreaterThan(0);

            expect(rule.Name).toBeDefined();
            expect(typeof rule.Name).toBe('string');
            expect(rule.Name.length).toBeGreaterThan(0);

            expect(rule.Category).toBeDefined();
            expect(typeof rule.Category).toBe('string');
            expect(rule.Category.length).toBeGreaterThan(0);

            expect(rule.Description).toBeDefined();
            expect(typeof rule.Description).toBe('string');
            expect(rule.Description.length).toBeGreaterThan(0);

            expect(rule.Severity).toBeDefined();
            expect(typeof rule.Severity).toBe('number');

            expect(rule.MinLicenseLevel).toBeDefined();
            expect(typeof rule.MinLicenseLevel).toBe('number');

            // Test references array
            expect(rule.References).toBeDefined();
            expect(Array.isArray(rule.References)).toBe(true);
            
            // Each reference should have link and description
            rule.References.forEach((ref: any, refIndex: number) => {
                expect(ref.Link).toBeDefined();
                expect(typeof ref.Link).toBe('string');
                expect(ref.Description).toBeDefined();
                expect(typeof ref.Description).toBe('string');
            });
        });
    });

    test('all rules should have AIFixInstructions with Prompt property', () => {
        const allRules: any[] = getRulesAsJson();
        allRules.forEach((rule, index) => {
            expect(rule.AIFixInstructions).toBeDefined();
            expect(rule.AIFixInstructions.Description).not.toBeNull();
            expect(rule.AIFixInstructions.Prompt).toBeDefined();
            expect(rule.AIFixInstructions.IsWholeQueryFix).toBeDefined();
            expect(rule.AIFixInstructions.IsActive).toBeDefined();
        });
    });

    test('all rules should strip AIFixInstructions Prompt when includePrompt is false', () => {
        const allRules: any[] = getRulesAsJson(false);
        allRules.forEach((rule, index) => {
            console.log(`Testing rule ${index + 1}/${allRules.length}: ID=${rule.ID}`);
            expect(rule.AIFixInstructions).toBeDefined();
            expect(rule.AIFixInstructions.Description).toBeDefined();
            expect(rule.AIFixInstructions.Prompt).toBeUndefined();
            expect(rule.AIFixInstructions.IsWholeQueryFix).toBeUndefined();
            expect(rule.AIFixInstructions.IsActive).toBeDefined();          
        });
    });    

    test('all rules should have valid severity values', () => {
        const validSeverities = [0, 1, 2, 3]; // SeverityLevel enum values
        const allRules: any[] = getRulesAsJson();
        allRules.forEach((rule, index) => {
            console.log(`Rule ID: ${rule.ID}, Severity: ${rule.Severity}`);
            expect(validSeverities).toContain(rule.Severity);
        });
    });

    test('all rules should have valid minLicenseLevel values', () => {
        const validLicenseLevels = [0,1,2,3];
        const allRules: any[] = getRulesAsJson();
        allRules.forEach((rule, index) => {
            expect(validLicenseLevels).toContain(rule.MinLicenseLevel);
        });
    });

    test('all rules should have unique IDs', () => {
        const allRules: any[] = getRulesAsJson();
        const ruleIds = allRules.map(rule => rule.ID);

        const uniqueIds = new Set(ruleIds);
        
        expect(uniqueIds.size).toBe(ruleIds.length);
    });
});
