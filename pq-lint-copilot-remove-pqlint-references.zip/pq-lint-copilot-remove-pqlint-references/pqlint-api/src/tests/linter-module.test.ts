import { lintTMDLCode,  getPowerQueryPairingsForLinting, lintMCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { RuleResult, TMDL_Level_PowerQueryPairing } from 'src/lint/rule-types';
import { allPQRules, allTMDLLevelPQRules } from 'src/lint/all-rules';
import { tmdlCodeSample1, tmdlCodeSample2, tmdlCodeSample3, tmdlCodeSample4, tmdlCodeSample5 } from './hardcoded-tmdl'
import { logDebug } from 'src/lint/rule-assistance';
import * as fs from 'fs';
import * as path from 'path';
// TMDL Code example
const blankTMDLCode = `
`
const badCodeExample = `
    let 
        X = 1,
    in
        X
`

const basicFunction = `(x) => x + 1`;

const _TMDL_With_Calculated_Partition_DataFilePath = path.resolve('./test-files/Calculated-Partition.tmdl');

// Sample TMDL code with M code blocks and back ticks
const _TMDL_Sample_Model_DataFilePath = path.resolve('./test-files/harcoded-sample-model.tmdl');

// Start Script TMDL file
const _TMDL_Start_Scripts_DataFilePath = path.resolve('./test-files/StarterScript.tmdl');


describe('getPowerQueryPairingsForLinting', () => {
    it('should extract PowerQuery pairings from TMDL file with calculated partitions', async () => {
        const fileContent = fs.readFileSync(_TMDL_With_Calculated_Partition_DataFilePath, 'utf-8');
        const extractedData: TMDL_Level_PowerQueryPairing[] = await getPowerQueryPairingsForLinting(fileContent);  
        logDebug("Extracted Data: ", JSON.stringify(extractedData));
        expect(extractedData).toBeDefined();
        expect(extractedData.length).toBeGreaterThan(0); // Expect some pairings to be extracted

    });
});

describe('Lint TMDL Code - Basic Scenarios', () => {
    it('should return no results for empty TMDL code', async () => {
        // Parse the TMDL Code
        const results: RuleResult[]  = await lintTMDLCode(blankTMDLCode,[],[],[]);

        expect(results.length).toBe(0); // Expect no results for blank TMDL code
    });    

    it('should return no results for empty TMDL code with all PQ rules', async () => {
        // Parse the TMDL Code
        const results: RuleResult[]  = await lintTMDLCode(blankTMDLCode,allPQRules,[],[]);

        expect(results.length).toBe(0); // Expect no results for blank TMDL code
    });        

    it('should return no results for empty TMDL code with no rules', async () => {
        // Parse the TMDL Code
        const results: RuleResult[]  = await lintTMDLCode(blankTMDLCode,[],[],[]);

        expect(results.length).toBe(0); // Expect no results for blank TMDL code
    });       

    it('should return no results for invalid M code syntax', async () => {
        // Parse the TMDL Code
        const results: RuleResult[]  = await lintTMDLCode(badCodeExample,allPQRules,[],[]);

        expect(results.length).toBe(0); // Expect no results for blank TMDL code
    });   

    it('should return no results for basic function expression', async () => {
        // Parse the TMDL Code
        const results: RuleResult[]  = await lintTMDLCode(basicFunction,allPQRules,[],[]);

        expect(results.length).toBe(0); // Expect no results for blank TMDL code
    });   
    
    
    it('should return rule violations for tmdlCodeSample1', async () => {
        // Parse the TMDL Code
        const results: RuleResult[]  = await lintTMDLCode(tmdlCodeSample1,allPQRules,[],[]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(4);  
		const validLinesNumbers = [279,281];
        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            logDebug("Error Object: ", JSON.stringify(result.ID));
            logDebug("Line Number: ", JSON.stringify(result.ErrorInformation.errorLocation.positionStart.lineNumber));   
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
			expect(validLinesNumbers).toContain(result.ErrorInformation.errorLocation.positionStart.lineNumber); // Check if the line number is in the valid lines
		});
           
    });   
	
    it('should return rule violations for tmdlCodeSample2', async () => {
        // Parse the TMDL Code
        const results: RuleResult[]  = await lintTMDLCode(tmdlCodeSample2,allPQRules,[],[]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(10);  
        const validLinesNumbers = [42,43,46,47,49,51,53,54];
        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            logDebug("Error Object: ", JSON.stringify(result.ID));
            logDebug("Line Number: ", JSON.stringify(result.ErrorInformation.errorLocation.positionStart.lineNumber));   
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
			expect(validLinesNumbers).toContain(result.ErrorInformation.errorLocation.positionStart.lineNumber); // Check if the line number is in the valid lines
		});
    }); 
	
    it('should return rule violations for tmdlCodeSample3', async () => {
        // Parse the TMDL Code
        const results: RuleResult[]  = await lintTMDLCode(tmdlCodeSample3,allPQRules,[],[]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(65);  
        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            logDebug("Error Object: ", JSON.stringify(result.ID));
            logDebug("Line Number: ", JSON.stringify(result.ErrorInformation.errorLocation.positionStart.lineNumber));   
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
		});
    }); 	

    it('should return rule violations for tmdlCodeSample4', async () => {
        // Parse the TMDL Code
        const results: RuleResult[]  = await lintTMDLCode(tmdlCodeSample4,allPQRules,[],[],false);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(2);  
        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            logDebug("Error Object: ", JSON.stringify(result.ID));
            logDebug("Line Number: ", JSON.stringify(result.ErrorInformation.errorLocation.positionStart.lineNumber));   
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
		});
    }); 	

    it('should return rule violations for tmdlCodeSample5', async () => {
        // Parse the TMDL Code
        const results: RuleResult[]  = await lintTMDLCode(tmdlCodeSample5,allPQRules,[],[],true);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(5);  
        const validLinesNumbers = [42,44,67,81,95];
        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            logDebug("Error Object: ", JSON.stringify(result.ID));
            logDebug("Line Number: ", JSON.stringify(result.ErrorInformation.errorLocation.positionStart.lineNumber));   
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            expect(validLinesNumbers).toContain(result.ErrorInformation.errorLocation.positionStart.lineNumber); // Check if the line number is in the valid lines
		});
    }); 

    it('should return comprehensive results for tmdlCodeSample5 in verbose mode', async () => {
        // Parse the TMDL Code
        const results: RuleResult[]  = await lintTMDLCode(tmdlCodeSample5,allPQRules,[],[],true,true);
        const failedResults = results.filter(x => x.Passed === false);

        // Check if the results match the expected RuleResult
        expect(failedResults.length).toBe(5);  
        const validLinesNumbers = [42,44,67,81,95];
        // Validate that positionStart is not undefined in the results
        failedResults.forEach(result => {
            logDebug("Error Object: ", JSON.stringify(result.ID));
            logDebug("Line Number: ", JSON.stringify(result.ErrorInformation.errorLocation.positionStart.lineNumber));   
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            expect(validLinesNumbers).toContain(result.ErrorInformation.errorLocation.positionStart.lineNumber); // Check if the line number is in the valid lines
		});

        expect(results.length).toBeGreaterThanOrEqual(allTMDLLevelPQRules.length); // Expect more results than just the failed ones
    });    
    
    // Test for calculated partition handling - ensures no false positives
    it('should return no issues for TMDL file with calculated partitions', async () => {
        const fileContent = fs.readFileSync(_TMDL_With_Calculated_Partition_DataFilePath, 'utf-8');
        const results: RuleResult[]  = await lintTMDLCode(fileContent,allPQRules,allTMDLLevelPQRules,[]);
        logDebug("Extracted Data: ", JSON.stringify(results));
        expect(results).toBeDefined();
        expect(results.length).toBe(0); // Expect some pairings to be extracted

    });    

    // Test for sample model file - baseline validation
    it('should return no issues for hardcoded sample model TMDL file', async () => {
        const _TMDL_Sample_Model = fs.readFileSync(_TMDL_Sample_Model_DataFilePath, 'utf-8');
        const results: RuleResult[]  = await lintTMDLCode(_TMDL_Sample_Model,allPQRules,allTMDLLevelPQRules,[]);
        logDebug("Extracted Data: ", JSON.stringify(results));
        expect(results).toBeDefined();
        expect(results.length).toBeGreaterThan(0); // Expect some pairings to be extracted

    });    

    // Test for sample model file - baseline validation
    it('should return no issues for hardcoded sample model TMDL file', async () => {
        const _TMDL_Sample_Model = fs.readFileSync(_TMDL_Sample_Model_DataFilePath, 'utf-8');
        const results: RuleResult[]  = await lintTMDLCode(_TMDL_Sample_Model,allPQRules,allTMDLLevelPQRules,[]);
        logDebug("Extracted Data: ", JSON.stringify(results));
        expect(results).toBeDefined();
        expect(results.length).toBeGreaterThan(0); // Expect some pairings to be extracted

    });      
});

describe('Lint TMDL Code - Duplicate Test Suite', () => {
    // Note: This appears to be a duplicate test suite that should be consolidated
    it('should return no results for empty TMDL code (duplicate)', async () => {
        // Parse the TMDL Code
        const results: RuleResult[]  = await lintTMDLCode(blankTMDLCode,[],[],[]);

        expect(results.length).toBe(0); // Expect no results for blank TMDL code
    });    

    it('should return no results for empty tmdl', async () => {
        // Parse the TMDL Code
        const results: RuleResult[]  = await lintTMDLCode(blankTMDLCode,[],[],[]);

        expect(results.length).toBe(0); // Expect no results for blank TMDL code
    });    

    it('should return no results for empty tmdl', async () => {
        // Parse the TMDL Code
        const results: RuleResult[]  = await lintTMDLCode(blankTMDLCode,allPQRules,[],[]);

        expect(results.length).toBe(0); // Expect no results for blank TMDL code
    });        

    it('should return no results for empty tmdl', async () => {
        // Parse the TMDL Code
        const results: RuleResult[]  = await lintTMDLCode(blankTMDLCode,[],[],[]);

        expect(results.length).toBe(0); // Expect no results for blank TMDL code
    });       

    it('should return no results for bad code', async () => {
        // Parse the TMDL Code
        const results: RuleResult[]  = await lintTMDLCode(badCodeExample,allPQRules,[],[]);

        expect(results.length).toBe(0); // Expect no results for blank TMDL code
    });   

    it('should return no results for basic function', async () => {
        // Parse the TMDL Code
        const results: RuleResult[]  = await lintTMDLCode(basicFunction,allPQRules,[],[]);

        expect(results.length).toBe(0); // Expect no results for blank TMDL code
    });   
    
    
    it('should return results for tmdlCodeSample1', async () => {
        // Parse the TMDL Code
        const results: RuleResult[]  = await lintTMDLCode(tmdlCodeSample1,allPQRules,[],[]);

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(4);  
		const validLinesNumbers = [279,281];
        // Validate that positionStart is not undefined in the results
        results.forEach(result => {
            logDebug("Error Object: ", JSON.stringify(result.ID));
            logDebug("Line Number: ", JSON.stringify(result.ErrorInformation.errorLocation.positionStart.lineNumber));   
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
			expect(validLinesNumbers).toContain(result.ErrorInformation.errorLocation.positionStart.lineNumber); // Check if the line number is in the valid lines
		});
           
    });   

    it('should return no error for starter script', async () => {
        // Parse the TMDL Code
        const _TMDL_Starter_Script = fs.readFileSync(_TMDL_Start_Scripts_DataFilePath, 'utf-8');
        const results: RuleResult[]  = await lintTMDLCode(_TMDL_Starter_Script,allPQRules,allTMDLLevelPQRules,[]);
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(0);
           
    });     

});