import { cleanupPQ } from 'pqlint-api/src/functions/cleanupPQ';
import { HttpRequest, InvocationContext } from "@azure/functions";
import { BlobServiceClient } from "@azure/storage-blob";
import { QueueClient } from "@azure/storage-queue";

// Mock dependencies
jest.mock("@azure/storage-blob");
jest.mock("@azure/storage-queue");
jest.mock("pqlint-api/src/helpers/event-hub", () => ({
    sendEventToEventHub: jest.fn().mockResolvedValue(undefined)
}));

// Custom mock for parsePowerQueryText to simulate error for invalid M code
jest.mock("src/parser/pq/parse-pq", () => ({
    parsePowerQueryText: jest.fn((code: string) =>
        code === "let x = 1, in x"
            ? Promise.resolve({ error: "Syntax error" })
            : Promise.resolve({ error: undefined })
    )
}));

const mockContext = {
    log: jest.fn()
} as unknown as InvocationContext;

describe("cleanupPQ Azure Function", () => {
    beforeEach(() => {
        process.env.EVENT_HUB_CONNECTION_STRING = "test-connection-string";
        process.env.EVENT_HUB_NAME = "test-event-hub";
        process.env.ENVIRONMENT = "Test";
        process.env.AzureWebJobsStorage = "UseDevelopmentStorage=true";
    });

    it("returns 405 for non-POST requests", async () => {
        const req = {
            method: "GET",
            query: new Map(),
            headers: new Map(),
            text: jest.fn()
        } as unknown as HttpRequest;

        const result = await cleanupPQ(req, mockContext);
        expect(result.status).toBe(405);
        expect(result.body).toBe("Method Not Allowed");
    });

    it("returns 401 for non-pro mode", async () => {
        const req = {
            method: "POST",
            query: new Map([["mode", "free"]]),
            headers: new Map(),
            text: jest.fn()
        } as unknown as HttpRequest;

        const result = await cleanupPQ(req, mockContext);
        expect(result.status).toBe(401);
        expect(result.body).toBe("Not Authorized");
    });

    it("returns 400 if M Code is missing", async () => {
        const req = {
            method: "POST",
            query: new Map([["mode", "pro"]]),
            headers: new Map(),
            text: jest.fn().mockResolvedValue("")
        } as unknown as HttpRequest;

        const result = await cleanupPQ(req, mockContext);
        expect(result.status).toBe(400);
        expect(result.body).toBe("Bad Request: M Code payload is required");
    });

    it("returns 202 and jobId for valid pro request", async () => {
        const req = {
            method: "POST",
            query: new Map([["mode", "pro"], ["email", "test@example.com"]]),
            headers: new Map(),
            text: jest.fn().mockResolvedValue("let x = 1 in x")
        } as unknown as HttpRequest;

        // Mock Blob and Queue clients
        (BlobServiceClient.fromConnectionString as jest.Mock).mockReturnValue({
            getContainerClient: jest.fn().mockReturnValue({
                createIfNotExists: jest.fn().mockResolvedValue(undefined),
                getBlockBlobClient: jest.fn().mockReturnValue({
                    upload: jest.fn().mockResolvedValue(undefined)
                })
            })
        });
        (QueueClient as jest.Mock).mockImplementation(() => ({
            createIfNotExists: jest.fn().mockResolvedValue(undefined),
            sendMessage: jest.fn().mockResolvedValue(undefined)
        }));

        const result = await cleanupPQ(req, mockContext);
        expect(result.status).toBe(202);
        // If result.body is a JSON string, parse it first
        const body = typeof result.body === "string" ? JSON.parse(result.body) : result.body;
        expect(body).toHaveProperty("jobId");
        expect(body.message).toMatch("Job submitted successfully");
    });

    it("returns 500 on internal error", async () => {
        const req = {
            method: "POST",
            query: new Map([["mode", "pro"]]),
            headers: new Map(),
            text: jest.fn().mockRejectedValue(new Error("fail"))
        } as unknown as HttpRequest;

        const result = await cleanupPQ(req, mockContext);
        expect(result.status).toBe(500);
        expect(result.body).toBe("Internal Server Error");
    });

    it("returns 400 if invalid M Code is submitted", async () => {
        const req = {
            method: "POST",
            query: new Map([["mode", "pro"], ["email", "test@example.com"]]),
            headers: new Map(),
            text: jest.fn().mockResolvedValue("let x = 1, in x")
        } as unknown as HttpRequest;

        // Mock Blob and Queue clients
        (BlobServiceClient.fromConnectionString as jest.Mock).mockReturnValue({
            getContainerClient: jest.fn().mockReturnValue({
                createIfNotExists: jest.fn().mockResolvedValue(undefined),
                getBlockBlobClient: jest.fn().mockReturnValue({
                    upload: jest.fn().mockResolvedValue(undefined)
                })
            })
        });
        (QueueClient as jest.Mock).mockImplementation(() => ({
            createIfNotExists: jest.fn().mockResolvedValue(undefined),
            sendMessage: jest.fn().mockResolvedValue(undefined)
        }));

        const result = await cleanupPQ(req, mockContext);
        expect(result.status).toBe(400);
        expect(result.body).toMatch(/Bad Request/i);
    });    
});