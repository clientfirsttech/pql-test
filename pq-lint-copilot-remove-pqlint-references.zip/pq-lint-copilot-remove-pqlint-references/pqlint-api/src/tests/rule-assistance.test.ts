import * as path from 'path';
import { LexedJson, ParseResult } from 'src/parser/pq/parse-types';
import {
    logDebug, findIdentifiers, findNodesWithRecursiveExpression, findFunctionExpressions, extractParameters, findParentNodesWithLiteral, findTableBufferPattern,
    findFunctionCallsInAST, findParametersInASTForFunctionCall
} from 'src/lint/rule-assistance';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { parseHelperForFunctions, parseHelper } from './rule-testing-assistance';

const _Complicated_Function_DataFilePath = path.resolve('./test-files/Functions/Complicated_Function.txt');
const _No_Return_Type_DataFilePath = path.resolve('./test-files/Functions/No_Return_Type.txt');
const _One_Parameter_Defined_DataFilePath = path.resolve('./test-files/Functions/One_Parameter_Defined.txt');

//
const _Table_SelectRows_Without_Buffer_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Table_SelectRows.tmdl');
const _Table_SelectRows_With_Buffer_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Table_SelectRows_With_Buffer.tmdl');
const _Sort_Check_With_Buffer_Fail_2_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Sort_Check_With_Buffer_Fail_2.tmdl');
const _Sort_Check_With_Buffer_Success_2_DataFilePath = path.resolve('./test-files/test_tmdl/PowerQueryLinter.SemanticModel/definition/tables/Sort_Check_With_Buffer_Success_2.tmdl');

// recursive expression test
const _SharePoint_Combine_Content_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/ManipulatingFilesLinter.SemanticModel/definition/tables/Combine_Content_Fail.tmdl');
const _Fail_Content_Fail_DataFilePath = path.resolve('./test-files/test_tmdl/ManipulatingFilesLinter.SemanticModel/definition/tables/Files_Fail.tmdl');

// get last two function calls
const dFExample = `
let
  Source = Excel.Workbook(Web.Contents("https://kerski-my.sharepoint.com/personal/john_kerski_net/Documents/Apps/Microsoft Power Query/Uploaded Files/FakeSales.xlsx"), null, true),
  #"Navigation 1" = Source{[Item = "FakeSales", Kind = "Sheet"]}[Data],
  #"Promoted headers" = Table.PromoteHeaders(#"Navigation 1", [PromoteAllScalars = true]),
  #"Replaced value" = Table.ReplaceValue(#"Promoted headers", "North", "North,South", Replacer.ReplaceValue, {"Customer Region"}),
  #"Added custom" = Table.AddColumn(#"Replaced value", "Custom", each Text.Split([Customer Region], ",")),
  #"Transform columns" = Table.TransformColumnTypes(#"Added custom", {{"Date", type text}, {"Product", type text}, {"Category", type text}, {"Sales Amount", type text}, {"Quantity", type text}, {"Customer Region", type text}}),
  #"Replace errors" = Table.ReplaceErrorValues(#"Transform columns", {{"Date", null}, {"Product", null}, {"Category", null}, {"Sales Amount", null}, {"Quantity", null}, {"Customer Region", null}}),
  #"Transform columns 1" = Table.TransformColumnTypes(#"Replace errors", {{"Custom", type text}}),
  #"Replace errors 1" = Table.ReplaceErrorValues(#"Transform columns 1", {{"Custom", null}})
in
  #"Replace errors 1"
`

const duplicateColumnFail = `
let
    Source = Excel.Workbook(File.Contents("C:\Users\JohnKerski\OneDrive - Kerski Family\Documents\Git\pqlint-dev\tests\Files\FakeSales.xlsx"), null, true),
    FakeSales_Sheet = Source{[Item="FakeSales",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(FakeSales_Sheet, [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Date", type date}, {"Product", type text}, {"Category", type text}, {"Sales Amount", Int64.Type}, {"Quantity", Int64.Type}, {"Customer Region", type text}}),
    #"Duplicated Column" = Table.DuplicateColumn(#"Changed Type", "Date", "Date - Copy"),
    #"Renamed Columns" = Table.RenameColumns(#"Duplicated Column",{{"Date - Copy", "Start of Week"}})
in
    #"Renamed Columns"
`

describe(' Test findParametersInASTForFunctionCall', () => {

    it('should find Date as third arugment and Date - Copy as fourth arugment for Table.DuplicateColumn', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(duplicateColumnFail);

        // Find last two function calls in the AST
        const functionCalls: any[] = findFunctionCallsInAST(parsedCode.ast);

        const duplicateCalls = functionCalls.filter((call) => {
            return call?.literal === "Table.DuplicateColumn";
        });

        expect(duplicateCalls.length).toBe(1);
        // Now retrieve the parameters for the first function call
        const parameters = findParametersInASTForFunctionCall(duplicateCalls[0], parsedCode.ast);

        expect(parameters.length).toBe(3);
        expect(parameters[1].literal).toBe('\"Date\"');
        expect(parameters[2].literal).toBe('\"Date - Copy\"');
    });

    it('should find Date and third arugment and Date - Copy as fourth arugment for Table.DuplicateColumn', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(duplicateColumnFail);

        // Find last two function calls in the AST
        const functionCalls: any[] = findFunctionCallsInAST(parsedCode.ast);

        const renameCalls = functionCalls.filter((call) => {
            return call?.literal === "Table.RenameColumns";
        });

        expect(renameCalls.length).toBe(1);
        // Now retrieve the parameters for the first function call
        const parameters = findParametersInASTForFunctionCall(renameCalls[0], parsedCode.ast);

        expect(parameters.length).toBe(2);
        expect(parameters[1].kind).toBe('ListExpression');
    });


});

describe('Test findFunctionCallsInAST', () => {

    it('should find 2 specific functions within the M code', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parsePowerQueryText(dFExample);

        const x: any[] = findFunctionCallsInAST(parsedCode.ast, 2);
        // Check if the results match the expected RuleResult
        expect(x.length).toBe(2);
        expect(x[0]?.literal).toContain("Table.TransformColumnTypes");
        expect(x[1]?.literal).toContain("Table.ReplaceErrorValues");

    });

});

describe('Test Rule Assistance Functions Rule', () => {

    it('should find 4 functions within the M code', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parseHelperForFunctions(_Complicated_Function_DataFilePath);

        const x = findFunctionExpressions(parsedCode.ast);

        // Check if the results match the expected RuleResult
        expect(x.length).toBe(4);
    });

});

describe('Test Extract Parameters Functions Rule', () => {

    it('should find two parameters function M code', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parseHelperForFunctions(_No_Return_Type_DataFilePath);

        const x = extractParameters(parsedCode.ast);
        // Check if the results match the expected RuleResult
        expect(x.length).toBe(2);
        expect(x[0].type).toBe('any');
        expect(x[1].type).toBe('any');
    });

    it('should find two parameters function M code (one with a type, one without)', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parseHelperForFunctions(_One_Parameter_Defined_DataFilePath);

        const x = extractParameters(parsedCode.ast);
        // Check if the results match the expected RuleResult
        expect(x.length).toBe(2);
        expect(x[0].type).toBe('number');
        expect(x[1].type).toBe('unknown');
    });

    it('should find two parameters function M code (complicated functions)', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parseHelperForFunctions(_Complicated_Function_DataFilePath);

        const x: any = findFunctionExpressions(parsedCode.ast);

        let results: any[] = [];
        for (let i = 0; i < x.length; i++) {
            let z: any = extractParameters(x[i]);
            results.push(z);
        }
        // Flatten array 
        results = results.flat();
        // Check if the results match the expected RuleResult
        expect(results.length).toBe(4);
        expect(results[0].positionStart).toBeDefined();
        expect(results[0].positionEnd).toBeDefined();

    });

});

describe('Test findTableBufferFunction', () => {

    it('should find 1 match of Table.Buffer within the M code', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parseHelper(_Table_SelectRows_With_Buffer_DataFilePath);

        const x = findTableBufferPattern(parsedCode.lexed ?? []);
        // Check if the results match the expected RuleResult
        expect(x.length).toBe(1);
    });

    it('should find 1 match of Table.Buffer within the M code', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parseHelper(_Sort_Check_With_Buffer_Success_2_DataFilePath);

        const x = findTableBufferPattern(parsedCode.lexed ?? []);
        // Check if the results match the expected RuleResult
        expect(x.length).toBe(1);
    });


    it('should find 0 matches of Table.Buffer based on in line Table.Buffer within the M code', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parseHelper(_Sort_Check_With_Buffer_Fail_2_DataFilePath);

        const x = findTableBufferPattern(parsedCode.lexed ?? []);
        // Check if the results match the expected RuleResult
        expect(x.length).toBe(0);
    });
});

describe('Test findIdentifiers and findNodesWithRecursiveExpressions', () => {

    it('should find 1 match of Table.AddColumn within the M code', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parseHelper(_Table_SelectRows_Without_Buffer_DataFilePath);

        const x = findIdentifiers(parsedCode.lexed ?? [], 'Table.AddColumn') ?? [];
        // Check if the results match the expected RuleResult
        expect(x.length).toBe(1);
    });

    it('should find 1 match Table.AddColumn with Table.SelectRows', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parseHelper(_Table_SelectRows_With_Buffer_DataFilePath);

        const x: LexedJson[] = findIdentifiers(parsedCode.lexed ?? [], 'Table.AddColumn') ?? [];

        const results = findNodesWithRecursiveExpression(x, parsedCode.ast, '"literal":"Table.SelectRows');

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);
        logDebug(results);

    });

    it('should find 1 match Table.AddColumn with Transform Function', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parseHelper(_SharePoint_Combine_Content_Fail_DataFilePath);

        const x: LexedJson[] = findIdentifiers(parsedCode.lexed ?? [], 'Table.AddColumn') ?? [];;
        const tempArray: any[] = [];
        tempArray.push(x[0]);
        const results = findNodesWithRecursiveExpression(x, parsedCode.ast, '"literal":"#\\\"Transform')
        //"literal":"#\"Transform File\""

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);
        logDebug(results);
    });

    it('should find 1 match Table.AddColumn with Transform Function', async () => {
        // Parse the M Code
        const parsedCode: ParseResult = await parseHelper(_Fail_Content_Fail_DataFilePath);

        const x: LexedJson[] = findIdentifiers(parsedCode.lexed ?? [], 'Table.AddColumn') ?? [];
        const tempArray: any[] = [];
        tempArray.push(x[0]);
        const results = findNodesWithRecursiveExpression(tempArray, parsedCode.ast, '"literal":"#\\\"Transform')
        //"literal":"#\"Transform File\""

        // Check if the results match the expected RuleResult
        expect(results.length).toBe(1);
        logDebug(results);
    });
});