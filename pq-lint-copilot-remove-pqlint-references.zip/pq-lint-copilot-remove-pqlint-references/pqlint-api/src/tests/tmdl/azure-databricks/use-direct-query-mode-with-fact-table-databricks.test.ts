import { useDirectQueryModeWithFactTableDatabricks } from 'src/lint/tmdl/azure-databricks/use-direct-query-mode-with-fact-table-databricks';
import { RuleResult } from 'src/lint/rule-types';
import { tmdlCodeSample1 } from '../../hardcoded-tmdl';
import { lintTMDLCode } from 'src/lint/linter-module';
import * as fs from 'fs';
import * as path from 'path';
import { logDebug } from 'src/lint/rule-assistance';
import { log } from 'console';

const _TMDL_With_Import_Mode_Databricks_DataFilePath = path.resolve('./test-files/DatabricksSamples.tmdl');
const _TMDL_With_Multiple_Modes_Databricks_DataFilePath = path.resolve('./test-files/DatabricksMultipleModes.tmdl');
const _TMDL_With_Multiple_Modes_FactTableImport_Databricks_DataFilePath = path.resolve('./test-files/DatabricksMultipleModes_FactTableImport.tmdl');
const _TMDL_User_Agg_DataFilePath = path.resolve('./test-files/Databricks_UserAgg.tmdl');
const _TMDL_Starter_Scripts_DataFilePath = path.resolve('./test-files/StarterScript.tmdl');

describe('useDirectQueryModeWithFactTableDatabricks', () => {
    it('should return no violations when Databricks import mode is not detected', async () => {
        const errors: RuleResult[] = await lintTMDLCode(tmdlCodeSample1,[], [useDirectQueryModeWithFactTableDatabricks],[]);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it

    it('should return no violations when Start Scripts are used', async () => {
        const fileContent = fs.readFileSync(_TMDL_Starter_Scripts_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [useDirectQueryModeWithFactTableDatabricks],[],true);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it    

    it('should return no violations when Databricks with import mode but no relationships', async () => {
        const fileContent = fs.readFileSync(_TMDL_With_Import_Mode_Databricks_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [useDirectQueryModeWithFactTableDatabricks],[],true);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it    

    it('should return no violations when Databricks with direct query mode is used for Fact Table', async () => {
        const fileContent = fs.readFileSync(_TMDL_With_Multiple_Modes_Databricks_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [useDirectQueryModeWithFactTableDatabricks],[],true);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it        

    it('should detect optimization opportunities for Databricks import mode Fact Table', async () => {
        const fileContent = fs.readFileSync(_TMDL_With_Multiple_Modes_FactTableImport_Databricks_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [useDirectQueryModeWithFactTableDatabricks],[],true);
        logDebug('Errors:', errors);
        errors.forEach(result => {
            logDebug(result.ErrorInformation.errorLocation.positionStart.lineNumber);
        });

        expect(errors.length).toBe(1); // Expect errors for import mode without partitioning

        errors.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        // Extract line numbers and verify both expected values are present
        const lineNumbers = errors.map(error => error.ErrorInformation.errorLocation.positionStart.lineNumber);
        expect(lineNumbers).toContain(107);

    }); // end it

    it('should return no violations when Databricks with import mode and isHidden (assumeed aggregation)', async () => {
        const fileContent = fs.readFileSync(_TMDL_User_Agg_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [useDirectQueryModeWithFactTableDatabricks],[],true);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it 
});