import { usePartitioningWhenImportModeDatabricks } from 'src/lint/tmdl/azure-databricks/use-partitioning-when-import-mode-databricks';
import { RuleResult } from 'src/lint/rule-types';
import { tmdlCodeSample1 } from '../../hardcoded-tmdl';
import { lintTMDLCode } from 'src/lint/linter-module';
import * as fs from 'fs';
import * as path from 'path';
import { logDebug } from 'src/lint/rule-assistance';
import { log } from 'console';

const _TMDL_With_Import_Mode_Databricks_DataFilePath = path.resolve('./test-files/DatabricksSamples.tmdl');
const _TMDL_With_Import_Mode_Databricks_RefreshPolicy_DataFilePath = path.resolve('./test-files/DatabricksSamples_RefreshPolicy.tmdl');
const _TMDL_User_Agg_DataFilePath = path.resolve('./test-files/Databricks_UserAgg.tmdl');

describe('usePartitioningWhenImportModeDatabricks', () => {
    it('should return no violations when Databricks import mode is not detected', async () => {
        const errors: RuleResult[] = await lintTMDLCode(tmdlCodeSample1,[], [usePartitioningWhenImportModeDatabricks],[]);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it

    it('should detect optimization opportunities for Databricks import mode tables without partitioning', async () => {
        const fileContent = fs.readFileSync(_TMDL_With_Import_Mode_Databricks_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [usePartitioningWhenImportModeDatabricks],[],true);
        logDebug('Errors:', errors);
        errors.forEach(result => {
            logDebug(result.ErrorInformation.errorLocation.positionStart.lineNumber);
        });

        expect(errors.length).toBe(2); // Expect errors for import mode without partitioning

        errors.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        // Extract line numbers and verify both expected values are present
        const lineNumbers = errors.map(error => error.ErrorInformation.errorLocation.positionStart.lineNumber);
        expect(lineNumbers).toContain(285);
        expect(lineNumbers).toContain(709);

    }); // end it	

    it('should return no violations for Databricks tables with incremental refresh enabled', async () => {
        const fileContent = fs.readFileSync(_TMDL_With_Import_Mode_Databricks_RefreshPolicy_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [usePartitioningWhenImportModeDatabricks],[],true);
        logDebug('Errors:', errors);
        errors.forEach(result => {
            logDebug(result.ErrorInformation.errorLocation.positionStart.lineNumber);
        });
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it    

    it('should return no violations when Databricks with import mode and isHidden (assumeed aggregation)', async () => {
        const fileContent = fs.readFileSync(_TMDL_User_Agg_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [usePartitioningWhenImportModeDatabricks],[],true);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it     
});