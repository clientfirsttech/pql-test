import { requireStandardPrefixForFunctions } from 'src/lint/tmdl/require-standard-prefix-for-functions';
import { RuleResult } from 'src/lint/rule-types';
import { tmdlCodeSample1 } from '../hardcoded-tmdl';
import { lintTMDLCode } from 'src/lint/linter-module';
import * as fs from 'fs';
import * as path from 'path';

const _TMDL_with_Several_Funcs_DataFilePath = path.resolve('./test-files/tmdl_with_several_functions.tmdl');
const _TMDL_With_Calculated_Partition_DataFilePath = path.resolve('./test-files/Calculated-Partition.tmdl');

describe('requireStandardPrefixForFunctions', () => {
    it('should return no errors for functions with standard prefixes', async () => {
        const errors: RuleResult[] = await lintTMDLCode(tmdlCodeSample1,[], [requireStandardPrefixForFunctions],[]);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it

    it('should return no errors for no functions TMDL script', async () => {
        const fileContent = fs.readFileSync(_TMDL_With_Calculated_Partition_DataFilePath, 'utf-8');
		const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [requireStandardPrefixForFunctions],[]);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it	

    it('should return an error with no standard prefixes', async () => {
        const errors: RuleResult[] = await lintTMDLCode(noPrefixFunc,[], [requireStandardPrefixForFunctions],[],false);
        expect(errors.length).toBe(1); // Expect no errors for functions with standard prefixes

        errors.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            // Check if the error location is correct
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(16);
        });  		

    }); // end it 
	
    it('should return an error with two without standard prefixes', async () => {
		const fileContent = fs.readFileSync(_TMDL_with_Several_Funcs_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [requireStandardPrefixForFunctions],[],true);
        expect(errors.length).toBe(2); // Expect no errors for functions with standard prefixes

        errors.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });  	
		
		expect(errors[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(72);
		expect(errors[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(115);

    }); // end it 	
	
});


// Test case for functions without standard prefixes
let noPrefixFunc = `createOrReplace

	model Model
		culture: en-US
		defaultPowerBIDataSourceVersion: powerBI_V3
		sourceQueryCulture: en-US
		dataAccessOptions
			legacyRedirects
			returnErrorValuesAsNull

		cultureInfo en-US

			linguisticMetadata = {"Version":"1.0.0","Language":"en-US"}
				contentType: json

		expression noPrefix =
				(x as number) as number =>
				let
				  y = x + 1
				in
				y
			lineageTag: a9c7ece4-bce6-4cf6-b49c-bf56fd7624ef

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Function

		annotation __PBI_TimeIntelligenceEnabled = 0

		annotation PBIDesktopVersion = 2.139.1678.0 (24.12)+2a034ab280bddf891eb7bb9ebfe6996f9c3a3196

		annotation PBI_QueryOrder = ["noPrefix"]

		annotation PBI_ProTooling = ["DevMode"]
`

