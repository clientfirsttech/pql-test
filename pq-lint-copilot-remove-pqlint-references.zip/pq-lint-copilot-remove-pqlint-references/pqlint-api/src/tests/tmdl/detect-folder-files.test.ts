import {detectFolderFiles} from 'src/lint/tmdl/detect-folder-files';
import { RuleResult } from 'src/lint/rule-types';
import { tmdlCodeSample1 } from '../hardcoded-tmdl';
import { lintTMDLCode } from 'src/lint/linter-module';
import * as fs from 'fs';
import * as path from 'path';
import { logDebug } from 'src/lint/rule-assistance';

const _TMDL_With_File_Folder_DataFilePath = path.resolve('./test-files/scan_tmdl/FileFolderAccess.tmdl');

describe('detectFolderFiles', () => {
    it('should return no detection', async () => {
        const errors: RuleResult[] = await lintTMDLCode(tmdlCodeSample1,[], [detectFolderFiles],[]);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it

    it('should return 1 detection', async () => {
        const fileContent = fs.readFileSync(_TMDL_With_File_Folder_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [detectFolderFiles],[],true);
        logDebug('Errors:', errors);
        expect(errors.length).toBe(1); // Expect no errors for functions with standard prefixes

        errors.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });  		
        // Check if the error location is correct
        expect(errors[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(85);
    }); // end it	
});