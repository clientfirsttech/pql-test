import { detectModelOverwrite } from 'src/lint/tmdl/detect-model-overwrite';
import { RuleResult } from 'src/lint/rule-types';
import { tmdlCodeSample1 } from '../hardcoded-tmdl';
import { lintTMDLCode } from 'src/lint/linter-module';
import * as fs from 'fs';
import * as path from 'path';

const _TMDL_With_Model_Overwrite_DataFilePath = path.resolve('./test-files/scan_tmdl/ModelOverwrite.tmdl');
const _TMDL_With_No_Model_Ovewrite_DataFilePath = path.resolve('./test-files/scan_tmdl/NoModelOverwrite.tmdl');

describe('detectModelOverwrite', () => {
    it('should return no detection without Model Overwrite', async () => {
        const fileContent = fs.readFileSync(_TMDL_With_No_Model_Ovewrite_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [],[detectModelOverwrite],true);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it

    it('should return a detection with Model Overwrite', async () => {
        const fileContent = fs.readFileSync(_TMDL_With_Model_Overwrite_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [],[detectModelOverwrite],true);
        expect(errors.length).toBe(1); // Expect no errors for functions with standard prefixes

        errors.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });  		
        // Check if the error location is correct
        expect(errors[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(3);
        expect(errors[0].ErrorInformation.errorLocation.positionEnd.lineNumber).toBe(3);
    }); // end it	*/
});