import { usePartitioningWhenImportModeDatabricks } from 'src/lint/tmdl/azure-databricks/use-partitioning-when-import-mode-databricks';
import { RuleResult } from 'src/lint/rule-types';
import { tmdlCodeSample1 } from '../../hardcoded-tmdl';
import { lintTMDLCode } from 'src/lint/linter-module';
import * as fs from 'fs';
import * as path from 'path';
import { logDebug } from 'src/lint/rule-assistance';
import { usePartitioningWhenImportModeFoundry } from 'src/lint/tmdl/foundry/use-partitioning-when-import-mode-foundry';

const _TMDL_With_Import_Mode_Foundry_DataFilePath = path.resolve('./test-files/Palantir_Example.tmdl');
const _TMDL_User_Agg_DataFilePath = path.resolve('./test-files/Databricks_UserAgg.tmdl');

describe('usePartitioningWhenImportModeFoundry', () => {

    it('should return detections with Import Mode Foundry', async () => {
        const fileContent = fs.readFileSync(_TMDL_With_Import_Mode_Foundry_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [usePartitioningWhenImportModeFoundry],[],true);
        logDebug('Errors:', errors);
        errors.forEach(result => {
            logDebug(result.ErrorInformation.errorLocation.positionStart.lineNumber);
        });

        expect(errors.length).toBe(2); // Expect errors for import mode without partitioning

        errors.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });

        // Extract line numbers and verify both expected values are present
        const lineNumbers = errors.map(error => error.ErrorInformation.errorLocation.positionStart.lineNumber);
        expect(lineNumbers).toContain(134);
        expect(lineNumbers).toContain(1139);

    }); // end it

    it('should return no violations when Foundry with import mode and isHidden (assumed aggregation)', async () => {
        const fileContent = fs.readFileSync(_TMDL_User_Agg_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [usePartitioningWhenImportModeFoundry],[],true);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it        
});