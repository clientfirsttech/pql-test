import { useQueryReferencesToAvoidDuplicativeCode } from 'src/lint/tmdl/use-query-references-to-avoid-duplicative-code';
import { RuleResult } from 'src/lint/rule-types';
import { lintTMDLCode } from 'src/lint/linter-module';
import * as fs from 'fs';
import * as path from 'path';

const _TMDL_With_Duplicated_Code_DataFilePath = path.resolve('./test-files/tmdl_duplicate_code.tmdl');
const _TMDL_Without_Duplicated_Code_DataFilePath = path.resolve('./test-files/tmdl_no_duplicative_code.tmdl');
const _TMDL_Multiple_Duplicated_Code_Test_DataFilePath = path.resolve('./test-files/tmdl_multiple_duplicative_code.tmdl');
const _TMDL_Multiple_Duplicated_Code_Test_DataFilePath2 = path.resolve('./test-files/tmdl_multiple_duplicative_code2.tmdl');
const _TMDL_Sample_Model_DataFilePath = path.resolve('./test-files/harcoded-sample-model.tmdl');

describe('useQueryReferencesToAvoidDuplicativeCode', () => {
    it('should return one errors for TMDL with duplicative tables', async () => {
        const fileContent = fs.readFileSync(_TMDL_With_Duplicated_Code_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [useQueryReferencesToAvoidDuplicativeCode],[]);
        expect(errors.length).toBe(1); // Expect no errors for functions with standard prefixes

        errors.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });  		
        // Check if the error location is correct
        expect(errors[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(715);        
    }); // end it

    it('should return one errors for TMDL', async () => {
        const fileContent = fs.readFileSync(_TMDL_Without_Duplicated_Code_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [useQueryReferencesToAvoidDuplicativeCode],[]);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
  
    }); // end it    

    it('should return one errors for TMDL with multi-duplicative tables', async () => {
        const fileContent = fs.readFileSync(_TMDL_Multiple_Duplicated_Code_Test_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [useQueryReferencesToAvoidDuplicativeCode],[]);
        expect(errors.length).toBe(2); // Expect no errors for functions with standard prefixes

        errors.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });  		
        // Check if the error location is correct
        // Extract line numbers and verify both expected values are present
        const lineNumbers = errors.map(error => error.ErrorInformation.errorLocation.positionStart.lineNumber);        
        expect(lineNumbers).toContain(715);
        expect(lineNumbers).toContain(767);
    }); // end it

    it('should return one errors for TMDL with multi-duplicative tables2', async () => {
        const fileContent = fs.readFileSync(_TMDL_Multiple_Duplicated_Code_Test_DataFilePath2, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [useQueryReferencesToAvoidDuplicativeCode],[]);
        expect(errors.length).toBe(2); // Expect no errors for functions with standard prefixes

        errors.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });  		
        // Check if the error location is correct
        // Extract line numbers and verify both expected values are present
        const lineNumbers = errors.map(error => error.ErrorInformation.errorLocation.positionStart.lineNumber);        
        expect(lineNumbers).toContain(719);
        expect(lineNumbers).toContain(797);
    }); // end it

    it('should return one errors for TMDL with Sample Model with back ticks in TMDL and local date tables', async () => {
        const fileContent = fs.readFileSync(_TMDL_Sample_Model_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [useQueryReferencesToAvoidDuplicativeCode],[]);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it        
});
