import { requireTableSelectRowsWithErrors } from 'src/lint/tmdl/require-table-select-rows-with-errors';
import { RuleResult } from 'src/lint/rule-types';
import { lintTMDLCode } from 'src/lint/linter-module';
import * as fs from 'fs';
import * as path from 'path';
import { logDebug } from 'src/lint/rule-assistance';

const _TMDL_With_Only_Table_Remove_Errors_DataFile_Path = path.resolve('./test-files/tmdl_remove_errors_only.tmdl');
const _TMDL_With_Only_Table_Remove_Errors2_DataFile_Path = path.resolve('./test-files/tmdl_remove_errors_only2.tmdl');
const _TMDL_With_Table_Select_Rows_With_Errors_DataFile_Path = path.resolve('./test-files/tmdl_remove_errors_with_exception_report.tmdl');
const _TMDL_With_Table_Select_Rows_With_Errors2_DataFile_Path = path.resolve('./test-files/tmdl_remove_errors_with_exception_report2.tmdl');
describe('requireTableSelectRowsWithErrors', () => {

    it('should return 1 detection', async () => {
        const fileContent = fs.readFileSync(_TMDL_With_Only_Table_Remove_Errors_DataFile_Path, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [requireTableSelectRowsWithErrors],[],true);
        logDebug('Errors:', errors);
        expect(errors.length).toBe(1); // Expect no errors for functions with standard prefixes

        errors.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });  		
        // Check if the error location is correct
        expect(errors[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(60);
    }); // end it

    it('should return 2 detections', async () => {
        const fileContent = fs.readFileSync(_TMDL_With_Only_Table_Remove_Errors2_DataFile_Path, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [requireTableSelectRowsWithErrors],[],true);
        logDebug('Errors:', errors);
        expect(errors.length).toBe(2); // Expect no errors for functions with standard prefixes

        errors.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });  		
        // Check if the error location is correct
        expect(errors[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(120);
        expect(errors[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(121);
    }); // end it    
    
    it('should return 0 detection', async () => {
        const fileContent = fs.readFileSync(_TMDL_With_Table_Select_Rows_With_Errors_DataFile_Path, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [requireTableSelectRowsWithErrors],[],true);
        logDebug('Errors:', errors);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it  
    
    it('should return 0 detection', async () => {
        const fileContent = fs.readFileSync(_TMDL_With_Table_Select_Rows_With_Errors2_DataFile_Path, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [requireTableSelectRowsWithErrors],[],true);
        logDebug('Errors:', errors);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it      
});