import { detectPythonExecute } from 'src/lint/tmdl/detect-python.execute';
import { RuleResult } from 'src/lint/rule-types';
import { tmdlCodeSample1 } from '../hardcoded-tmdl';
import { lintTMDLCode } from 'src/lint/linter-module';
import * as fs from 'fs';
import * as path from 'path';

const _TMDL_With_Several_Python_Executes_DataFilePath = path.resolve('./test-files/scan_tmdl/Python.tmdl');

describe('detectPythonExecute', () => {
    it('should return no detection without Python', async () => {
        const errors: RuleResult[] = await lintTMDLCode(tmdlCodeSample1,[], [detectPythonExecute],[]);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it

    it('should return 2 detections with Python', async () => {
		const fileContent = fs.readFileSync(_TMDL_With_Several_Python_Executes_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [detectPythonExecute],[],true);
        expect(errors.length).toBe(2); // Expect no errors for functions with standard prefixes

        errors.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });  		
        // Check if the error location is correct
        // Extract line numbers and verify both expected values are present
        const lineNumbers = errors.map(error => error.ErrorInformation.errorLocation.positionStart.lineNumber);        
        expect(lineNumbers).toContain(239);
		expect(lineNumbers).toContain(336);
    }); // end it
});