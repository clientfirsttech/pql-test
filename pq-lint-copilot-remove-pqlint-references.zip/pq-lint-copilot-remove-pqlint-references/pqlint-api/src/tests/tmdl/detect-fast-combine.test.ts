import { detectFastCombine } from 'src/lint/tmdl/detect-fast-combine';
import { RuleResult } from 'src/lint/rule-types';
import { tmdlCodeSample1 } from '../hardcoded-tmdl';
import { lintTMDLCode } from 'src/lint/linter-module';
import * as fs from 'fs';
import * as path from 'path';

const _TMDL_With_Fast_Combine_DataFilePath = path.resolve('./test-files/scan_tmdl/FastCombine.tmdl');

describe('detectFastCombine', () => {
    it('should return no detection without Fast Combine', async () => {
        const errors: RuleResult[] = await lintTMDLCode(tmdlCodeSample1,[], [],[detectFastCombine]);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it

    it('should return a detection with Fast Combine', async () => {
        const fileContent = fs.readFileSync(_TMDL_With_Fast_Combine_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [],[detectFastCombine],true);
        expect(errors.length).toBe(1); // Expect no errors for functions with standard prefixes

        errors.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });  		
        // Check if the error location is correct
        expect(errors[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(9);
        expect(errors[0].ErrorInformation.errorLocation.positionEnd.lineNumber).toBe(9);
    }); // end it	*/
});