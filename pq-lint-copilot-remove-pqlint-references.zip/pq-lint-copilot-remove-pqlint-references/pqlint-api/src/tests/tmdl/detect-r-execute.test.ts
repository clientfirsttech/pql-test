import { detectRExecute } from 'src/lint/tmdl/detect-r-execute';
import { RuleResult } from 'src/lint/rule-types';
import { tmdlCodeSample1 } from '../hardcoded-tmdl';
import { lintTMDLCode } from 'src/lint/linter-module';
import * as fs from 'fs';
import * as path from 'path';
import { logDebug } from 'src/lint/rule-assistance';

const _TMDL_With_Several_R_Executes_DataFilePath = path.resolve('./test-files/scan_tmdl/R.tmdl');

describe('detectRExecute', () => {
    it('should return no detection without R', async () => {
        const errors: RuleResult[] = await lintTMDLCode(tmdlCodeSample1,[], [detectRExecute],[]);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it

    it('should return 2 detections with R', async () => {
		const fileContent = fs.readFileSync(_TMDL_With_Several_R_Executes_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [detectRExecute],[],true);
        logDebug('Errors:', errors);
        expect(errors.length).toBe(2); // Expect no errors for functions with standard prefixes

        errors.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });  		
        // Extract line numbers and verify both expected values are present
        const lineNumbers = errors.map(error => error.ErrorInformation.errorLocation.positionStart.lineNumber);
        expect(lineNumbers).toContain(236);
        expect(lineNumbers).toContain(328);
    }); // end it	
});