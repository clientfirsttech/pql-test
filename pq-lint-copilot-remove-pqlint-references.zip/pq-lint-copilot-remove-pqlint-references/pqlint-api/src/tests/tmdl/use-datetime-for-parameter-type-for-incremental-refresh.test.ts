import { lintTMDLCode } from 'src/lint/linter-module'; // Adjust the import path according to your project structure
import { useDatetimeParameterForIncrementalRefresh } from 'src/lint/tmdl/use-datetime-for-parameter-type-for-incremental-refresh';
import { ParseResult } from 'src/parser/pq/parse-types';
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { RuleResult } from 'src/lint/rule-types';



describe('useDatetimeParameterForIncrementalRefresh Rule', () => {
    // Test case for RangeStart parameter with date type (should detect error - datetime type recommended)
    it('should return error for RangeStart parameter with date type declaration', async () => {
        const results: RuleResult[] = await lintTMDLCode(rangeStartFail, [], [useDatetimeParameterForIncrementalRefresh], []);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(3);
        });
        expect(results.length).toBe(1);
    });

    // Test case for RangeStart parameter with proper datetime type (should pass - correct type)
    it('should return no errors for RangeStart parameter with datetime type declaration', async () => {
        const results: RuleResult[] = await lintTMDLCode(rangeStartPass, [], [useDatetimeParameterForIncrementalRefresh], []);
        expect(results.length).toBe(0);
    });

    // Test case for RangeEnd parameter with date type (should detect error - datetime type recommended)
    it('should return error for RangeEnd parameter with date type declaration', async () => {
        const results: RuleResult[] = await lintTMDLCode(rangeEndFail, [], [useDatetimeParameterForIncrementalRefresh], []);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(3);
        });
        expect(results.length).toBe(1);
    });

    // Test case for RangeEnd parameter with proper datetime type (should pass - correct type)
    it('should return no errors for RangeEnd parameter with datetime type declaration', async () => {
        const results: RuleResult[] = await lintTMDLCode(rangeEndPass, [], [useDatetimeParameterForIncrementalRefresh], []);
        expect(results.length).toBe(0);
    });

    // Test case for RangeStart parameter with datetimezone type (should detect error - datetime recommended over datetimezone)
    it('should return error for RangeStart parameter with DateTimeZone type declaration', async () => {
        const results: RuleResult[] = await lintTMDLCode(rangeStartFailDTZ, [], [useDatetimeParameterForIncrementalRefresh], []);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(3);
        });
        expect(results.length).toBe(1);
    });
    
    // Test case for RangeEnd parameter with datetimezone type (should detect error - datetime recommended over datetimezone)
    it('should return error for RangeEnd parameter with DateTimeZone type declaration', async () => {
        const results: RuleResult[] = await lintTMDLCode(rangeEndFailDTZ, [], [useDatetimeParameterForIncrementalRefresh], []);

        results.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionStart.lineNumber).toBe(38);
        });
        expect(results.length).toBe(1);
    });    

    // Test case for query using RangeStart/RangeEnd in filtering logic (should pass - no false positives for parameter usage)
    it('should return no errors when RangeStart/RangeEnd are used in filtering expressions without parameter declarations', async () => {
        const results: RuleResult[] = await lintTMDLCode(avoidFalsePositive, [], [useDatetimeParameterForIncrementalRefresh], []);
        expect(results.length).toBe(0);
    });  
});

// Test cases for different scenarios

// Test case: RangeStart with "date" type (should fail - should use datetime instead)
const rangeStartFail = `
   createOrReplace
	expression RangeStart = #date(2012, 9, 12) meta [IsParameterQuery=true, Type="DateTime", IsParameterQueryRequired=true]
		lineageTag: e11bb4b2-53ed-432a-86af-b4f7bc13d528

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = DateTimeZone
`;
// RangeStart

// Test case: RangeStart with "datetime" type (should pass - correct type)
const rangeStartPass = `
   createOrReplace
	expression RangeStart = #datetime(2012, 9, 12, 0, 0, 0) meta [IsParameterQuery=true, Type="DateTime", IsParameterQueryRequired=true]
		lineageTag: e11bb4b2-53ed-432a-86af-b4f7bc13d528

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = DateTimeZone
`;

// Test case: RangeEnd with "date" type (should fail - should use datetime instead)
const rangeEndFail = `
   createOrReplace
	expression RangeStart = #datetimezone(2012, 9, 12, 0, 0, 0, -4, 0) meta [IsParameterQuery=true, Type="DateTimeZone", IsParameterQueryRequired=true]
		lineageTag: e11bb4b2-53ed-432a-86af-b4f7bc13d528

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = DateTimeZone
`;

// Test case: RangeEnd with "datetime" type (should pass - correct type)
const rangeEndPass = `
	expression RangeStart = #datetime(2012, 9, 12, 0, 0, 0) meta [IsParameterQuery=true, Type="DateTime", IsParameterQueryRequired=true]
		lineageTag: e11bb4b2-53ed-432a-86af-b4f7bc13d528

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = DateTimeZone
`;

// Test case: RangeEnd with "datetimezone" type (should fail - should use datetime instead)
const rangeEndFailDTZ = `createOrReplace

	model Model
		culture: en-US
		defaultPowerBIDataSourceVersion: powerBI_V3
		sourceQueryCulture: en-US
		dataAccessOptions
			legacyRedirects
			returnErrorValuesAsNull

		table Table
			lineageTag: 632741b6-9efe-426c-a22f-6dea7f8daaba

			column Column1
				dataType: string
				lineageTag: 1439de02-e044-40f3-a38e-fe0372f2490d
				summarizeBy: none
				sourceColumn: Column1

				annotation SummarizationSetBy = Automatic

			partition Table = m
				mode: import
				source =
						let
						    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i44FAA==", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [Column1 = _t]),
						    #"Changed Type" = Table.TransformColumnTypes(Source,{{"Column1", type text}})
						in
						    #"Changed Type"

			annotation PBI_ResultType = Table

		cultureInfo en-US

			linguisticMetadata = {"Version":"1.0.0","Language":"en-US"}
				contentType: json

		expression RangeEnd = #datetimezone(2012, 9, 12, 0, 0, 0, -4, 0) meta [IsParameterQuery=true, Type="DateTimeZone", IsParameterQueryRequired=true]
			lineageTag: e11bb4b2-53ed-432a-86af-b4f7bc13d528

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = DateTimeZone

		annotation __PBI_TimeIntelligenceEnabled = 0

		annotation PBI_QueryOrder = ["RangeStart","Table"]

		annotation PBI_ProTooling = ["TMDLView_Desktop"]

`;

// Test case: RangeStart with "datetimezone" type (should fail - should use datetime instead)
const rangeStartFailDTZ = `createOrReplace

	expression RangeStart = #datetimezone(2012, 9, 12, 0, 0, 0, -4, 0) meta [IsParameterQuery=true, Type="DateTimeZone", IsParameterQueryRequired=true]
		lineageTag: e11bb4b2-53ed-432a-86af-b4f7bc13d528

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = DateTimeZone

`;

// Test case: Query that uses RangeStart/RangeEnd in filtering (should pass - no false positives)
const avoidFalsePositive = `let
    Source = Upstream,

    // Filters rows by created date to keep records in the specified range
    #"Filtered Rows By Created Date Range" = Table.SelectRows(Source, each [Created] >= RangeStart and RangeEnd >= [Created])

    in #"Filtered Rows By Created Date Range"`