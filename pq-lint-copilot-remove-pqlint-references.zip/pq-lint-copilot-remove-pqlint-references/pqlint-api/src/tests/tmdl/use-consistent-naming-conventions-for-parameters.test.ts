import { useConsistentNamingConventionsForParameters } from 'src/lint/tmdl/use-consistent-naming-conventions-for-parameters';
import { RuleResult } from 'src/lint/rule-types';
import { tmdlCodeSample1 } from '../hardcoded-tmdl';
import { lintTMDLCode } from 'src/lint/linter-module';
import * as fs from 'fs';
import * as path from 'path';

const _TMDL_With_Non_Standard_Parameters_DataFilePath = path.resolve('./test-files/tmdl_with_non_standard_parameters.tmdl');
const _TMDL_With_Standard_Parameters_DataFilePath = path.resolve('./test-files/tmdl_with_standard_parameters.tmdl');
const _TMDL_With_One_Non_Standard_Parameters_DataFilePath = path.resolve('./test-files/tmdl_with_one_non_standard_parameters.tmdl');

describe('useConsistentNamingConventionsForParameters ', () => {
    it('should return an error for TMDL with non standard parameters', async () => {
		const fileContent = fs.readFileSync(_TMDL_With_Non_Standard_Parameters_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [useConsistentNamingConventionsForParameters],[],true);
        expect(errors.length).toBe(3); // Expect no errors for functions with standard prefixes
		expect(errors[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(86);
		expect(errors[1].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(93);
		expect(errors[2].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(100);
    }); // end it 

    it('should return an error for TMDL with standard parameters', async () => {
		const fileContent = fs.readFileSync(_TMDL_With_Standard_Parameters_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [useConsistentNamingConventionsForParameters],[],true);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it 
	
    it('should return an error for TMDL with one non-standard parameter', async () => {
		const fileContent = fs.readFileSync(_TMDL_With_One_Non_Standard_Parameters_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [useConsistentNamingConventionsForParameters],[],true);
        expect(errors.length).toBe(1); // Expect no errors for functions with standard prefixes
		expect(errors[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(93);
    }); // end it 	

    it('should return an error for TMDL with non standard parameters from hardcoded sample tmdl_DBX_Test_Pass', async () => {
        const errors: RuleResult[] = await lintTMDLCode(tmdl_DBX_Test_Pass,[], [useConsistentNamingConventionsForParameters],[],true);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    });
});

const tmdl_DBX_Test_Pass = `createOrReplace

	model Model
		culture: en-US
		defaultPowerBIDataSourceVersion: powerBI_V3
		sourceQueryCulture: en-US
		dataAccessOptions
			legacyRedirects
			returnErrorValuesAsNull

		cultureInfo en-US

			linguisticMetadata = {"Version":"1.0.0","Language":"en-US"}
				contentType: json

		expression DBX_URL = "adb-123.azuredatabricks.net" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]
			lineageTag: c12f645d-9686-41bb-9aa3-7658bf7c2727

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Text

		expression WorkspaceID = "9658004c-8083-4630-a7f4-3cb30c95db23" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]
			lineageTag: 6eee3616-a008-4b10-b92e-b3ec485cfcc8

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Text

		annotation __PBI_TimeIntelligenceEnabled = 0

		annotation PBI_QueryOrder = ["DBX_URL","WorkspaceID"]
`