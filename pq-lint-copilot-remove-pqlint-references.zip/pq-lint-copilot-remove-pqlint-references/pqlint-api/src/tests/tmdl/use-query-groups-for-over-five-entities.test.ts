import { useQueryGroupsForOverFiveEntities } from 'src/lint/tmdl/use-query-groups-for-over-five-entities';
import { RuleResult } from 'src/lint/rule-types';
import { tmdlCodeSample1 } from '../hardcoded-tmdl';
import { lintTMDLCode } from 'src/lint/linter-module';
import * as fs from 'fs';
import * as path from 'path';

const _TMDL_with_Several_Funcs_DataFilePath = path.resolve('./test-files/tmdl_with_no_query_groups.tmdl');
const _TMDL_with_Ticks_DataFilePath = path.resolve('./test-files/tmdl_with_ticks.tmdl');

describe('useQueryGroupsForOverFiveEntities', () => {
    it('should return no errors for TMDL with one table', async () => {
        const errors: RuleResult[] = await lintTMDLCode(tmdlCodeSample1,[], [useQueryGroupsForOverFiveEntities],[]);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it

    it('should return an error for TMDL with one function ', async () => {
        const errors: RuleResult[] = await lintTMDLCode(noPrefixFunc,[], [useQueryGroupsForOverFiveEntities],[],false);
        expect(errors.length).toBe(0); // Expect no errors
    }); // end it 

    it('should return an error for TMDL with over five entities and no query groups', async () => {
		const fileContent = fs.readFileSync(_TMDL_with_Several_Funcs_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [useQueryGroupsForOverFiveEntities],[],false);
        expect(errors.length).toBe(1); // Expect no errors for functions with standard prefixes
		expect(errors[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(1); // Check if the line number is in the valid lines
    }); // end it 

    it('should return no error for TMDL with multiple query groups', async () => {
		const fileContent = fs.readFileSync(_TMDL_with_Ticks_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [useQueryGroupsForOverFiveEntities],[],false);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it 
});


// Test case for functions without standard prefixes
let noPrefixFunc = `createOrReplace

	model Model
		culture: en-US
		defaultPowerBIDataSourceVersion: powerBI_V3
		sourceQueryCulture: en-US
		dataAccessOptions
			legacyRedirects
			returnErrorValuesAsNull

		cultureInfo en-US

			linguisticMetadata = {"Version":"1.0.0","Language":"en-US"}
				contentType: json

		expression noPrefix =
				(x as number) as number =>
				let
				  y = x + 1
				in
				y
			lineageTag: a9c7ece4-bce6-4cf6-b49c-bf56fd7624ef

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Function

		annotation __PBI_TimeIntelligenceEnabled = 0

		annotation PBIDesktopVersion = 2.139.1678.0 (24.12)+2a034ab280bddf891eb7bb9ebfe6996f9c3a3196

		annotation PBI_QueryOrder = ["noPrefix"]

		annotation PBI_ProTooling = ["DevMode"]
`

