import { detectWebContentsPost } from 'src/lint/tmdl/detect-web-contents-post';
import { RuleResult } from 'src/lint/rule-types';
import { tmdlCodeSample1 } from '../hardcoded-tmdl';
import { lintTMDLCode } from 'src/lint/linter-module';
import * as fs from 'fs';
import * as path from 'path';
import { logDebug } from 'src/lint/rule-assistance';

const _TMDL_With_Several_Web_Contents_Executes_DataFilePath = path.resolve('./test-files/scan_tmdl/WebContents.tmdl');

describe('detectWebContentsPost', () => {
    it('should return no detection without Web.Contents using POST', async () => {
        const errors: RuleResult[] = await lintTMDLCode(tmdlCodeSample1,[], [detectWebContentsPost],[]);
        expect(errors.length).toBe(0); // Expect no errors for functions with standard prefixes
    }); // end it
    
    it('should return a detections with Web.Contents using POST', async () => {
		const fileContent = fs.readFileSync(_TMDL_With_Several_Web_Contents_Executes_DataFilePath, 'utf-8');
        const errors: RuleResult[] = await lintTMDLCode(fileContent,[], [detectWebContentsPost],[],true);
        logDebug('Errors:', errors);
        expect(errors.length).toBe(1); // Expect no errors for functions with standard prefixes

        errors.forEach(result => {
            expect(result.ErrorInformation.errorLocation.positionStart).toBeDefined();
            expect(result.ErrorInformation.errorLocation.positionEnd).toBeDefined();
        });  		
        // Check if the error location is correct
        expect(errors[0].ErrorInformation.errorLocation.positionStart.lineNumber).toBe(261);
		
    }); // end it	    
});