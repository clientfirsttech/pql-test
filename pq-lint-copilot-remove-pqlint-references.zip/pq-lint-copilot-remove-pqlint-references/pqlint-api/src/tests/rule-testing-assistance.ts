import { ParseResult } from 'src/parser/pq/parse-types';
import { extractNamedExpressionMCode, extractPartitionMCode, Partition } from 'src/lint/extract-m-code'; // Import code extraction functions
import { parsePowerQueryText } from 'src/parser/pq/parse-pq'; // Import parsing functions
import * as path from 'path';
import * as fs from 'fs';

/**
 * Reads the contents of a file at the specified path.
 * 
 * @param filePath - The path to the file to be read.
 * @returns The contents of the file as a string.
 * @throws An error if the file does not exist.
 */
function getFileContents(filePath: string): string {
    if (!fs.existsSync(filePath)) {
        throw new Error(`File not found: ${filePath}`);
    }
    return fs.readFileSync(filePath, 'utf-8');
}

/**
 * Helper function to parse the code.
 * 
 * @param filePath - The path to the file to be parsed.
 * @returns A promise that resolves to the parsed result.
 */
export async function parseHelperForFunctions(filePath: string): Promise<ParseResult> {
    // Get Contents
    const fileContents = getFileContents(filePath);
    // Parse the code using the parsePowerQueryText function
    let parsedCode: ParseResult = await parsePowerQueryText(fileContents);

    // Check for parsing errors
    if (parsedCode.error !== null) {
        throw new Error(`Error parsing code: ${parsedCode.error}`);
    }

    // Save the parsed code to a file
    const parsedFilePath = path.join(__dirname, 'parsed_files', path.basename(filePath) + '.parsed');
    fs.mkdirSync(path.dirname(parsedFilePath), { recursive: true });
    fs.writeFileSync(parsedFilePath, JSON.stringify(parsedCode, null, 2));

    return parsedCode;
}

/**
 * Helper function to parse the code.
 * 
 * @param filePath - The path to the file to be parsed.
 * @returns A promise that resolves to the parsed result.
 */
export async function parseHelper(filePath: string): Promise<ParseResult> {
    let code: any = '';
    // Get Contents
    const fileContent = fs.readFileSync(filePath, 'utf-8');
    // Extract named expressions and partitions from the code
    if (filePath.endsWith('expressions.tmdl')) {
        code = extractNamedExpressionMCode(fileContent);
    } else {
        // Other extraction logic
        code = extractPartitionMCode(fileContent);
    }
    
    // Parse the code using the parsePowerQueryText function
    let parsedCode: ParseResult = await parsePowerQueryText(code[0].mCode);

    // Check for parsing errors
    if (parsedCode.error !== null) {
        throw new Error(`Error parsing code: ${parsedCode.error}`);
    }

    // Save the parsed code to a file
    const parsedFilePath = path.join(__dirname, 'parsed_files', path.basename(filePath) + '.parsed');
    fs.mkdirSync(path.dirname(parsedFilePath), { recursive: true });
    fs.writeFileSync(parsedFilePath, JSON.stringify(parsedCode, null, 2));

    return parsedCode;
}

/**
 * Load environment variables from local.settings.json and return API credentials
 * @returns Object containing endpoint and apiKey for Azure OpenAI
 */
export function loadApiCredentials(): { endpoint: string; apiKey: string } {
    const localSettingsPath = path.resolve(__dirname, "../../local.settings.json");
    if (fs.existsSync(localSettingsPath)) {
        const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, "utf8"));
        Object.entries(localSettings.Values).forEach(([key, value]) => {
            process.env[key] = value as string;
        });
    }

    return {
        endpoint: process.env.REWRITE_API_URL ?? "",
        apiKey: process.env.REWRITE_API_KEY ?? ""
    };
}

/**
 * Generic helper to test AI fixes for any linting rule
 * 
 * @param tmdlContent - TMDL content string to test
 * @param rule - The linting rule to apply
 * @param expectedViolationsBefore - Expected number of violations before fixing
 * @param options - Optional configuration
 * @returns Promise that resolves when test is complete
 */
export async function testAIFix(
    tmdlContent: string,
    rule: any,
    expectedViolationsBefore: number,
    options?: {
        debug?: boolean;
        skipLineNumberCheck?: boolean;
        fileName?: string;
    }
): Promise<void> {
    const { endpoint, apiKey } = loadApiCredentials();
    
    // Write TMDL content to a temporary file for parsing/debugging (optional)
    const fileName = options?.fileName ?? 'temp-test';
    const tempOriginalPath = path.resolve(`./test-files/test-output/temp-${fileName}.tmdl`);
    fs.writeFileSync(tempOriginalPath, tmdlContent, 'utf8');

    try {
        // Use lintTMDLCode to find violations (lint across the whole TMDL)
        const { lintTMDLCode } = await import('src/lint/linter-module');
        const results = await lintTMDLCode(tmdlContent, [rule], [], [], options?.debug ?? false, false);
        
        if (expectedViolationsBefore !== results.length) {
            throw new Error(`Expected ${expectedViolationsBefore} violations but found ${results.length}`);
        }

        // Use AI to fix the violations in the TMDL content
        const { fixTMDL } = await import('pqlint-api/src/rewrite/fix-tmdl');
        const fixedTMDL = await fixTMDL(
            endpoint,
            apiKey,
            results,
            tmdlContent,
            { debug: options?.debug ?? false, stream: false }
        );

        // Write the fixed TMDL to a temporary file for parsing
        const tempFixedPath = path.resolve(`./test-files/test-output/temp-fixed-${fileName}.tmdl`);
        fs.writeFileSync(tempFixedPath, fixedTMDL, 'utf8');

        try {
            // Lint the fixed TMDL file content to verify violations are resolved
            const results_again = await lintTMDLCode(fixedTMDL, [rule], [], [], options?.debug ?? false, false);
            
            // Verify all violations are resolved
            if (results_again.length !== 0) {
                throw new Error(`Expected 0 violations after fix but found ${results_again.length}`);
            }
            
            // Verify that each original violation line number does not appear in results_again
            if (!options?.skipLineNumberCheck) {
                results.forEach(originalResult => {
                    const originalLineNumber = originalResult.ErrorInformation.errorLocation.positionStart.lineNumber;
                    const stillExists = results_again.some(newResult => 
                        newResult.ID === originalResult.ID &&
                        newResult.ErrorInformation.errorLocation.positionStart.lineNumber === originalLineNumber
                    );
                    if (stillExists) {
                        throw new Error(`Violation at line ${originalLineNumber} still exists after fix`);
                    }
                });
            }

            // Validate that all M code blocks in the fixed TMDL can be parsed without errors
            const { extractMCodeAndProperties } = await import('src/parser/tmdl/tmdl-parser');
            const extractedData = extractMCodeAndProperties(fixedTMDL);
            
            let parseErrorCount = 0;
            const parseErrors: string[] = [];
            
            for (let index = 0; index < extractedData.length; index++) {
                const item = extractedData[index];
                
                // Only validate non-calculated items with code
                if (item.properties.isCalculated === false && item.code) {
                    try {
                        const parseResult = await parsePowerQueryText(item.code);
                        
                        // Check if parse result indicates an error
                        if (!parseResult || parseResult.error) {
                            parseErrorCount++;
                            const errorMsg = `Parse error in ${item.resultType} '${item.name}' at line ${item.lineNumber}`;
                            parseErrors.push(errorMsg);
                            if (options?.debug) {
                                console.error(`✗ ${errorMsg}`);
                                if (parseResult?.error) {
                                    console.error('Error details:', JSON.stringify(parseResult.error, null, 2));
                                }
                            }
                        } else if (options?.debug) {
                            console.log(`✓ ${item.resultType} '${item.name}' parsed successfully`);
                        }
                    } catch (err) {
                        parseErrorCount++;
                        const errorMsg = `Parse exception in ${item.resultType} '${item.name}' at line ${item.lineNumber}: ${err instanceof Error ? err.message : String(err)}`;
                        parseErrors.push(errorMsg);
                        if (options?.debug) {
                            console.error(`✗ ${errorMsg}`);
                            console.error(`Problematic code:\n${item.code.substring(0, 300)}...`);
                        }
                    }
                }
            }
            
            // Throw error if any parse errors were found
            if (parseErrorCount > 0) {
                throw new Error(`Found ${parseErrorCount} parse error(s) in fixed TMDL:\n${parseErrors.join('\n')}`);
            }
            
            if (options?.debug) {
                console.log(`✓ All ${extractedData.length} M code blocks parsed successfully without errors`);
            }
        } finally {
            // Clean up fixed temporary file
            if (fs.existsSync(tempFixedPath)) {
                //fs.unlinkSync(tempFixedPath);
            }
        }
    } finally {
        // Clean up original temporary file
        if (fs.existsSync(tempOriginalPath)) {
            //fs.unlinkSync(tempOriginalPath);
        }
    }
}