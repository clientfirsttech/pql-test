import { BlobServiceClient } from "@azure/storage-blob";
import { JobStatus } from 'src/helpers/queue-types';

/**
 * Writes a job status and result to the result container blob.
 * Tracks and logs any errors during the upload process.
 * @param resultContainer The Azure Blob container client for results.
 * @param jobStatus The job status object to write.
 */
export async function writeJobStatus(
  resultContainer: ReturnType<BlobServiceClient["getContainerClient"]>,
  jobStatus: JobStatus,
): Promise<void> {
  const resultBlob = resultContainer.getBlockBlobClient(`${jobStatus.jobId}.json`);
  try {
    // Try to read the existing status first
    let existingStatus: JobStatus = {jobId: jobStatus.jobId, status: jobStatus.status, updatedAt: new Date().toISOString()};
    try {
      const downloadResponse = await resultBlob.download();
      const downloaded = await streamToString(downloadResponse.readableStreamBody ?? null);
      existingStatus = JSON.parse(downloaded) as JobStatus;
    } catch (readError) {
      // If not found, proceed with empty object (new upsert)
      existingStatus = {jobId: jobStatus.jobId, status: jobStatus.status, updatedAt: new Date().toISOString()};
    }

    // Merge properties: keep existing non-null, update with new non-null
    const mergedStatus: JobStatus = { ...existingStatus };
    for (const key of Object.keys(jobStatus)) {
      const value = (jobStatus as any)[key];
      if (value !== null && value !== undefined) {
        (mergedStatus as any)[key] = value;
      }
    }

    await resultBlob.uploadData(
      Buffer.from(JSON.stringify(mergedStatus), "utf-8")
    );
  } catch (error) {
    // Log the error for diagnostics
    console.error(`Failed to write job status for jobId ${jobStatus.jobId}:`, error);
    // Optionally, you could add more error handling or alerting here
  }
}

/**
 * Reads a job status from the result container blob.
 * @param resultContainer The Azure Blob container client for results.
 * @param jobId The job ID to read status for.
 * @returns The JobStatus object, or null if not found or error occurs.
 */
export async function readJobStatus(
  resultContainer: ReturnType<BlobServiceClient["getContainerClient"]>,
  jobId: string
): Promise<JobStatus | null> {
  const resultBlob = resultContainer.getBlockBlobClient(`${jobId}.json`);
  try {
    const downloadResponse = await resultBlob.download();
    const downloaded = await streamToString(downloadResponse.readableStreamBody ?? null);
    return JSON.parse(downloaded) as JobStatus;
  } catch (error) {
    console.error(`Failed to read job status for jobId ${jobId}:`, error);
    return null;
  }
}

/**
 * Helper function to convert a readable stream to a string.
 */
async function streamToString(stream: NodeJS.ReadableStream | null): Promise<string> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    if (!stream) return resolve("");
    stream.on("data", (data) => chunks.push(Buffer.from(data)));
    stream.on("end", () => resolve(Buffer.concat(chunks).toString("utf-8")));
    stream.on("error", reject);
  });
}