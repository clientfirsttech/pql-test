import { EventHubProducerClient } from "@azure/event-hubs";

/**
 * Sends an event to Azure Event Hub.
 *
 * This function creates an EventHubProducerClient, creates a batch, adds the event data,
 * and sends the batch to the specified Event Hub. It handles errors and ensures the client is closed.
 *
 * @param eventData - The data to send as an event (any serializable object).
 * @param connectionString - The connection string for the Azure Event Hub namespace.
 * @param eventHubName - The name of the Event Hub to send the event to.
 * @returns Promise<void>
 */
export async function sendEventToEventHub(eventData: any, connectionString: string, eventHubName: string) {
    const producer = new EventHubProducerClient(connectionString, eventHubName);

    try {
        // Create a batch of events
        const batch = await producer.createBatch();
        batch.tryAdd({ body: eventData }); // Add event data to the batch

        // Send the batch to Event Hub
        await producer.sendBatch(batch);
    } catch (error) {
        // Handle errors during event sending
        console.error("Error sending event:", error);
    } finally {
        // Close the producer client
        await producer.close();
    }
}

/**
 * Interface representing details of an API request for logging or auditing.
 */
export interface RequestDetails {
    requestId: string; // GUID for the request
    function: string; // Function name (e.g., Azure Function name)
    method: string; // HTTP method (GET, POST, etc.)
    ipAddress: string; // IP address of the sender
    emailAddress?: string; // Email address of the sender (optional)
    utcDate: string;   // UTC date of the request in ISO format
    licenseLevel: string; // License level (Free or Pro)
    environment: string; // Environment (Development or Production)
    code?: string; // Payload (optional)
}

/**
 * Interface representing details of an API request with a subscription key for logging or auditing.
 */
export interface APIRequestDetails {
    requestId: string; // GUID for the request
    function: string; // Function name (e.g., Azure Function name)
    method: string; // HTTP method (GET, POST, etc.)
    ipAddress: string; // IP address of the sender
    subscriptionId: string; // Subscription Id of the sender
    apiProductId: string; // API Product Id of the sender
    utcDate: string;   // UTC date of the request in ISO format
    environment: string; // Environment (Development or Production)
    code?: string; // Payload (optional)
}

/**
 * Interface representing details of an API response for logging or auditing.
 */
export interface ResponseDetails {
    requestDetails: RequestDetails; // Details of the request
    statusCode: number; // HTTP status code of the response
    responseBody: string; // Response body
    errorMessage?: string; // Error message if any
    utcDate?: string; // UTC date of the response in ISO format
}

/**
 * Interface representing details of an API response with a subscription key for logging or auditing.
 */
export interface APIResponseDetails {
    requestDetails: APIRequestDetails; // Details of the request
    statusCode: number; // HTTP status code of the response
    responseBody: string; // Response body
    errorMessage?: string; // Error message if any
    utcDate?: string; // UTC date of the response in ISO format
}