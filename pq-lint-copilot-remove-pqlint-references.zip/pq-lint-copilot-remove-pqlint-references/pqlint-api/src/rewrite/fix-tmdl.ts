import { AzureOpenAI } from "openai";
import { RuleResult } from 'src/lint/rule-types';
import { TMDL_LANGUAGE } from "./rewrite-prompts";
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { logDebug } from 'src/lint/rule-assistance';
import { ChatCompletionMessageParam } from "openai/resources/chat";
import * as fs from "fs";
import * as path from "path";
import { getRulesAsJson } from 'src/lint/all-rules';

/**
 * Callback for streaming chunks of content
 */
export interface StreamCallback {
    onStatus?: (message: string) => void;
    onBatchStatus?: (current: number, total: number) => void;
    onDelta?: (content: string) => void;
    onError?: (message: string) => void;
}

/**
 * Build rule groups with AIFix instructions from lint results
 * 
 * @param lintRulesResults - Array of lint rule results
 * @returns Map of rule groups with consolidated lines and AIFix instructions
 */
export function buildRuleGroups(lintRulesResults: RuleResult[]): Map<string, { rule: RuleResult, lines: string[], aiFixInstructions: any }> {
    // Filter applicable rules that request AI fixes
    const applicableRules = lintRulesResults.filter(r => 
        (r as any)?.AIFixInstructions && (r as any).AIFixInstructions.IsActive === true
    );

    const ruleGroups = new Map<string, { rule: RuleResult, lines: string[], aiFixInstructions: any }>();

    if (!applicableRules || applicableRules.length === 0) {
        return ruleGroups;
    }

    // Build a map of rule definitions (by ID) to get AIFixInstructions and Prompts
    const rulesJson = getRulesAsJson(true); // include prompts
    const ruleDefMap = new Map<string, any>();
    rulesJson.forEach((r: any) => {
        if (r && r.ID) {
            ruleDefMap.set(r.ID, r);
        }
    });

    // Build prompt entries for each applicable rule, consolidating by rule ID
    applicableRules.forEach(rule => {
        const ruleId = rule.ID;
        const line = rule.ErrorInformation?.errorLocation?.positionStart?.lineNumber?.toString() ?? "unknown";
        logDebug(`Processing rule ${ruleId} at line ${line}`);
        if (ruleGroups.has(ruleId)) {
            ruleGroups.get(ruleId)!.lines.push(line);
        } else {
            // Lookup AIFix instructions from the rule definition map (includes Prompt)
            const ruleDef = ruleDefMap.get(ruleId);
            logDebug(`Found rule definition for ${ruleId}:`, ruleDef);
            logDebug(`AIFixInstructions for ${ruleId}:`, ruleDef?.AIFixInstructions);
            const aiFixInstructions = ruleDef?.AIFixInstructions || { Prompt: "", Description: "", IsActive: false };
            ruleGroups.set(ruleId, { rule, lines: [line], aiFixInstructions });
        }
    });

    return ruleGroups;
}

/**
 * Build AI fix prompts from rule groups
 * 
 * @param ruleGroups - Map of rule groups with consolidated lines and AIFix instructions
 * @returns Array of formatted prompt strings
 */
export function buildPromptsFromRuleGroups(ruleGroups: Map<string, { rule: RuleResult, lines: string[], aiFixInstructions: any }>): string[] {
    const regularPrompts: string[] = [];
    const wholeQueryPrompts: string[] = [];
    
    Array.from(ruleGroups.values()).forEach(group => {
        const isWholeQueryFix = group.aiFixInstructions?.IsWholeQueryFix === true;
        const linesText = isWholeQueryFix ? "for the entirety of the code" : group.lines.join(", ");
        const rulePrompt = group.aiFixInstructions?.Prompt ?? "";
        const prompt = `Rule ${group.rule.ID} (${group.rule.Name}) at line${isWholeQueryFix ? 's' : (group.lines.length > 1 ? 's' : '')} ${linesText}:\n${rulePrompt}`;
        
        if (isWholeQueryFix) {
            wholeQueryPrompts.push(prompt);
        } else {
            regularPrompts.push(prompt);
        }
    });
    
    return [...regularPrompts, ...wholeQueryPrompts];
}

/**
 * Use AI to fix TMDL code based on lint rule results that include prompts.
 * Now supports HTTP streaming when stream option is enabled.
 * 
 * @param endpoint - Azure OpenAI endpoint URL
 * @param apiKey - Azure OpenAI API key
 * @param lintRulesResults - Array of lint rule results that include AIFixInstructions prompts
 * @param tmdlCode - Original TMDL code to be fixed
 * @param options - Optional configuration
 * @returns Promise<string> - Fixed TMDL code OR AsyncGenerator for HTTP streaming
 */
export async function fixTMDL(
    endpoint: string, 
    apiKey: string, 
    lintRulesResults: RuleResult[], 
    tmdlCode: string, 
    options?: {
        debug?: boolean;
        stream?: boolean;
        streamCallback?: StreamCallback;
    }
): Promise<string> {
    // If streaming is enabled, delegate to streaming generator
    if (options?.stream) {
        let result = '';
        for await (const chunk of fixTMDLStream(endpoint, apiKey, lintRulesResults, tmdlCode, options)) {
            result += chunk;
            
            // Call legacy callback for backward compatibility
            if (options.streamCallback?.onDelta) {
                options.streamCallback.onDelta(chunk);
            }
        }
        return result;
    }
    
    // Non-streaming mode
    return fixTMDLNonStream(endpoint, apiKey, lintRulesResults, tmdlCode, options);
}

/**
 * Async generator for HTTP streaming TMDL fixes
 * Yields raw content chunks directly for HTTP streaming
 */
export async function* fixTMDLStream(
    endpoint: string, 
    apiKey: string, 
    lintRulesResults: RuleResult[], 
    tmdlCode: string, 
    options?: {
        debug?: boolean;
        streamCallback?: StreamCallback;
    }
): AsyncGenerator<string> {
    const apiVersion = process.env.REWRITE_API_VERSION || "2025-01-01-preview";
    const deployment = process.env.REWRITE_DEPLOYMENT_MODEL || "gpt-4o-mini";
    const maxCompletionTokens = parseInt(process.env.REWRITE_MAX_COMPLETION_TOKENS || "100000", 10);
    const debug = options?.debug ?? false;

    if (!endpoint || !apiKey) {
        yield ''; // Yield empty on error for HTTP streaming
        return;
    }

    if (!tmdlCode) {
        yield '';
        return;
    }

    if (!lintRulesResults || lintRulesResults.length === 0) {
        yield tmdlCode; // Yield original code directly
        return;
    }

    const client = new AzureOpenAI({ endpoint, apiKey, apiVersion, deployment });
    let currentCode = tmdlCode;

    try {
        const ruleGroups = buildRuleGroups(lintRulesResults);

        if (ruleGroups.size === 0) {
            yield currentCode;
            return;
        }

        const promptEntries = buildPromptsFromRuleGroups(ruleGroups);

        // Create batches based on token limits
        const systemTokens = Math.ceil((TMDL_LANGUAGE.length) / 4);
        const codeTokens = Math.ceil((currentCode.length * 2) / 4);
        const baseTokens = systemTokens + codeTokens;
        const availableTokens = maxCompletionTokens - baseTokens - 1000;

        if (availableTokens <= 0) {
            yield '';
            return;
        }

        const batches: string[][] = [];
        let currentBatch: string[] = [];
        let currentBatchTokens = 0;
        
        for (const prompt of promptEntries) {
            const promptTokens = Math.ceil((prompt.length * 2) / 4);
            
            if (currentBatch.length > 0 && (currentBatchTokens + promptTokens > availableTokens)) {
                batches.push(currentBatch);
                currentBatch = [prompt];
                currentBatchTokens = promptTokens;
            } else {
                currentBatch.push(prompt);
                currentBatchTokens += promptTokens;
            }
        }
        
        if (currentBatch.length > 0) {
            batches.push(currentBatch);
        }

        // Process each batch and stream results
        for (let batchIndex = 0; batchIndex < batches.length; batchIndex++) {
            const batch = batches[batchIndex];
            const allPrompts = batch.join("\n\n---\n\n");

            if (options?.streamCallback?.onBatchStatus) {
                options.streamCallback.onBatchStatus(batchIndex + 1, batches.length);
            }

            const userContent = [
                "Apply fixes for the following prompts. For each prompt, update the provided TMDL code so the prompt is resolved.",
                "Do not add explanations — only return the TMDL code using createOrReplace where applicable.",
                "Do not alter any existing comments unless the prompt explicitly requires it.",
                "",
                "Prompts:",
                allPrompts,
                "",
                "TMDL Code:",
                "~~~",
                currentCode,
                "~~~",
                "Apply all the fixes and return the updated TMDL code."
            ].join("\n");

            if (debug) logDebug(`Calling AI for batch ${batchIndex + 1}/${batches.length}`);

            // Stream AI response chunks directly
            let accumulatedBatchCode = '';
            for await (const chunk of getAzureOpenAIResponseStream(
                client,
                TMDL_LANGUAGE,
                userContent,
                deployment,
                maxCompletionTokens
            )) {
                accumulatedBatchCode += chunk;
                yield chunk; // Yield raw delta content for HTTP streaming
            }

            currentCode = accumulatedBatchCode.replace(/^~~~|~~~$/g, '').trim();
        }

        // Validate final result
        try {
            await parsePowerQueryText(currentCode);
        } catch (err) {
            if (debug) logDebug('Generated code failed validation', err);
        }

    } catch (err) {
        if (debug) logDebug('Error in fixTMDLStream', err);
        yield '';
    }
}

/**
 * Non-streaming version for backward compatibility
 */
async function fixTMDLNonStream(
    endpoint: string, 
    apiKey: string, 
    lintRulesResults: RuleResult[], 
    tmdlCode: string, 
    options?: {
        debug?: boolean;
        streamCallback?: StreamCallback;
    }
): Promise<string> {
    const apiVersion = process.env.REWRITE_API_VERSION || "2025-01-01-preview";
    const deployment = process.env.REWRITE_DEPLOYMENT_MODEL || "gpt-4o-mini";
    const maxCompletionTokens = parseInt(process.env.REWRITE_MAX_COMPLETION_TOKENS || "100000", 10);
    const debug = options?.debug ?? false;
    const callback = options?.streamCallback;

    if (!endpoint || !apiKey) {
        throw new Error("AI endpoint and API key are required.");
    }

    if (!tmdlCode) {
        throw new Error("Power Query code must be provided.");
    }

    if (!lintRulesResults || lintRulesResults.length === 0) {
        return tmdlCode;
    }

    const client = new AzureOpenAI({ endpoint, apiKey, apiVersion, deployment });
    let currentCode = tmdlCode;

    try {
        const ruleGroups = buildRuleGroups(lintRulesResults);

        if (ruleGroups.size === 0) {
            return currentCode;
        }

        const promptEntries = buildPromptsFromRuleGroups(ruleGroups);

        if (debug) logDebug(`Processing ${promptEntries.length} consolidated prompts`);
        if (callback?.onStatus) callback.onStatus(`Processing ${promptEntries.length} rules...`);

        // Create batches based on token limits
        const systemTokens = Math.ceil((TMDL_LANGUAGE.length) / 4);
        const codeTokens = Math.ceil((currentCode.length * 2) / 4);
        const baseTokens = systemTokens + codeTokens;
        const availableTokens = maxCompletionTokens - baseTokens - 1000;

        if (availableTokens <= 0) {
            throw new Error("Code is too large to process with current token limits");
        }

        const batches: string[][] = [];
        let currentBatch: string[] = [];
        let currentBatchTokens = 0;
        
        for (const prompt of promptEntries) {
            const promptTokens = Math.ceil((prompt.length * 2) / 4);
            
            if (currentBatch.length > 0 && (currentBatchTokens + promptTokens > availableTokens)) {
                batches.push(currentBatch);
                currentBatch = [prompt];
                currentBatchTokens = promptTokens;
            } else {
                currentBatch.push(prompt);
                currentBatchTokens += promptTokens;
            }
        }
        
        if (currentBatch.length > 0) {
            batches.push(currentBatch);
        }
        
        if (debug) logDebug(`Split into ${batches.length} batches based on token limits`);

        // Process each batch sequentially
        for (let batchIndex = 0; batchIndex < batches.length; batchIndex++) {
            const batch = batches[batchIndex];
            const allPrompts = batch.join("\n\n---\n\n");

            if (callback?.onBatchStatus) {
                callback.onBatchStatus(batchIndex + 1, batches.length);
            }

            const userContent = [
                "Apply fixes for the following prompts. For each prompt, update the provided TMDL code so the prompt is resolved.",
                "Do not add explanations — only return the TMDL code using createOrReplace where applicable.",
                "Do not alter any existing comments unless the prompt explicitly requires it.",
                "",
                "Prompts:",
                allPrompts,
                "",
                "TMDL Code:",
                "~~~",
                currentCode,
                "~~~",
                "Apply all the fixes and return the updated TMDL code."
            ].join("\n");

            // Save prompt if debugging
            if (debug) {
                try {
                    const outDir = path.resolve("./src/test-files/test-output/fixed_files");
                    fs.mkdirSync(outDir, { recursive: true });
                    const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
                    const outPath = path.join(outDir, `tmdl_batch_${batchIndex + 1}_prompt_${timestamp}.txt`);
                    fs.writeFileSync(outPath, userContent, "utf8");
                    logDebug(`Saved TMDL batch ${batchIndex + 1} prompt to: ${outPath}`);
                } catch (ioErr) {
                    console.error("Failed to save TMDL prompt to fixed_files:", ioErr);
                }
            }

            if (debug) logDebug(`Calling AI for batch ${batchIndex + 1}/${batches.length}`);

            const returned = await getAzureOpenAIResponse(
                client,
                TMDL_LANGUAGE,
                userContent,
                deployment,
                maxCompletionTokens,
                false,
                callback,
                debug
            );

            const cleaned = returned.replace(/^~~~|~~~$/g, '').trim();
            currentCode = cleaned;

            if (debug) {
                logDebug(`Updated code after batch ${batchIndex + 1} AI fixes:`);
                logDebug(currentCode);
            }
        }
    } catch (err) {
        console.error("Error calling AI for batched prompts:", err);
        if (callback?.onError) {
            callback.onError(err instanceof Error ? err.message : 'Internal error occurred');
        }
        throw err;
    }
    
    // Validate the final result
    try {
        await parsePowerQueryText(currentCode);
    } catch (err) {
        console.error("Parsed result indicates invalid Power Query after AI edits:", err);
        if (callback?.onError) {
            callback.onError('Generated code failed validation');
        }
        throw err;
    }

    return currentCode;
}

/**
 * Stream Azure OpenAI response as async generator for HTTP streaming
 */
async function* getAzureOpenAIResponseStream(
    client: AzureOpenAI, 
    systemContent: string,
    userContent: string,
    deployment: string, 
    maxCompletionTokens: number
): AsyncGenerator<string> {
    const systemMsg = { role: "system", content: systemContent } as ChatCompletionMessageParam;
    const userMsg = { role: "user", content: userContent } as ChatCompletionMessageParam;
    const messages: ChatCompletionMessageParam[] = [systemMsg, userMsg];
    
    while (true) {
        const streamResponse = await client.chat.completions.create({
            model: deployment,
            messages: messages,
            max_completion_tokens: maxCompletionTokens,
            temperature: .2,
            top_p: 1,
            frequency_penalty: 0,
            presence_penalty: 0,
            stream: true,
        });

        let assistantReply = "";
        let finishReason = "";

        for await (const chunk of streamResponse) {
            const delta = chunk.choices[0]?.delta?.content || '';
            const reason = chunk.choices[0]?.finish_reason;
            
            if (delta) {
                assistantReply += delta;
                yield delta; // Yield each delta chunk for HTTP streaming
            }
            
            if (reason) {
                finishReason = reason;
            }
        }

        if (!assistantReply) {
            throw new Error("No content returned from Azure OpenAI.");
        }

        if (finishReason !== 'length') {
            break;
        }

        messages.push({ role: "assistant", content: assistantReply });
        messages.push({ role: "user", content: "Continue from where you left off." });
    }
}

/**
 * Get complete response from Azure OpenAI (non-streaming)
 */
async function getAzureOpenAIResponse(
    client: AzureOpenAI, 
    systemContent: string,
    userContent: string,
    deployment: string, 
    maxCompletionTokens: number,
    stream: boolean,
    callback?: StreamCallback,
    debug: boolean = false
): Promise<string> {
    const systemMsg = { role: "system", content: systemContent } as ChatCompletionMessageParam;
    const userMsg = { role: "user", content: userContent } as ChatCompletionMessageParam;
    const messages: ChatCompletionMessageParam[] = [systemMsg, userMsg];
    let accumulatedResponse = "";
    
    while (true) {
        let assistantReply = "";
        let finishReason = "";

        if (stream) {
            // Streaming mode - use SDK's async iterator
            const streamResponse = await client.chat.completions.create({
                model: deployment,
                messages: messages,
                max_completion_tokens: maxCompletionTokens,
                temperature: .2,
                top_p: 1,
                frequency_penalty: 0,
                presence_penalty: 0,
                stream: true,
            });

            try {
                for await (const chunk of streamResponse) {
                    const delta = chunk.choices[0]?.delta?.content || '';
                    const reason = chunk.choices[0]?.finish_reason;
                    
                    if (delta) {
                        assistantReply += delta;
                        if (callback?.onDelta) {
                            callback.onDelta(delta);
                        }
                    }
                    
                    if (reason) {
                        finishReason = reason;
                    }
                }
            } catch (err) {
                throw new Error(`Streaming error: ${err instanceof Error ? err.message : String(err)}`);
            }
        } else {
            // Non-streaming mode
            const response = await client.chat.completions.create({
                model: deployment,
                messages: messages,
                max_completion_tokens: maxCompletionTokens,
                temperature: .2,
                top_p: 1,
                frequency_penalty: 0,
                presence_penalty: 0,
                stream: false,
            });
            
            assistantReply = response.choices[0]?.message?.content || "";
            finishReason = response.choices[0]?.finish_reason || "";
        }

        if (!assistantReply) {
            throw new Error("No content returned from Azure OpenAI.");
        }

        accumulatedResponse += assistantReply;

        if (finishReason !== 'length') {
            break;
        }

        if (debug) logDebug("Response was truncated, continuing...");

        messages.push({ role: "assistant", content: assistantReply });
        messages.push({ role: "user", content: "Continue from where you left off." });
    }

    return accumulatedResponse;
}
