import { add } from "lodash";
import { ChatCompletionMessageParam } from "openai/resources/chat";

export const Cleanup_Power_Query_Prompt: ChatCompletionMessageParam[] = [
    {
        role: "developer",
        "content": [
            {
                "type": "text",
                "text": "You are an assistant to help Power Query developers comment their code. Please make sure the response is Power Query code without syntax errors. This includes making sure no dangling comma is added"
            }
        ]
    },
    {
        role: "user",
        "content": [
            {
                "type": "text",
                "text": "Perform the following to each line denoted by ~~~:"
            },
            {
                "type": "text",
                "text": "1) Do not replace any commented code that may exist. If a comment exists before a line of code, do not add a comment above it or below it.  Otherwise, insert a comment above each line of code explaining what that piece of code is doing."
            },
            {
                "type": "text",
                "text": "2) Do not start the comment with the word Step or a number."
            },
            {
                "type": "text",
                "text": "3) Do not copy code into the comment."
            },
            {
                "type": "text",
                "text": "4) Keep the comments to a maximum of 225 characters."
            },
            {
                "type": "text",
                "text": "5) Do NOT add a comment above the 'in' keyword or the 'let' keyword explaining what the code is doing."
            },            
            {
                "type": "text",
                "text": "6) Wrap the response with ~~~ so we can identify the code."
            },
            {
                "type": "text",
                "text": "\n"
            },
            {
                "type": "text",
                "text": "Please also update each line of code by performing the following:"
            },
            {
                "type": "text",
                "text": "1) Update the variable name explaining what that piece of code is doing."
            },
            {
                "type": "text",
                "text": "2) The variable name should always start with a verb in the past tense."
            },
            {
                "type": "text",
                "text": "3) The variable name should have spaces between words."
            },
            {
                "type": "text",
                "text": "4) Please keep the variable to a maximum of 50 characters."
            },
            {
                "type": "text",
                "text": "5) The variable name should be wrapped in double quotes and preceded by the '#'."
            },
            {
                "type": "text",
                "text": "\n"
            },
            {
                "type": "text",
                "text": "The response will be parsed, so any additional text other that code will cause an error.  If the code starts with the keyword let, please make sure the response starts with the keyword let and the response could be parsed by power query."
            },
            {
                "type": "text",
                "text": "~~~"
            },
            {
                "type": "text",
                "text": "{|||PLACED_HOLDER_M|||}"
            },
            {
                "type": "text",
                "text": "~~~"
            }            
        ]
    }
];

export const Cleanup_TMDL_Prompt: ChatCompletionMessageParam[] = [
    {
        role: "developer",
        "content": [
            {
                "type": "text",
                "text": "You are an assistant to help TMDL developers optimize their code. Please make sure the response is valid TMDL code without syntax errors."
            }
        ]
    },
    {
        role: "user",
        "content": [
            {
                "type": "text",
                "text": "Given the TMDL Code denoted by ~~~ perform the following:"
            },
            {
                "type": "text",
                "text": "1. For each column value set isAvailableInMdx: false if the column is hidden, the table is hidden, and this column is not used in a hierarchy, or used by another column for by the sortByColumn property."
            },
            {
                "type": "text",
                "text": "2. For each column update to \"summarizeBy: none\" if it has a value other than none."
            },
            {
                "type": "text",
                "text": "3. If a /// comment does not exist before the column definition add a comment describing the column in less than 50 characters."
            },
            {
                "type": "text",
                "text": "4. For and tables with the prefix \"LocalDateTable_\" remove and remove all relationships identified with tables with the prefix \"LocalDateTable_\""
            },
            {
                "type": "text",
                "text": "5. Only return the TMDL script that it can be executed by another application."
            },
            {
                "type": "text",
                "text": "~~~"
            },
            {
                "type": "text",
                "text": "{|||PLACED_HOLDER_M|||}"
            },
            {
                "type": "text",
                "text": "~~~"
            }            
        ]
    }
];

export const TMDL_LANGUAGE = `
You are a AI assistant helping TMDL developers write and optimize TMDL code which include the M language.

Given the TMDL language denoted by !!! generate a TMDL script that resolves the prompts provided.  Please following these rules:

1) Return only valid TMDL text when used as a prompt context (no explanations).
2) Ensure the TMDL code can be parsed by a TMDL parser.
3) Make sure createOrReplace is the first line of the response followed by a blank line and then the TMDL code indented by one tab.
4) Do not remove any comments that exist in the TMDL code.
5) = include is not a valid TMDL syntax within an expression.  Please remove it from the TMDL code.
6) Never truncate or abridge the TMDL code as this will be linted again and processed.
7) Ensure tabs are used for indentation and not spaces.
8) For Power Query Code variable name should be wrapped in double quotes and preceded by the '#'
9) Comments are preceded by the '//' characters

!!!
TMDL language
Object declaration
Except for Server object, TMDL exposes the entire TOM Database object tree in the Microsoft.AnalysisServices.Tabular namespace.

A TMDL object is declared by specifying the TOM object type followed by its name. In the following code example, each object type: model, table, column is followed by an object name.

tmdl

Copy
model Model    
    culture: en-US    

table Sales
    
    measure Sales = SUM(…)
        formatString: $ #,##0

    column 'Customer Key'
        datatype: int64
        sourceColumn: CustomerKey

Objects like partition or measure have default properties that can be assigned after the equals (=) delimiter in the same line of the object declaration or in the following line for a multi-line expression:

tmdl

Copy
table Sales

    partition Sales-Part1 = m
        mode: import
        ...        
    
    measure Sales = SUM(…)
        formatString: $ #,##0

    measure 'Sales (ly)' = 
            var ly = ...
            return ly
        formatString: $ #,##0

The TMDL object name must be enclosed in single quotes (') if it includes any of the following characters:
- Dot (.)
- Equals (=)
- Colon (:)
- Single Quote (')
- Whitespace ( )
If an object name contains single quotes ('), use two single quotes to escape it.

Object Properties
Object properties are specified after the object declaration or object default property multi-line expression. Object property values are specified following the colon (:) delimiter. For example:

tmdl

Copy
table Sales
    lineageTag: e9374b9a-faee-4f9e-b2e7-d9aafb9d6a91    

    column Quantity
        dataType: int64
        isHidden
        isAvailableInMdx: false
        sourceColumn: Quantity

    measure 'Sales Amount' = 
            var result = SUMX(...)
            return result
  formatString: $ #,##0
  displayFolder: " My ""Amazing"" Measures"

Rules for property values:
- Value must be in the same line following the colon and cannot have multiple lines.

Text property values:
- Leading and trailing double-quotes are optional and automatically stripped during serialization.
- Must be enclosed in double quotes (") if the text contains trailing or leading whitespace.
- When enclosed in double quotes, double quotes inside the value are escaped by doubling them.

Boolean properties:
- Can be set via key/value syntax or shortcut where property name implies true (e.g. isHidden).

Named object references:
- References use object names with the same quoting/escaping rules. Fully qualified names use dot notation, e.g. 'Table 1'.'Column 1'.

Child objects:
- Child elements in scope of their parent implicitly make up collections (no explicit child collection syntax). Child objects can be intermingled and non-contiguous.

Default properties:
- Many object types have a default property (often expression). Default property values can be single-line after "=" or a multi-line expression following the header.

Expressions:
- Expressions can be single-line or multi-line. Multi-line expressions must be indented one level deeper than parent object properties.
- Vertical whitespace lines are allowed and part of the expression.
- Trailing blank lines and trailing whitespace are removed unless the expression is enclosed by triple backticks.
- When needed, use triple backticks immediately after "=" to preserve exact indentation and trailing blank lines.

Special rules for backtick-enclosed expressions:
- Everything between triple backticks is verbatim. Indentation rules are not applied inside.
- Relative indentation is retained; the ending delimiter determines left boundary.
- Default behavior: serializer encloses expressions with backticks if necessary for roundtrip safety.

Properties treated as expressions (some examples):
- Measure: Expression (DAX)
- MPartitionSource: Expression (M)
- CalculatedPartitionSource: Expression (DAX)
... (full mapping exists in spec)

Default property and expression language by object type:
- Measure: Expression (DAX)
- CalculatedColumn: Expression (DAX)
- NamedExpression: Expression (M)
- MPartitionSource: Expression (M)
... (full mapping exists in spec)

Descriptions:
- Use triple-slash (///) immediately above the object declaration for descriptions. No whitespace between description block end and object token.
- Descriptions may span lines and are wrapped at ~80 characters.

Partial declaration:
- Objects can be declared across multiple TMDL files (partial). Avoid declaring same property twice across files.

Object references (ref keyword):
- Use ref to reference objects and preserve deterministic ordering for collections (model -> ref table ...).

Property value delimiters:
- Equals (=) for default/expression properties.
- Colon (:) for non-expression properties and model references.

Indentation:
- TMDL uses single-tab indentation; strict rules indicate three levels:
  Level 1 - Object Declaration
  Level 2 - Object Properties
  Level 3 - Object property multi-line expressions
- Not following indentation causes parse errors.

Whitespace:
- Property values: leading/trailing whitespace trimmed (unless quoted or backticks used).
- Expressions: trailing whitespace lines removed (unless backticks used).

Casing:
- Serializer uses camelCase for object types, keywords, and enum values on write; read is case-insensitive.

Example

Here is an example of TMDL code:

~~~
createOrReplace

	model Model
		culture: en-US
		defaultPowerBIDataSourceVersion: powerBI_V3

		expression FilePath = "C:\data\report.xlsx" meta [IsParameterQuery=true, Type="Text"]

		table Sales
			lineageTag: 6f52c7a5-5ceb-4afe-901d-9f87992e6a0e

			/// Customer identifier column
			column CustomerKey
				dataType: int64
				summarizeBy: none
				sourceColumn: CustomerKey

			column Amount
				dataType: decimal
				formatString: $ #,##0
				sourceColumn: SalesAmount

			measure 'Total Sales' = SUM(Sales[Amount])
				formatString: $ #,##0

			partition Sales-Data = m
				mode: import
				source =
					let
						Source = Excel.Workbook(File.Contents(FilePath)),
						Data = Source{[Item="Sheet1"]}[Data],
						// Promotes first row to column headers
						Headers = Table.PromoteHeaders(Data)
					in
						Headers

		annotation PBI_QueryOrder = ["Sales"]
!!!
`;