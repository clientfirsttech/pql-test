import { AzureOpenAI } from "openai";
import { Cleanup_Power_Query_Prompt } from "./rewrite-prompts";
import { parsePowerQueryText } from 'src/parser/pq/parse-pq';
import { logDebug } from 'src/lint/rule-assistance';
import { ChatCompletionMessageParam } from "openai/resources/chat";


export async function cleanupPQ(endpoint: string, apiKey: string, powerQueryCode: string, debug: boolean = false): Promise<string> {
    const apiVersion = process.env.REWRITE_API_VERSION || "2025-01-01-preview";
    const deployment = process.env.REWRITE_DEPLOYMENT_MODEL || "o4-mini";

    // Validate inputs
    if (!endpoint || !apiKey) {
        throw new Error("Azure OpenAI endpoint and API key are required.");
    }

    if (!powerQueryCode) {
        throw new Error("Power Query code must be provided.");
    }

    const client = new AzureOpenAI({ endpoint, apiKey, apiVersion, deployment });

    try {

        // Make sure the prompt is in the correct format
        const firstCheck = parsePowerQueryText(powerQueryCode);
    } catch (error) {
        console.error("Error is parsing Power Query provided.", error);
        throw error;
    }
    // Update prompt
    try {
        // Assigned the prompt to a variable
        // Use structuredClone to create a deep copy of the array
        const tempMessage: ChatCompletionMessageParam[] = structuredClone(Cleanup_Power_Query_Prompt);

        // Replace the placeholder with the actual Power Query code
        if (tempMessage.length > 1) {
            if (Array.isArray(tempMessage[1].content)) {
                // Join the array elements into a single string if needed, or directly assign the string
                const contentArr = tempMessage[1].content as any[];
                const newContentArr = [...contentArr];
                newContentArr[newContentArr.length - 2] = { type: "text", text: powerQueryCode };
                // Convert the array to a string (if the API expects a string)
                tempMessage[1] = { ...tempMessage[1], content: newContentArr.map(item => typeof item === "string" ? item : item.text ?? "").join("\n") };
            } else {
                throw new Error("tempMessage[1].content is not an array and cannot be replaced.");
            }
        } else {
            throw new Error("tempMessage[1].content is not a string and cannot be replaced.");
        }

        logDebug("Prompt for Azure OpenAI:", JSON.stringify(tempMessage));

        // Call the Azure OpenAI API to rewrite the Power Query code
        const result = await client.chat.completions.create({
            model: deployment, // Specify the model to use
            messages: tempMessage,
            //max_tokens: 9000,
            max_completion_tokens: 9000,
            temperature: 1,
            top_p: 1,
            frequency_penalty: 0,
            presence_penalty: 0,
            stop: null
        });

        // Get the rewritten Power Query code from the response
        let rewrittenCode = result.choices[0]?.message?.content;

        if (!rewrittenCode) {
            throw new Error("No rewritten code returned from Azure OpenAI.");
        }

        // Remove preceding ~~~ or trailing ~~~
        rewrittenCode = rewrittenCode.replace(/^~~~|~~~$/g, '').trim();

        // Parse the rewritten code to ensure it's valid Power Query
        const parsedCode = parsePowerQueryText(rewrittenCode);
        try {

            // Make sure the prompt is in the correct format
            const secondCheck = parsePowerQueryText(powerQueryCode);
        } catch (error) {
            console.error("Error is parsing Power Query updated.", error);
            throw error;
        }

        if (debug) {
            logDebug("Rewritten Power Query Code:");
            logDebug(JSON.stringify(result, null, 2));
        }

        return rewrittenCode;
    } catch (error) {
        console.error("Error occurred while rewriting Power Query code:", error);
        throw error;
    }
}