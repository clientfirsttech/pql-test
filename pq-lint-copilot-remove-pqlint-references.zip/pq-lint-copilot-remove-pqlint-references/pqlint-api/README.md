# Code Advisor - Power Query Linter

A comprehensive linting and code fixing solution for Power Query (M) code in TMDL files, with AI-powered automatic fixes.

## Prerequisites

- Node.js (v20.x or later)
- Azure Functions Core Tools
- Azure subscription (for AI features)
- Git

## Installation

```bash
npm install
```

## Configuration

### Local Settings

Create a `local.settings.json` file in the root directory with the following configuration:

```json
{
  "IsEncrypted": false,
  "Values": {
    // Core Azure Functions Settings
    "AzureWebJobsStorage": "UseDevelopmentStorage=true",
    "FUNCTIONS_WORKER_RUNTIME": "node",
    
    // AI Rewrite Configuration (Azure OpenAI or Anthropic)
    "REWRITE_API_URL": "<your-azure-openai-endpoint-url>",
    "REWRITE_API_KEY": "<your-api-key>",
    "REWRITE_API_VERSION": "2025-01-01-preview",
    "REWRITE_DEPLOYMENT_MODEL": "gpt-4.1-mini",
    "REWRITE_MAX_COMPLETION_TOKENS": "32768",
    
    // Anthropic Configuration (Optional - Set IS_ANTHROPIC to "1" to use)
    "IS_ANTHROPIC": "0",
    "ANTHROPIC_MODEL": "claude-sonnet-4-20250514",
    
    // Event Hub Configuration (for telemetry)
    "EVENT_HUB_CONNECTION_STRING": "<your-event-hub-connection-string>",
    "EVENT_HUB_NAME": "<your-event-hub-name>",
    "EVENT_V2_HUB_NAME": "<your-event-hub-name>",
    
    // Environment Settings
    "ENVIRONMENT": "Development",
    "DEBUG": true,
    
    // Testing Configuration
    "TEST_ENVIRONMENT": "DEV",
    "DEV_TESTING_PREFIX": "<dev-function-app-url>",
    "DEV_TESTING_CODE": "<dev-function-key>",
    
    // API Management Testing (DEV)
    "API_DEV_TESTING_PREFIX": "<dev-api-management-url>",
    "API_DEV_TESTING_CODE": "<dev-subscription-key>",
    "API_DEV_FREE_TESTING_CODE": "<dev-free-tier-key>",
    "API_DEV_FREE_USER": "test-free-<timestamp>@example.com",
    
    // UAT Environment
    "UAT_TESTING_PREFIX": "<uat-function-app-url>",
    "UAT_TESTING_CODE": "<uat-function-key>",
    "API_UAT_TESTING_PREFIX": "<uat-api-management-url>",
    "API_UAT_TESTING_CODE": "<uat-subscription-key>",
    "API_UAT_FREE_TESTING_CODE": "<uat-free-tier-key>",
    "API_UAT_FREE_USER": "test-free-uat-<timestamp>@example.com",
    
    // Production Environment
    "PROD_TESTING_PREFIX": "<prod-function-app-url>",
    "PROD_TESTING_CODE": "<prod-function-key>",
    "API_PROD_TESTING_PREFIX": "<prod-api-management-url>",
    "API_PROD_TESTING_CODE": "<prod-subscription-key>",
    "API_PROD_FREE_TESTING_CODE": "<prod-free-tier-key>",
    "API_PROD_FREE_USER": "test-free-prod-<timestamp>@example.com",
    
    // API Management Configuration
    "API_MANAGEMENT_SUBSCRIPTION_ID": "<azure-subscription-id>",
    "API_MANAGEMENT_RESOURCE_GROUP": "<resource-group-name>",
    "API_MANAGMENT_NAME": "<api-management-service-name>",
    "API_MANAGEMENT_PRODUCT_ID_PRO": "api-dev",
    "API_MANAGEMENT_PRODUCT_ID_FREE": "free-api-dev",
    "API_MANAGEMENT_API_BASE_URL": "https://management.azure.com",
    "API_MANAGEMENT_USER_API_BASE_URL": "<user-facing-api-url>",
    
    // Internal API Management URLs
    "API_MANAGEMENT_DEV_INTERNAL_API_BASE_URL": "<dev-internal-api-url>",
    "API_MANAGEMENT_DEV_INTERNAL_API_CODE": "<dev-internal-subscription-key>",
    "API_MANAGEMENT_UAT_INTERNAL_API_BASE_URL": "<uat-internal-api-url>",
    "API_MANAGEMENT_UAT_INTERNAL_API_CODE": "<uat-internal-subscription-key>",
    "API_MANAGEMENT_PROD_INTERNAL_API_BASE_URL": "<prod-internal-api-url>",
    "API_MANAGEMENT_PROD_INTERNAL_API_CODE": "<prod-internal-subscription-key>"
  }
}
```

### Configuration Details

#### AI Provider Setup

**Azure OpenAI (Default)**
1. Set `IS_ANTHROPIC` to `"0"`
2. `REWRITE_API_URL`: Full Azure OpenAI endpoint URL including deployment and API version
   - Format: `https://<resource>.cognitiveservices.azure.com/openai/deployments/<deployment>/chat/completions?api-version=<version>`
3. `REWRITE_API_KEY`: Your Azure OpenAI API key
4. `REWRITE_DEPLOYMENT_MODEL`: Your deployment name (e.g., `gpt-4.1-mini`, `gpt-4o`)
5. `REWRITE_MAX_COMPLETION_TOKENS`: Maximum tokens for completion (default: 32768)

**Anthropic Claude (Alternative)**
1. Set `IS_ANTHROPIC` to `"1"`
2. `REWRITE_API_URL`: Anthropic API base URL or Azure AI Foundry endpoint
   - Azure AI Foundry format: `https://<resource>.services.ai.azure.com/anthropic/v1/messages`
3. `REWRITE_API_KEY`: Your Anthropic API key or Azure AI Foundry key
4. `ANTHROPIC_MODEL`: Claude model name (e.g., `claude-sonnet-4-20250514`)

#### Event Hub Setup

Used for telemetry and logging:
1. Create an Event Hub in Azure
2. Copy the connection string from "Shared access policies"
3. Set `EVENT_HUB_CONNECTION_STRING` and `EVENT_HUB_NAME`

#### Testing Environments

The project supports three testing environments: DEV, UAT, and PROD.

**For each environment, configure:**
- `<ENV>_TESTING_PREFIX`: Direct Function App URL
- `<ENV>_TESTING_CODE`: Function App host key
- `API_<ENV>_TESTING_PREFIX`: API Management URL
- `API_<ENV>_TESTING_CODE`: Pro tier subscription key
- `API_<ENV>_FREE_TESTING_CODE`: Free tier subscription key
- `API_<ENV>_FREE_USER`: Test user email for free tier

**Set the active environment:**
```json
"TEST_ENVIRONMENT": "DEV"  // or "UAT" or "PROD"
```

#### API Management

For Azure API Management integration:
1. `API_MANAGEMENT_SUBSCRIPTION_ID`: Your Azure subscription ID
2. `API_MANAGEMENT_RESOURCE_GROUP`: Resource group containing APIM
3. `API_MANAGMENT_NAME`: Name of your API Management service
4. Internal API codes are used for internal service-to-service communication

## Development

### Build

```bash
npm run build
```

### Watch Mode

```bash
npm run watch
```

### Run Locally

```bash
npm start
```

### Testing

```bash
# Run all tests
npm test

# Run AI-powered tests only
npm run test:ai

# Run non-AI tests only
npm run test:noai

# Watch mode
npm run test:watch

# Coverage report
npm run test:coverage
```

## Deployment

### Prerequisites
- Azure CLI installed and authenticated
- Function App created in Azure
- Environment variables configured in Function App settings

### Deploy to DEV

```bash
npm run deploy-dev
```

### Deploy to Other Environments

Update `package.json` scripts or use Azure CLI:

```bash
az functionapp deployment source config-zip \
  --resource-group <resource-group> \
  --name <function-app-name> \
  --src <zip-file>
```

## Features

### Core Features
- **TMDL Parsing**: Extract and analyze Power Query code from TMDL files
- **Linting**: Validate Power Query code against best practices
- **AI-Powered Fixes**: Automatically fix code issues using AI (Azure OpenAI or Anthropic)
- **Streaming Responses**: Real-time streaming of AI fixes for better UX
- **Multi-Environment Support**: DEV, UAT, and PROD configurations

### API Endpoints

- `POST /api/lintTMDL`: Lint TMDL code and return validation results
- `POST /api/fixTMDL`: Fix TMDL code issues (batch mode)
- `POST /api/fixTMDLStreaming`: Fix TMDL code with streaming responses (recommended)

### Supported AI Models

**Azure OpenAI:**
- GPT-4 Turbo
- GPT-4.1-mini
- GPT-4o
- Custom deployments

**Anthropic:**
- Claude Sonnet 4
- Claude Opus
- Via Azure AI Foundry or direct API

## Troubleshooting

### Common Issues

**"OpenAI credentials not configured"**
- Ensure `REWRITE_API_URL` and `REWRITE_API_KEY` are set in `local.settings.json`
- Verify the API endpoint is accessible

**"Cannot parse empty body"**
- Ensure request body contains valid JSON with `code` and `rulesResults` fields

**Tests timing out**
- Increase timeout values in test configuration
- Check network connectivity to Azure services
- Verify AI service quotas haven't been exceeded

**Stream not completing**
- Check `REWRITE_MAX_COMPLETION_TOKENS` is sufficient
- Verify AI model supports streaming
- Check for network interruptions

## Security Notes

⚠️ **Important**: Never commit `local.settings.json` to source control!

- Add `local.settings.json` to `.gitignore`
- Use Azure Key Vault for production secrets
- Rotate API keys regularly
- Use managed identities where possible

## License

[Your License Here]

## Contributing

[Your Contributing Guidelines Here]