/**
 * Test script for MCP-compatible endpoints
 * Tests the Azure Functions MCP tools via HTTP requests
 */

const fs = require('fs');
const path = require('path');

// Load subscription key from local.settings.json
const localSettingsPath = path.join(__dirname, '..', 'local.settings.json');
let subscriptionKey = '';

if (fs.existsSync(localSettingsPath)) {
  try {
    const localSettings = JSON.parse(fs.readFileSync(localSettingsPath, 'utf8'));
    subscriptionKey = localSettings.Values?.SUBSCRIPTION_KEY || '';
    console.log('Loaded subscription key from local.settings.json');
  } catch (error) {
    console.error('Error reading local.settings.json:', error.message);
  }
}

if (!subscriptionKey) {
  console.error('No subscription key found. Please set SUBSCRIPTION_KEY in local.settings.json');
  process.exit(1);
}

// Base URL for the Azure Functions (adjust if different)
const BASE_URL = 'http://localhost:7071/api';

/**
 * Test the MCP Get Linting Rules endpoint
 */
async function testGetLintingRules() {
  console.log('\n=== Testing MCP Get Linting Rules ===');
  
  const requestBody = {
    subscription_key: subscriptionKey
  };

  try {
    const response = await fetch(`${BASE_URL}/mcp/tools/get-linting-rules`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-MCP-Tool': 'get-linting-rules'
      },
      body: JSON.stringify(requestBody)
    });

    const result = await response.json();
    console.log('Status:', response.status);
    
    if (response.ok) {
      console.log('Success! Retrieved linting rules:');
      console.log('- Content:', result.content[0]?.text);
      console.log('- Rule count:', result.meta?.ruleCount);
      console.log('- First few rules:', result.meta?.rules?.slice(0, 3).map(r => r.Name));
    } else {
      console.log('Error:', result);
    }
  } catch (error) {
    console.error('Error testing get linting rules:', error.message);
  }
}

/**
 * Test the MCP Lint Code endpoint
 */
async function testLintCode() {
  console.log('\n=== Testing MCP Lint Code ===');
  
  // Sample Power Query M code with intentional issues
  const testCode = `
let
    Source = Excel.Workbook(File.Contents("C:\\path\\to\\file.xlsx"), null, true),
    Sheet1_Sheet = Source{[Item="Sheet1",Kind="Sheet"]}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(Sheet1_Sheet, [PromoteAllScalars=true]),
    x = 1,
    y = 2,
    z = x + y
in
    z
  `;

  const requestBody = {
    subscription_key: subscriptionKey,
    code: testCode,
    options: {
      format: "pq",
      severity: "Information"
    }
  };

  try {
    const response = await fetch(`${BASE_URL}/mcp/tools/lint-code`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-MCP-Tool': 'lint-code'
      },
      body: JSON.stringify(requestBody)
    });

    const result = await response.json();
    console.log('Status:', response.status);
    
    if (response.ok) {
      console.log('Success! Linting results:');
      console.log('- Content:', result.content[0]?.text);
      console.log('- Issue count:', result.meta?.issueCount);
      if (result.meta?.issues?.length > 0) {
        console.log('- Issues found:');
        result.meta.issues.forEach((issue, index) => {
          console.log(`  ${index + 1}. ${issue.Name} (${issue.Severity})`);
        });
      }
    } else {
      console.log('Error:', result);
    }
  } catch (error) {
    console.error('Error testing lint code:', error.message);
  }
}

/**
 * Test with specific rules
 */
async function testLintCodeWithSpecificRules() {
  console.log('\n=== Testing MCP Lint Code with Specific Rules ===');
  
  const testCode = `
let
    Source = Excel.Workbook(File.Contents("C:\\hardcoded\\path.xlsx"), null, true)
in
    Source
  `;

  const requestBody = {
    subscription_key: subscriptionKey,
    code: testCode,
    rules: ["HardcodedDataSource", "UnusedVariable"],
    options: {
      format: "pq"
    }
  };

  try {
    const response = await fetch(`${BASE_URL}/mcp/tools/lint-code`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-MCP-Tool': 'lint-code'
      },
      body: JSON.stringify(requestBody)
    });

    const result = await response.json();
    console.log('Status:', response.status);
    
    if (response.ok) {
      console.log('Success! Specific rule linting results:');
      console.log('- Content:', result.content[0]?.text);
      console.log('- Issue count:', result.meta?.issueCount);
    } else {
      console.log('Error:', result);
    }
  } catch (error) {
    console.error('Error testing lint code with specific rules:', error.message);
  }
}

/**
 * Test error handling
 */
async function testErrorHandling() {
  console.log('\n=== Testing Error Handling ===');
  
  // Test with invalid JSON
  try {
    const response = await fetch(`${BASE_URL}/mcp/tools/lint-code`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-MCP-Tool': 'lint-code'
      },
      body: 'invalid json'
    });

    const result = await response.json();
    console.log('Invalid JSON test - Status:', response.status);
    console.log('Error response:', result);
  } catch (error) {
    console.error('Error in error handling test:', error.message);
  }

  // Test with missing subscription key
  try {
    const response = await fetch(`${BASE_URL}/mcp/tools/lint-code`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-MCP-Tool': 'lint-code'
      },
      body: JSON.stringify({ code: "let x = 1 in x" })
    });

    const result = await response.json();
    console.log('Missing subscription key test - Status:', response.status);
    console.log('Error response:', result);
  } catch (error) {
    console.error('Error in missing subscription key test:', error.message);
  }
}

/**
 * Main test function
 */
async function runTests() {
  console.log('Starting MCP endpoint tests...');
  console.log('Base URL:', BASE_URL);
  
  await testGetLintingRules();
  await testLintCode();
  await testLintCodeWithSpecificRules();
  await testErrorHandling();
  
  console.log('\n=== All tests completed ===');
}

// Run the tests
runTests().catch(console.error);
