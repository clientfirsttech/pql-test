# MCP Server for PQLint API

This directory contains the Model Context Protocol (MCP) server implementation for the PQLint API, providing AI assistants with access to Power Query M and TMDL code linting capabilities.

## Overview

The MCP server exposes PQLint functionality through HTTP endpoints that return MCP-compatible responses. This implementation works with the current Azure Functions SDK and can be used by AI assistants like Claude, ChatGPT, and other MCP-compatible clients.

## Available Endpoints

### 1. Get Linting Rules
**Endpoint:** `POST /api/mcp/tools/get-linting-rules`

Retrieves all available linting rules for Power Query M code and TMDL analysis.

**Request Body:**
```json
{
  "subscription_key": "your-subscription-key"
}
```

**Response Format:**
```json
{
  "content": [
    {
      "type": "text",
      "text": "Retrieved 50 linting rules successfully..."
    }
  ],
  "isError": false,
  "meta": {
    "ruleCount": 50,
    "rules": [...]
  }
}
```

### 2. Lint Code
**Endpoint:** `POST /api/mcp/tools/lint-code`

Lints Power Query M code or TMDL code and returns rule violations.

**Request Body:**
```json
{
  "subscription_key": "your-subscription-key",
  "code": "let Source = Excel.Workbook(...) in Source",
  "rules": ["HardcodedDataSource"],  // Optional
  "options": {                       // Optional
    "severity": "Warning",
    "format": "pq"
  }
}
```

**Response Format:**
```json
{
  "content": [
    {
      "type": "text",
      "text": "Code linting completed. Found 2 issues..."
    }
  ],
  "isError": false,
  "meta": {
    "issueCount": 2,
    "issues": [...]
  }
}
```

## Authentication

Both endpoints require a `subscription_key` in the request body. This should be your PQLint API subscription key from Azure API Management.

## Usage Examples

### Node.js Client
```javascript
const response = await fetch('http://localhost:7071/api/mcp/tools/lint-code', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-MCP-Tool': 'lint-code'
  },
  body: JSON.stringify({
    subscription_key: 'your-key-here',
    code: 'let Source = Excel.Workbook(...) in Source',
    options: { format: 'pq' }
  })
});

const result = await response.json();
console.log(result.content[0].text);
```

### Testing
Run the test script to verify endpoints:
```bash
node test-mcp-endpoints.js
```

## Files

- `mcpServer.ts` - Main MCP server implementation 
- `mcp-client.js` - MCP client for Claude Desktop integration
- `test-mcp-endpoints.js` - Test script for HTTP endpoints
- `claude-desktop-config.json` - Example Claude Desktop configuration
- `README.md` - This documentation
