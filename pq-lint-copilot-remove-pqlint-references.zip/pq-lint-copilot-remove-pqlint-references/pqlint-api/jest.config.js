module.exports = {
  rootDir: '.',
  preset: 'ts-jest',
  testEnvironment: 'node',
  testMatch: ["**/src/**/**/*.test.ts"],
  moduleFileExtensions: ['ts', 'js'],
  modulePaths: ['<rootDir>/node_modules', '<rootDir>/../node_modules', '<rootDir>/..'],
  moduleDirectories: ['node_modules', '../node_modules'],
  moduleNameMapper: {
    '^src/(.*)$': '<rootDir>/../src/$1',
    '^pqlint-api/src/(.*)$': '<rootDir>/src/$1'
  },
  setupFiles: ['<rootDir>/jest.setup.ts'],
  testPathIgnorePatterns: [
    "/node_modules/",
    "\\.ai\\.test\\.ts$"
  ]
};
