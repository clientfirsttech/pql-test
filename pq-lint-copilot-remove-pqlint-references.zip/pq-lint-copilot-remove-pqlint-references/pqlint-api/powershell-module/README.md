# PQLint API PowerShell Module

A PowerShell module for interfacing with the PQLint API to lint Power Query M code, TMDL code, and retrieve linting rules.

## Features

- **Get-LintingRules**: Retrieve all available linting rules from the API
- **Invoke-CodeLinting**: Lint Power Query M code or TMDL code with configurable options
- Comprehensive error handling and logging
- Support for pipeline operations
- Full parameter validation

## Installation

1. Copy the module files to your PowerShell modules directory or a local folder
2. Import the module:

```powershell
Import-Module .\PQLintAPI.psd1
```

## Functions

### Get-LintingRules

Retrieves all linting rules from the PQLint API.

```powershell
# Get all available linting rules
$rules = Get-LintingRules

# Display rule information
$rules | Format-Table id, name, category, severity -AutoSize
```

### Invoke-CodeLinting

Lints Power Query M code or TMDL code using the PQLint API.

#### Parameters

- **Code** (Mandatory): The code to lint
- **SubscriptionKey** (Mandatory): API subscription key for authorization
- **Rules** (Optional): Array of specific rule IDs to apply
- **Severity** (Optional): Minimum severity level to include in results
- **Format** (Optional): "pq" for Power Query M code or "tmdl" for TMDL code (default: "pq")

#### Examples

```powershell
# Basic Power Query code linting
$pqCode = @"
let
    Source = Excel.Workbook(File.Contents("C:\temp\data.xlsx"), null, true),
    Sheet1_Sheet = Source{[Item="Sheet1",Kind="Sheet"]}[Data]
in
    Sheet1_Sheet
"@

$results = Invoke-CodeLinting -Code $pqCode -SubscriptionKey "your-key-here"

# Lint TMDL code with specific severity
$tmdlCode = @"
table 'Sales Data'
    column 'Sales Amount'
        dataType: decimal
        summarizeBy: sum
"@

$results = Invoke-CodeLinting -Code $tmdlCode -SubscriptionKey "your-key-here" -Format "tmdl" -Severity "2"

# Lint with specific rules only
$specificRules = @("rule-id-1", "rule-id-2")
$results = Invoke-CodeLinting -Code $pqCode -SubscriptionKey "your-key-here" -Rules $specificRules

# Pipeline usage
$codes = @($pqCode, $tmdlCode)
$results = $codes | Invoke-CodeLinting -SubscriptionKey "your-key-here"
```

## API Configuration

The module is configured to use the UAT environment by default:
- Base URL: `https://api.pqlint.com/uat/v1`

To change the API endpoint, modify the `$script:ApiBaseUrl` variable in the module file.

## Error Handling

The module provides comprehensive error handling:
- HTTP status codes and error messages are properly parsed
- Detailed error information is returned from the API
- Input validation prevents common mistakes

## Testing

Run the included Pester tests:

```powershell
# Install Pester if not already installed
Install-Module -Name Pester -Force -SkipPublisherCheck

# Run unit tests
Invoke-Pester .\PQLintAPI.Tests.ps1

# Run integration tests (requires PQLINT_SUBSCRIPTION_KEY environment variable)
$env:PQLINT_SUBSCRIPTION_KEY = "your-subscription-key"
Invoke-Pester .\PQLintAPI.Tests.ps1 -Tag "Integration"
```

## Examples

See `Examples.ps1` for comprehensive usage examples.

## Requirements

- PowerShell 5.1 or later
- Internet connectivity to reach the PQLint API
- Valid PQLint API subscription key

## License

This module is provided under the MIT License.

## Support

For API-related issues, consult the PQLint API documentation.
For module-specific issues, please report them in the project repository.
