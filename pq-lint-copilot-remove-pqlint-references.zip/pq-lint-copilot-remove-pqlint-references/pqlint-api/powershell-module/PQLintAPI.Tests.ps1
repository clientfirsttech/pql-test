# PQLint API PowerShell Module Tests
# Run these tests to verify the module functionality

BeforeAll {
    # Import the module
    Import-Module "$PSScriptRoot\PQLintAPI.psd1" -Force
}

Describe "PQLint API PowerShell Module Tests" {
    
    Context "Get-LintingRules Function" {
        It "Should export Get-LintingRules function" {
            Get-Command Get-LintingRules -Module PQLintAPI | Should -Not -BeNullOrEmpty
        }
        
        It "Should have proper help documentation" {
            $help = Get-Help Get-LintingRules -Full
            $help.Synopsis | Should -Not -BeNullOrEmpty
            $help.Description | Should -Not -BeNullOrEmpty
            $help.Examples | Should -Not -BeNullOrEmpty
        }
    }
    
    Context "Invoke-CodeLinting Function" {
        It "Should export Invoke-CodeLinting function" {
            Get-Command Invoke-CodeLinting -Module PQLintAPI | Should -Not -BeNullOrEmpty
        }
        
        It "Should have proper help documentation" {
            $help = Get-Help Invoke-CodeLinting -Full
            $help.Synopsis | Should -Not -BeNullOrEmpty
            $help.Description | Should -Not -BeNullOrEmpty
            $help.Examples | Should -Not -BeNullOrEmpty
        }
        
        It "Should require mandatory parameters" {
            $command = Get-Command Invoke-CodeLinting
            $mandatoryParams = $command.Parameters.Values | Where-Object { $_.Attributes.Mandatory -eq $true }
            $mandatoryParams.Name | Should -Contain "Code"
            $mandatoryParams.Name | Should -Contain "SubscriptionKey"
        }
        
        It "Should validate Format parameter values" {
            $command = Get-Command Invoke-CodeLinting
            $formatParam = $command.Parameters["Format"]
            $validateSet = $formatParam.Attributes | Where-Object { $_ -is [System.Management.Automation.ValidateSetAttribute] }
            $validateSet.ValidValues | Should -Contain "pq"
            $validateSet.ValidValues | Should -Contain "tmdl"
        }
        
        It "Should throw error for empty code" {
            { Invoke-CodeLinting -Code "" -SubscriptionKey "test-key" } | Should -Throw "*Cannot bind argument to parameter 'Code' because it is an empty string.*"
        }
        
        It "Should throw error for empty subscription key" {
            { Invoke-CodeLinting -Code "test code" -SubscriptionKey "" } | Should -Throw "*Cannot bind argument to parameter 'SubscriptionKey'*"
        }
    }
    
    Context "Module Manifest" {
        It "Should load module manifest correctly" {
            $manifest = Test-ModuleManifest "$PSScriptRoot\PQLintAPI.psd1"
            $manifest | Should -Not -BeNullOrEmpty
            $manifest.Name | Should -Be "PQLintAPI"
            $manifest.Version | Should -Be "1.0.0"
        }
        
        It "Should export correct functions" {
            $manifest = Test-ModuleManifest "$PSScriptRoot\PQLintAPI.psd1"
            $manifest.ExportedFunctions.Keys | Should -Contain "Get-LintingRules"
            $manifest.ExportedFunctions.Keys | Should -Contain "Invoke-CodeLinting"
        }
    }
}

# Integration tests (require valid API access)
Describe "PQLint API Integration Tests" -Tag "Integration" {
    BeforeAll {
        # Read subscription key from local.settings.json file
        $localSettingsPath = Join-Path (Split-Path $PSScriptRoot -Parent) "local.settings.json"
        $script:subscriptionKey = $null
        
        if (Test-Path $localSettingsPath) {
            try {
                $localSettings = Get-Content $localSettingsPath | ConvertFrom-Json
                # Use UAT testing code since the module is configured for UAT environment
                $script:subscriptionKey = $localSettings.Values.API_UAT_TESTING_CODE
                
                if (-not $script:subscriptionKey) {
                    Write-Warning "API_UAT_TESTING_CODE not found in local.settings.json"
                }
            }
            catch {
                Write-Warning "Failed to read local.settings.json: $($_.Exception.Message)"
            }
        }
        else {
            Write-Warning "local.settings.json not found at: $localSettingsPath"
        }
        
        # Fallback to environment variable if local.settings.json doesn't work
        if (-not $script:subscriptionKey) {
            $script:subscriptionKey = $env:PQLINT_SUBSCRIPTION_KEY
        }
        
        if (-not $script:subscriptionKey) {
            Write-Warning "Skipping integration tests - no subscription key found in local.settings.json (API_UAT_TESTING_CODE) or PQLINT_SUBSCRIPTION_KEY environment variable"
        }
    }
    
    Context "API Connectivity" -Skip:(-not $script:subscriptionKey) {
        It "Should retrieve linting rules from API" {
            $rules = Get-LintingRules
            $rules | Should -Not -BeNullOrEmpty
            $rules.Count | Should -BeGreaterThan 0
            
            # Verify rule structure
            $firstRule = $rules[0]
            $firstRule.id | Should -Not -BeNullOrEmpty
            $firstRule.name | Should -Not -BeNullOrEmpty
            $firstRule.category | Should -Not -BeNullOrEmpty
        }
        
        It "Should lint Power Query code successfully" {
            $testCode = @"
let
    Source = Excel.Workbook(File.Contents("C:\temp\data.xlsx"), null, true)
in
    Source
"@
            
            $results = Invoke-CodeLinting -Code $testCode -SubscriptionKey $script:subscriptionKey
            $results | Should -Not -BeNull
            # Results could be empty array if no issues found
        }
        
        It "Should lint TMDL code successfully" {
            $testCode = @"
table TestTable
    column TestColumn
        dataType: string
"@
            
            $results = Invoke-CodeLinting -Code $testCode -SubscriptionKey $script:subscriptionKey -Format "tmdl"
            $results | Should -Not -BeNull
        }
    }
}

AfterAll {
    # Clean up
    Remove-Module PQLintAPI -Force -ErrorAction SilentlyContinue
}
