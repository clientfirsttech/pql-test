/**
 * Jest global test setup
 *
 * Sets environment variables required for tests that would normally be
 * loaded from local.settings.json. These are test-only mock values and
 * do not represent real credentials.
 */

// Enable PRO mode in tests so that all lint rules (Free + Pro) are exercised.
// The lintCodeV2 tests send product-id="api-dev"; setting this variable to
// the same value causes the function to activate PRO mode, matching the
// behaviour developers see when running with a local.settings.json.
if (!process.env.API_MANAGEMENT_PRODUCT_ID_PRO) {
    process.env.API_MANAGEMENT_PRODUCT_ID_PRO = 'api-dev';
}
