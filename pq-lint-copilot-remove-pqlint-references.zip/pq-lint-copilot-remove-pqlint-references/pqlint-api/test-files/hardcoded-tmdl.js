"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tmdlCodeSample5 = exports.tmdlCodeSample4 = exports.tmdlCodeSample3 = exports.tmdlCodeSample2 = exports.tmdlCodeSample1 = void 0;
// Sample TMDL code containing a model definition with a table named "PlannerTasks".
// This table includes multiple columns and a partition that fetches data from the Microsoft Planner API.
exports.tmdlCodeSample1 = `createOrReplace

	model Model
		culture: en-US
		defaultPowerBIDataSourceVersion: powerBI_V3
		sourceQueryCulture: en-US
		dataAccessOptions
			legacyRedirects
			returnErrorValuesAsNull

		table PlannerTasks
			lineageTag: eb05326c-764e-4bcd-8c15-ce83055b0eb3

			column '@odata.context'
				dataType: string
				lineageTag: 8e8bcafc-c11d-46ab-be94-bae8c8fe2a53
				summarizeBy: none
				sourceColumn: @odata.context

				annotation SummarizationSetBy = Automatic

			column '@odata.count'
				dataType: int64
				formatString: 0
				lineageTag: 7691c731-c11c-42cf-aed1-df077fb3e1d0
				summarizeBy: sum
				sourceColumn: @odata.count

				annotation SummarizationSetBy = Automatic

			column 'value.@odata.etag'
				dataType: string
				lineageTag: 6f8ed7ed-3703-45fa-9e6e-a52e40ddaf8e
				summarizeBy: none
				sourceColumn: value.@odata.etag

				annotation SummarizationSetBy = Automatic

			column 'value.planId'
				dataType: string
				lineageTag: 946d4bc7-2a07-4874-a8e5-787dd32efba2
				summarizeBy: none
				sourceColumn: value.planId

				annotation SummarizationSetBy = Automatic

			column 'value.bucketId'
				dataType: string
				lineageTag: f642326e-4572-4dda-8fcb-13fb6c575f77
				summarizeBy: none
				sourceColumn: value.bucketId

				annotation SummarizationSetBy = Automatic

			column 'value.title'
				dataType: string
				lineageTag: b2bd03cb-cca0-49c5-a9b5-d02fca73f2a9
				summarizeBy: none
				sourceColumn: value.title

				annotation SummarizationSetBy = Automatic

			column 'value.orderHint'
				dataType: string
				lineageTag: 2e4a1c23-ae0a-4c3e-b9c6-f5a704422685
				summarizeBy: none
				sourceColumn: value.orderHint

				annotation SummarizationSetBy = Automatic

			column 'value.assigneePriority'
				dataType: string
				lineageTag: 97159019-576a-4757-9cf2-90869de009a5
				summarizeBy: none
				sourceColumn: value.assigneePriority

				annotation SummarizationSetBy = Automatic

			column 'value.percentComplete'
				dataType: int64
				formatString: 0
				lineageTag: b473b6e7-3159-4dfe-924d-94bd021d953b
				summarizeBy: sum
				sourceColumn: value.percentComplete

				annotation SummarizationSetBy = Automatic

			column 'value.startDateTime'
				dataType: string
				lineageTag: 668b8b21-fdbd-4c57-b20f-98b93f0e900b
				summarizeBy: none
				sourceColumn: value.startDateTime

				annotation SummarizationSetBy = Automatic

			column 'value.createdDateTime'
				dataType: dateTime
				formatString: General Date
				lineageTag: 1b33f4a4-aea6-419d-a54d-aaa5b7f0b63b
				summarizeBy: none
				sourceColumn: value.createdDateTime

				annotation SummarizationSetBy = Automatic

			column 'value.dueDateTime'
				dataType: string
				lineageTag: 6b9e8803-6646-4dca-b3ba-e9842b54350f
				summarizeBy: none
				sourceColumn: value.dueDateTime

				annotation SummarizationSetBy = Automatic

			column 'value.hasDescription'
				dataType: boolean
				formatString: """TRUE"";""TRUE"";""FALSE"""
				lineageTag: a689fe1c-7a66-46fc-9fc0-5be154b1d2b6
				summarizeBy: none
				sourceColumn: value.hasDescription

				annotation SummarizationSetBy = Automatic

			column 'value.previewType'
				dataType: string
				lineageTag: 4bbba8cf-0091-4c73-8a9e-53abf530d1d2
				summarizeBy: none
				sourceColumn: value.previewType

				annotation SummarizationSetBy = Automatic

			column 'value.completedDateTime'
				dataType: string
				lineageTag: 409ec05b-f463-4d3b-9e67-fd20c34ef1d1
				summarizeBy: none
				sourceColumn: value.completedDateTime

				annotation SummarizationSetBy = Automatic

			column 'value.referenceCount'
				dataType: int64
				formatString: 0
				lineageTag: d93d5767-1397-4ed8-b845-745c19bc7392
				summarizeBy: sum
				sourceColumn: value.referenceCount

				annotation SummarizationSetBy = Automatic

			column 'value.checklistItemCount'
				dataType: int64
				formatString: 0
				lineageTag: c5b3594c-871e-4936-ad21-342ae733ba6c
				summarizeBy: sum
				sourceColumn: value.checklistItemCount

				annotation SummarizationSetBy = Automatic

			column 'value.activeChecklistItemCount'
				dataType: int64
				formatString: 0
				lineageTag: 2bb093d2-ae33-41ff-afae-20bee3de88ef
				summarizeBy: sum
				sourceColumn: value.activeChecklistItemCount

				annotation SummarizationSetBy = Automatic

			column 'value.conversationThreadId'
				dataType: string
				lineageTag: 44825790-5c07-49e6-86ac-f6b1ba26c2bf
				summarizeBy: none
				sourceColumn: value.conversationThreadId

				annotation SummarizationSetBy = Automatic

			column 'value.priority'
				dataType: int64
				formatString: 0
				lineageTag: c8d4b7a7-2520-4d26-b00f-179fa673900c
				summarizeBy: sum
				sourceColumn: value.priority

				annotation SummarizationSetBy = Automatic

			column 'value.id'
				dataType: string
				lineageTag: 04b8fd48-fb83-4137-9bc5-7a8fff3771bc
				summarizeBy: none
				sourceColumn: value.id

				annotation SummarizationSetBy = Automatic

			column 'value.completedBy'
				dataType: string
				lineageTag: c0fa216d-807b-47e8-8337-c799f18b196f
				summarizeBy: none
				sourceColumn: value.completedBy

				annotation SummarizationSetBy = Automatic

			column 'value.createdBy.application.displayName'
				dataType: string
				lineageTag: 79fb9aa5-9f4d-473c-ab58-27ebaf2279f4
				summarizeBy: none
				sourceColumn: value.createdBy.application.displayName

				annotation SummarizationSetBy = Automatic

			column 'value.createdBy.application.id'
				dataType: string
				lineageTag: 534b99c7-be23-47db-ba41-a4e0a48bfa30
				summarizeBy: none
				sourceColumn: value.createdBy.application.id

				annotation SummarizationSetBy = Automatic

			column 'value.createdBy.user.displayName'
				dataType: string
				lineageTag: e61f7f76-daf4-42e6-8dc4-f35d0739b73f
				summarizeBy: none
				sourceColumn: value.createdBy.user.displayName

				annotation SummarizationSetBy = Automatic

			column 'value.createdBy.user.id'
				dataType: string
				lineageTag: 4ba21b03-f8f2-4d06-851d-a2f9c19db915
				summarizeBy: none
				sourceColumn: value.createdBy.user.id

				annotation SummarizationSetBy = Automatic

			column 'value.appliedCategories.category5'
				dataType: boolean
				formatString: """TRUE"";""TRUE"";""FALSE"""
				lineageTag: b9365db6-37c3-4a90-9b25-7d18634ca64c
				summarizeBy: none
				sourceColumn: value.appliedCategories.category5

				annotation SummarizationSetBy = Automatic

			column 'value.appliedCategories.category3'
				dataType: boolean
				formatString: """TRUE"";""TRUE"";""FALSE"""
				lineageTag: 3dbd5ba6-79c1-48f3-91f4-b51255f89f5e
				summarizeBy: none
				sourceColumn: value.appliedCategories.category3

				annotation SummarizationSetBy = Automatic

			column 'value.appliedCategories.category2'
				dataType: boolean
				formatString: """TRUE"";""TRUE"";""FALSE"""
				lineageTag: fdad18e3-74ff-403c-9cbf-5bb56618f04b
				summarizeBy: none
				sourceColumn: value.appliedCategories.category2

				annotation SummarizationSetBy = Automatic

			column 'value.appliedCategories.category1'
				dataType: boolean
				formatString: """TRUE"";""TRUE"";""FALSE"""
				lineageTag: b93c52a1-b718-4d35-af38-ebe55e19128e
				summarizeBy: none
				sourceColumn: value.appliedCategories.category1

				annotation SummarizationSetBy = Automatic

			column 'value.appliedCategories.category11'
				dataType: boolean
				formatString: """TRUE"";""TRUE"";""FALSE"""
				lineageTag: 0ecae2b1-4482-461a-9db2-963d9c18cfb5
				summarizeBy: none
				sourceColumn: value.appliedCategories.category11

				annotation SummarizationSetBy = Automatic

			partition PlannerTasks = m
				mode: import
				source =
						let
						    Source = Json.Document(Web.Contents("https://graph.microsoft.com/v1.0/planner/plans/o0F8dLRD302lGhJbE3K2q2UADy3v/tasks")),
						    #"Converted to Table" = Table.FromRecords({Source}),
						    #"Expanded value" = Table.ExpandListColumn(#"Converted to Table", "value"),
						    #"Expanded value1" = Table.ExpandRecordColumn(#"Expanded value", "value", {"@odata.etag", "planId", "bucketId", "title", "orderHint", "assigneePriority", "percentComplete", "startDateTime", "createdDateTime", "dueDateTime", "hasDescription", "previewType", "completedDateTime", "referenceCount", "checklistItemCount", "activeChecklistItemCount", "conversationThreadId", "priority", "id", "completedBy", "createdBy", "appliedCategories", "assignments"}, {"value.@odata.etag", "value.planId", "value.bucketId", "value.title", "value.orderHint", "value.assigneePriority", "value.percentComplete", "value.startDateTime", "value.createdDateTime", "value.dueDateTime", "value.hasDescription", "value.previewType", "value.completedDateTime", "value.referenceCount", "value.checklistItemCount", "value.activeChecklistItemCount", "value.conversationThreadId", "value.priority", "value.id", "value.completedBy", "value.createdBy", "value.appliedCategories", "value.assignments"}),
						    #"Expanded value.createdBy" = Table.ExpandRecordColumn(#"Expanded value1", "value.createdBy", {"application", "user"}, {"value.createdBy.application", "value.createdBy.user"}),
						    #"Expanded value.createdBy.application" = Table.ExpandRecordColumn(#"Expanded value.createdBy", "value.createdBy.application", {"displayName", "id"}, {"value.createdBy.application.displayName", "value.createdBy.application.id"}),
						    #"Expanded value.createdBy.user" = Table.ExpandRecordColumn(#"Expanded value.createdBy.application", "value.createdBy.user", {"displayName", "id"}, {"value.createdBy.user.displayName", "value.createdBy.user.id"}),
						    #"Expanded value.appliedCategories" = Table.ExpandRecordColumn(#"Expanded value.createdBy.user", "value.appliedCategories", {"category5", "category3", "category2", "category1", "category11"}, {"value.appliedCategories.category5", "value.appliedCategories.category3", "value.appliedCategories.category2", "value.appliedCategories.category1", "value.appliedCategories.category11"}),
						    #"Expanded value.assignments" = Table.ExpandRecordColumn(#"Expanded value.appliedCategories", "value.assignments", {}, {}),
						    #"Changed Type" = Table.TransformColumnTypes(#"Expanded value.assignments",{{"@odata.context", type text}, {"@odata.count", Int64.Type}, {"value.@odata.etag", type text}, {"value.planId", type text}, {"value.bucketId", type text}, {"value.title", type text}, {"value.orderHint", type text}, {"value.assigneePriority", type any}, {"value.percentComplete", Int64.Type}, {"value.startDateTime", type any}, {"value.createdDateTime", type datetime}, {"value.dueDateTime", type any}, {"value.hasDescription", type logical}, {"value.previewType", type text}, {"value.completedDateTime", type any}, {"value.referenceCount", Int64.Type}, {"value.checklistItemCount", Int64.Type}, {"value.activeChecklistItemCount", Int64.Type}, {"value.conversationThreadId", type any}, {"value.priority", Int64.Type}, {"value.id", type text}, {"value.completedBy", type any}, {"value.createdBy.application.displayName", type any}, {"value.createdBy.application.id", type text}, {"value.createdBy.user.displayName", type any}, {"value.createdBy.user.id", type text}, {"value.appliedCategories.category5", type logical}, {"value.appliedCategories.category3", type logical}, {"value.appliedCategories.category2", type logical}, {"value.appliedCategories.category1", type logical}, {"value.appliedCategories.category11", type logical}})
						in
						    #"Changed Type"

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Table

		cultureInfo en-US

			linguisticMetadata =
					{
					  "Version": "1.0.0",
					  "Language": "en-US"
					}
				contentType: json

		annotation __PBI_TimeIntelligenceEnabled = 0

		annotation PBIDesktopVersion = 2.139.1678.0 (24.12)+2a034ab280bddf891eb7bb9ebfe6996f9c3a3196

		annotation PBI_QueryOrder = ["PlannerTasks"]

		annotation PBI_ProTooling = ["DevMode"]
`;
// Sample TMDL code containing a table named "Without Value_Type".
// This table includes columns and a partition that processes rows from a "Functions Table".
exports.tmdlCodeSample2 = `createOrReplace

	table 'Without Value_Type'
		lineageTag: fd1c5f77-60d9-401d-aa02-540cf308b133

		column 'Custom.Documentation.Name'
			dataType: string
			lineageTag: 45bad09e-6820-4959-8403-09922439d698
			summarizeBy: none
			sourceColumn: Custom.Documentation.Name

			annotation SummarizationSetBy = Automatic

		column Parameters
			dataType: string
			lineageTag: 3f01d256-000b-4ae9-aa66-fa8461f19da1
			summarizeBy: none
			sourceColumn: Parameters

			annotation SummarizationSetBy = Automatic

		column 'Custom.Documentation.Name.1'
			dataType: string
			lineageTag: 08b0c240-5eef-4dfd-844b-2b3e59e9f73a
			summarizeBy: none
			sourceColumn: Custom.Documentation.Name.1

			annotation SummarizationSetBy = Automatic

		column Custom
			dataType: string
			lineageTag: 93c12102-3d4a-4d6b-bb46-337ea01a51ee
			summarizeBy: none
			sourceColumn: Custom

			annotation SummarizationSetBy = Automatic

		partition 'Without Value_Type' = m
			mode: import
			source =
					let
					    Source = #"Functions Table",
					    #"Filtered Rows" = Table.SelectRows(Source, each Text.Contains([Custom.Documentation.LongDescription], "<code>culture</code>",Comparer.OrdinalIgnoreCase)),
					    #"Sorted Rows" = Table.Sort(#"Filtered Rows",{{"Custom.Documentation.Name", Order.Ascending}}),
					    #"Kept First Rows" = Table.FirstN(#"Sorted Rows",10),
					    #"Removed Other Columns" = Table.SelectColumns(#"Kept First Rows",{"Custom.Documentation.LongDescription", "Custom.Documentation.Name"}),
					    #"Split Column by Delimiter1" = Table.ExpandListColumn(Table.TransformColumns(#"Removed Other Columns", {{"Custom.Documentation.LongDescription", Splitter.SplitTextByDelimiter("</code>", QuoteStyle.Csv), let itemType = (type nullable text) meta [Serialized.Text = true] in type {itemType}}}), "Custom.Documentation.LongDescription"),
					    #"Filtered Rows1" = Table.SelectRows(#"Split Column by Delimiter1", each Text.Contains([Custom.Documentation.LongDescription], "<code>",Comparer.OrdinalIgnoreCase)),
					    #"Split Column by Delimiter" = Table.SplitColumn(#"Filtered Rows1", "Custom.Documentation.LongDescription", Splitter.SplitTextByEachDelimiter({"<code>"}, QuoteStyle.Csv, false), {"Custom.Documentation.LongDescription.1", "Custom.Documentation.LongDescription.2"}),
					    #"Renamed Columns" = Table.RenameColumns(#"Split Column by Delimiter",{{"Custom.Documentation.LongDescription.2", "Parameters"}}),
					    #"Removed Columns" = Table.RemoveColumns(#"Renamed Columns",{"Custom.Documentation.LongDescription.1"}),
					    #"Changed Type" = Table.TransformColumnTypes(#"Removed Columns",{{"Custom.Documentation.Name", type text}}),
					    #"Added Custom" = Table.AddColumn(#"Changed Type", "Custom", each 1.2, Currency.Type),
					    #"Grouped Rows" = Table.Group(#"Added Custom", {"Custom.Documentation.Name"}, {{"AllRows", each _, type table [Parameters=nullable text, Custom.Documentation.Name=text]}}),
					    #"Expanded AllRows" = Table.ExpandTableColumn(#"Grouped Rows", "AllRows", {"Parameters", "Custom.Documentation.Name", "Custom"}, {"Parameters", "Custom.Documentation.Name.1", "Custom"})
					in
					    #"Expanded AllRows"

		annotation PBI_NavigationStepName = Navigation

		annotation PBI_ResultType = Table
`;
// Sample TMDL code containing a model with multiple tables demonstrating culture-specific transformations.
// Includes tables like "Date_Culture_Fail", "Date_Culture_Pass", and "Date_Culture_SomeFail".
exports.tmdlCodeSample3 = `createOrReplace

	model Model
		culture: en-US
		defaultPowerBIDataSourceVersion: powerBI_V3
		sourceQueryCulture: en-US
		dataAccessOptions
			legacyRedirects
			returnErrorValuesAsNull

		table Date_Culture_Fail
			lineageTag: 6f9cb740-9dfc-4df7-9b6b-3d83250e188b

			column OriginalDate
				dataType: string
				lineageTag: 1aacc8cf-5090-4481-8411-2368530866df
				summarizeBy: none
				sourceColumn: OriginalDate

				annotation SummarizationSetBy = Automatic

			column DayOfWeekName
				dataType: string
				lineageTag: 03dba271-1b24-41ee-8141-67073dc5f5f3
				summarizeBy: none
				sourceColumn: DayOfWeekName

				annotation SummarizationSetBy = Automatic

			column DateFrom
				dataType: string
				lineageTag: f8175bab-bcde-4c4c-a55b-ee7a0d892519
				summarizeBy: none
				sourceColumn: DateFrom

				annotation SummarizationSetBy = Automatic

			column MonthName
				dataType: string
				lineageTag: a22edcf8-60be-4ae9-9125-4a87ea6ddfaf
				summarizeBy: none
				sourceColumn: MonthName

				annotation SummarizationSetBy = Automatic

			column DateAsText
				dataType: string
				lineageTag: f8e3421f-66d3-45d4-a12e-555019a4a433
				summarizeBy: none
				sourceColumn: DateAsText

				annotation SummarizationSetBy = Automatic

			partition Date_Culture_Fail = m
				mode: import
				source =
						let
						    // Step 1: Create a list of 10 dates starting from today
						    startDate = Date.From(DateTime.LocalNow()),
						    dateList = List.Dates(startDate, 10, #duration(1, 0, 0, 0)),
						
						    // Step 2: Convert to a table
						    dateTable = Table.FromList(dateList, Splitter.SplitByNothing(), {"OriginalDate"}),
						
						    // Step 3: Add each function as a new column
						    withDayOfWeek = Table.AddColumn(dateTable, "DayOfWeekName", each Date.DayOfWeekName([OriginalDate])),
						    withDateFrom = Table.AddColumn(withDayOfWeek, "DateFrom", each Date.From([OriginalDate])),
						    withMonthName = Table.AddColumn(withDateFrom, "MonthName", each Date.MonthName([OriginalDate])),
						    withText = Table.AddColumn(withMonthName, "DateAsText", each Date.ToText([OriginalDate]))
						
						in
						    withText

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Table

		table Date_Culture_Pass
			lineageTag: 3aec31ae-9ddd-4c97-a949-44c9ecbbe022

			column OriginalDate
				dataType: string
				lineageTag: 20e08253-b5e9-47de-932b-37b17946ca81
				summarizeBy: none
				sourceColumn: OriginalDate

				annotation SummarizationSetBy = Automatic

			column DayOfWeekName
				dataType: string
				lineageTag: 009ef241-b843-42e7-9d4c-1f507517046e
				summarizeBy: none
				sourceColumn: DayOfWeekName

				annotation SummarizationSetBy = Automatic

			column DateFrom
				dataType: string
				lineageTag: 2cc6c95b-0a45-4772-8e58-e3e6a450eac3
				summarizeBy: none
				sourceColumn: DateFrom

				annotation SummarizationSetBy = Automatic

			column MonthName
				dataType: string
				lineageTag: a0b13a5b-2c6f-4b6e-9c75-17497293505d
				summarizeBy: none
				sourceColumn: MonthName

				annotation SummarizationSetBy = Automatic

			column DateAsText
				dataType: string
				lineageTag: 3855d9cd-8b88-41b8-b237-d013e6cbe6ce
				summarizeBy: none
				sourceColumn: DateAsText

				annotation SummarizationSetBy = Automatic

			partition Date_Culture_Pass = m
				mode: import
				source =
						let
						    // Step 1: Define culture to use
						    culture = "fr-FR",
						
						    // Step 2: Create a list of 10 dates starting from today
						    startDate = Date.From(DateTime.LocalNow()),
						    dateList = List.Dates(startDate, 10, #duration(1, 0, 0, 0)),
						
						    // Step 3: Convert to a table
						    dateTable = Table.FromList(dateList, Splitter.SplitByNothing(), {"OriginalDate"}),
						
						    // Step 4: Apply functions with culture
						    withDayOfWeek = Table.AddColumn(dateTable, "DayOfWeekName", each Date.DayOfWeekName([OriginalDate], culture)),
						    withDateFrom = Table.AddColumn(withDayOfWeek, "DateFrom", each Date.From([OriginalDate])), // no culture needed here
						    withMonthName = Table.AddColumn(withDateFrom, "MonthName", each Date.MonthName([OriginalDate], culture)),
						    withText = Table.AddColumn(withMonthName, "DateAsText", each Date.ToText([OriginalDate], null,culture))
						
						in
						    withText

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Table

		table Date_Culture_SomeFail
			lineageTag: 07aa5a5f-443a-4351-91da-7f98bbc8f332

			column OriginalDate
				dataType: string
				lineageTag: d1b6095b-2a21-4391-be5b-7f5cb0a58eb3
				summarizeBy: none
				sourceColumn: OriginalDate

				annotation SummarizationSetBy = Automatic

			column DayOfWeekName
				dataType: string
				lineageTag: 0aa45fad-a3dd-4267-af62-e2f7d69cf35d
				summarizeBy: none
				sourceColumn: DayOfWeekName

				annotation SummarizationSetBy = Automatic

			column DateFrom
				dataType: string
				lineageTag: 539a492e-b4ca-4415-a9d6-888c69c1b5d7
				summarizeBy: none
				sourceColumn: DateFrom

				annotation SummarizationSetBy = Automatic

			column MonthName
				dataType: string
				lineageTag: 0cbd86fa-6e5e-4702-9b50-3a20ade30770
				summarizeBy: none
				sourceColumn: MonthName

				annotation SummarizationSetBy = Automatic

			column DateAsText
				dataType: string
				lineageTag: 941f0e27-cc31-4c62-aefe-92e8298a8b75
				summarizeBy: none
				sourceColumn: DateAsText

				annotation SummarizationSetBy = Automatic

			partition Date_Culture_SomeFail = m
				mode: import
				source =
						let
						    // Step 1: Create a list of 10 dates starting from today
						    startDate = Date.From(DateTime.LocalNow(),"en-US"),
						    dateList = List.Dates(startDate, 10, #duration(1, 0, 0, 0)),
						
						    // Step 2: Convert to a table
						    dateTable = Table.FromList(dateList, Splitter.SplitByNothing(), {"OriginalDate"}),
						
						    // Step 3: Add each function as a new column
						    withDayOfWeek = Table.AddColumn(dateTable, "DayOfWeekName", each Date.DayOfWeekName([OriginalDate], "en-US")),
						    withDateFrom = Table.AddColumn(withDayOfWeek, "DateFrom", each Date.From([OriginalDate])),
						    withMonthName = Table.AddColumn(withDateFrom, "MonthName", each Date.MonthName([OriginalDate], "en-US")),
						    withText = Table.AddColumn(withMonthName, "DateAsText", each Date.ToText([OriginalDate]))
						
						in
						    withText

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Table

		table Date_Culture_DateTimeFail
			lineageTag: b7b9ad5c-973e-4bba-b1b2-207924ebb670

			column OriginalDate
				dataType: string
				lineageTag: f7fa80b6-0261-42ca-8641-0e64a7d6ba2e
				summarizeBy: none
				sourceColumn: OriginalDate

				annotation SummarizationSetBy = Automatic

			column DayOfWeekName
				dataType: string
				lineageTag: a54fa9c9-0496-457a-abab-4c5fb710e73d
				summarizeBy: none
				sourceColumn: DayOfWeekName

				annotation SummarizationSetBy = Automatic

			column DateFrom
				dataType: string
				lineageTag: 03a0f9f8-6dbf-417d-9196-f182ec16cd33
				summarizeBy: none
				sourceColumn: DateFrom

				annotation SummarizationSetBy = Automatic

			column MonthName
				dataType: string
				lineageTag: e7603fe2-adf3-414f-97dc-dc6f5285c2a5
				summarizeBy: none
				sourceColumn: MonthName

				annotation SummarizationSetBy = Automatic

			column DateAsText
				dataType: string
				lineageTag: 0553a2f5-557d-4866-9277-e911822d41b6
				summarizeBy: none
				sourceColumn: DateAsText

				annotation SummarizationSetBy = Automatic

			column DateTimeAsText
				dataType: string
				lineageTag: 532234b7-3d1e-42fb-a7bc-4f8adbbccd1a
				summarizeBy: none
				sourceColumn: DateTimeAsText

				annotation SummarizationSetBy = Automatic

			partition Date_Culture_DateTimeFail = m
				mode: import
				source =
						let
						    // Step 1: Create a list of 10 dates starting from today
						    startDate = Date.From(DateTime.LocalNow(),"en-US"),
						    startDT = DateTime.From(DateTime.LocalNow(),"en-US"),
						    dateList = List.Dates(startDate, 10, #duration(1, 0, 0, 0)),
						
						    // Step 2: Convert to a table
						    dateTable = Table.FromList(dateList, Splitter.SplitByNothing(), {"OriginalDate"}),
						
						    // Step 3: Add each function as a new column
						    withDayOfWeek = Table.AddColumn(dateTable, "DayOfWeekName", each Date.DayOfWeekName([OriginalDate], "en-US")),
						    withDateFrom = Table.AddColumn(withDayOfWeek, "DateFrom", each Date.From([OriginalDate])),
						    withMonthName = Table.AddColumn(withDateFrom, "MonthName", each Date.MonthName([OriginalDate], "en-US")),
						    withText = Table.AddColumn(withMonthName, "DateAsText", each Date.ToText([OriginalDate],[Culture="fr-FR"])),
						    withDTText = Table.AddColumn(withText, "DateTimeAsText", each DateTime.ToText(startDT,[Culture="fr-FR"]))
						
						in
						    withDTText

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Table

		table 'Functions Table'
			lineageTag: 995ccd14-30cf-4c9f-bc70-f4e6e909abcc

			column Name
				dataType: string
				lineageTag: 52ce667e-4009-49db-abb6-c271a5568ea0
				summarizeBy: none
				sourceColumn: Name

				annotation SummarizationSetBy = Automatic

			column Value
				dataType: string
				lineageTag: eb17badf-a32a-49d0-80d4-956c3f773786
				summarizeBy: none
				sourceColumn: Value

				annotation SummarizationSetBy = Automatic

			column 'Is Function'
				dataType: boolean
				formatString: """TRUE"";""TRUE"";""FALSE"""
				lineageTag: fd57b589-9f1d-4af2-ac05-080390241ac5
				summarizeBy: none
				sourceColumn: Is Function

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.Name'
				dataType: string
				lineageTag: 6441c324-9352-475c-b5dc-4cf6421cf84f
				summarizeBy: none
				sourceColumn: Custom.Documentation.Name

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.Description'
				dataType: string
				lineageTag: 46560602-e63f-4a76-83a0-64fe74649232
				summarizeBy: none
				sourceColumn: Custom.Documentation.Description

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.LongDescription'
				dataType: string
				lineageTag: 0c1fcd56-5f3c-4b37-b39a-211620e1771a
				summarizeBy: none
				sourceColumn: Custom.Documentation.LongDescription

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.Category'
				dataType: string
				lineageTag: a8939ac6-2e4c-4fa8-bc4e-da0a21e82d2c
				summarizeBy: none
				sourceColumn: Custom.Documentation.Category

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.Examples'
				dataType: string
				lineageTag: a0255f7c-0081-4613-b857-f5f36900dc97
				summarizeBy: none
				sourceColumn: Custom.Documentation.Examples

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation. LongDescription'
				dataType: string
				lineageTag: 35019958-63a0-491f-bb5c-2ce726866d24
				summarizeBy: none
				sourceColumn: Custom.Documentation. LongDescription

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.DisplayName'
				dataType: string
				lineageTag: 664aa7b0-4eb5-4917-a197-7558f35ca32b
				summarizeBy: none
				sourceColumn: Custom.Documentation.DisplayName

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.Caption'
				dataType: string
				lineageTag: 5ee933bc-3b10-4a38-a06f-0a92da1efeb5
				summarizeBy: none
				sourceColumn: Custom.Documentation.Caption

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.FieldDescription'
				dataType: string
				lineageTag: bcfc54ee-9b60-49aa-8641-ebf8ff1d7464
				summarizeBy: none
				sourceColumn: Custom.Documentation.FieldDescription

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.Icon'
				dataType: string
				lineageTag: 20f533ce-03aa-41b9-95e9-1e0cbc1bf93e
				summarizeBy: none
				sourceColumn: Custom.Documentation.Icon

				annotation SummarizationSetBy = Automatic

			column 'Field Names'
				dataType: string
				lineageTag: 3352acca-5bf6-46ca-99bc-67a7a7130bce
				summarizeBy: none
				sourceColumn: Field Names

				annotation SummarizationSetBy = Automatic

			partition 'Functions Table' = m
				mode: import
				source =
						let
						    Query1 = #shared,
						    #"Converted to Table" = Record.ToTable(Query1),
						    // Test if a function
						    #"Added Is Function" = Table.AddColumn(#"Converted to Table", "Is Function", each try Value.Is([Value], type function) otherwise false, type logical),
						    #"Filtered For Is Function = TRUE" = Table.SelectRows(#"Added Is Function", each ([Is Function] = true)),
						    // Value.Metadata(Value.Type gets the documentation for a function.
						    #"Added Documentation" = Table.AddColumn(#"Filtered For Is Function = TRUE", "Documentation", each Value.Metadata(Value.Type([Value]))),
						    #"Added Custom" = Table.AddColumn(#"Added Documentation", "Field Names", each Record.FieldNames([Documentation])),
						    #"Expanded Custom" = Table.ExpandRecordColumn(#"Added Custom", "Documentation", {"Documentation.Name", "Documentation.Description", "Documentation.LongDescription", "Documentation.Category", "Documentation.Examples", "Documentation. LongDescription", "Documentation.DisplayName", "Documentation.Caption", "Documentation.FieldDescription", "Documentation.Icon"}, {"Custom.Documentation.Name", "Custom.Documentation.Description", "Custom.Documentation.LongDescription", "Custom.Documentation.Category", "Custom.Documentation.Examples", "Custom.Documentation. LongDescription", "Custom.Documentation.DisplayName", "Custom.Documentation.Caption", "Custom.Documentation.FieldDescription", "Custom.Documentation.Icon"})
						in
						    #"Expanded Custom"

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Table

		table 'Has <code>Culture</code>'
			lineageTag: 52739812-f0c2-4b9a-9e62-9af4eb46e13d

			column Name
				dataType: string
				lineageTag: 522a4d9f-e115-4aa7-ac67-ffd017726deb
				summarizeBy: none
				sourceColumn: Name

				annotation SummarizationSetBy = Automatic

			column Value
				dataType: string
				lineageTag: 7e57372e-a2bf-4936-b398-2833696040a5
				summarizeBy: none
				sourceColumn: Value

				annotation SummarizationSetBy = Automatic

			column 'Is Function'
				dataType: boolean
				formatString: """TRUE"";""TRUE"";""FALSE"""
				lineageTag: 5c9b8f34-0d25-4fd5-9d67-06a090a7f251
				summarizeBy: none
				sourceColumn: Is Function

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.Name'
				dataType: string
				lineageTag: 21f99e99-9f47-4d90-893b-5deb8055fea4
				summarizeBy: none
				sourceColumn: Custom.Documentation.Name

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.Description'
				dataType: string
				lineageTag: f8cf4273-f84d-4787-8c5e-04a07bc1e6cb
				summarizeBy: none
				sourceColumn: Custom.Documentation.Description

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.LongDescription'
				dataType: string
				lineageTag: 0c67776c-143b-486c-a94c-cea28b43bed0
				summarizeBy: none
				sourceColumn: Custom.Documentation.LongDescription

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.Category'
				dataType: string
				lineageTag: 8fd2159a-1523-476c-8d80-d6ac69971841
				summarizeBy: none
				sourceColumn: Custom.Documentation.Category

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.Examples'
				dataType: string
				lineageTag: de03e7d9-58d9-419f-bd42-878f8fd839a0
				summarizeBy: none
				sourceColumn: Custom.Documentation.Examples

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation. LongDescription'
				dataType: string
				lineageTag: 4f0f7d1f-3dd2-47ce-9f4d-8876fea544df
				summarizeBy: none
				sourceColumn: Custom.Documentation. LongDescription

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.DisplayName'
				dataType: string
				lineageTag: 5c4307a8-251e-414a-bbc1-b87b7b035eb2
				summarizeBy: none
				sourceColumn: Custom.Documentation.DisplayName

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.Caption'
				dataType: string
				lineageTag: 8cc6baf8-3cd7-4469-b557-e5df03dc6c8e
				summarizeBy: none
				sourceColumn: Custom.Documentation.Caption

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.FieldDescription'
				dataType: string
				lineageTag: ca6f8e5e-acc6-4687-8a85-274ae3564e25
				summarizeBy: none
				sourceColumn: Custom.Documentation.FieldDescription

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.Icon'
				dataType: string
				lineageTag: 781c0596-23a2-4e78-a2b3-4c987de7f9cc
				summarizeBy: none
				sourceColumn: Custom.Documentation.Icon

				annotation SummarizationSetBy = Automatic

			column 'Field Names'
				dataType: string
				lineageTag: c36a5ca7-7282-4780-917c-079a7cc1ffa6
				summarizeBy: none
				sourceColumn: Field Names

				annotation SummarizationSetBy = Automatic

			partition 'Has <code>Culture</code>' = m
				mode: import
				source =
						let
						    Source = #"Functions Table",
						    #"Filtered Rows" = Table.SelectRows(Source, each Text.Contains([Custom.Documentation.LongDescription], "<code>culture</code>",Comparer.OrdinalIgnoreCase)),
						    #"Sorted Rows" = Table.Sort(#"Filtered Rows",{{"Custom.Documentation.Name", Order.Ascending}})
						in
						    #"Sorted Rows"

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Table

		table 'Field Names'
			lineageTag: 9a90f838-1583-41b5-bb14-7e9cb48bf040

			column 'Field Names'
				dataType: string
				lineageTag: 15bdb16f-bd37-4b40-a711-fd84ffcf417d
				summarizeBy: none
				sourceColumn: Field Names

				annotation SummarizationSetBy = Automatic

			partition 'Field Names' = m
				mode: import
				source =
						let
						    Source = #"Functions Table",
						    #"Removed Other Columns" = Table.SelectColumns(Source,{"Field Names"}),
						    #"Expanded Field Names" = Table.ExpandListColumn(#"Removed Other Columns", "Field Names"),
						    #"Filtered Rows" = Table.SelectRows(#"Expanded Field Names", each [Field Names] <> null and [Field Names] <> ""),
						    #"Removed Duplicates" = Table.Distinct(#"Filtered Rows")
						in
						    #"Removed Duplicates"

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Table

		table 'Without Value_Type'
			lineageTag: fd1c5f77-60d9-401d-aa02-540cf308b133

			column 'Custom.Documentation.Name'
				dataType: string
				lineageTag: 45bad09e-6820-4959-8403-09922439d698
				summarizeBy: none
				sourceColumn: Custom.Documentation.Name

				annotation SummarizationSetBy = Automatic

			column Parameters
				dataType: string
				lineageTag: 3f01d256-000b-4ae9-aa66-fa8461f19da1
				summarizeBy: none
				sourceColumn: Parameters

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.Name.1'
				dataType: string
				lineageTag: 08b0c240-5eef-4dfd-844b-2b3e59e9f73a
				summarizeBy: none
				sourceColumn: Custom.Documentation.Name.1

				annotation SummarizationSetBy = Automatic

			column Custom
				dataType: string
				lineageTag: 93c12102-3d4a-4d6b-bb46-337ea01a51ee
				summarizeBy: none
				sourceColumn: Custom

				annotation SummarizationSetBy = Automatic

			partition 'Without Value_Type' = m
				mode: import
				source =
						let
						    Source = #"Functions Table",
						    #"Filtered Rows" = Table.SelectRows(Source, each Text.Contains([Custom.Documentation.LongDescription], "<code>culture</code>",Comparer.OrdinalIgnoreCase)),
						    #"Sorted Rows" = Table.Sort(#"Filtered Rows",{{"Custom.Documentation.Name", Order.Ascending}}),
						    #"Kept First Rows" = Table.FirstN(#"Sorted Rows",10),
						    #"Removed Other Columns" = Table.SelectColumns(#"Kept First Rows",{"Custom.Documentation.LongDescription", "Custom.Documentation.Name"}),
						    #"Split Column by Delimiter1" = Table.ExpandListColumn(Table.TransformColumns(#"Removed Other Columns", {{"Custom.Documentation.LongDescription", Splitter.SplitTextByDelimiter("</code>", QuoteStyle.Csv), let itemType = (type nullable text) meta [Serialized.Text = true] in type {itemType}}}), "Custom.Documentation.LongDescription"),
						    #"Filtered Rows1" = Table.SelectRows(#"Split Column by Delimiter1", each Text.Contains([Custom.Documentation.LongDescription], "<code>",Comparer.OrdinalIgnoreCase)),
						    #"Split Column by Delimiter" = Table.SplitColumn(#"Filtered Rows1", "Custom.Documentation.LongDescription", Splitter.SplitTextByEachDelimiter({"<code>"}, QuoteStyle.Csv, false), {"Custom.Documentation.LongDescription.1", "Custom.Documentation.LongDescription.2"}),
						    #"Renamed Columns" = Table.RenameColumns(#"Split Column by Delimiter",{{"Custom.Documentation.LongDescription.2", "Parameters"}}),
						    #"Removed Columns" = Table.RemoveColumns(#"Renamed Columns",{"Custom.Documentation.LongDescription.1"}),
						    #"Changed Type" = Table.TransformColumnTypes(#"Removed Columns",{{"Custom.Documentation.Name", type text}}),
						    #"Added Custom" = Table.AddColumn(#"Changed Type", "Custom", each 1.2, Currency.Type),
						    #"Grouped Rows" = Table.Group(#"Added Custom", {"Custom.Documentation.Name"}, {{"AllRows", each _, type table [Parameters=nullable text, Custom.Documentation.Name=text]}}),
						    #"Expanded AllRows" = Table.ExpandTableColumn(#"Grouped Rows", "AllRows", {"Parameters", "Custom.Documentation.Name", "Custom"}, {"Parameters", "Custom.Documentation.Name.1", "Custom"})
						in
						    #"Expanded AllRows"

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Table

		table 'With Value_Type'
			lineageTag: 6ac34b8b-69d1-4ad8-9504-e52d11670f21

			column 'Custom.Documentation.Name'
				dataType: string
				lineageTag: 0ccb3b31-a5b7-4221-a9e1-36b8ca703285
				summarizeBy: none
				sourceColumn: Custom.Documentation.Name

				annotation SummarizationSetBy = Automatic

			column Parameters
				dataType: string
				lineageTag: 6f8e2f51-e96c-4b1f-8af1-7668b419eff0
				summarizeBy: none
				sourceColumn: Parameters

				annotation SummarizationSetBy = Automatic

			column 'Custom.Documentation.Name.1'
				dataType: string
				lineageTag: 009d6e8b-6d6e-4bcf-8ebf-1a4186e9d32d
				summarizeBy: none
				sourceColumn: Custom.Documentation.Name.1

				annotation SummarizationSetBy = Automatic

			column Custom
				dataType: decimal
				formatString: \$#,0.###############;(\$#,0.###############);\$#,0.###############
				lineageTag: 462e237a-ab3d-40f9-af1a-7be71e88dea5
				summarizeBy: sum
				sourceColumn: Custom

				annotation SummarizationSetBy = Automatic

				annotation PBI_FormatHint = {"currencyCulture":"en-US"}

			partition 'With Value_Type' = m
				mode: import
				source =
						let
						    Source = #"Functions Table",
						    #"Filtered Rows" = Table.SelectRows(Source, each Text.Contains([Custom.Documentation.LongDescription], "<code>culture</code>",Comparer.OrdinalIgnoreCase)),
						    #"Sorted Rows" = Table.Sort(#"Filtered Rows",{{"Custom.Documentation.Name", Order.Ascending}}),
						    #"Kept First Rows" = Table.FirstN(#"Sorted Rows",10),
						    #"Removed Other Columns" = Table.SelectColumns(#"Kept First Rows",{"Custom.Documentation.LongDescription", "Custom.Documentation.Name"}),
						    #"Split Column by Delimiter1" = Table.ExpandListColumn(Table.TransformColumns(#"Removed Other Columns", {{"Custom.Documentation.LongDescription", Splitter.SplitTextByDelimiter("</code>", QuoteStyle.Csv), let itemType = (type nullable text) meta [Serialized.Text = true] in type {itemType}}}), "Custom.Documentation.LongDescription"),
						    #"Filtered Rows1" = Table.SelectRows(#"Split Column by Delimiter1", each Text.Contains([Custom.Documentation.LongDescription], "<code>",Comparer.OrdinalIgnoreCase)),
						    #"Split Column by Delimiter" = Table.SplitColumn(#"Filtered Rows1", "Custom.Documentation.LongDescription", Splitter.SplitTextByEachDelimiter({"<code>"}, QuoteStyle.Csv, false), {"Custom.Documentation.LongDescription.1", "Custom.Documentation.LongDescription.2"}),
						    #"Renamed Columns" = Table.RenameColumns(#"Split Column by Delimiter",{{"Custom.Documentation.LongDescription.2", "Parameters"}}),
						    #"Removed Columns" = Table.RemoveColumns(#"Renamed Columns",{"Custom.Documentation.LongDescription.1"}),
						    #"Changed Type" = Table.TransformColumnTypes(#"Removed Columns",{{"Custom.Documentation.Name", type text}}),
						    #"Added Custom" = Table.AddColumn(#"Changed Type", "Custom", each 1.2, Currency.Type),
						    #"Grouped Rows" = Table.Group(#"Added Custom", {"Custom.Documentation.Name"}, {{"AllRows", each _, Value.Type(#"Added Custom")}}),
						    #"Expanded AllRows" = Table.ExpandTableColumn(#"Grouped Rows", "AllRows", {"Parameters", "Custom.Documentation.Name", "Custom"}, {"Parameters", "Custom.Documentation.Name.1", "Custom"})
						in
						    #"Expanded AllRows"

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Table

		relationship AutoDetected_04cfdb01-dcdb-4418-ba6f-640a5de9878f
			crossFilteringBehavior: bothDirections
			fromCardinality: one
			fromColumn: Date_Culture_DateTimeFail.OriginalDate
			toColumn: Date_Culture_Fail.OriginalDate

		relationship AutoDetected_07023018-f5ad-4dac-bfdf-1b3097045099
			crossFilteringBehavior: bothDirections
			fromCardinality: one
			fromColumn: Date_Culture_DateTimeFail.OriginalDate
			toColumn: Date_Culture_Pass.OriginalDate

		relationship AutoDetected_1a9bbf80-d855-41ee-9102-a1809bf8418f
			crossFilteringBehavior: bothDirections
			fromCardinality: one
			fromColumn: Date_Culture_DateTimeFail.OriginalDate
			toColumn: Date_Culture_SomeFail.OriginalDate

		relationship AutoDetected_1e1bffa9-69d6-4f95-83fc-03dc15b54f31
			fromColumn: 'Without Value_Type'.'Custom.Documentation.Name'
			toColumn: 'Has <code>Culture</code>'.'Custom.Documentation.Name'

		relationship AutoDetected_254e5943-4858-4feb-b975-c98b13101001
			fromColumn: 'With Value_Type'.'Custom.Documentation.Name'
			toColumn: 'Has <code>Culture</code>'.'Custom.Documentation.Name'

		cultureInfo en-US

			linguisticMetadata =
					{
					  "Version": "1.0.0",
					  "Language": "en-US"
					}
				contentType: json

		annotation __PBI_TimeIntelligenceEnabled = 0

		annotation PBIDesktopVersion = 2.139.1678.0 (24.12)+2a034ab280bddf891eb7bb9ebfe6996f9c3a3196

		annotation PBI_QueryOrder = ["Date_Culture_Fail","Date_Culture_Pass","Date_Culture_SomeFail","Date_Culture_DateTimeFail","Functions Table","Has <code>Culture</code>","Field Names","Without Value_Type","With Value_Type"]

		annotation PBI_ProTooling = ["DevMode","TMDLView_Desktop"]
`;
// Sample TMDL code containing a minimal model with a single table and an expression.
// The table includes a partition that processes rows from a JSON document.
exports.tmdlCodeSample4 = `
createOrReplace

	model Model
		culture: en-US
		defaultPowerBIDataSourceVersion: powerBI_V3
		sourceQueryCulture: en-US
		dataAccessOptions
			legacyRedirects
			returnErrorValuesAsNull

		table Table
			lineageTag: d7ea5df1-6530-48cf-aed3-a44298445edb

			column Column1
				dataType: string
				lineageTag: 21cabc44-c6fd-458f-a692-4b26cc21b537
				summarizeBy: none
				sourceColumn: Column1

				annotation SummarizationSetBy = Automatic

			partition Table = m
				mode: import
				source =
						let
						    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i45WCkktLlGKjQUA", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [Column1 = _t]),
						    #"Changed Type" = Table.TransformColumnTypes(Source,{{"Column1", type text}})
						in
						    #"Changed Type"

			annotation PBI_ResultType = Table

		cultureInfo en-US

			linguisticMetadata = {"Version":"1.0.0","Language":"en-US"}
				contentType: json

		expression AnyParameter = "https://kerski.sharepoint.com" meta [IsParameterQuery=true, Type="Any", IsParameterQueryRequired=true]
			lineageTag: a2df46b0-9ca8-457b-ac07-8236ff0156f0

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Text

		annotation __PBI_TimeIntelligenceEnabled = 0

		annotation PBIDesktopVersion = 2.139.1678.0 (24.12)+2a034ab280bddf891eb7bb9ebfe6996f9c3a3196

		annotation PBI_QueryOrder = ["Table","AnyParameter"]

`;
// Tests multiple parameters with Any type
exports.tmdlCodeSample5 = `createOrReplace

	model Model
		culture: en-US
		defaultPowerBIDataSourceVersion: powerBI_V3
		sourceQueryCulture: en-US
		dataAccessOptions
			legacyRedirects
			returnErrorValuesAsNull

		table ProblemList
			lineageTag: ca6cf574-b556-4ae6-be93-5f7809156d19

			column Title
				dataType: string
				lineageTag: 17053bcc-6230-4735-bf15-496510587d2f
				summarizeBy: none
				sourceColumn: Title

				annotation SummarizationSetBy = Automatic

			column 'A Lookup Column'
				dataType: string
				lineageTag: 82019a03-5724-4a37-86b2-49c7d7a44aa5
				summarizeBy: none
				sourceColumn: A Lookup Column

				annotation SummarizationSetBy = Automatic

			column 'A Lookup Column:Date Received'
				dataType: string
				lineageTag: fd0a5551-c0d1-4fce-9c77-b9b5a11121b0
				summarizeBy: none
				sourceColumn: A Lookup Column:Date Received

				annotation SummarizationSetBy = Automatic

			partition ProblemList = m
				mode: import
				source =
						let
						    Source = SharePoint.Tables(SharePointURL, [Implementation="2.0", ViewMode="All"]),
						    #"b2d0f4ec-de04-4c47-ada2-ea94cde9c7ad" = Source{[Id="b2d0f4ec-de04-4c47-ada2-ea94cde9c7ad"]}[Items],
						    #"Removed Other Columns" = Table.SelectColumns(#"b2d0f4ec-de04-4c47-ada2-ea94cde9c7ad",{"Title", "A Lookup Column", "A Lookup Column:Date Received"})
						in
						    #"Removed Other Columns"

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Table

		table 'Fake Data'
			lineageTag: 8aa17002-050b-4bc5-a6e2-baee4d16da5a

			column Column1
				dataType: string
				lineageTag: 7e641551-175b-4fe8-ab40-fb0c8176b096
				summarizeBy: none
				sourceColumn: Column1

				annotation SummarizationSetBy = Automatic

			partition 'Fake Data' = m
				mode: import
				source =
						let
						    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("i45WckvMTlVwSSxJVIqNBQA=", BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [Column1 = _t]),
						    #"Changed Type" = Table.TransformColumnTypes(Source,{{"Column1", type text}})
						in
						    #"Changed Type"

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Table

		cultureInfo en-US

			linguisticMetadata = {"Version":"1.0.0","Language":"en-US"}
				contentType: json

		expression SharePointURL = "https://kerski.sharepoint.com" meta [IsParameterQuery=true, Type="Any", IsParameterQueryRequired=true]
			lineageTag: 20cdff74-a185-40a3-a5d1-1b70ac05b191

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Text

		expression SharePointURLText = "https://kerski.sharepoint.com" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]
			lineageTag: 9e188653-8aea-4958-b2cc-a28cc251e5b8

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Text

		expression Parameter1 = "PfY8Q~jmPJ2si69HsBo.rzZbbxY9z_hUc1vwVa1D" meta [IsParameterQuery = true, IsParameterQueryRequired = true, Type = type text]
			lineageTag: ffa62e70-cfd8-4a44-b970-31cc5be2dc64

			annotation PBI_NavigationStepName = Navigation

			annotation PBI_ResultType = Text

		annotation __PBI_TimeIntelligenceEnabled = 0

		annotation PBIDesktopVersion = 2.139.1678.0 (24.12)+2a034ab280bddf891eb7bb9ebfe6996f9c3a3196

		annotation PBI_QueryOrder = ["ProblemList","Fake Data","SharePointURL","SharePointURLText","Parameter1"]

		annotation PBI_ProTooling = ["TMDLView_Desktop"]


`;
