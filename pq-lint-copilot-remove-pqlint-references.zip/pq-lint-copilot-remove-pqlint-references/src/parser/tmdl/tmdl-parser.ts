import { log, table } from "console";
import { logDebug } from "../../lint/rule-assistance";

// Represents a single parsed line in the TMDL file, including its position, indentation, key, and value.
export interface Parsed_Line {
    startPositionLineNumber: number; // The starting line number of the parsed line.
    endPositionLineNumber: number; // The ending line number of the parsed line.
    indentation: string; // The indentation of the line.
    key: string; // The key extracted from the line.
    value: string; // The value associated with the key.
}

// Represents the parsed data structure, organized by keys and subkeys.
export interface Raw_TMDL_Parsed_Data {
    [key: string]: {
        [subKey: string]: Parsed_Line[];
    };
}

// Represents the position of a TMDL entry, including its key, value, and line numbers.
export interface TMDL_Position {
    key: string; // The type of the entry (e.g., 'partition' or 'expression').
    value: string; // The name or identifier of the entry.
    startPositionLineNumber: number; // The starting line number of the entry.
    endPositionLineNumber: number; // The ending line number of the entry.
}

// Represents an M code object, including its name, code, result type, line number, and properties.
export interface M_Code {
    name: string; // The name of the partition or expression.
    code: string | null; // The extracted code.
    resultType: 'Partition' | 'Expression'; // The type of the result (Partition or Expression).
    lineNumber: number; // The starting line number of the partition or expression.
    properties: {
        isCalculated?: boolean; // Indicates if the table is calculated (only for partitions).
        queryGroup?: string | null; // The query group associated with the partition or expression.
        mode?: string | null; // The mode associated with the partition (only for partitions).
        mAttributes?: string | null; // The M attributes associated with the expression (only for expressions).
    };
}

export interface Column_Code {
    name: string; // The name of the column
    dataType: string; // The data type of the column
    formatString?: string; // The format string of the column, if specified
    lineageTag?: string; // The lineage tag of the column, if specified
    isKey?: boolean; // Indicates if the column is a key column
    isHidden?: boolean; // Indicates if the column is hidden
    isAvailableInMdx?: boolean; // Indicates if the column is available in MDX
    sourceProviderType?: string; // The source provider type, if specified
    summarizeBy?: string; // The summarizeBy property of the column, if specified
    sourceColumn?: string; // The source column name, if specified
    annotations?: { [key: string]: string }; // Any annotations associated with the column
    lineNumber: number; // The starting line number of the column definition
    properties: {
        isVisible?: boolean; // Indicates if the column is visible
        isKey?: boolean; // Indicates if the column is a key column
        sortByColumn?: string; // The column to sort by, if specified
    };
}

// Represents an Table code object, including its name, code, result type, line number, and properties.
export interface Table_Code {
    name: string; // The name of the partition or expression.
    columns?: Column_Code[]; // The columns defined in the table, if any.
    relationships?: Relationship_Code[]; // The relationships defined in the table, if any.
    partitions: M_Code[]; // The extracted code.
    resultType: 'Table'; // The type of the result (Table).
    lineNumber: number; // The starting line number of the partition or expression.
    properties: {
        dataCategory?: string | null; // The data category of the table, if specified.
        isIncremental?: boolean; // Indicates if the table is incremental (only for tables).
        isHidden?: boolean; // Indicates if the table is hidden
    };
}

// Represents a relationship code object, including its GUID, properties, and line number.
export interface Relationship_Code {
    guid: string; // The GUID identifier of the relationship
    fromColumn: string; // The source column in 'Table'.'Column' format
    toColumn: string; // The target column in 'Table'.'Column' format
    fromTable: string; // The source table name extracted from fromColumn
    toTable: string; // The target table name extracted from toColumn
    fromColumnName: string; // The source column name extracted from fromColumn
    toColumnName: string; // The target column name extracted from toColumn
    isActive: boolean; // Indicates if the relationship is active (default true)
    crossFilteringBehavior: string; // The cross filtering behavior (default 'automatic')
    fromCardinality: string; // The cardinality from the source (default 'many')
    toCardinality: string; // The cardinality to the target (default 'one')
    lineNumber: number; // The starting line number of the relationship definition
    properties: {
        securityFilteringBehavior?: string; // The security filtering behavior, if specified
        relyOnReferentialIntegrity?: boolean; // Whether to rely on referential integrity, if specified
    };
}

// Parses the lines of a TMDL file and organizes them into a structured ParsedData object.
/**
 * Parses the lines of a TMDL file and organizes them into a structured ParsedData object.
 * @param input - The TMDL file content as a string.
 * @returns A ParsedData object containing the structured representation of the TMDL file.
 */
export function parseTMDLLines(input: string): Raw_TMDL_Parsed_Data {
    const lines = input.split('\n');
    const parsedData: Raw_TMDL_Parsed_Data = {};
    let currentKey = '';

    lines.forEach((line, lineNumber) => {
        const trimmedLine = line.trim();
        if (trimmedLine === '') return;

        const indentation = line.slice(0, line.indexOf(trimmedLine));
        const firstWord = trimmedLine.split(/\s|:|=/)[0];
        const key = firstWord.trim();
        const value = trimmedLine.slice(key.length).trim();

        // Determine the endPositionLineNumber
        let endPositionLineNumber = lineNumber + 1;
        for (let i = lineNumber + 1; i < lines.length; i++) {
            const nextLine = lines[i];
            const nextIndentation = nextLine.slice(0, nextLine.indexOf(nextLine.trim()));
            if (nextIndentation.length <= indentation.length && nextLine.trim() !== '') {
                break;
            }
            endPositionLineNumber = i + 1;
        }

        const parsedLine: Parsed_Line = {
            startPositionLineNumber: lineNumber + 1,
            endPositionLineNumber,
            indentation,
            key,
            value,
        };

        // Organize the parsed data by key and subKey
        if (!parsedData[key]) {
            parsedData[key] = {};
        }

        if (!parsedData[key][value]) {
            parsedData[key][value] = [];
        }

        parsedData[key][value].push(parsedLine);
    });

    return parsedData;
}

// Extracts the positions of partitions and expressions from the TMDL code.
/**
 * Extracts the positions of partitions and expressions from the TMDL code.
 * @param tmdlCode - The TMDL file content as a string.
 * @returns An array of TMDLPosition objects representing the positions of partitions and expressions.
 */
export function extractTablePositions(tmdlCode: string): TMDL_Position[] {
    const parsedLines = parseTMDLLines(tmdlCode);
    const tables = Object.keys(parsedLines).filter(key => key.toLowerCase().includes('table'));

    const result: TMDL_Position[] = [];

    // Iterate through tables
    tables.forEach(tableKey => {
        const tableEntries = parsedLines[tableKey];
        Object.keys(tableEntries).forEach(valueKey => {
            tableEntries[valueKey].forEach(entry => {
                result.push({
                    key: tableKey,
                    value: valueKey,
                    startPositionLineNumber: entry.startPositionLineNumber,
                    endPositionLineNumber: entry.endPositionLineNumber,
                });
            });
        });
    });

    return result;
}

// Extracts Table code and its associated properties from the TMDL code.
/**
 * Extracts Table code and its associated properties from the TMDL code.
 * @param tmdlCode - The TMDL file content as a string.
 * @returns An array of Table_Code objects containing the extracted Table code and its properties.
 */
export function extractTableAndProperties(tmdlCode: string): Table_Code[] {
    const positions = extractTablePositions(tmdlCode);
    const lines = tmdlCode.split('\n');

    return positions.map(position => {
        let temp: any = {}; // Initialize an empty object for each position
        const extractedTable = lines
            .slice(position.startPositionLineNumber - 1, position.endPositionLineNumber) // Extract lines inclusively
            .join('\n'); // Join the lines back into a single string

        // Parse the extracted code by tabs, colons, backticks, and equals signs
        const parsedDetails = extractedTable.split('\n').map((line, index, allLines) => {
            const trimmedLine = line.trim();
            if(trimmedLine.includes('table ')){
                logDebug("Processing Table Line", index, trimmedLine);
            }

            const tabCount = line.match(/^\t*/)?.[0].length || 0; // Count leading tabs
            const [key, ...rest] = trimmedLine.split(/[:=]/); // Split by colon, backticks, or equals
            const value = rest.join(':').trim(); // Join the rest as the value

            const parsedLine: any = {
                tabCount,
                key: key.trim(),
                value,
            };

            // Special handling for 'table ' keys
            if (key.startsWith('table')) {
                
                const tableName = key.split('=')[0].replace('table ', '').trim().replace(/^'|'$/g, ''); // Extract name before '=' and remove quotes
                logDebug("Extracted Table Name", tableName);
                temp.tableName = tableName;

                const hasRefreshPolicy = value.trim().includes('refreshPolicy'); // Check if the table has refresh policy
                // Extract values at the next indentation level
                const nextIndentation = tabCount + 1;
                const tableValues: { isIncremental: boolean; dataCategory: string | null; isHidden: boolean } = {
                    isIncremental: hasRefreshPolicy, // Default to false
                    dataCategory: null, // Default to null
                    isHidden: false // Default to false
                };
                // Used for tracking the offset of the source lines
                let offSet = position.startPositionLineNumber - 1;
                const partitionsCode: M_Code[] = [];
                const tableColumns: Column_Code[] = [];
                for (let i = index + 1; i < allLines.length; i++) {
                    //logDebug("Processing Line", i, allLines[i]);
                    offSet++;
                    const nextLine = allLines[i];


                    // Before identation check, make sure refreshPolicy doesn't exist, if it does update property
                    if (allLines[i].trim() === 'refreshPolicy') {
                        tableValues.isIncremental = true; // Set to true if 'refreshPolicy' is present                    
                    }

                    // Check if the next line's indentation matches the expected indentation level
                    //if (nextLineTabCount !== nextIndentation) break; // Stop if indentation changes
                    const nextTrimmedLine = nextLine.trim();

                    if (nextTrimmedLine === 'refreshPolicy') {
                        tableValues.isIncremental = true; // Set to true if 'refreshPolicy' is present
                    }
                    else if (nextTrimmedLine.startsWith('dataCategory:')) {
                        tableValues.dataCategory = nextTrimmedLine.split('dataCategory:')[1].trim();
                    }
                    else if(nextTrimmedLine.startsWith('isHidden')){
                        tableValues.isHidden = true;
                    }
                    else if (nextTrimmedLine.startsWith('column')) {
                        let tempColumns = extractColumnAndProperties(allLines.slice(i).join('\n'));

                        tableColumns.push(...tempColumns);
                    }else if (nextTrimmedLine.startsWith('partition')) {
                        let extractedPartition = extractMCodeAndProperties(allLines.slice(i).join('\n'))
                        extractedPartition.forEach(partition => {
                            partition.lineNumber += offSet; // Adjust line number for the partition
                        });
                        partitionsCode.push(...extractedPartition);
                    }
                }
                const tableTemp = {
                    name: tableName,
                    // There is a chance duplicates because of mixing of other properies between columns, so remove duplicates by name just in case
                    columns: Array.from(new Map(tableColumns.map(col => [col.name, col])).values()),
                    partitions: partitionsCode,
                    resultType: 'table',
                    // Use the start line number of the partition and add the offset for the source
                    lineNumber: position.startPositionLineNumber,
                    properties: { isIncremental: tableValues?.isIncremental, dataCategory: tableValues?.dataCategory , isHidden: tableValues?.isHidden},
                };

                temp = tableTemp; // Assign the M code object to temp
            }
            return parsedLine;
        });

        return temp;
    }).filter(table => table && table.name); // Make sure no empty records
}

// Extracts the positions of partitions and expressions from the TMDL code.
/**
 * Extracts the positions of partitions and expressions from the TMDL code.
 * @param tmdlCode - The TMDL file content as a string.
 * @returns An array of TMDLPosition objects representing the positions of partitions and expressions.
 */
export function extractMCodePositions(tmdlCode: string): TMDL_Position[] {
    const parsedLines = parseTMDLLines(tmdlCode);
    const partitions = Object.keys(parsedLines).filter(key => key.toLowerCase().includes('partition'));
    const expressions = Object.keys(parsedLines).filter(key => key.toLowerCase().includes('expression'));

    const result: TMDL_Position[] = [];

    // Iterate through partitions
    partitions.forEach(partitionKey => {
        const partitionEntries = parsedLines[partitionKey];
        Object.keys(partitionEntries).forEach(valueKey => {
            partitionEntries[valueKey].forEach(entry => {
                result.push({
                    key: partitionKey,
                    value: valueKey,
                    startPositionLineNumber: entry.startPositionLineNumber,
                    endPositionLineNumber: entry.endPositionLineNumber,
                });
            });
        });
    });

    // Iterate through expressions
    expressions.forEach(expressionKey => {
        const expressionEntries = parsedLines[expressionKey];
        Object.keys(expressionEntries).forEach(valueKey => {
            expressionEntries[valueKey].forEach(entry => {
                result.push({
                    key: expressionKey,
                    value: valueKey,
                    startPositionLineNumber: entry.startPositionLineNumber,
                    endPositionLineNumber: entry.endPositionLineNumber,
                });
            });
        });
    });

    return result;
}

// Extracts M code and its associated properties from the TMDL code.
/**
 * Extracts M code and its associated properties from the TMDL code.
 * @param tmdlCode - The TMDL file content as a string.
 * @returns An array of MCode objects containing the extracted M code and its properties.
 */
export function extractMCodeAndProperties(tmdlCode: string): M_Code[] {
    const positions = extractMCodePositions(tmdlCode);
    const lines = tmdlCode.split('\n');

    return positions.map(position => {
        let temp: any = {}; // Initialize an empty object for each position
        const extractedCode = lines
            .slice(position.startPositionLineNumber - 1, position.endPositionLineNumber) // Extract lines inclusively
            .join('\n'); // Join the lines back into a single string

        // Parse the extracted code by tabs, colons, backticks, and equals signs
        const parsedDetails = extractedCode.split('\n').map((line, index, allLines) => {
            const trimmedLine = line.trim();
            const tabCount = line.match(/^\t*/)?.[0].length || 0; // Count leading tabs
            const [key, ...rest] = trimmedLine.split(/[:=]/); // Split by colon, backticks, or equals
            const value = rest.join(':').trim(); // Join the rest as the value

            const parsedLine: any = {
                tabCount,
                key: key.trim(),
                value,
            };

            // Special handling for 'partition ' keys
            if (key.startsWith('partition')) {

                const partitionName = key.split('=')[0].replace('partition ', '').trim().replace(/^'|'$/g, ''); // Extract name before '=' and remove quotes
                temp.partitionName = partitionName;

                const hasCalculated = value.trim().includes('calculated'); // Check if the partition is calculated

                // Extract values at the next indentation level
                const nextIndentation = tabCount + 1;
                const partitionValues: { mode: string | null; queryGroup: string | null; source: string | null; isCalculated: boolean } = {
                    mode: null,
                    queryGroup: null,
                    source: null,
                    isCalculated: hasCalculated // Default to false
                };
                // Used for tracking the offset of the source lines
                let offSet = 1;
                for (let i = index + 1; i < allLines.length; i++) {
                    //logDebug("Processing Line", i, allLines[i]);
                    offSet++;
                    const nextLine = allLines[i];
                    const nextLineTabCount = nextLine.match(/^\t*/)?.[0].length || 0;

                    // Before identation check, make sure calculated doesn't exist, if it does update property
                    if (allLines[i].trim() === 'calculated') {
                        partitionValues.isCalculated = true; // Set to true if 'calculated' is present                    
                    }

                    // Check if the next line's indentation matches the expected indentation level
                    if (nextLineTabCount !== nextIndentation) break; // Stop if indentation changes
                    const nextTrimmedLine = nextLine.trim();

                    if (nextTrimmedLine.startsWith('mode:')) {
                        partitionValues.mode = nextTrimmedLine.split('mode:')[1].trim();
                    } else if (nextTrimmedLine.startsWith('queryGroup:')) {
                        partitionValues.queryGroup = nextTrimmedLine.split('queryGroup:')[1].trim();
                    } else if (nextTrimmedLine === 'calculated') {
                        partitionValues.isCalculated = true; // Set to true if 'calculated' is present
                    } else if (nextTrimmedLine.startsWith('source =')) {
                        const sourceLines = [];
                        for (let j = i + 1; j < allLines.length; j++) {
                            const sourceLine = allLines[j];
                            const sourceLineTabCount = sourceLine.match(/^\t*/)?.[0].length || 0;
                            const trimmedSourceLine = sourceLine.trim();
                            
                            // Stop if we encounter a line with lower or equal indentation that's not empty
                            if (sourceLineTabCount <= nextIndentation && trimmedSourceLine !== '') {
                                // Check if it's a comment or part of M code
                                if (!trimmedSourceLine.startsWith('//') && !trimmedSourceLine.startsWith('#')) {
                                    break; // Stop if it's not a comment and has lower indentation
                                }
                            }
                            
                            // Include the line (even if it's empty or a comment within the code block)
                            sourceLines.push(sourceLine.trimEnd());
                        }
                        partitionValues.source = removeTripleBackticks(sourceLines.join('\n').trimEnd()); // Join the source lines
                        break; // Stop processing after source
                    }

                }
                const mCodeTemp = {
                    name: partitionName,
                    code: partitionValues.source,
                    resultType: 'Partition',
                    // Use the start line number of the partition and add the offset for the source
                    lineNumber: position.startPositionLineNumber + offSet,
                    properties: { queryGroup: partitionValues?.queryGroup, mode: partitionValues?.mode, isCalculated: partitionValues?.isCalculated },
                };

                temp = mCodeTemp; // Assign the M code object to temp
            }
            // Special handling for 'expression' keys
            else if (key.startsWith('expression')) {
                logDebug("Expression Key", key, key.split('\n').length);
                const expressionName = key.split('=')[0].replace('expression', '').trim(); // Extract name before '='
                temp.expressionName = expressionName;
                const expressionValues: { mode: string | null; queryGroup: string | null; code: string | null; mAttributes: string | null } = {
                    mode: null,
                    queryGroup: null,
                    code: null,
                    mAttributes: null
                };
                // Extract the code after '=' until encountering 'lineageTag:', 'queryGroup:', or 'annotation' or mAttributes
                const codeLines = [];
                let firstPass = true;
                for (let i = index; i < allLines.length; i++) {
                    let nextLine: string = allLines[i].trim();
                    //allLines[i].trim();
                    if (nextLine.startsWith('lineageTag:') || nextLine.startsWith('queryGroup:') || nextLine.startsWith('annotation') || nextLine.startsWith('mAttributes:')) {
                        break; // Stop if encountering these terms
                    } else if (firstPass) {
                        const firstEqualsIndex = nextLine.indexOf('=');
                        nextLine = nextLine.slice(firstEqualsIndex + 1); // Extract code after first '='
                        logDebug("First Pass", nextLine.length, nextLine.indexOf('\n'));
                        firstPass = false; // Set to false after first pass
                    }
                    codeLines.push(nextLine);
                    logDebug("Code Lines", codeLines.length, codeLines.join('\n'));

                }
                expressionValues.code = removeTripleBackticks(codeLines.join('\n')); // Join the extracted code lines

                for (let i = index + 1; i < allLines.length; i++) {
                    const nextLine = allLines[i];
                    const nextTrimmedLine = nextLine.trim();
                    if (nextTrimmedLine.startsWith('queryGroup:')) {
                        expressionValues.queryGroup = nextTrimmedLine.split('queryGroup:')[1].trim();
                    }
                    if (nextTrimmedLine.startsWith('mAttributes:')) {
                        expressionValues.mAttributes = nextTrimmedLine.split('mAttributes:')[1].trim();
                    }
                }

                const mCodeTemp = {
                    name: expressionName,
                    code: expressionValues.code,
                    resultType: 'Expression',
                    lineNumber: position.startPositionLineNumber,
                    properties: { queryGroup: expressionValues.queryGroup, mAttributes: expressionValues.mAttributes, isCalculated: false }, // Expressions are not calculated
                };
                temp = mCodeTemp; // Assign the M code object to temp
            }

            return parsedLine;
        });

        return temp;
    });
}

// Extracts the positions of columns from the TMDL code
/**
 * Extracts the positions of columns from the TMDL code.
 * @param tmdlCode - The TMDL file content as a string.
 * @returns An array of TMDL_Position objects representing the positions of columns.
 */
export function extractColumnPositions(tmdlCode: string): TMDL_Position[] {
    const parsedLines = parseTMDLLines(tmdlCode);
    const columns = Object.keys(parsedLines).filter(key => key.toLowerCase() == "column");
    const result: TMDL_Position[] = [];

    // Iterate through columns
    columns.forEach(columnKey => {
        const columnEntries = parsedLines[columnKey];
        Object.keys(columnEntries).forEach(valueKey => {
            columnEntries[valueKey].forEach(entry => {
                result.push({
                    key: columnKey,
                    value: valueKey,
                    startPositionLineNumber: entry.startPositionLineNumber,
                    endPositionLineNumber: entry.endPositionLineNumber,
                });
            });
        });
    });

    return result;
}

// Extracts Column code and its associated properties from the TMDL code
/**
 * Extracts Column code and its associated properties from the TMDL code.
 * @param tmdlCode - The TMDL file content as a string.
 * @returns An array of Column_Code objects containing the extracted column definitions and their properties.
 */
export function extractColumnAndProperties(tmdlCode: string): Column_Code[] {
    const positions = extractColumnPositions(tmdlCode);
    const lines = tmdlCode.split('\n');

    return positions.map(position => {
        let temp: any = {}; // Initialize an empty object for each position
        const extractedCode = lines
            .slice(position.startPositionLineNumber - 1, position.endPositionLineNumber) // Extract lines inclusively
            .join('\n'); // Join the lines back into a single string

        // Parse the extracted code by tabs, colons, and equals signs
        const parsedDetails = extractedCode.split('\n').map((line, index, allLines) => {
            const trimmedLine = line.trim();
            const tabCount = line.match(/^\t*/)?.[0].length || 0; // Count leading tabs
            const [key, ...rest] = trimmedLine.split(/[=]/); // Split by colon or equals
            const value = rest.join(':').trim(); // Join the rest as the value

            const parsedLine: any = {
                tabCount,
                key: key.trim(),
                value,
            };

            // Special handling for 'column' keys
            if (key.startsWith('column')) {
                //logDebug("Column Key", key);
                const columnName = key.replace('column', '').trim(); // Extract column name
                temp.columnName = columnName;

                // Initialize column values
                const columnValues: {
                    dataType: string | null,
                    formatString: string | null,
                    lineageTag: string | null,
                    isAvailableInMdx: boolean,
                    isHidden: boolean,
                    isKey: boolean,
                    sourceProviderType: string | null,
                    summarizeBy: string | null,
                    sourceColumn: string | null,
                    isVisible: boolean,
                    sortByColumn: string | null,
                    annotations: { [key: string]: string }
                } = {
                    dataType: null,
                    formatString: null,
                    lineageTag: null,
                    isAvailableInMdx: true, // Default to true
                    isHidden: false, // Default to false
                    isKey: false, // Default to false
                    sourceProviderType: null,
                    summarizeBy: null,
                    sourceColumn: null,
                    isVisible: true, // Default to true
                    sortByColumn: null,
                    annotations: {}
                };

                // Extract values at the next indentation level
                const nextIndentation = tabCount + 1;
                
                for (let i = index + 1; i < allLines.length; i++) {
                    //logDebug("Processing Column Line", i, allLines[i]);
                    const nextLine = allLines[i];
                    const nextLineTabCount = nextLine.match(/^\t*/)?.[0].length || 0;
                    const nextTrimmedLine = nextLine.trim();

                    // Check if the next line's indentation matches the expected indentation level
                    if (nextLineTabCount !== nextIndentation) {
                        break; // Stop if indentation decreases and line is not empty
                    }// Check if the next line's indentation matches the expected indentation level


                    // Skip empty lines
                    if (nextTrimmedLine === '') continue;

                    // Handle annotations (they typically have higher indentation)
                    if (nextTrimmedLine.startsWith('annotation ')) {
                        const annotationContent = nextTrimmedLine.replace('annotation ', '');
                        const [annotationKey, annotationValue] = annotationContent.split(' = ');
                        if (annotationKey && annotationValue) {
                            columnValues.annotations[annotationKey.trim()] = annotationValue.trim();
                        }
                        continue;
                    }

                    // Handle standard properties
                    if (nextLineTabCount === nextIndentation) {
                        if (nextTrimmedLine.startsWith('dataType:')) {
                            columnValues.dataType = nextTrimmedLine.split('dataType:')[1].trim();
                        } else if (nextTrimmedLine.startsWith('formatString:')) {
                            columnValues.formatString = nextTrimmedLine.split('formatString:')[1].trim();
                        } else if (nextTrimmedLine.startsWith('lineageTag:')) {
                            columnValues.lineageTag = nextTrimmedLine.split('lineageTag:')[1].trim();
                        } else if (nextTrimmedLine.startsWith('isAvailableInMdx:')) {
                            columnValues.isAvailableInMdx = nextTrimmedLine.split('isAvailableInMdx:')[1].trim().toLowerCase() === 'true';
                        } else if (nextTrimmedLine.startsWith('isHidden')) {
                            columnValues.isHidden = true;
                        }else if (nextTrimmedLine.startsWith('isKey')) {
                            columnValues.isKey = true;
                        }                            
                         else if (nextTrimmedLine.startsWith('sourceProviderType:')) {
                            columnValues.sourceProviderType = nextTrimmedLine.split('sourceProviderType:')[1].trim();
                        } else if (nextTrimmedLine.startsWith('summarizeBy:')) {
                            columnValues.summarizeBy = nextTrimmedLine.split('summarizeBy:')[1].trim();
                        } else if (nextTrimmedLine.startsWith('sourceColumn:')) {
                            columnValues.sourceColumn = nextTrimmedLine.split('sourceColumn:')[1].trim();
                        } else if (nextTrimmedLine.startsWith('isHidden:')) {
                            const isHidden = nextTrimmedLine.split('isHidden:')[1].trim().toLowerCase() === 'true';
                            columnValues.isVisible = !isHidden; // Invert isHidden to get isVisible
                        } else if (nextTrimmedLine.startsWith('isKey:')) {
                            columnValues.isKey = nextTrimmedLine.split('isKey:')[1].trim().toLowerCase() === 'true';
                        } else if (nextTrimmedLine.startsWith('sortByColumn:')) {
                            columnValues.sortByColumn = nextTrimmedLine.split('sortByColumn:')[1].trim();
                        }
                    }
                }

                const columnTemp: Column_Code = {
                    name: temp.columnName,
                    dataType: columnValues.dataType || 'unknown',
                    formatString: columnValues.formatString ?? undefined,
                    lineageTag: columnValues.lineageTag ?? undefined,
                    isAvailableInMdx: columnValues.isAvailableInMdx,
                    isHidden: columnValues.isHidden,
                    isKey: columnValues.isKey,
                    sourceProviderType: columnValues.sourceProviderType ?? undefined,
                    summarizeBy: columnValues.summarizeBy ?? undefined,
                    sourceColumn: columnValues.sourceColumn ?? undefined,
                    annotations: Object.keys(columnValues.annotations).length > 0 ? columnValues.annotations : undefined,
                    lineNumber: position.startPositionLineNumber,
                    properties: {
                        isVisible: columnValues.isVisible,
                        isKey: columnValues.isKey,
                        sortByColumn: columnValues.sortByColumn ?? undefined
                    }
                };

                temp = columnTemp; // Assign the column object to temp
            }

            return parsedLine;
        });

        return temp;
    }).filter(column => column && column.name); // Filter out any invalid entries
}

// Extracts the positions of relationships from the TMDL code
/**
 * Extracts the positions of relationships from the TMDL code.
 * @param tmdlCode - The TMDL file content as a string.
 * @returns An array of TMDL_Position objects representing the positions of relationships.
 */
export function extractRelationshipPositions(tmdlCode: string): TMDL_Position[] {
    const parsedLines = parseTMDLLines(tmdlCode);
    const relationships = Object.keys(parsedLines).filter(key => key.toLowerCase() === "relationship");
    const result: TMDL_Position[] = [];

    // Iterate through relationships
    relationships.forEach(relationshipKey => {
        const relationshipEntries = parsedLines[relationshipKey];
        Object.keys(relationshipEntries).forEach(valueKey => {
            relationshipEntries[valueKey].forEach(entry => {
                result.push({
                    key: relationshipKey,
                    value: valueKey,
                    startPositionLineNumber: entry.startPositionLineNumber,
                    endPositionLineNumber: entry.endPositionLineNumber,
                });
            });
        });
    });

    return result;
}

// Extracts Relationship code and its associated properties from the TMDL code
/**
 * Extracts Relationship code and its associated properties from the TMDL code.
 * @param tmdlCode - The TMDL file content as a string.
 * @returns An array of Relationship_Code objects containing the extracted relationship definitions and their properties.
 */
export function extractRelationshipAndProperties(tmdlCode: string): Relationship_Code[] {
    const positions = extractRelationshipPositions(tmdlCode);
    const lines = tmdlCode.split('\n');

    /**
     * Helper function to parse table and column names from column references
     * @param columnRef - The column reference in format 'Table'.'Column' or Table.Column
     * @returns Object containing table name and column name
     */
    function parseColumnReference(columnRef: string): { tableName: string; columnName: string } {
        if (!columnRef) {
            return { tableName: 'unknown', columnName: 'unknown' };
        }

        // Handle quoted table names: 'Table Name'.'Column Name'
        const quotedMatch = columnRef.match(/^'([^']+)'\.(?:'([^']+)'|([^.]+))$/);
        if (quotedMatch) {
            return {
                tableName: quotedMatch[1],
                columnName: quotedMatch[2] || quotedMatch[3]
            };
        }

        // Handle unquoted table names: TableName.ColumnName
        const unquotedMatch = columnRef.match(/^([^.]+)\.(.+)$/);
        if (unquotedMatch) {
            return {
                tableName: unquotedMatch[1],
                columnName: unquotedMatch[2]
            };
        }

        // Fallback if parsing fails
        return { tableName: 'unknown', columnName: columnRef };
    }

    return positions.map(position => {
        let temp: any = {}; // Initialize an empty object for each position
        const extractedCode = lines
            .slice(position.startPositionLineNumber - 1, position.endPositionLineNumber) // Extract lines inclusively
            .join('\n'); // Join the lines back into a single string

        // Parse the extracted code by tabs, colons, and equals signs
        const parsedDetails = extractedCode.split('\n').map((line, index, allLines) => {
            const trimmedLine = line.trim();
            const tabCount = line.match(/^\t*/)?.[0].length || 0; // Count leading tabs
            const [key, ...rest] = trimmedLine.split(/[:]/); // Split by colon
            const value = rest.join(':').trim(); // Join the rest as the value

            const parsedLine: any = {
                tabCount,
                key: key.trim(),
                value,
            };

            // Special handling for 'relationship' keys
            if (key.startsWith('relationship')) {
                const relationshipGuid = key.replace('relationship', '').trim(); // Extract GUID
                temp.relationshipGuid = relationshipGuid;

                // Initialize relationship values with defaults
                const relationshipValues: {
                    fromColumn: string | null,
                    toColumn: string | null,
                    isActive: boolean,
                    crossFilteringBehavior: string,
                    fromCardinality: string,
                    toCardinality: string,
                    securityFilteringBehavior: string | null,
                    relyOnReferentialIntegrity: boolean | null
                } = {
                    fromColumn: null,
                    toColumn: null,
                    isActive: true, // Default to true
                    crossFilteringBehavior: 'automatic', // Default behavior
                    fromCardinality: 'many', // Default cardinality
                    toCardinality: 'one', // Default cardinality
                    securityFilteringBehavior: null,
                    relyOnReferentialIntegrity: null
                };

                // Extract values at the next indentation level
                const nextIndentation = tabCount + 1;
                
                for (let i = index + 1; i < allLines.length; i++) {
                    const nextLine = allLines[i];
                    const nextLineTabCount = nextLine.match(/^\t*/)?.[0].length || 0;
                    const nextTrimmedLine = nextLine.trim();

                    // Check if the next line's indentation matches the expected indentation level
                    if (nextLineTabCount !== nextIndentation) {
                        break; // Stop if indentation decreases
                    }

                    // Skip empty lines
                    if (nextTrimmedLine === '') continue;

                    // Handle standard relationship properties
                    if (nextTrimmedLine.startsWith('fromColumn:')) {
                        relationshipValues.fromColumn = nextTrimmedLine.split('fromColumn:')[1].trim();
                    } else if (nextTrimmedLine.startsWith('toColumn:')) {
                        relationshipValues.toColumn = nextTrimmedLine.split('toColumn:')[1].trim();
                    } else if (nextTrimmedLine.startsWith('isActive:')) {
                        relationshipValues.isActive = nextTrimmedLine.split('isActive:')[1].trim().toLowerCase() === 'true';
                    } else if (nextTrimmedLine.startsWith('isActive') && !nextTrimmedLine.includes(':')) {
                        // Handle boolean properties without explicit value (assumes false when present)
                        relationshipValues.isActive = false;
                    } else if (nextTrimmedLine.startsWith('crossFilteringBehavior:')) {
                        relationshipValues.crossFilteringBehavior = nextTrimmedLine.split('crossFilteringBehavior:')[1].trim();
                    } else if (nextTrimmedLine.startsWith('fromCardinality:')) {
                        relationshipValues.fromCardinality = nextTrimmedLine.split('fromCardinality:')[1].trim();
                    } else if (nextTrimmedLine.startsWith('toCardinality:')) {
                        relationshipValues.toCardinality = nextTrimmedLine.split('toCardinality:')[1].trim();
                    } else if (nextTrimmedLine.startsWith('securityFilteringBehavior:')) {
                        relationshipValues.securityFilteringBehavior = nextTrimmedLine.split('securityFilteringBehavior:')[1].trim();
                    } else if (nextTrimmedLine.startsWith('relyOnReferentialIntegrity:')) {
                        relationshipValues.relyOnReferentialIntegrity = nextTrimmedLine.split('relyOnReferentialIntegrity:')[1].trim().toLowerCase() === 'true';
                    }
                }

                // Parse table and column names from the column references
                const fromParsed = parseColumnReference(relationshipValues.fromColumn ?? 'unknown');
                const toParsed = parseColumnReference(relationshipValues.toColumn ?? 'unknown');

                const relationshipTemp: Relationship_Code = {
                    guid: temp.relationshipGuid,
                    fromColumn: relationshipValues.fromColumn || 'unknown',
                    toColumn: relationshipValues.toColumn || 'unknown',
                    fromTable: fromParsed.tableName,
                    toTable: toParsed.tableName,
                    fromColumnName: fromParsed.columnName,
                    toColumnName: toParsed.columnName,
                    isActive: relationshipValues.isActive,
                    crossFilteringBehavior: relationshipValues.crossFilteringBehavior,
                    fromCardinality: relationshipValues.fromCardinality,
                    toCardinality: relationshipValues.toCardinality,
                    lineNumber: position.startPositionLineNumber,
                    properties: {
                        securityFilteringBehavior: relationshipValues.securityFilteringBehavior ?? undefined,
                        relyOnReferentialIntegrity: relationshipValues.relyOnReferentialIntegrity !== null ? relationshipValues.relyOnReferentialIntegrity : undefined
                    }
                };

                temp = relationshipTemp; // Assign the relationship object to temp
            }

            return parsedLine;
        });

        return temp;
    }).filter(relationship => relationship && relationship.guid); // Filter out any invalid entries
}

// Removes leading and trailing triple backticks from a given code string.
/**
 * Removes leading and trailing triple backticks from a given code string.
 * @param code - The code string from which to remove the triple backticks.
 * @returns The cleaned code string without leading and trailing triple backticks.
 */
function removeTripleBackticks(code: string): string {
    let removedBackticks = code;

    if (code.trimStart().startsWith('```')) {
        code = code.trimStart().replace(/^```/g, ''); // Remove leading backticks
    }

    if (code.trimEnd().endsWith('```')) { // Check if the code ends with a backtick
        code = code.trimEnd().replace(/```$/g, ''); // Remove trailing backticks
    }

    return code.trimEnd();
}