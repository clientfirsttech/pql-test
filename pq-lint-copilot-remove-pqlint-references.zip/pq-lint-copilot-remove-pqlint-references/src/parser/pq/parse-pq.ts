/**
 * Power Query Parser Module
 * 
 * This module provides functionality to parse Power Query (M) code into its abstract syntax tree (AST),
 * lexed tokens, and error messages. It includes utilities for handling escaped quotes, removing surrounding
 * quotes, and parsing the input text using the Power Query parser library.
 * 
 * Key Features:
 * - Removes surrounding quotes from input strings to ensure clean parsing.
 * - Parses Power Query text into an AST and lexed tokens using the `@microsoft/powerquery-parser` library.
 * - Handles errors during lexing and parsing, providing detailed error messages.
 * 
 * Functions:
 * - `removeSurroundingQuotes`: Removes surrounding double quotes from a string if present.
 * - `parsePowerQueryText`: Parses Power Query text and returns a structured result containing the AST, lexed tokens, and errors.
 * 
 * Dependencies:
 * - `@microsoft/powerquery-parser`: Provides the core parsing and lexing functionality.
 * - `parse-types`: Defines the types used for the parsing results.
 */

import { DefaultSettings, TaskUtils, Task } from '@microsoft/powerquery-parser';
import { LexedJson, ParseResult } from './parse-types';
import { logDebug } from '../../lint/rule-assistance';

/**
 * Removes surrounding double quotes from a string if they are present.
 * 
 * @param input - The input string to process.
 * @returns The string without surrounding double quotes, or the original string if no quotes are present.
 */
function removeSurroundingQuotes(input: string | null | undefined): string | null | undefined {
    // If input is null/undefined or blank (only whitespace), return it unchanged
    if (input == null) {
        return input;
    }
    if (input.trim() === "") {
        return input;
    }

    if (input.startsWith('"') && input.endsWith('"')) {
        return input.slice(1, -1); // Remove the first and last character
    }
    return input; // Return the string unchanged if no surrounding quotes
}

/**
 * Parses Power Query text and returns the abstract syntax tree (AST), lexed text, and any error message.
 * 
 * @param text - The Power Query text to be parsed.
 * @returns A promise that resolves to a ParseResult object containing the AST, lexed text, and any error message.
 */
export async function parsePowerQueryText(text: string): Promise<ParseResult> {

    // Check if the input text is empty, undefined, or just whitespace    
    text = removeSurroundingQuotes(text) ?? text;
    // Try lexing and parsing the input text, which returns a Result object.
    // A Result<T, E> is the union (Ok<T> | Error<E>).
    const task: Task.TriedLexParseTask = await TaskUtils.tryLexParse(DefaultSettings, text);
    
    // Initialize the result object
    const result: ParseResult = {
        ast: null,
        lexed: [] as LexedJson[],
        error: null
    };

    // If lexing and parsing were successful, return the abstract syntax tree (AST) and lexed text as formatted JSON strings.
    if (TaskUtils.isParseStageOk(task)) {
        result.ast = task.ast as unknown;
        result.lexed = task.lexerSnapshot.tokens as LexedJson[];
    }
    // If there was an error during lexing, return the error message.
    else if (TaskUtils.isLexStageError(task)) {
        result.error = task.error.message
    }
    // If there was an error during parsing, return a detailed error message.
    else if (TaskUtils.isParseStageError(task)) {
        // Determine if a CommonError or ParseError was thrown and construct the error message accordingly.
        let errorMessage = `A ${task.isCommonError ? "CommonError" : "ParseError"} was thrown during parsing: ${task.error.message}`;

        // If it is a ParseError, include additional information about the parsed leaf nodes.
        if (!task.isCommonError) {
            errorMessage += `\nParsed ${task} leaf nodes`;
        }

        result.error = errorMessage;
    }
    // Return the result object containing the AST, lexed text, and any error message.
    return result;
}