import { logDebug } from "../../lint/rule-assistance";
import { M_Code_From_Copied_PQ } from "../pq/parse-types";

export async function parseCopiedPQ(input: string): Promise<M_Code_From_Copied_PQ[]> {
  const lines = input.split(/\r?\n/);
  const sections: string[] = [];
  let currentSection: string[] = [];
  const lineNumbers: number[] = [];
  lineNumbers.push(1); // Initialize with the first section starting at line 0
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    // Detect section start by looking for comment lines starting a new block
    if (
      line.trim().startsWith("//") &&
      i + 1 < lines.length &&
      lines[i + 1].trim() !== "" &&
      (
        lines[i + 1].trim().startsWith("let") ||
        lines[i + 1].trim().match(/^["\(]/) ||         // literal value or function start
        lines[i + 1].trim().match(/^[\d]+ meta/)        // parameter literal
      )
    ) {
      if (currentSection.length > 0) {
        sections.push(currentSection.join("\n").trim());
        currentSection = [];
        lineNumbers.push(i + 1); // Store the line number of the new section
        logDebug(`New section detected at line ${i + 1}: ${line.trim()}`);

      }
    }

    currentSection.push(line);
  }// end for loop

  // Add final section
  if (currentSection.length > 0) {
    sections.push(currentSection.join("\n").trim());
  }
    // Remove entries where the section is empty after trimming and cleaning
  const results: M_Code_From_Copied_PQ[] = [];
  for (let i = 0; i < sections.length; i++) {
      const cleaned = sections[i].trim().replace(/\s+/g, "");
      if (cleaned !== "") {
          results.push({
              code: sections[i],
              lineNumber: lineNumbers[i] || 0 // Use the stored line number or default to 0
          });
      }
  } 

  return results;
}

export default parseCopiedPQ;
