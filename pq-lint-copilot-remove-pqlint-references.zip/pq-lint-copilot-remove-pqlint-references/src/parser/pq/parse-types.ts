/**
 * Interface representing the result of parsing Power Query text.
 */
export interface ParseResult {
  /**
   * The abstract syntax tree (AST) resulting from the parse operation.
   */
  ast: any;

  /**
   * The lexed tokens resulting from the lexing operation.
   */
  lexed: LexedJson[] | undefined; // Change from null to undefined to match usage

  /**
   * Any error message encountered during parsing.
   */
  error: string | null;
}

/**
 * Interface representing a position in the code.
 */
export interface Position {
  /**
   * The code unit position.
   */
  codeUnit: number;

  /**
   * The line code unit position.
   */
  lineCodeUnit: number;

  /**
   * The line number.
   */
  lineNumber: number;
}

/**
 * Interface representing a lexed token in JSON format.
 */
export interface LexedJson {
  /**
   * The kind of the token.
   */
  kind: string;

  /**
   * The data of the token.
   */
  data: string;

  /**
   * The starting position of the token.
   */
  positionStart: Position;

  /**
   * The ending position of the token.
   */
  positionEnd: Position;
}


// Represents a copied Power Query (PQ) code as copied from the copied and paste feature in Power Query.
export interface M_Code_From_Copied_PQ {
    code: string | null; // The extracted M code.
    lineNumber: number; // The starting line number of the partition or expression.
}


export interface PQ_Copied_PowerQueryPairing {
  MCode: M_Code_From_Copied_PQ;
  ParseResult: ParseResult;
}