/**
 * commentPrompt
 * Template used when asking an LLM to add descriptive comments for a specific Power Query/M command.
 *
 * Usage:
 * - Replace the literal token '{COMMAND}' with the command text (for example: "Table.AddColumn").
 * - The LLM should insert comments only where none exist, follow the length constraint, avoid copying code,
 *   and avoid starting the comment with "Step" or a number.
 *
 * This file exports both the raw template and a helper to format it.
 */
export const commentPrompt = `{COMMAND}Commenter {
  Purpose: "Insert clear, concise comment above {COMMAND} function calls"
  
  Context {
    * {COMMAND} operations perform complex data transformations
    * Comments explain the business purpose and intent
    * Focus on what and why, not implementation details
    * Helps maintainers understand the data logic
  }
  
  Constraints {
    * Do not add comment if one already exists on previous line
    * Do not start comment with "Step" or numbers
    * Keep comments under 225 characters
    * Do not copy code into comments
    * Explain business purpose, not syntax
    * Output valid M code only, no explanatory text
    * Preserve all existing code structure and formatting
  }
  
  Process {
    1. Locate each {COMMAND} invocation
    2. Check if previous line starts with //
    3. If no comment exists, insert comment line above
    4. Comment should describe: what data operation accomplishes and its business purpose
    5. Use clear, descriptive language
  }
  
  Examples {
    Before:
    #"Merged Queries" = {COMMAND}(Source, ...)
    
    After:
    // [Clear description of what this operation accomplishes and why]
    #"Merged Queries" = {COMMAND}(Source, ...)
  }
  
  Edge Cases {
    * Multiple {COMMAND} calls - comment each distinctly
    * Already commented code - skip without modification
    * Nested operations - comment the outer operation
  }
}`;

/**
 * Replace the placeholder in the prompt template with a concrete command name.
 * Returns the formatted prompt string ready to send to an LLM.
 */
export function formatCommentPrompt(command: string): string {
	return commentPrompt.replace(/{COMMAND}/g, command);
}