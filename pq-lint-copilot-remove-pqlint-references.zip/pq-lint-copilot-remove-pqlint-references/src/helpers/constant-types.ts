/**
 * Class that stores application constants.
 * This class contains constants for mode, ipAddress, and email.
 */
export class QueryStringConstants {
    public static readonly MODE: string = "mode";
    public static readonly MODE_DEFAULT: string = "free";
    public static readonly IP_ADDRESS: string = "ipaddress";
    public static readonly IP_ADDRESS_DEFAULT: string = "Unknown IP";
    public static readonly EMAIL: string = "email";
    public static readonly EMAIL_DEFAULT: string = "Unknown Email";
    public static readonly SUBSCRIPTION_ID: string = "subscription-id";
    public static readonly SUBSCRIPTION_ID_DEFAULT: string = "Unknown Subscription ID";
    public static readonly API_PRODUCT_ID: string = "product-id";
    public static readonly API_PRODUCT_ID_DEFAULT: string = "Unknown Product ID";
    public static readonly SUBSCRIPTION_KEY: string = "subscription-key";
    public static readonly SUBSCRIPTION_KEY_DEFAULT: string = "Unknown Subscription Key";   
    public static readonly STRIPE_ID: string = "stripe-id";
    public static readonly STRIPE_ID_DEFAULT: string = "Unknown Stripe ID";
}

export class HeaderConstants {
    public static readonly SUBSCRIPTION_KEY: string = "Ocp-Apim-Subscription-Key";
}

/**
 * Class that stores mode constants.
 * This class contains constants for free and pro modes.
 */
export class ModeConstants {
    public static readonly FREE: string = "free";
    public static readonly PRO: string = "pro";
}   

export class EnvironmentConstants {
    public static readonly DEVELOPMENT: string = "development";
    public static readonly PRODUCTION: string = "production";
    public static readonly PROD: string = "prod";
}
