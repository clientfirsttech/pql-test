/**
 * Enum for allowed queue actions.
 */
export enum QueueAction {
    CleanupPQ = "cleanupPQ",
    CleanupTMDL = "cleanupTMDL"
}

/**
 * Enum for allowed job statuses.
 */
export enum JobStatusEnum {
    Queued = "Queued",
    Started = "Started",
    InProgress = "In Progress",
    Completed = "Completed",
    Failed = "Failed"
}

/**
 * Interface for the message sent to the Azure Storage Queue for cleanupPQ jobs.
 */
export interface QueueMessage {
    jobId: string;
    action: QueueAction;
}

/*
* Interface for the response details sent.
*/
export interface JobStatus {
    jobId: string;
    status: JobStatusEnum;
    email?: string
    error?: string;
    input?: any;
    result?: any;
    updatedAt: string; // ISO datetime string
}