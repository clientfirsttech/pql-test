import { SeverityLevel } from "../lint/rule-types";

/**
 * Constants for format types
 */
export const FormatConstants = {
    TMDL: 'tmdl' as const,
    PQ: 'pq' as const
};

export type FormatType = typeof FormatConstants[keyof typeof FormatConstants];

/**
 * Interface representing the options for linting.
 */
export interface LintOptions {
    severity?: SeverityLevel
    format?: FormatType
    verbose?: boolean
}

/**
 * Interface representing the request body for linting.
 */
export interface LintRequest {
    code: string;           // Multiline string with linebreaks
    rules?: string[];        // Array of rule names
    options?: LintOptions;   // Linting options (e.g., severity), only raise options meeting this minimum level
}

/**
 * Interface representing AI fix instructions for a rule.
 */
export interface FixTMDLRequest {
    code: string;
    rulesResults: any[]; // Array of RuleResult objects
}

/**
 * Interface representing a subscription with associated Stripe ID
 */
export interface Subscription {
    subscriptionId: string;
    subscriptionKey: string;
}