/**
 * Formats an email address by replacing '@' with '-' and removing all characters except letters, numbers, and dashes.
 * @param email The email address to format.
 * @returns The formatted email string.
 */
export function formatEmailForSubscription(email: string): string {
    return email.replace(/@/g, '-').replace(/[^a-zA-Z0-9-]/g, '');
}

/**
 * Formats a subscription id by replacing underscores with dashes.
 * @param subscriptionId The subscription id to format.
 * @returns The formatted subscription id string.
 */
export function formatSubscriptionId(subscriptionId: string): string {
    return subscriptionId.replace(/_/g, '-');
}
