import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";

// Create a Rule object with the function as a string
export const consolidateSimilarTableTransformColumnTypes: PowerQueryRule = {
    ID: "consolidate-similar-table-transform-column-types",
    Name: "Consolidate Multiple Change Type Steps to Improve Performance",
    Category: "Best Practice",
    Description: "Multiple Change Types Steps should be consolidated to improve performance. By consolidating multiple change types steps into less step, you can reduce the number of operations and improve performance.",
    References: [
        {
            Description: "Power BI Query Performance: Query Diagnostics",
            Link: "https://sqlserverbi.blog/2020/02/16/power-bi-query-performance-query-diagnostics/"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Free,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const lexTokens : LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // Identify the instances of Number.Round
        const instances = lexTokens.filter((current) => {
            return current.kind === "Identifier" && (current.data === "Table.TransformColumns" || current.data === "Table.TransformColumnTypes");
        });
        // If more than 4 instances are found, add them to the error objects
        if (instances.length >= 4) {
            instances.forEach(element => {
                const errorObject: ErrorObject = {
                    positionStart: element.positionStart,
                    positionEnd: element.positionEnd
                };
                errorObjects.push(errorObject);
            });
        }

        return errorObjects;
    }
};

export default consolidateSimilarTableTransformColumnTypes;