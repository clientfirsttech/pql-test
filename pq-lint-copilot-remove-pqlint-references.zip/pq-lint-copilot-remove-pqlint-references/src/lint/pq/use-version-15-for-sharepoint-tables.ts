import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findIdentifiers, findNodesWithRecursiveExpression } from "../rule-assistance";

// Create a Rule object with the function as a string
export const useVersion15ForSharePointTables: PowerQueryRule = {
    ID: "use-version-15-for-sharepoint-tables",
    Name: "Use API Version 15 for SharePoint On-Premises Connections",
    Category: "Best Practice",
    Description: "For SharePoint on-premise connections, use API version 15.",
    References: [
        {
            Description: "Chapter 3 - The Ultimate Power Query Cookbook for Power BI and Excel",
            Link: "https://amzn.to/3H3EJUq"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,    
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) return [];

        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;        
        const errorObjects: ErrorObject[] = [];

        const instances = findIdentifiers(lexTokens, "SharePoint.Tables") ?? [];
        // Find the index of the relevant identifiers in the lexed tokens
        instances.forEach(instance => {
            const searchString = '"positionStart":' + JSON.stringify(instance.positionStart, null, 0) + ',"positionEnd":' + JSON.stringify(instance.positionEnd, null, 0);

            const tempArray : any[] = [];
            tempArray.push(instance);
            const apiVersionUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens,'"literal":"ApiVersion"');
            const version14Usage = findNodesWithRecursiveExpression(tempArray, aSTTokens,'"literal":"14",');
            const versionAutoUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens,'"literal":"Auto",');
            const implementationUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens,'"literal":"Implementation"');

            // Check to make sure it's on-premise (no implemenation) and that the API version is not 15
            if (apiVersionUsage.length > 0 && (version14Usage.length > 0 || versionAutoUsage.length > 0) && implementationUsage.length === 0) {
                const errorObject: ErrorObject = {
                    positionStart: instance.positionStart,
                    positionEnd: instance.positionEnd
                };
                errorObjects.push(errorObject);
            }            
        });

        return errorObjects;
    }
};

export default useVersion15ForSharePointTables;