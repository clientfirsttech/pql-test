import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findIdentifiers } from "../rule-assistance";

// Create a Rule object
export const useNameForSalesforceReports: PowerQueryRule = {
    ID: "use-name-for-salesforce-reports",
    Name: "Use 'Name' instead of 'Label' for Salesforce Reports",
    Category: "Potential Issue",
    Description: "For Salesforce Reports, use the Name argument instead of Label. The Name field is unique while Label field can change causing an error in loading data.",
    References: [
        {
            Description:"Chapter 5 - The Ultimate Power Query Cookbook for Power BI and Excel",
            Link: "https://amzn.to/3H3EJUq"
        }
    ],     
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) return [];

        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const errorObjects: ErrorObject[] = [];

        // Find the position of the Salesforce.Reports call
        const instances: LexedJson[] = findIdentifiers(lexTokens, "Salesforce.Reports") ?? [];

        // Find the position of the variable list call
        const aSTElements = input.ast?.variableList?.elements;

        // Check for Salesforce.Reports instance before checking for Kind and Item
        instances.forEach(instance => {

            const searchString = '"positionStart":' + JSON.stringify(instance.positionStart, null, 0) + ',"positionEnd":' + JSON.stringify(instance.positionEnd, null, 0);

            // Find the element that matches the target positionStart
            const matchingIndex = aSTElements.findIndex((element: any) => {
                // Check if the current object matches the snippet
                if (JSON.stringify(element, null, 0).includes(searchString)) {
                    return true; // Return the matching element
                }
            }
            );

            // If a matching element is found
            if (matchingIndex !== -1 && matchingIndex + 1 <= aSTElements.length - 1) {

                // We'll assume the next element will be the Item and Kind section
                const jsonString = JSON.stringify(aSTElements[matchingIndex + 1], null, 0);

                // Check if the string contains the Item and Kind sequence
                const hasLabel = jsonString.includes('"literal":"Label"');

                // If used then add to error objects
                if (hasLabel == true) {
                    const errorObject: ErrorObject = {
                        positionStart: aSTElements[matchingIndex + 1].tokenRange.positionStart,
                        positionEnd: aSTElements[matchingIndex + 1].tokenRange.positionEnd
                    };
                    errorObjects.push(errorObject);
                }
            }
        });

        return errorObjects;
    }
};

export default useNameForSalesforceReports;