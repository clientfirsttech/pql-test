import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { checkMissingComments } from "../rule-assistance";
import { formatCommentPrompt } from "../../rewrite/rule-prompt";

// Create a Rule object with the function as a string
export const requireCommentForTableAddColumn: PowerQueryRule = {
    ID: "require-comment-for-table-add-column",
    Name: "Add Comment for Custom Column to Improve Documentation",
    Category: "Best Practice",
    Description: "Add Comments for Complicated Steps - For a custom column, if the previous line does not have a preceding comment line, we suggest renaming the columns and/or inserting a comment.",
    References: [
        {
            Description: "Best Practice: Comment Your Power Query",
            Link: "https://youtu.be/6qQycs89NFo"
        },
        {
            Description: "Doing Power BI the Right Way - 4 Power Query Design Best Practices",
            Link: "https://sqlserverbi.blog/2021/02/14/doing-power-bi-the-right-way-4-power-query-design-best-practices/"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Free,
    AIFixInstructions:{
        Description: "Automatically add a comment for the custom column step.",
        Prompt: formatCommentPrompt("Table.AddColumn"),
        IsActive: true,
        IsWholeQueryFix: false
    },
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) return [];

        const lexTokens: LexedJson[] = input.lexed as LexedJson[];

        return checkMissingComments(lexTokens, "Table.AddColumn");
    }
};

export default requireCommentForTableAddColumn;