import { ParseResult } from "../../parser/pq/parse-types";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { containsTokenSequence, findIdentifiers, logDebug, searchAST } from "../rule-assistance";
import { log } from "console";

// Create a Rule object
export const useItemAndKindForExcelConnection: PowerQueryRule = {
  ID: "use-item-and-kind-for-excel-connection",
  Name: "Explicitly Set Item Name and Type for Excel Connections",
  Category: "Potential Issue",
  Description: "Explicitly state the item name and type for Excel connection. This can avoid an issue if a new sheet is added or if you have a table and sheet with the same name.",
  References: [
    {
        Description:"Chapter 2 - The Ultimate Power Query Cookbook for Power BI and Excel",
        Link: "https://amzn.to/3H3EJUq"
    }
],   
  Severity: SeverityLevel.Error,
  MinLicenseLevel: LicenseLevel.Free,
  Check: (input: ParseResult | undefined): ErrorObject[] => {
    // Cast to access the properties
    const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
    // Initialize an array to collect all error objects
    const errorObjects: ErrorObject[] = [];

    // Find the position of the Excel.Workbook call
    const instances: LexedJson[] = findIdentifiers(lexTokens, "Excel.Workbook") ?? [];

    // Define token sequences to search for [Item] and [Kind]
    const itemSequence = [
      { kind: "LeftBracket", data: "[" },
      { kind: "Identifier", data: "Item" },
      { kind: "RightBracket", data: "]" }
    ];

    const itemEqualsSequence = [
      { kind: "Identifier", data: "Item" },
      { kind: "Equal", data: "=" }
    ];

    const kindSequence = [
      { kind: "LeftBracket", data: "[" },
      { kind: "Identifier", data: "Kind" },
      { kind: "RightBracket", data: "]" }
    ];

    const kindEqualsSequence = [
      { kind: "Identifier", data: "Kind" },
      { kind: "Equal", data: "=" }
    ];

    // Check for Excel.Workbook instance before checking for Kind and Item
    instances.forEach((instance, index) => {
      // Find the index of the current instance in lexTokens
      const instanceIndex = lexTokens.findIndex(token => 
        token.positionStart.codeUnit === instance.positionStart.codeUnit &&
        token.positionStart.lineNumber === instance.positionStart.lineNumber
      );

      if (instanceIndex === -1) return;

      // Determine the range to search: from current instance to next instance or end of tokens
      const nextInstance = instances[index + 1];
      let endIndex = lexTokens.length;
      
      if (nextInstance) {
        const nextInstanceIndex = lexTokens.findIndex(token => 
          token.positionStart.codeUnit === nextInstance.positionStart.codeUnit &&
          token.positionStart.lineNumber === nextInstance.positionStart.lineNumber
        );
        if (nextInstanceIndex !== -1) {
          endIndex = nextInstanceIndex;
        }
      }

      // Slice the tokens to search in the relevant range
      const tokensToSearch = lexTokens.slice(instanceIndex, endIndex);

      // Check if both [Item] and [Kind] sequences are present
      const hasItem = containsTokenSequence(tokensToSearch, itemSequence) || 
                      containsTokenSequence(tokensToSearch, itemEqualsSequence);
      const hasKind = containsTokenSequence(tokensToSearch, kindSequence) || 
                      containsTokenSequence(tokensToSearch, kindEqualsSequence);
      logDebug(`Instance ${index + 1}: hasItem=${hasItem}, hasKind=${hasKind}`);
      // If either is missing, add to error objects
      if (hasItem === false || hasKind === false) {
        let errorStart = instance.positionStart;
        let errorEnd = instance.positionEnd;
        
        // If at least one is found, use its position for the error
        if (hasItem === true || hasKind === true) {
          // Find the position of Item sequence if it exists
          if (hasItem === true) {
            for (let i = 0; i < tokensToSearch.length - 2; i++) {
              if (tokensToSearch[i].kind === "LeftBracket" && tokensToSearch[i].data === "[" &&
                  tokensToSearch[i + 1].kind === "Identifier" && tokensToSearch[i + 1].data === "Item" &&
                  (tokensToSearch[i + 2].kind === "RightBracket" && tokensToSearch[i + 2].data === "]" ||
                   tokensToSearch[i + 2].kind === "Equal" && tokensToSearch[i + 2].data === "=")) {
                errorStart = tokensToSearch[i].positionStart;
                errorEnd = tokensToSearch[i + 2].positionEnd;
                break;
              }
            }
          }
          // Find the position of Kind sequence if it exists (and Item doesn't)
          if (hasKind === true && hasItem === false) {
            for (let i = 0; i < tokensToSearch.length - 2; i++) {
              if (tokensToSearch[i].kind === "LeftBracket" && tokensToSearch[i].data === "[" &&
                  tokensToSearch[i + 1].kind === "Identifier" && tokensToSearch[i + 1].data === "Kind" &&
                  (tokensToSearch[i + 2].kind === "RightBracket" && tokensToSearch[i + 2].data === "]" ||
                   tokensToSearch[i + 2].kind === "Equal" && tokensToSearch[i + 2].data === "=")) {
                errorStart = tokensToSearch[i].positionStart;
                errorEnd = tokensToSearch[i + 2].positionEnd;
                break;
              }
            }
          }
        }

        const errorObject: ErrorObject = {
          positionStart: errorStart,
          positionEnd: errorEnd
        };
        errorObjects.push(errorObject);
      }
    });

    return errorObjects;
  }
};

export default useItemAndKindForExcelConnection;