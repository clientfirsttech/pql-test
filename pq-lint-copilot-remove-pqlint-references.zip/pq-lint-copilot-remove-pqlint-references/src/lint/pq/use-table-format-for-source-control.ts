import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";

// Create a Rule object with the function as a string
export const useTableFormatForSourceControl: PowerQueryRule = {
  ID: "use-table-format-for-source-control",
  Name: "Use #table Instead of Binary.FromText for Hardcoded Data",
  Category: "Best Practice",
  Description: "Consider using #table instead of Binary.FromText because source control will work better in tracking changes with hard-coded data. Courtesy of Daryl Lynch.",
  References: [
    {
      Description: "Idea from Daryl Lynch",
      Link: "https://www.linkedin.com/in/daryl-lynch-75a08584/"
    }
  ],
  Severity: SeverityLevel.Warning,
  MinLicenseLevel: LicenseLevel.Free,
  AIFixInstructions: {
    Description: "Convert Binary.FromText to #table format for better source control",
    Prompt: `BinaryToTableConverter {
  Purpose: "Replace Binary.FromText format with #table structure for better version control and readability"
  
  Context {
    * Binary.FromText stores data as encoded binary blob
    * #table format is human-readable in source control
    * Easier to track changes and review data
    * More maintainable for hardcoded lookup tables
  }
  
  Constraints {
    * Preserve all data exactly
    * Maintain column names and types
    * Output valid M syntax only
    * Ensure proper type definitions
  }
  
  #table Syntax {
    format: #table(type table [Col1 = type1, Col2 = type2], {{val1, val2}, {val3, val4}})
    
    valid types: {
      any, null, logical, number, time, date, datetime,
      datetimezone, duration, text, binary, type, list,
      record, table, function, anynonnull, none
    }
    
    important: Do NOT use "type" keyword in column definitions
    correct: #table(type table [Name = text, Score = number], ...)
    incorrect: #table(type table [Name = type text], ...)
  }
  
  Process {
    1. Locate Binary.FromText wrapped in Json.Document(Binary.Decompress(...))
    2. Decode the binary data to extract structure
    3. Identify column names from data or subsequent TransformColumnTypes
    4. Extract all data rows
    5. Determine column types from data or type transformation step
    6. Construct #table format:
       #table(type table [columns with types], {{rows}})
    7. If Table.TransformColumnTypes exists, verify types match
    8. Replace entire Json.Document(...) expression with #table
    9. Remove redundant Table.TransformColumnTypes if types in #table
  }
  
  Examples {
    Before:
    Source = Json.Document(Binary.Decompress(Binary.FromText("i53Vy...", BinaryEncoding.Base64), Compression.Deflate)),
    #"Converted to Table" = Table.FromList(Source, Splitter.SplitByNothing(), null, null, ExtraValues.Error),
    #"Changed Type" = Table.TransformColumnTypes(#"Converted to Table", {{"Name", type text}, {"Score", type number}})
    
    After:
    Source = #table(type table [Name = text, Score = number], {{"Betty", 90.3}, {"Carl", 89.5}, {"Dan", 87.2}}),
    #"Converted to Table" = Source
    
    ---
    
    Simpler Before:
    Data = Json.Document(Binary.Decompress(Binary.FromText("...")))
    
    After:
    Data = #table(type table [Column1 = text, Column2 = number], {{"A", 1}, {"B", 2}})
  }
  
  Edge Cases {
    * Unknown types - use "any" and let Power Query infer
    * Nested structures - flatten or keep as record/list types
    * Large datasets - warn that #table is for small lookup tables only
    * Special characters in data - properly escape in strings
  }
}`,
    IsActive: true,
    IsWholeQueryFix: false
  },
  Check: (input: ParseResult | undefined): ErrorObject[] | null => {
    // Cast to LexedJson[] to access the properties
    const tokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
    const lineNumber = tokens.findIndex((current, i) => {
      if (i < 3 || i + 1 >= tokens.length) {
        return false;
      }

      const next = tokens[i + 1];
      const previous = tokens[i - 1];
      const beforePrevious = tokens[i - 2];
      const before2Previous = tokens[i - 3];

      return current.kind === "LeftParenthesis" && current.data === "(" &&
        next.kind === "Identifier" && next.data === "Binary.FromText" &&
        previous.kind === "Identifier" && previous.data === "Binary.Decompress" &&
        beforePrevious.kind === "LeftParenthesis" && beforePrevious.data === "(" &&
        before2Previous.kind === "Identifier" && before2Previous.data === "Json.Document";
    });
    if (lineNumber === -1) {
      return null;
    }
    const errorObject: ErrorObject[] = [{
      positionStart: tokens[lineNumber + 1].positionStart,
      positionEnd: tokens[lineNumber + 1].positionEnd
    }];
    //logDebug(errorObject);
    return errorObject;
  }
};

export default useTableFormatForSourceControl;
