import { log } from "console";
import { ParseResult } from "../../parser/pq/parse-types";
import { containsTokenSequence, logDebug, RegexPatternsForConstants } from "../rule-assistance";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";

// Create a Rule object
export const useTypeTextForParameter: PowerQueryRule = {
    ID: "use-type-text-for-parameter", // Unique identifier for the rule
    Name: "Avoid using any type for a file path, URL, or database reference", // Rule name
    Category: "Potential Issue", // Rule category
    Description: "Parameter types that are of type 'any' cannot be updated in the Power BI service. Consider using a more specific type, such as 'text', to ensure compatibility with the Power BI service.", // Rule description
    References: [
        {
            Description: "Potential Issue: Parameter with Type Any",
            Link: "https://youtu.be/iXc9Kh0cYcQ"
        },
        {
            Description: "Potential Issue: Parameter with Type Any",
            Link: "https://youtu.be/iXc9Kh0cYcQ"
        }
    ], // References related to the rule
    AIFixInstructions: {
        Description: "Change parameter type from 'any' to 'text' for path/URL parameters",
        IsActive: true,
        IsWholeQueryFix: false,
        Prompt: `
ParameterTypeFixer {
  Purpose: "Replace 'any' type with 'text' type on parameters holding file paths, URLs, or database references"

  Context {
    * Parameters typed as 'any' cannot be updated in the Power BI service
    * File paths, URLs, and database references are always text values
    * Using 'text' type ensures compatibility with Power BI service parameter editing
    * Three syntax variants exist for specifying 'any' type in meta records
  }

  Constraints {
    * Only modify the Type value in the meta record — leave all other code unchanged
    * Preserve existing comments, formatting, and whitespace
    * Do not alter the parameter value itself
    * Do not change other meta properties (e.g., IsParameterQuery)
    * Output valid Power Query M code only — no explanatory text
  }

  Detection Patterns {
    Variant 1 (TextLiteral):   Type = "Any"
    Variant 2 (KeywordType):   Type = type any
    Variant 3 (Identifier):    Type = Any.Type
  }

  Replacement Mapping {
    Variant 1: Type = "Any"     =>  Type = "Text"
    Variant 2: Type = type any  =>  Type = type text
    Variant 3: Type = Any.Type  =>  Type = Text.Type
  }

  Process {
    1. Locate the meta record attached to the parameter expression
    2. Find the Type property within the meta record
    3. Identify which variant of 'any' type is used
    4. Replace with the corresponding 'text' type from Replacement Mapping
    5. Preserve all surrounding syntax and other meta properties
  }

  Examples {
    Before (Variant 1):
    "C:\\\\Data\\\\Sales.xlsx" meta [IsParameterQuery=true, Type="Any", IsParameterQueryRequired=true]

    After (Variant 1):
    "C:\\\\Data\\\\Sales.xlsx" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]

    Before (Variant 2):
    "https://api.example.com/data" meta [IsParameterQuery=true, Type = type any]

    After (Variant 2):
    "https://api.example.com/data" meta [IsParameterQuery=true, Type = type text]

    Before (Variant 3):
    "server.database.windows.net" meta [IsParameterQuery=true, Type = Any.Type]

    After (Variant 3):
    "server.database.windows.net" meta [IsParameterQuery=true, Type = Text.Type]
  }

  Edge Cases {
    * If multiple meta properties exist, change only the Type property
    * If meta record spans multiple lines, preserve the line formatting
    * Do not modify parameters that already use type text, "Text", or Text.Type
    * If the parameter value is a complex expression (e.g., function call), leave it unchanged — only fix the Type in meta
  }
}
`
    },
    Severity: SeverityLevel.Error, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Pro, // Minimum license level required to use the rule
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast the input to access its properties
        const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;

        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // If the AST tokens do not represent a "MetadataExpression", return an empty array
        if (aSTTokens.kind !== "MetadataExpression") return errorObjects;

        // Define regex patterns for local file paths, URLs, and database hostnames
        const localFilePathRegex = RegexPatternsForConstants.localFilePath; // Matches local file paths
        const urlRegex = RegexPatternsForConstants.url; // Matches URLs
        const databasePathRegex = RegexPatternsForConstants.databasePath; // Matches database hostnames

        // If there are no lexical tokens, return an empty array
        if (lexTokens.length === 0) return errorObjects;

        logDebug("LexTokens: ", lexTokens[0].data);

        // Check if the first lexical token matches any of the regex patterns
        if (
            localFilePathRegex.test(lexTokens[0].data) ||
            urlRegex.test(lexTokens[0].data) ||
            databasePathRegex.test(lexTokens[0].data)
        ) {
            logDebug("Match found for file path, URL, or database hostname");

            // Define token sequences to check for "Any" type
            const sequenceCheck = [
                { kind: "Identifier", data: "Type" },
                { kind: "Equal", data: "=" },
                { kind: "TextLiteral", data: "\"Any\"" },
            ];

            const sequenceCheck2 = [
                { kind: "Identifier", data: "Type" },
                { kind: "Equal", data: "=" },
                { kind: "KeywordType", data: "type" },
                { kind: "Identifier", data: "any" },
            ];

            const sequenceCheck3 = [
                { kind: "Identifier", data: "Type" },
                { kind: "Equal", data: "=" },
                { kind: "Identifier", data: "Any.Type" },
            ];

            // Check if any of the token sequences are present in the lexical tokens
            const firstCheck = containsTokenSequence(lexTokens, sequenceCheck);
            const secondCheck = containsTokenSequence(lexTokens, sequenceCheck2);
            const thirdCheck = containsTokenSequence(lexTokens, sequenceCheck3);

            // If any of the checks pass, create an error object
            if (firstCheck || secondCheck || thirdCheck) {
                const errorObject: ErrorObject = {
                    positionStart: lexTokens[0].positionStart, // Start position of the error
                    positionEnd: lexTokens[0].positionEnd, // End position of the error
                };
                errorObjects.push(errorObject); // Add the error object to the array
            }
        }

        // Return all collected error objects
        return errorObjects;
    }
};

export default useTypeTextForParameter;