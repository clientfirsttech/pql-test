import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { searchAST } from "../rule-assistance";

// Create a Rule object with the function as a string
export const useSpecificParametersForFuzzyMerge: PowerQueryRule = {
    ID: "use-specific-parameters-for-fuzzy-merge",
    Name: "Set Threshold and SimilarityColumnName in Fuzzy Joins for Clarity",
    Category: "Best Practice",
    Description: "Fuzzy Joins should have a threshold and similaritycolumnname set explicity for readability and maintenance. The Default values for these settings are .8 and no column respectively and should be defined to reduce ambiguity.",
    References: [],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,    
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const lexTokens : LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // Identify the instances of Table.FuzyNestedJoin and Table.FuzzyJoin
        const instances = lexTokens.filter((current) => {
            return current.kind === "Identifier" && (current.data === "Table.FuzzyNestedJoin" || current.data === "Table.FuzzyJoin");
        });
        instances.forEach(element => {
            // Construct the search string using the properties of the element
            const searchString = '"positionStart":'+JSON.stringify(element.positionStart,null,0)+',"positionEnd":'+JSON.stringify(element.positionEnd,null,0);
            let searchResults: {path: string; match: any}[] = searchAST(aSTTokens, "", searchString);                    
            
            if(searchResults.length > 0){
                
                let temp = searchResults[searchResults.length-1].match;  
                let checkString = JSON.stringify(temp?.recursiveExpressions?.elements);
                
                // Check if missing fields
                if(checkString.includes('"literal":"Threshold"') === false || checkString.includes('"literal":"SimilarityColumnName"') === false){
                    // Define line number to add to the error object
                    const errorObject: ErrorObject = {
                        positionStart: element.positionStart,
                        positionEnd: element.positionEnd
                    };
                    errorObjects.push(errorObject);
                }
            }
        });
        return errorObjects;
    }
};

export default useSpecificParametersForFuzzyMerge;