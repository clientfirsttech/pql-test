import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findFunctionCallsInAST, findIdentifiers } from "../rule-assistance";

// Define the rule object
export const useExplicitTypesForDataflows: PowerQueryRule = {
    ID: "use-explicit-types-for-dataflows", // Unique identifier for the rule
    Name: "Explicitly Set Column Types in Dataflows to Prevent Null Values", // Rule name
    Category: "Potential Issue", // Rule category
    Description: "Detected this M code is probably used in a dataflow. Set column types explicity to avoid accidentally nullifying column values.", // Rule description
    References: [], // References for the rule
    Severity: SeverityLevel.Error, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Pro, // Minimum license level required to use the rule
    // The main check function for the rule
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const lexTokens : LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // Find last two function calls in the AST
        const x: any[] = findFunctionCallsInAST(aSTTokens, 2);

        if(x.length == 0 || x.length < 2) return errorObjects; // No function calls found
        
        if(x[0]?.literal === "Table.TransformColumnTypes" && x[1]?.literal === "Table.ReplaceErrorValues"){
            const lastCall: any = findIdentifiers(lexTokens, 'Table.ReplaceErrorValues');
            const errorObject: ErrorObject = {
                positionStart: lastCall[lastCall.length - 1].positionStart,
                positionEnd: lastCall[lastCall.length - 1].positionEnd
            };
            errorObjects.push(errorObject);            
        }// end if

        return errorObjects;
    }
};

export default useExplicitTypesForDataflows;