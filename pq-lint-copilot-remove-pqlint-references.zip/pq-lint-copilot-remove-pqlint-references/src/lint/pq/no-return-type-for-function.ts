import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findFunctionExpressions } from "../rule-assistance";

// Define the rule object for checking explicit return types in Power Query functions
export const noReturnTypeForFunction: PowerQueryRule = {
    ID: "no-return-type-for-function", // Unique identifier for the rule
    Name: "Specify Return Type in Function Definitions", // Rule name
    Category: "Potential Issue", // Rule category
    Description: "A return type should be identified for the function. Explicit return types do make it visually more clear what type is returned by a function.", // Rule description
    References: [        {
        Description: "Chapter 9 - The Definitive Guide to Power Query (M)",
        Link: "https://amzn.to/43zc4ye"
    }], // References for the rule
    Severity: SeverityLevel.Error, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Free, // Minimum license level required to use the rule
    // The main check function for the rule
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast the input to access AST tokens
        const aSTTokens: any = (input as ParseResult).ast;

        // Use the helper function to find all function expressions in the AST
        const functionIdentifiers: any = findFunctionExpressions(aSTTokens);

        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // If function expressions are found, process them
        if (functionIdentifiers.length > 0) {
            functionIdentifiers.forEach((element: any) => {
                // Check if the function does not have a defined return type
                if (element?.functionReturnType === undefined) {
                    // Create an error object for functions missing a return type
                    errorObjects.push({
                        positionStart: element?.fatArrowConstant?.tokenRange?.positionStart, // Start position of the error
                        positionEnd: element?.fatArrowConstant?.tokenRange?.positionEnd, // End position of the error
                    });
                }
            });
        }

        // Return the collected error objects
        return errorObjects;
    }
};

export default noReturnTypeForFunction;