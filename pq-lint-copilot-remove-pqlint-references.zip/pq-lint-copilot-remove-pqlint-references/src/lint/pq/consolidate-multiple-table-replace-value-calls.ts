import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findIdentifiers } from "../rule-assistance";

// Create a Rule object with the function as a string
export const consolidateMultipleTableReplaceValueCalls: PowerQueryRule = {
    ID: "consolidate-multiple-table-replace-value-calls",
    Name: "Consolidate Multiple Table.ReplaceValue Steps to Improve Performance",
    Category: "Best Practice",
    Description: "Multple Table.ReplaceValue Steps can lead to slow and unwieldy queries. Consider replacing with a translation table/bulk replace approach.",
    References: [
        {
            Description: "Chapter 11 - The Definitive Guide to Power Query (M)",
            Link: "https://amzn.to/43zc4ye"
        },
        {
            Description: "Bulk Replace Using Translation Table",
            Link: "https://gorilla.bi/power-query/replace-values/#bulk-replace-translation-table"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Free,
    AIFixInstructions: {
        Description: "Consolidate multiple Table.ReplaceValue calls or suggest translation table approach",
        Prompt: `ReplaceValueConsolidator {
  Purpose: "Optimize multiple Table.ReplaceValue calls using nested approach or translation table pattern"
  
  Context {
    * Multiple Table.ReplaceValue calls cause performance issues
    * Each call creates a new table scan
    * Consolidation reduces query complexity
    * Translation table approach is better for many replacements (5+)
  }
  
  Constraints {
    * Only consolidate consecutive calls on same column
    * Preserve replacement order (critical for overlapping patterns)
    * Maintain all options and replacer types
    * Output valid M syntax only
  }
  
  Strategy Selection {
    if replacements <= 5 on same column: use nested Table.ReplaceValue
    if replacements > 5: recommend translation table approach with comment
  }
  
  Nested Consolidation Pattern {
    structure:
    Table.ReplaceValue(
      Table.ReplaceValue(
        Table.ReplaceValue(source, old1, new1, replacer, {col}),
        old2, new2, replacer, {col}),
      old3, new3, replacer, {col})
  }
  
  Translation Table Pattern {
    // Consider using a translation table for better performance
    // Create table: = #table({"Old", "New"}, {{"N/A", null}, {"Unknown", null}, ...})
    // Then join with main table and replace column
  }
  
  Process {
    1. Identify sequence of Table.ReplaceValue calls
    2. Group by target column
    3. For each group on same column:
       if <= 5 replacements {
         a. Extract source, old/new pairs, replacer, options
         b. Build nested structure innermost to outermost
         c. Create single consolidated step
         d. Use descriptive step name
       }
       if > 5 replacements {
         a. Add comment suggesting translation table approach
         b. Provide example code in comment
         c. Optionally implement translation table pattern
       }
    4. Update downstream references
  }
  
  Examples {
    Before (3-5 replacements):
    #"Replace 1" = Table.ReplaceValue(Source, "N/A", null, Replacer.ReplaceValue, {"Status"}),
    #"Replace 2" = Table.ReplaceValue(#"Replace 1", "Unknown", null, Replacer.ReplaceValue, {"Status"}),
    #"Replace 3" = Table.ReplaceValue(#"Replace 2", "NA", null, Replacer.ReplaceValue, {"Status"})
    
    After:
    #"Cleaned Status" = Table.ReplaceValue(
      Table.ReplaceValue(
        Table.ReplaceValue(Source, "N/A", null, Replacer.ReplaceValue, {"Status"}),
        "Unknown", null, Replacer.ReplaceValue, {"Status"}),
      "NA", null, Replacer.ReplaceValue, {"Status"})
    
    ---
    
    Before (many replacements):
    #"Replace 1" = Table.ReplaceValue(Source, "val1", "new1", Replacer.ReplaceValue, {"Col"}),
    ... (10 more replacements) ...
    
    After:
    // Consider using a translation table for better performance with many replacements
    // TranslationTable = #table({"Old", "New"}, {{"val1", "new1"}, {"val2", "new2"}, ...}),
    // #"Merged" = Table.NestedJoin(Source, "Col", TranslationTable, "Old", "Trans"),
    // #"Expanded" = Table.ExpandTableColumn(#"Merged", "Trans", {"New"}),
    // #"Replaced" = Table.TransformColumns(#"Expanded", {{"Col", each if [New] <> null then [New] else _, type text}})
    [Keep existing code but add guidance comment]
  }
  
  Edge Cases {
    * Different columns - do NOT consolidate together
    * Non-consecutive calls - keep separate
    * Different replacer types - keep separate
    * Mixed with other operations - maintain order
  }
}`,
        IsActive: true,
        IsWholeQueryFix: false
    },
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const lexTokens : LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // Identify the instances of Number.Round
        const instances = findIdentifiers(lexTokens, "Table.ReplaceValue") ?? [];

        // If more than 5 instances are found, add them to the error objects
        if (instances.length >= 5) {
            instances.forEach(element => {
                const errorObject: ErrorObject = {
                    positionStart: element.positionStart,
                    positionEnd: element.positionEnd
                };
                errorObjects.push(errorObject);
            });
        }

        return errorObjects;
    }
};

export default consolidateMultipleTableReplaceValueCalls