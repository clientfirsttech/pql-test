import { ParseResult } from "../../parser/pq/parse-types";
import { logDebug, RegexPatternsForConstants } from "../rule-assistance";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";


// Create a Rule object
export const noPlainTextClientForParameter: PowerQueryRule = {
    ID: "no-plain-text-client-secret-as-parameter",
    Name: "Avoid Storing Secrets (e.g., Azure Keys) in M Code.",
    Category: "Potential Issue",
    Description: "Storing Azure Service Principal client secret or an Azure API key is a security issue. Consider using a more secure method, such as a customer connector, to handle sensitive information.",
    References: [],
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;

        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        if (aSTTokens === null || aSTTokens === undefined) {
            return errorObjects; // Return empty array if aSTTokens is null or undefined
        }

        // If parameter ("MetadataExpression") is not found, return empty array
        if (aSTTokens.kind !== "MetadataExpression") return errorObjects;

        const clientSecretRegex = RegexPatternsForConstants.clientSecretRegex;
        const apiKeyRegex = RegexPatternsForConstants.apiKeyRegex;
        const domainEndingRegex = RegexPatternsForConstants.domainEndingRegex;
        const guidRegex = RegexPatternsForConstants.guidRegex;

        if (lexTokens.length == 0) return errorObjects;

        // Exclude GUIDs (workspace IDs, etc.) from client secret detection
        if (guidRegex.test(lexTokens[0].data)) {
            logDebug("Detected GUID pattern, skipping...");
            return errorObjects;
        }

        // Check if the first token matches client secret or API key patterns
        if (clientSecretRegex.test(lexTokens[0].data) || apiKeyRegex.test(lexTokens[0].data)) {
            logDebug("Found potential client secret or API key in parameter. Client Secret Test: " + 
                    clientSecretRegex.test(lexTokens[0].data) + " API Key: " + apiKeyRegex.test(lexTokens[0].data));
            logDebug("Domain Regex Test: " + domainEndingRegex.test(lexTokens[0].data));
            // Exclude legitimate URLs that might match the pattern
            if (!domainEndingRegex.test(lexTokens[0].data)) {
                logDebug("Domain ending regex test passed, so likely not a URL. Flagging as potential client secret or API key.");
                const errorObject: ErrorObject = {
                    positionStart: lexTokens[0].positionStart,
                    positionEnd: lexTokens[0].positionEnd,
                };
                errorObjects.push(errorObject);
            } // end if - domain ending regex check
        } // end if - client secret or API key pattern match

        return errorObjects;
    } // end Check function
}; // end noPlainTextClientForParameter rule

export default noPlainTextClientForParameter;