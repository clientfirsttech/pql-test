import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findIdentifiers, logDebug, findNodesWithRecursiveExpression } from "../rule-assistance";


// Define the rule object
export const useValueTypeWithAllRowsForTableGroup: PowerQueryRule = {
    ID: "use-value-type-with-all-rows-for-table-group", // Unique identifier for the rule
    Name: "Use Value.Type to Dynamically Retrieve Prior Step's Table Type and Avoid Loading Errors", // Rule name
    Category: "Potential Issue", // Rule category
    Description: "Grouping your data with the All Rows operation often hardcodes the data type. If you change the types prior to this, you could encounter errors loading this data into Power BI. Use Value.Type(#\"Previous Steps\") so any future changes in prior steps are automatically picked up.", // Rule description
    References: [
        {
            Description: "Chapter 5 - The Definitive Guide to Power Query (M)",
            Link: "https://amzn.to/43zc4ye"
        }
    ], // References for the rule
    Severity: SeverityLevel.Error, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Pro, // Minimum license level required to use the rule
    // The main check function for the rule
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) {
            return [];
        }
        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const astTokens: any = input.ast;
        const errorObjects: ErrorObject[] = [];

        // Find all instances of "Table.Group"
        const instances: LexedJson[] = findIdentifiers(lexTokens, "Table.Group") ?? [];

        logDebug(`Found ${instances.length} instance(s) of 'Table.Group'.`);

        // Iterate over each instance of "Table.Group"
        instances.forEach((instance) => {
            const tempArray: any[] = [instance];
            // Identify hard code tabel definitions
            const tableTypeNodes = findNodesWithRecursiveExpression(tempArray, astTokens, '"kind":"TableType"'); 
            // Commented out as it is not used to find the presence
            //const valueTypeNodes = findNodesWithRecursiveExpression(tempArray, astTokens, '"kind":"Value.Type"');

            tableTypeNodes.forEach((node) => {
                const errorObject: ErrorObject = {
                    positionStart: instance.positionStart,
                    positionEnd: instance.positionEnd,
                };
                errorObjects.push(errorObject);
            });
        });

        // Return the collected error objects
        return errorObjects;
    }
};

export default useValueTypeWithAllRowsForTableGroup;