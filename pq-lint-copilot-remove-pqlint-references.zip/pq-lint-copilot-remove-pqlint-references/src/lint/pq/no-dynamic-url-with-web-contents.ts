import { ParseResult } from "../../parser/pq/parse-types";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { findIdentifiers, findNodesWithRecursiveExpression, logDebug, searchAST } from "../rule-assistance";

// Create a Rule object with the function as a string
export const noDynamicUrlWithWebContents: PowerQueryRule = {
    ID: "no-dynamic-url-with-web-contents",
    Name: "Avoid Building Dynamic URLs in Web.Contents URL Parameter",
    Category: "Potential Issue",
    Description: "Do not build dynamic URLs within Web.Contents()'s URL parameter. While this can work in the desktop, in the service you'll likely receive this message: 'You can't schedule refresh for this dataset because the following data sources currently don’t support refresh'. Use RelativePath and/or Query instead with a Parameterized URL.",
    References: [
        {
            Description: "Web.Contents(), M Functions And Dataset Refresh Errors In Power BI",
            Link: "https://blog.crossjoin.co.uk/2016/08/23/web-contents-m-functions-and-dataset-refresh-errors-in-power-bi/"
        }
    ],
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        const instances = findIdentifiers(lexTokens, 'Web.Contents') ?? [];

        instances.forEach(element => {
            const tempArray: any[] = [];
            tempArray.push(element);

            // Construct the search string using the properties of the element
            const searchString = '"positionStart":' + JSON.stringify(element.positionStart, null, 0) + ',"positionEnd":' + JSON.stringify(element.positionEnd, null, 0);
            let searchResults: { path: string; match: any }[] = searchAST(aSTTokens, "", searchString);

            // Check if Web.Contents has a second parameter and if it uses a variable
            if (searchResults.length > 0) {
                // Get the last match (most specific)
                let temp = searchResults[searchResults.length - 1].match;
                logDebug(temp.recursiveExpressions?.elements[0]?.content.elements.length);

                if (temp.recursiveExpressions?.elements[0]?.content.elements.length > 0) {
                    logDebug(temp.recursiveExpressions?.elements[0]?.content.elements[0].node);

                    const ampersandUsageCheck = JSON.stringify(temp.recursiveExpressions?.elements[0]?.content.elements[0].node);

                    if (ampersandUsageCheck.includes('"constantKind":"&"')) {

                        const errorObject: ErrorObject = {
                            positionStart: temp.recursiveExpressions?.elements[0]?.content.elements[0].node?.operatorConstant?.tokenRange?.positionStart || element.positionStart,
                            positionEnd: temp.recursiveExpressions?.elements[0]?.content.elements[0].node?.operatorConstant?.tokenRange?.positionEnd || element.positionEnd,
                        };
                        errorObjects.push(errorObject);
                    }
                }
            }

        });


        return errorObjects;
    }
};

export default noDynamicUrlWithWebContents