import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import {ParseResult} from "../../parser/pq/parse-types";
import { logDebug } from "../rule-assistance";

// Create a Rule object with the function as a string
export const useTypeWithAddColumn: PowerQueryRule = {
    ID: "use-type-with-add-column",
    Name: "Include Column Type as Fourth Argument in Table.AddColumn",
    Category: "Best Practice",
    Description: "For using the custom column function, the fourth argument be used to cast the column type. It is much easier to see in one step the context when the column name, transformation, and data type are contained in a single step.",
    References: [
        {
            Description: "Chapter 9 - The Ultimate Power Query Cookbook for Power BI and Excel",
            Link: "https://amzn.to/3H3EJUq"
        }
    ],    
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Free,
    AIFixInstructions: {
        Description: "Add column type as fourth argument to Table.AddColumn calls",
        IsActive: true,
        IsWholeQueryFix: false,
        Prompt: `
AddColumnTypeFixer {
  Purpose: "Add a fourth argument specifying the column data type to Table.AddColumn calls that are missing it"

  Context {
    * Table.AddColumn accepts an optional fourth argument for the column type
    * Including the type improves readability — column name, transformation, and type are in one step
    * Explicit types help Power Query optimize performance and avoid type inference
    * The fourth argument is a Power Query type value (e.g., type text, type number, Int64.Type)
  }

  Constraints {
    * Only modify Table.AddColumn calls that have exactly 3 arguments (missing the fourth)
    * Do not modify Table.AddColumn calls that already have 4 arguments
    * Preserve the existing three arguments exactly as they are
    * Preserve all comments, formatting, and whitespace
    * Output valid Power Query M code only — no explanatory text
    * Do not change any other functions or steps in the query
  }

  Process {
    1. Locate each Table.AddColumn call in the flagged code
    2. Verify it has exactly 3 arguments (table, column name, function)
    3. Analyze the transformation function (third argument) to infer the likely return type
    4. Add the inferred type as the fourth argument after the function argument
    5. If the return type cannot be confidently inferred, use type any as a safe default
  }

  Type Inference Guide {
    * Text operations (Text.Combine, Text.Upper, Text.Replace, & operator on text) => type text
    * Numeric operations (+, -, *, /, Number.Round, Number.From) => type number
    * Integer operations (Int64.From) => Int64.Type
    * Date operations (Date.From, DateTime.Date, #date) => type date
    * DateTime operations (DateTime.From, DateTime.LocalNow, #datetime) => type datetime
    * Logical operations (true/false comparisons, and, or, not) => type logical
    * Record access returning unknown type => type any
    * Complex or ambiguous expressions => type any
  }

  Examples {
    Before:
    Table.AddColumn(Source, "Full Name", each [First] & " " & [Last])

    After:
    Table.AddColumn(Source, "Full Name", each [First] & " " & [Last], type text)

    Before:
    Table.AddColumn(#"Previous Step", "Total", each [Price] * [Quantity])

    After:
    Table.AddColumn(#"Previous Step", "Total", each [Price] * [Quantity], type number)

    Before:
    Table.AddColumn(Source, "IsActive", each [Status] = "Active")

    After:
    Table.AddColumn(Source, "IsActive", each [Status] = "Active", type logical)

    Before:
    Table.AddColumn(Source, "OrderDate", each Date.From([Timestamp]))

    After:
    Table.AddColumn(Source, "OrderDate", each Date.From([Timestamp]), type date)

    Before (ambiguous type):
    Table.AddColumn(Source, "Result", each SomeCustomFunction([Value]))

    After (ambiguous type):
    Table.AddColumn(Source, "Result", each SomeCustomFunction([Value]), type any)
  }

  Edge Cases {
    * If the third argument is a multi-line function, place the type after the closing parenthesis on the same line as the closing paren
    * If Table.AddColumn is nested inside another function, only add the type to the inner call
    * If the each expression contains an if-then-else, infer type from the then/else branches if consistent; otherwise use type any
    * Do not add a type if the call already has 4 or more arguments
  }
}
`
    },
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const tokens: any = (input as ParseResult).ast;
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];
        const elements : any = tokens?.variableList?.elements as any;

        if(elements === undefined){
            return errorObjects;
        }

        elements.forEach((element: { node: { value: any; }; }, index: any) => {
            const node = element?.node?.value;
            // Check if the current element is a Table.AddColumn call
            if (node?.head?.identifier.literal === "Table.AddColumn"){
                // Check if the 4th argument exists
                const fourthArg = node?.recursiveExpressions?.elements?.[0].content?.elements?.[3]?.attributeIndex;
               
                const hasFourthArgument = fourthArg === 3 ? true : false;

                if (!hasFourthArgument) {
                    logDebug("No fourth argument found for Table.AddColumn");
                    logDebug("Node: ", node);
                    // Create an error object with the line number of the matched token
                    const errorObject: ErrorObject = {
                        positionStart: node?.head?.identifier?.tokenRange?.positionStart,
                        positionEnd: node?.head?.identifier?.tokenRange?.positionEnd,
                    };
                    errorObjects.push(errorObject);                    
                } // end if
            }
        }); // end for each variable List

        return errorObjects;
    }
};

export default useTypeWithAddColumn;