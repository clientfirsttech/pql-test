import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findFunctionExpressions, extractParameters } from "../rule-assistance";

// Define the rule object for checking explicit return types in Power Query functions
export const replaceRecursionWithIterationFunctions: PowerQueryRule = {
    ID: "replace-recursion-with-iteration-functions", // Unique identifier for the rule
    Name: "Recursion is less memory-efficient than iterative functions.", // Rule name
    Category: "Potential Issue", // Rule category
    Description: "Recursive functions can lead to stack overflows or inefficient memory usage. Replace the recursion function with functions like List.Transform, List.Generate, or List.Accumulate.", // Rule description
    References: [
        {
            Description: "Chapter 12 - The Definitive Guide to Power Query (M)",
            Link: "https://amzn.to/43zc4ye"
        }
    ], // References for the rule
    Severity: SeverityLevel.Error, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Pro, // Minimum license level required to use the rule
    // The main check function for the rule
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) return [];
        const tokens: LexedJson[] = input.lexed as LexedJson[];

        const errorObjects: ErrorObject[] = [];

        for (let i = 0; i < tokens.length - 1; i++) {
            if (
                tokens[i]?.kind === "AtSign" &&
                tokens[i]?.data === "@" &&
                tokens[i + 1]?.kind === "Identifier"
            ) {
                // Check if the next token is a function that is likely to be recursive
                errorObjects.push({
                    positionStart: tokens[i].positionStart,
                    positionEnd: tokens[i].positionEnd,
                });
            }
        }

        return errorObjects;
    }
};

export default replaceRecursionWithIterationFunctions;