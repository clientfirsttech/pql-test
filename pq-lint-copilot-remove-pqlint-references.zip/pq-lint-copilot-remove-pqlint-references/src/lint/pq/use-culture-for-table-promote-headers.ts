import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "..//../parser/pq/parse-types";
import { findIdentifiers, findNodesWithRecursiveExpression } from "../rule-assistance";

// Create a Rule object with the function as a string
export const useCultureForTablePromoteHeaders: PowerQueryRule = {
    ID: "use-culture-for-table-promote-headers",
    Name: "Explicitly Set Culture for Table.PromoteHeaders (e.g., \"en-US\")",
    Category: "Best Practice",
    Description: "Explicitly set the Culture (e.g. en-US) for Table.PromoteHeaders. This avoids ambiguity in using the default culture and possible unexpected formatting for dates and currency fields.",
    References: [
        {
            Description:"Chapter 7 - The Ultimate Power Query Cookbook for Power BI and Excel",
            Link: "https://amzn.to/3H3EJUq"
        }
    ],     
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Free,    
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) return [];

        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;        
        const errorObjects: ErrorObject[] = [];

        const instances = findIdentifiers(lexTokens, 'Table.PromoteHeaders') ?? [];
        // Find the index of the relevant identifiers in the lexed tokens
        instances.forEach(instance => {
            const searchString = '"positionStart":' + JSON.stringify(instance.positionStart, null, 0) + ',"positionEnd":' + JSON.stringify(instance.positionEnd, null, 0);

            const tempArray : any[] = [];
            tempArray.push(instance);
            const cultureUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens,'"literal":"Culture"');

            // Check to make sure the Culture is set
            if (cultureUsage.length === 0){
                const errorObject: ErrorObject = {
                    positionStart: instance.positionStart,
                    positionEnd: instance.positionEnd
                };
                errorObjects.push(errorObject);
            }            
        });

        return errorObjects;
    }
};

export default useCultureForTablePromoteHeaders;