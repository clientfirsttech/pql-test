import { ParseResult } from "../../parser/pq/parse-types";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { containsTokenSequence, findAllSpecificTokens, findIdentifiers, logDebug} from "../rule-assistance";

// Create a Rule object
export const useTableForExcelConnection : PowerQueryRule = {
    ID: "use-table-for-excel-connection",
    Name: "Use Excel Table Instead of Sheet for Better Structure",
    Category: "Best Practice",
    Description: "As a best practice, use Table instead of Sheet for Excel connection. This can avoid extra columns/rows and requiring extra steps to clean up.",
    References: [
      {
        Description: "Chapter 2 - The Ultimate Power Query Cookbook for Power BI and Excel",
        Link: "https://amzn.to/3H3EJUq"
      }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Free,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const lexTokens : LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // Find the position of the SQL.Database call
        const instances: LexedJson[] = findIdentifiers(lexTokens, "Excel.Workbook") ?? [];
        const keywordInstances: LexedJson[] = findAllSpecificTokens(lexTokens, "KeywordIn", "in");
  
        // Set the sequence to check for for Table Kind
        const sequenceCheck =   [{
            "kind": "Identifier",
            "data": "Kind"
          },
          {
            "kind": "Equal",
            "data": "=",
          },
          {
            "kind": "TextLiteral",
            "data": "\"Table\"",
          }];


          // Check for Excel.Workbook instance before checking for Kind
          if (instances.length > 0) {
            const sequenceCheckResult = containsTokenSequence(lexTokens, sequenceCheck);;

            // Identify the line number of the Excel.Workbook call
            const lineNumberExcel = instances[0].positionStart.lineNumber;
            // Get last 'in' keyword line number
            const inKeywordLineNumber = keywordInstances.length > 0 ? keywordInstances[keywordInstances.length-1].positionStart.lineNumber : 0;            

            // Differentiate between line numbers to make sure Excel.Workbook is being used as a source table for multiple sheets/tables
            const difference = inKeywordLineNumber - lineNumberExcel;
            logDebug(`Difference between 'in' keyword and Excel.Workbook call: ${difference}`);
            // If not used then add to error objects
            if (sequenceCheckResult === false && difference > 1) {
                const errorObject: ErrorObject = {
                    positionStart: instances[0].positionStart,
                    positionEnd: instances[0].positionEnd
                };
                errorObjects.push(errorObject);
            }
          }// end if

        return errorObjects;
    }
};

export default useTableForExcelConnection;