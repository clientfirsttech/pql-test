import { log } from "console";
import { ParseResult } from "../../parser/pq/parse-types";
import { logDebug } from "../rule-assistance";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
/**
 * Rule to detect when both RangeStart and RangeEnd use equality operators (>=, <=)
 * which can cause duplicate data in incremental refresh scenarios.
 */
export const noEqualOnBohRangesForIncrementalRefresh: PowerQueryRule = {
    ID: "no-equal-on-both-ranges-for-incremental-refresh",
    Name: "Avoid Equal Operators on Both RangeStart and RangeEnd",
    Category: "Potential Issue",
    Description: "When defining incremental refresh filters in Power Query, use an equality operator (=) on only one of the boundary parameters—either RangeStart or RangeEnd, but not both. Using >= RangeStart and <= RangeEnd together can cause a single row (e.g., a date exactly matching both boundaries) to appear in multiple partitions, resulting in duplicate data in your model.",
    References: [
        {
            Description: "Configure incremental refresh and real-time data",
            Link: "https://learn.microsoft.com/en-us/power-bi/connect-data/incremental-refresh-configure#filter-data"
        },
    ],
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Extract lexed tokens and AST from the parse result
        const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        
        // Initialize array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // Track operators found around RangeStart and RangeEnd
        let operators: LexedJson[] = [];

        // Scan through all tokens to find RangeStart and RangeEnd identifiers
        for (let i = 0; i < lexTokens.length; i++) {
            if (
                (lexTokens[i]?.kind === "Identifier" &&
                    lexTokens[i]?.data === "RangeEnd") ||
                (lexTokens[i]?.kind === "Identifier" &&
                    lexTokens[i]?.data === "RangeStart")
            ) {
                logDebug(lexTokens[i]);
                // Safely check the element before (avoiding out-of-bounds access)
                const prevElement = i > 0 ? lexTokens[i - 1] : null;

                // Safely check the element after (avoiding out-of-bounds access)
                const nextElement = i < lexTokens.length - 1 ? lexTokens[i + 1] : null;

                // Check for comparison operators before the range identifier
                if (prevElement) {
                    logDebug("Previous element: ", prevElement);
                    if (isComparisonOperator(prevElement)) {
                        operators.push(prevElement);
                    }
                }

                // Check for comparison operators after the range identifier
                if (nextElement) {
                    logDebug("Next element: ", nextElement);
                    if (isComparisonOperator(nextElement)) {
                        operators.push(nextElement);
                    }
                }
            }
        }

        // Check if both operators contain equality (causing potential duplicates)
        if (operators.length === 2) {
            // Both operators use equality (>= and <=), which can cause overlapping partitions
            if (operators[0].data.includes("=") && operators[1].data.includes("=")) {
                // Report error at the location of the first operator found
                errorObjects.push({
                    positionStart: operators[0].positionStart,
                    positionEnd: operators[0].positionEnd,
                });
            }
        }

        return errorObjects;
    }
};

/**
 * Helper function to determine if a token represents a comparison operator
 * @param token - The lexed token to check
 * @returns true if the token is a comparison operator (>=, <=, <, >)
 */
function isComparisonOperator(token: LexedJson): boolean {
    // Check if token is a recognized comparison operator type and has expected data
    if (
        (token.kind === "GreaterThanEqualTo" || token.kind === "LessThanEqualTo" || 
         token.kind === "LessThan" || token.kind === "GreaterThan") &&
        (token.data === ">=" || token.data === "<=" || token.data === "<" || token.data === ">")
    ) {
        return true;
    }
    return false;
}

export default noEqualOnBohRangesForIncrementalRefresh;