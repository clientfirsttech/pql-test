import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findIdentifiers, findNodesWithRecursiveExpression, logDebug } from "../rule-assistance";

/**
 * Rule: Ensure Text.Lower is used when filtering file extensions after Folder.Files or SharePoint.Files.
 * This helps avoid issues with case-sensitive extension filtering.
 */
export const useTextLowerForExtensionFilter: PowerQueryRule = {
    ID: "use-text-lower-for-extension-filter",
    Name: "Use Text.Lower for Extension Filter",
    Category: "Potential Issue",
    Description: "Ensure Text.Lower is used when filtering file extensions to avoid missing files due to case sensitivity (e.g., '.xlsx' vs '.XLSX'). ",
    References: [
        {
            Description: "Potential Issue - SharePoint Files & Filtering File Types",
            Link: "https://youtu.be/j4wceI44-to"
        },
        {
            Description: "Chapter 9 - Master Your Data with Power Query in Excel and Power BI",
            Link: "https://amzn.to/3HrG2Nd"
        }
    ],
    AIFixInstructions: {
        Description: "Automatically add Text.Lower to the extension filter step.",
        Prompt: "Modify the code to ensure that when filtering file extensions after a Folder.Files or SharePoint.Files call, the extension comparison uses Text.Lower to handle case sensitivity. For example, if the code filters for '.xlsx', it should be changed to use Text.Lower on the extension column and compare it to 'Text.Lower(\".xlsx\")'. Only return the modified M code without any additional explanations.",
        IsActive: true,
        IsWholeQueryFix: false
    },
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Free,
    Check: (input: ParseResult | undefined): ErrorObject[] | null => {
        // Extract tokens and AST from input
        const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;

        const errorObjects: ErrorObject[] = [];

        // Find Folder.Files and SharePoint.Files calls
        const folderFilesFind: LexedJson[] = findIdentifiers(lexTokens, "Folder.Files") ?? [];
        const sharePointFilesFind: LexedJson[] = findIdentifiers(lexTokens, "SharePoint.Files") ?? [];

        // Only proceed if either Folder.Files or SharePoint.Files is found
        if (folderFilesFind.length > 0 || sharePointFilesFind.length > 0) {
            // Find Table.SelectRows and Table.TransformColumns calls
            const tblSelectRowsFind: LexedJson[] = findIdentifiers(lexTokens, "Table.SelectRows") ?? [];
            const transformColumnsBase: LexedJson[] = findIdentifiers(lexTokens, "Table.TransformColumns") ?? [];

            tblSelectRowsFind.forEach((element) => {
                // Prepare array for recursive search
                const tempArrayForTableSelect: any[] = [element];
                logDebug(`Text.SelectRows found: ${tblSelectRowsFind.length} instances`);
                const textLowerCheckerInSelectRows = findNodesWithRecursiveExpression(tempArrayForTableSelect, aSTTokens, 'Text.Lower');
                // If Text.Lower is not found in the Table.SelectRows call
                if (textLowerCheckerInSelectRows.length === 0) {
                    // Check if the [Extension] column is referenced before Table.SelectRows
                    const extensionCheck = findNodesWithRecursiveExpression(tempArrayForTableSelect, aSTTokens, '"literal":"Extension"');
                    logDebug(`Extension found: ${extensionCheck.length} instances before Table.SelectRows`);

                    if (extensionCheck.length > 0) {
                        // Find Table.TransformColumns calls before this Table.SelectRows
                        const tableTransformColumns: LexedJson[] = transformColumnsBase
                            .filter(tl => tl.positionStart.lineNumber <= element.positionStart.lineNumber);
                        logDebug(`Table.TransformColumns found: ${tableTransformColumns.length} instances before Table.SelectRows`);

                        if (tableTransformColumns.length > 0) {
                            tableTransformColumns.forEach((textElement) => {
                                const tempArray2: any[] = [textElement];
                                // Check if Extension column and Text.Lower are used in TransformColumns
                                const extensionLCCheck = findNodesWithRecursiveExpression(tempArray2, aSTTokens, '"literal":"\\"Extension\\"');
                                const textLowerCChecker = findNodesWithRecursiveExpression(tempArray2, aSTTokens, 'Text.Lower');
                                logDebug(`Text.Lower found: ${textLowerCChecker.length} instances before Table.TransformColumns`);
                                logDebug(`Extension found: ${extensionLCCheck.length} instances before Table.TransformColumns`);

                                // If either Extension or Text.Lower is missing, flag an error
                                if (extensionLCCheck.length === 0 || textLowerCChecker.length === 0) {
                                    errorObjects.push({
                                        positionStart: element.positionStart,
                                        positionEnd: element.positionEnd,
                                    });
                                }
                            });
                        } else {
                            // If no Table.TransformColumns found before Table.SelectRows, flag an error
                            errorObjects.push({
                                positionStart: element.positionStart,
                                positionEnd: element.positionEnd,
                            });
                        }
                    }
                }
            });
        }

        return errorObjects;
    }
};

export default useTextLowerForExtensionFilter