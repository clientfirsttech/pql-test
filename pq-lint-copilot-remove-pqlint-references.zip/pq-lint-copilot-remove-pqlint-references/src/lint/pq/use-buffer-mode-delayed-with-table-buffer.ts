import { ParseResult } from "../../parser/pq/parse-types";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { findIdentifiers, findNodesWithRecursiveExpression} from "../rule-assistance";

// Create a Rule object with the function as a string
export const useBufferModeDelayedWithTableBuffer: PowerQueryRule = {
    ID: "use-buffer-mode-delayed-with-table-buffer",
    Name: "Use BufferMode.Delayed with Table.Buffer for Performance Gains",
    Category: "Best Practice",
    Description: "Use Buffer Mode Delayed with Table.Buffer() to increase evaluation performance. While this does not decrease loading time for the data, it does save time when saving your work on Power BI Desktop and especially Power BI Dataflows.",
    References: [
        {
            Link: "https://blog.crossjoin.co.uk/2022/03/20/new-options-for-the-table-buffer-function-in-power-query/",
            Description: "New Options for the Table.Buffer Function in Power Query"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const lexTokens : LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        const instances = findIdentifiers(lexTokens, 'Table.Buffer') ?? [];
    
        instances.forEach(element => {
            const tempArray : any[] = [];
            tempArray.push(element);
            const bufferModeUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens,'"literal":"BufferMode.Delayed"');

            if (bufferModeUsage.length === 0) {
                const errorObject: ErrorObject = {
                    positionStart: element.positionStart,
                    positionEnd: element.positionEnd
                };
                errorObjects.push(errorObject);
            }
        });


        return errorObjects;
    }
};

export default useBufferModeDelayedWithTableBuffer