import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findIdentifiers, findNodesWithRecursiveExpression, logDebug } from "../rule-assistance";

/**
 * Rule: Use SharePoint.Contents for Files instead of SharePoint.Files
 * This rule recommends using SharePoint.Contents instead of SharePoint.Files to improve performance and reliability.
 */
export const useFolderContentsForFiles: PowerQueryRule = {
    ID: "use-folder-contents-for-files",
    Name: "Use Folder.Contents for Files instead of filtering Folder Path with Folder.Files",
    Category: "Best Practice",
    Description: "When importing files from a directory, use Folder.Contents instead of Folder.Files to improve performance. Folder.Contents provides a more efficient way to access files, especially for folders with lots of files.",
    References: [
        {
            Description: "10 Power Query tips EVERY user should know! | Excel Off The Grid",
            Link: "https://www.youtube.com/watch?v=yYgvzfBfwF4&t=320s"
        }
    ],
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] | null => {
        // Extract tokens and AST from input
        const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;

        const errorObjects: ErrorObject[] = [];

        // Find Folder.Files calls - these should be replaced with Folder.Contents
        const folderFilesFind: LexedJson[] = findIdentifiers(lexTokens, "Folder.Files") ?? [];

        for (const element of folderFilesFind) {
            // Find Table.SelectRows and Table.TransformColumns calls
            const tblSelectRowsFind: LexedJson[] = findIdentifiers(lexTokens, "Table.SelectRows") ?? [];

            for (const tblElement of tblSelectRowsFind) {
                // Prepare array for recursive search
                const tempArrayForTableSelect: any[] = [tblElement];
                logDebug(`Text.SelectRows found: ${tblSelectRowsFind.length} instances`);

                // Check if the [Folder Path] column is referenced before Table.SelectRows
                const folderPathCheck = findNodesWithRecursiveExpression(tempArrayForTableSelect, aSTTokens, '"literal":"Folder Path');
                const extensionCheck = findNodesWithRecursiveExpression(tempArrayForTableSelect, aSTTokens, '"literal":"Extension');
                const nameCheck = findNodesWithRecursiveExpression(tempArrayForTableSelect, aSTTokens, '"literal":"Name');
                logDebug(`Folder Path found: ${folderPathCheck.length} instances before Table.SelectRows`);

                if (folderPathCheck.length > 0 || extensionCheck.length > 0 || nameCheck.length > 0) {
                    // If either Extension or Text.Lower is missing, flag an error
                    errorObjects.push({
                        positionStart: element.positionStart,
                        positionEnd: element.positionEnd
                    });
                    break; // only log once
                }
            }
        }

        return errorObjects;
    }
};

export default useFolderContentsForFiles;