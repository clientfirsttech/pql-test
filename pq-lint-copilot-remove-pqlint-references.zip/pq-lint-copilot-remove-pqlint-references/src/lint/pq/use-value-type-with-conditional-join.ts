import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { findIdentifiers, findNodesWithRecursiveExpression } from "../rule-assistance";
import {ParseResult} from "../../parser/pq/parse-types";
import { logDebug } from "../rule-assistance";
import { log } from "console";

// This rule checks for best practice usage of Value.Type in Table.AddColumn with Table.SelectRows
export const useValueTypeWithConditionalJoin: PowerQueryRule = {
    ID: "use-value-type-with-conditional-join",
    Name: "Use Value.Type for Joins with Table.AddColumn and Table.SelectRows",
    Category: "Best Practice",
    Description: "Using Value.Type in the fourth argment of Table.AddColumn (e.g., Value.Type(TableName)), you can retrieve the data types from the other table and avoid having to change data types in subsequent steps.",
    References: [
        {
            Description: "Chapter 9 - The Definitive Guide to Power Query (M)",
            Link: "https://amzn.to/43zc4ye"
        }
    ],    
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,    
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // If no input is provided, return an empty array
        if (!input) return [];

        // Extract lexed tokens and AST tokens from the input
        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        const errorObjects: ErrorObject[] = [];

        // Find all instances of Table.AddColumn in the lexed tokens
        const addColumnsRef: LexedJson[] = findIdentifiers(lexTokens, 'Table.AddColumn') ?? [];

        // For each Table.AddColumn reference found
        addColumnsRef.forEach(element => {
            const tempArray : any[] = [];
            tempArray.push(element); 
            // Find all references to Table.SelectRows within the AST tokens
            const tableSelectRowsNodes = findNodesWithRecursiveExpression(tempArray, aSTTokens, '"literal":"Table.SelectRows');        
            // Find all references to Value.Type within the AST tokens
            const valueTypeNodes = findNodesWithRecursiveExpression(tempArray, aSTTokens, '"literal":"Value.Type"');
            // Find all nodes with the key 'node' (for debugging/inspection)
            const nodeCheck = findNodesWithRecursiveExpression(tempArray, aSTTokens, 'node');
            
            // Debug logging for development
            logDebug("tableSelectRowsNodes: ", tableSelectRowsNodes);
            logDebug("valueTypeNodes: ", valueTypeNodes);
            logDebug("nodeCheck: ", nodeCheck);

            // If Table.SelectRows is used but Value.Type is not, flag as a warning
            if (tableSelectRowsNodes.length > 0 && valueTypeNodes.length === 0) {
                // Create an error object with the line number of the matched token
                const errorObject: ErrorObject = {
                    positionStart: element.positionStart,
                    positionEnd: element.positionEnd,
                };
                errorObjects.push(errorObject);
            }

        });

        // Return the list of error objects
        return errorObjects;
 }
};

export default useValueTypeWithConditionalJoin;