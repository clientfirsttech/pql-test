import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { searchAST } from "../rule-assistance";

// Create a Rule object with the function as a string
export const useMissingFieldParameterForTableRemoveColumns: PowerQueryRule = {
    ID: "use-missing-field-parameter-for-table-remove-columns",
    Name: "Provide Third Argument in Table.RemoveColumns (e.g., MissingField.Ignore)",
    Category: "Best Practice",
    Description: "Table.RemoveColumns does not provide a third argument MissingField.Ignore or MissingField.UseNull. By providing a third argument you can avoid possible errors if that upstream column is removed.",
    References: [
        {
            Description: "Safely removing columns in Power Query",
            Link: "https://xxlbi.com/blog/safely-removing-columns-power-query/"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const lexTokens : LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // Identify the instances of Number.Round
        const instances = lexTokens.filter((current) => {
            return current.kind === "Identifier" && current.data === "Table.RemoveColumns";
        });
    
        instances.forEach(element => {
            // Construct the search string using the properties of the element
            const searchString = '"positionStart":'+JSON.stringify(element.positionStart,null,0)+',"positionEnd":'+JSON.stringify(element.positionEnd,null,0);
            let searchResults: {path: string; match: any}[] = searchAST(aSTTokens, "", searchString);                    
            
            if(searchResults.length > 0){
                
                let temp = searchResults[searchResults.length-1].match;  
                let checkString = JSON.stringify(temp?.recursiveExpressions?.elements);
                // Check if MissingField. is present call string
                if(checkString.includes('"literal":"MissingField.') === false){
                    // Define line number to add to the error object
                    const errorObject: ErrorObject = {
                        positionStart: element.positionStart,
                        positionEnd: element.positionEnd
                    };
                    errorObjects.push(errorObject);
                }
            }
        });

        //logDebug(errorObjects);
        return errorObjects;
    }
};

export default useMissingFieldParameterForTableRemoveColumns;