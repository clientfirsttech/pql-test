import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findIdentifiers } from "../rule-assistance";

// Define the rule object
export const noAIFunctions: PowerQueryRule = {
    ID: "no-ai-functions", // Unique identifier for the rule
    Name: "Avoid AIFunctions.* usage as it will be deprecated on September 15th, 2025", // Rule name
    Category: "Potential Issue", // Rule category
    Description: "Cognitive services and Azure ML will be fully retired by September 15th, 2025", // Rule description
    References: [
        {
            Description: "Cognitive services and Azure ML will be fully retired by September 15th, 2025",
            Link: "https://powerbi.microsoft.com/en-us/blog/cognitive-services-and-azure-ml-for-dataflows-will-be-fully-retired-by-september-15th-2025/"
        }
    ], // References for the rule
    Severity: SeverityLevel.Error, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Free, // Minimum license level required to use the rule
    AIFixInstructions: {
        Description: "Remove deprecated AI functions that will be retired September 15, 2025",
        Prompt: `AIFunctionsRemover {
  Purpose: "Remove or replace deprecated AIFunctions.* calls that will be fully retired"
  
  Context {
    * Cognitive services and Azure ML in Power Query are deprecated
    * Full retirement date: September 15, 2025
    * Queries will fail after retirement if not updated
    * Alternative approaches should be used
  }
  
  Constraints {
    * Remove all AIFunctions.* calls
    * Output valid M code only
    * Preserve other functionality
    * Add comment explaining removal
  }
  
  Deprecated Functions {
    * AIFunctions.PostProcess
    * AIFunctions.Capacities
    * AIFunctions.Contents
    * AIFunctions.ExecuteInternal
    * AIFunctions.GetAutoMLEntity
  }
  
  Replacement Strategies {
    sentiment analysis: Use Azure Cognitive Services API directly via Web.Contents
    key phrase extraction: Use Azure Cognitive Services API directly
    language detection: Use Azure Cognitive Services API directly
    image tagging: Use Azure Computer Vision API directly
    AutoML: Use Azure ML endpoints or Python scripts
  }
  
  Process {
    1. Identify all AIFunctions.* calls in query
    2. For each AI function:
       a. Add comment explaining deprecation
       b. Comment out or remove the function call
       c. If possible, suggest alternative approach in comment
    3. Remove dependent steps if they only process AI function results
    4. Verify query still runs without AI functions
  }
  
  Examples {
    Before:
    #"Detected Language" = Table.AddColumn(Source, "Language", each AIFunctions.PostProcess([Text], "DetectLanguage")),
    #"Filtered English" = Table.SelectRows(#"Detected Language", each [Language] = "en")
    
    After:
    // AIFunctions.PostProcess is deprecated and will be retired September 15, 2025
    // Consider using Azure Cognitive Services Text Analytics API via Web.Contents
    // Example: https://learn.microsoft.com/azure/cognitive-services/language-service/
    #"Source" = Source,
    #"Filtered English" = Source  // Removed AI-dependent filter
    
    ---
    
    Before:
    Sentiment = AIFunctions.Contents("sentiment-analysis", [text = "Sample text"])
    
    After:
    // AIFunctions.Contents is deprecated (retirement: Sept 15, 2025)
    // Replace with direct API call to Azure Cognitive Services
    // Sentiment = [Removed - update with Web.Contents call to Azure API]
    Sentiment = null  // Placeholder - implement Azure API call
  }
  
  Edge Cases {
    * Multiple AI calls in sequence - remove all, consolidate alternatives
    * AI results used in joins - preserve join structure with placeholder data
    * Conditional logic based on AI - maintain structure, remove AI dependency
  }
}`,
        IsActive: true,
        IsWholeQueryFix: false
    },
    // The main check function for the rule
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const lexTokens : LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // AI Functions to check for
        const aiFunctionNames = [
            'AIFunctions.PostProcess',
            'AIFunctions.Capacities', 
            'AIFunctions.Contents',
            'AIFunctions.ExecuteInternal',
            'AIFunctions.GetAutoMLEntity'
        ];

        // Find instances of each AI function
        aiFunctionNames.forEach(functionName => {
            const instances = findIdentifiers(lexTokens, functionName) ?? [];
            
            instances.forEach(element => {
                const errorObject: ErrorObject = {
                    positionStart: element.positionStart,
                    positionEnd: element.positionEnd
                };
                errorObjects.push(errorObject);
            });
        });

        return errorObjects;
    }
};

export default noAIFunctions;