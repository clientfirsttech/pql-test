import { ParseResult } from "../../parser/pq/parse-types";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { findIdentifiers, findNodesWithRecursiveExpression, logDebug, searchAST } from "../rule-assistance";

/**
 * Rule to ensure Web.Contents uses RelativePath or Query parameters with parameterized URLs
 * to optimize connection pooling and avoid creating multiple connections.
 */
export const useRelativePathWithWebContents: PowerQueryRule = {
    ID: "use-relative-path-with-web-contents",
    Name: "Use RelativePath or Query with Parameterized URL in Web.Contents",
    Category: "Potential Issue",
    Description: "Hard Coded URL in Web.Contents() without use of Relative Path or Query can increase the number of connections. Use Relative Path or Query in conjunction with Parameterized URL to avoid this issue.",
    References: [
        {
            Description: "Using the RelativePath and Query Options with Web.Contents() in Power Query and Power BI M Code",
            Link: "https://blog.crossjoin.co.uk/2016/08/16/using-the-relativepath-and-query-options-with-web-contents-in-power-query-and-power-bi-m-code/"
        }
    ],
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Extract lexed tokens and AST from the parse result
        const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        
        // Initialize array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // Find all instances of Web.Contents function calls
        const instances = findIdentifiers(lexTokens, 'Web.Contents') ?? [];

        instances.forEach(element => {
            const tempArray: any[] = [];
            tempArray.push(element);
            
            // Construct search string to locate this specific Web.Contents call in the AST
            const searchString = '"positionStart":' + JSON.stringify(element.positionStart, null, 0) + ',"positionEnd":' + JSON.stringify(element.positionEnd, null, 0);
            let searchResults: { path: string; match: any }[] = searchAST(aSTTokens, "", searchString);
            let hasSecondParameterWithVariable = false;

            // Check if Web.Contents has a second parameter and if it uses a variable
            if (searchResults.length > 0) {
                // Get the last match (most specific)
                let temp = searchResults[searchResults.length - 1].match;
                logDebug(temp.recursiveExpressions?.elements[0]?.content.elements.length);
                
                if (temp.recursiveExpressions?.elements[0]?.content.elements.length > 1) {
                    logDebug(temp.recursiveExpressions?.elements[0]?.content.elements[0].node?.identifier?.kind);
                    
                    // Check if second parameter is an identifier (variable)
                    if (temp.recursiveExpressions?.elements[0]?.content.elements[1].node?.identifier?.kind == "Identifier") {
                        logDebug("Found second parameter with variable");
                        hasSecondParameterWithVariable = true;
                    }
                }
            }
            
            // Check for RelativePath usage in the Web.Contents call
            const relativePathUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens, '"literal":"RelativePath"');
            
            // Check for Query usage in the Web.Contents call
            const queryPathUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens, '"literal":"Query"');

            // If neither RelativePath nor Query is used, report an error
            if (relativePathUsage.length == 0 && queryPathUsage.length == 0 && hasSecondParameterWithVariable == false) {
                const errorObject: ErrorObject = {
                    positionStart: element.positionStart,
                    positionEnd: element.positionEnd
                };
                errorObjects.push(errorObject);
            }
        });

        return errorObjects;
    }
};

export default useRelativePathWithWebContents;