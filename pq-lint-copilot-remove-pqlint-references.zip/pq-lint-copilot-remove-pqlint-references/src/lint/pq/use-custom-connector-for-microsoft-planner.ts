import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { logDebug, findIdentifiers, findNodesWithRecursiveExpression } from "../rule-assistance";

// Create a Rule object
export const useCustomConnectorForMicrosoftPlanner: PowerQueryRule = {
    ID: "use-custom-connector-for-microsoft-planner",
    Name: "The use of 'graph.microsoft.com/v1.0/planner' in Web.Contents will not work in the Power BI service.",
    Category: "Potential Issue",
    Description: "If you want to connect from Power BI to REST APIs that use OAuth2 authentication, which includes Planner, you need to build a customer connector. Consider using a custom connector connector provided by a third-party or open-source.",
    References: [
        {
            Description:"Connecting To REST APIs With OAuth2 Authentication In Power Query/Power BI",
            Link: "https://blog.crossjoin.co.uk/2021/08/29/connecting-to-rest-apis-with-oauth2-authentication-in-power-query-power-bi/"
        },
        {
            Description:"Power Query Custom Data Connector for Microsoft Planner",
            Link: "https://github.com/kerski/powerquery-connector-ms-planner-rest-api"
        }
    ],     
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) return [];
        // Cast to access the properties
        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;    
        const errorObjects: ErrorObject[] = [];

        // Find the position of the Exchange.Contents call
        const instances: LexedJson[] = findIdentifiers(lexTokens, "Web.Contents") ?? [];

        const instanceCount = instances.length;
        let i = 0;
        let foundIssue = false;
        
        while (i < instanceCount && !foundIssue) {
            const instance = instances[i];
            const tempArray: any[] = [];
            tempArray.push(instance);
            // logDebug("Web.Contents instance found: ", instance);
            const plannerUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens, '"literal":"\\"https://graph.microsoft.com/v1.0/planner');
            // logDebug("Planner usage found: ", plannerUsage);
        
            // Check if the sequence is found
            if (plannerUsage.length > 0) {
                const errorObject: ErrorObject = {
                    positionStart: instance.positionStart,
                    positionEnd: instance.positionEnd
                };
                errorObjects.push(errorObject);
                foundIssue = true; // Stop searching after the first instance
            }
    
            i++;
        }

        return errorObjects;
    }
};

export default useCustomConnectorForMicrosoftPlanner;