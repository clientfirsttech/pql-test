import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findIdentifiers, findNodesWithRecursiveExpression } from "../rule-assistance";

// Create a Rule object
export const useVersion15ForSharePointFiles: PowerQueryRule = {
    ID: "use-version-15-for-sharepoint-files",
    Name: "Use API Version 15 for SharePoint File Connections",
    Category: "Best Practice",
    Description: "For SharePoint Files, API version 15 is recommended.",
    References: [
        {
            Description: "Chapter 3 - The Ultimate Power Query Cookbook for Power BI and Excel",
            Link: "https://amzn.to/3H3EJUq"
        }
    ],    
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,    
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) return [];

        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;        
        const errorObjects: ErrorObject[] = [];

        const instances = findIdentifiers(lexTokens, "SharePoint.Files") ?? [];
        instances.forEach(instance => {
            const searchString = '"positionStart":' + JSON.stringify(instance.positionStart, null, 0) + ',"positionEnd":' + JSON.stringify(instance.positionEnd, null, 0);

            const tempArray : any[] = [];
            tempArray.push(instance);
            const apiVersionUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens,'"literal":"ApiVersion"');
            const version14Usage = findNodesWithRecursiveExpression(tempArray, aSTTokens,'"literal":"14",');

            // Check to make sure that the API version is 14
            if (apiVersionUsage.length > 0 && version14Usage.length > 0) {
                const errorObject: ErrorObject = {
                    positionStart: instance.positionStart,
                    positionEnd: instance.positionEnd
                };
                errorObjects.push(errorObject);
            }            
        });

        return errorObjects;
    }
};

export default useVersion15ForSharePointFiles;