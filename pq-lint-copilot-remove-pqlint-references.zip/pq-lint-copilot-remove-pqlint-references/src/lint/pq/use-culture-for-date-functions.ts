import { ParseResult } from "../../parser/pq/parse-types";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { checkCultureForFunctionInstances } from "../rule-assistance";

// Create a Rule object
export const useCultureForDateFunctions: PowerQueryRule = {
    ID: "use-culture-for-date-functions", // Unique identifier for the rule
    Name: "Define Culture parameter for Specific Date/Time-related Functions", // Rule name
    Category: "Best Practice", // Rule category
    Description: "When a culture parameter is available, defining it is recommended (e.g., 'en-US'). That ensures your output is predictable regardless of the machine language of your users.", // Rule description
    References: [
        {
            Description: "Chapter 5 - The Definitive Guide to Power Query (M)",
            Link: "https://amzn.to/43zc4ye"
        }
    ],
    Severity: SeverityLevel.Warning, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Pro, // Minimum license level required to use the rule
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast the input to access its properties
        const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // List of Date functions that support the culture parameter
        const dateFunctions = ["Date.DayOfWeekName","Date.MonthName","Date.From","Date.FromText"];
        const dateTimeFunctions = ["DateTime.From","DateTimeZone.From","DateTime.FromText","Time.From","Time.FromText"];;
        const dateTimeZoneFunctions = ["DateTimeZone.From","DateTimeZone.FromText"];
        // 3rd argument
        const dateTime3rdArgumentFunctions = ["DateTime.ToText","Date.ToText","DateTimeZone.ToText","Time.ToText"];

        // Combine all date-related functions into one array
        const allDateFunctions = [
            ...dateFunctions,
            ...dateTimeFunctions,
            ...dateTimeZoneFunctions,
            ...dateTime3rdArgumentFunctions
        ];        
        
        // Identify all instances of Date functions with culture parameter
        const instances = lexTokens.filter((current) => {
            return current.kind === "Identifier" && allDateFunctions.includes(current.data);
        });

        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = checkCultureForFunctionInstances(aSTTokens, instances, dateTime3rdArgumentFunctions);


        // Return all collected error objects
        return errorObjects;
    }
};

export default useCultureForDateFunctions;