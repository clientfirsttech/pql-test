import {PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel} from "../rule-types";
import {ParseResult} from "../../parser/pq/parse-types";
import { findIdentifiers, findNodesWithRecursiveExpression, logDebug } from "../rule-assistance";
import { log } from "console";
// Create a Rule object with the function as a string
export const useEnableFoldingWithNativeQueries: PowerQueryRule = {
  ID: "use-enable-folding-with-native-queries",
  Name: "Enable Query Folding When Using Native Queries",
  Category: "Potential Issue",
  Description: "Check for the existence of the [EnableFolding = true] in the Value.NativeQuery and add to attempt to turn on query folding.",
  References: [
    {
        Description: "Potential Issue - Breaking Query Folding with Native Queries",
        Link: "https://youtu.be/q_Z1_U2e6l8"
    },
    {
        Link: "https://blog.crossjoin.co.uk/2021/02/21/query-folding-on-sql-queries-in-power-query-using-value-nativequery-and-enablefoldingtrue/",
        Description: "Query Folding On SQL Queries In Power Query Using Value.NativeQuery() and EnableFolding=true"
    }
  ],
  Severity: SeverityLevel.Error,
  MinLicenseLevel: LicenseLevel.Free,
  AIFixInstructions: {
    Description: "Split database query to enable folding with Value.NativeQuery",
    Prompt: `NativeQueryFoldingEnabler {
  Purpose: "Refactor database queries to use Value.NativeQuery with EnableFolding=true for query folding"
  
  Context {
    * Query parameter in database calls breaks query folding
    * Value.NativeQuery with EnableFolding=true preserves folding
    * Query folding pushes transformations to database for better performance
    * Reduces data transfer between database and Power BI
  }
  
  Constraints {
    * Preserve all query logic and connection parameters
    * Generate two distinct steps: connection and query
    * Output valid M syntax only
    * Step names must be descriptive and under 50 characters
    * Do not modify queries without Query parameter in database call
  }
  
  Detection Patterns {
    * Sql.Database(server, db, [Query="SQL"...])
    * Oracle.Database(server, [Query="SQL"...])
    * CommonDataService.Database(url, [Query="SQL"...])
    * Value.NativeQuery without EnableFolding option
  }
  
  Transformation Pattern 1: Database Call with Query {
    match: Database.Function(server, db, [Query="SQL", ...otherOptions])
    
    emit:
      step1: Database.Function(server, db, [otherOptions])
      step2: Value.NativeQuery(step1, "SQL", null, [EnableFolding=true])
  }
  
  Transformation Pattern 2: Value.NativeQuery without EnableFolding {
    match: Value.NativeQuery(source, "SQL", null)
    
    emit: Value.NativeQuery(source, "SQL", null, [EnableFolding=true])
  }
  
  Process {
    1. Scan for database source functions with Query parameter
    2. For each match:
       a. Extract server, database, SQL query string
       b. Extract other options (exclude Query parameter)
       c. Create connection step: Database.Function(server, db, [options])
       d. Name descriptively (e.g., #"Database Connection")
       e. Create query step: Value.NativeQuery(connection, "SQL", null, [EnableFolding=true])
       f. Name descriptively (e.g., #"Filtered Data")
    3. Scan for Value.NativeQuery without EnableFolding
    4. For each match, add [EnableFolding=true] as fourth parameter
    5. Update downstream step references
  }
  
  Examples {
    Before:
    Source = Sql.Database("server.windows.net", "Sales", [Query="SELECT * FROM Orders WHERE Year = 2023"])
    
    After:
    #"Database Connection" = Sql.Database("server.windows.net", "Sales"),
    #"Filtered Orders" = Value.NativeQuery(#"Database Connection", "SELECT * FROM Orders WHERE Year = 2023", null, [EnableFolding=true])
    
    ---
    
    Before:
    Data = Value.NativeQuery(Source, "SELECT * FROM Sales", null)
    
    After:
    Data = Value.NativeQuery(Source, "SELECT * FROM Sales", null, [EnableFolding=true])
  }
  
  Edge Cases {
    * Query with parameters - preserve parameter references
    * Multiple options in record - merge with EnableFolding
    * Nested queries - apply to each level
    * Connection already split - only add EnableFolding
  }
}`,
    IsActive: true,
    IsWholeQueryFix: false
  },
  Check: (input: ParseResult | undefined): ErrorObject[] => {
    // Cast to access the properties
    const lexTokens : LexedJson[] = (input as ParseResult).lexed as LexedJson[];
    const aSTTokens: any = (input as ParseResult).ast;
    // Initialize an array to collect all error objects
    const errorObjects: ErrorObject[] = [];

    // Find the position of the SQL.Database call
    const sqlFind: LexedJson[] = findIdentifiers(lexTokens, "Sql.Databases") ?? [];
    const sqlsFind: LexedJson[] = findIdentifiers(lexTokens, "Sql.Database") ?? [];
    const oracleFind: LexedJson[] = findIdentifiers(lexTokens, "Oracle.Database") ?? [];
    const commonDataServiceFind: LexedJson[] = findIdentifiers(lexTokens, "CommonDataService.Database") ?? [];
    // Combine arrays containing different database identifiers found in the lexed tokens.
    // This creates a single array with all matches for SQL, Oracle, and CommonDataService databases.
    const combinedDatabasesInstances: LexedJson[] = [
        ...sqlFind,
        ...sqlsFind,
        ...oracleFind,
        ...commonDataServiceFind
    ];
    // If neither SQL.Database nor CommonDataService.Database is found, return null
    if (combinedDatabasesInstances.length === 0) {
      return errorObjects; // Return empty array if no database identifiers are found
    }

    // Ensure each Query usage is wrapped with Value.NativeQuery
    combinedDatabasesInstances.forEach(element => {
        const querySearch: any[] = [];
        querySearch.push(element);
        const queryParameterUsage = findNodesWithRecursiveExpression(querySearch, aSTTokens, '"literal":"Query"');

        if (queryParameterUsage.length > 0) {
            errorObjects.push({
                positionStart: element.positionStart,
                positionEnd: element.positionEnd
            });
        }
    });
    // Identify the instances of native queries used via AST traversal
    const nativeQueryInstances = findIdentifiers(lexTokens, "Value.NativeQuery") ?? [];

    // Ensure each Value.NativeQuery call includes EnableFolding=true
    nativeQueryInstances.forEach(element => {
        const nativeSearch: any[] = [];
        nativeSearch.push(element);
        const enableFoldingUsage = findNodesWithRecursiveExpression(nativeSearch, aSTTokens, '"literal":"EnableFolding"');

        if (enableFoldingUsage.length === 0) {
            errorObjects.push({
                positionStart: element.positionStart,
                positionEnd: element.positionEnd
            });
        }
    });

    return errorObjects;
  }
};

export default useEnableFoldingWithNativeQueries;