import { ParseResult } from "../../parser/pq/parse-types";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { findIdentifiers, findNodesWithRecursiveExpression, logDebug } from "../rule-assistance";

// Rule to encourage using a single function for cleaning and trimming strings
export const useAlternativeForTextCleanAndTrimUsage: PowerQueryRule = {
    ID: "use-alternative-for-text-clean-and-trim-usage",
    Name: "Use an alternative function that cleans and trims the string.",
    Category: "Best Practice",
    Description: "Text.Trim does not remove duplicate spaces in the middle of a string. Use an alternative function that cleans and trims the string appropriately in one call.",
    References: [
        {
            Description: "Chapter 11 - The Definitive Guide to Power Query (M)",
            Link: "https://amzn.to/43zc4ye"
        },
        {
            Description: "fnCleanTrim function",
            Link: "https://gist.github.com/kerski/49af08b7216e02cec54086d0b32f2f13"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Extract lexed tokens and AST from the input
        const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // Array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // Find all instances of Text.Trim and Text.Clean in the code
        const trimInstances = findIdentifiers(lexTokens, 'Text.Trim') ?? [];
        const cleanInstances = findIdentifiers(lexTokens, 'Text.Clean') ?? [];

        // Compare line numbers between trimInstances and cleanInstances
        trimInstances.forEach(trim => {
            cleanInstances.forEach(clean => {
                const lineDiff = Math.abs(trim.positionStart.lineNumber - clean.positionStart.lineNumber);
                logDebug(
                    `Trim at line ${trim.positionStart.lineNumber}, Clean at line ${clean.positionStart.lineNumber}, Difference: ${lineDiff}`
                );

                // If both functions are used within 1 line of each other, flag as an issue
                if (lineDiff <= 1) {
                    const errorObject: ErrorObject = {
                        positionStart: trim.positionStart,
                        positionEnd: trim.positionEnd,
                    };
                    errorObjects.push(errorObject);
                }
            });
        });

        return errorObjects;
    }
};

export default useAlternativeForTextCleanAndTrimUsage