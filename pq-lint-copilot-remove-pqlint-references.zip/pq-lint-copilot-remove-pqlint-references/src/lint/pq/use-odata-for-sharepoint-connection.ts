import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";

// Create a Rule object with the function as a string
export const useOdataForSharepointConnection: PowerQueryRule = {
    ID: "use-odata-for-sharepoint-connection",
    Name: "Consider Using OData Instead of SharePoint List Connector",
    Category: "Best Practice",
    Description: "SharePoint's Native List Connector is notoriously slow (especially for big lists). OData may be more efficient to reduce the number of columns retrieved if you can keep the query below 2100 characters.",
    References: [
        {
            Description:"DataOps Principle #8 - Reflect",
            Link:"https://blog.kerski.tech/bringing-dataops-to-power-bi-part27/"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Free,    
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) return [];

        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const errorObjects: ErrorObject[] = [];

        // Find the index of the relevant identifiers in the lexed tokens
        const spIndex = lexTokens.findIndex((item: LexedJson) => item.kind === 'Identifier' && item.data === 'SharePoint.Tables');
        
        if(spIndex !== -1){
            const errorObject: ErrorObject = {
                positionStart: lexTokens[spIndex].positionStart,
                positionEnd: lexTokens[spIndex].positionEnd
            };
            errorObjects.push(errorObject);
        }

        return errorObjects;
    }
};

export default useOdataForSharepointConnection;