import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { logDebug, findFunctionCallsInAST, findParametersInASTForFunctionCall } from "../rule-assistance";
import { log } from "console";

// Define the rule object
export const useNewColumnNamesForTableExpandRecordColumn: PowerQueryRule = {
    ID: "use-new-column-names-for-table-expand-record-column", // Unique identifier for the rule
    Name: "Rename Expanded Column in Same Step for Clarity", // Rule name
    Category: "Best Practice", // Rule category
    Description: "After expanding a cell's column, a rename step was called after the expansion. This can be accomplished in the expansion step, so the context of the column creations are more concise.", // Rule description
    References: [
        {
            Description:"Chapter 10 - The Ultimate Power Query Cookbook for Power BI and Excel",
            Link: "https://amzn.to/3H3EJUq"
        }
    ],    
    Severity: SeverityLevel.Warning, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Pro, // Minimum license level required to use the rule
    // The main check function for the rule
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Extract lexed tokens and AST tokens from the input
        const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        const errorObjects: ErrorObject[] = []; // Array to store error objects

        // Find all function calls in the AST
        const functionCalls: any[] = findFunctionCallsInAST(aSTTokens);

        // Filter function calls to find "Table.ExpandTableColumn" calls
        const expandCalls = functionCalls.filter((call) => {
            return call?.literal === "Table.ExpandRecordColumn";
        });
        logDebug("Expand Record Column Calls:", expandCalls.length);

        // Iterate over each "Table.ExpandTableColumn" call
        expandCalls.forEach(element => {
            logDebug("Expand Record Column Element:", element?.literal);

            // Retrieve the parameters of the function call
            const parameters: any[] = findParametersInASTForFunctionCall(element, aSTTokens);
            const columnSearch: any[] = []; // Array to store column names
            if (parameters.length >= 4) {
                // Extract column names from the parameters
                for (let i = 0; i < parameters[3]?.content?.elements.length; i++) {
                    logDebug("Parameters[3] Elements:", parameters[3]?.content?.elements[i]?.node?.literal);
                    columnSearch.push(parameters[3]?.content?.elements[i]?.node?.literal);
                }
            }

            // Check if each column name is used in a rename step
            columnSearch.forEach((newColumnName: string) => {
                logDebug("New Column Name:", newColumnName);

                // Escape double quotes in the column name for searching
                const newColumnSearch = newColumnName.replace(/"/g, '\\"');
                // Find the index of the current function call
                const functionCallIndex = functionCalls.findIndex((item) => {
                    return item.tokenRange.positionStart.codeUnit === element.tokenRange.positionStart.codeUnit &&
                        item.tokenRange.positionStart.lineNumber === element.tokenRange.positionStart.lineNumber;
                });
                logDebug("Function Call Index:", functionCallIndex);

                const functionCallChecks: any[] = []; // Array to store subsequent function calls
                if (functionCallIndex > 0) {
                    // Collect all subsequent "Table.RenameColumns" calls
                    let index = functionCallIndex + 1;
                    while (index <= functionCalls.length) {
                        if (functionCalls[index]?.literal === "Table.RenameColumns") {
                            functionCallChecks.push(functionCalls[index]);
                        }
                        index++;
                    }
                }
                logDebug("Function Call Checks:", functionCallChecks);

                // Check each subsequent "Table.RenameColumns" call
                functionCallChecks.forEach((nextFunctionCall) => {
                    logDebug("Next Function Call:", nextFunctionCall);

                    if (nextFunctionCall?.literal === "Table.RenameColumns") {
                        // Retrieve the parameters of the rename function call
                        const renameParameters = findParametersInASTForFunctionCall(nextFunctionCall, aSTTokens);
                        logDebug("Rename Parameters:", renameParameters);

                        if (renameParameters.length > 0) {
                            // Check if the column name is included in the rename parameters
                            for (let i = 0; i < renameParameters[1]?.content?.elements.length; i++) {
                                if (JSON.stringify(renameParameters[1]?.content?.elements[i]?.node).includes('"literal":"' + newColumnSearch + '"')) {
                                    // Create an error object for the matched token
                                    const errorObject: ErrorObject = {
                                        positionStart: renameParameters[1].tokenRange.positionStart,
                                        positionEnd: renameParameters[1].tokenRange.positionEnd,
                                    };
                                    errorObjects.push(errorObject);
                                    return errorObjects; // Return early if an error is found
                                }
                            }
                        }
                    }
                });
            });
        });

        // Return all collected error objects
        return errorObjects;
    }
};

export default useNewColumnNamesForTableExpandRecordColumn;