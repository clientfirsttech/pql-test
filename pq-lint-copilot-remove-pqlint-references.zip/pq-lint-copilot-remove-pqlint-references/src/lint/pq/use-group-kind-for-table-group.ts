import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import {ParseResult} from "../../parser/pq/parse-types";
import { searchAST } from "../rule-assistance";
// Create a Rule object with the function as a string
export const useGroupKindForTableGroup: PowerQueryRule = {
    ID: "use-group-kind-for-table-group",
    Name: "Specify GroupKind in Table.Group for Consistency",
    Category: "Potential Issue",
    Description: "For Table.Group make sure to set GroupKind.Local if the data is continguous. Otherwise, it's best practice to add a fourth argument for readability.",
    References: [
        {
            Description: "Speed/Performance aspects",
            Link: "https://www.thebiccountant.com/speedperformance-aspects/"            
        }
    ],
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const lexTokens : LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // Identify the instances of Number.Round
        const instances = lexTokens.filter((current) => {
            return current.kind === "Identifier" && current.data === "Table.Group";
        });
    
        instances.forEach(element => {
            // Construct the search string using the properties of the element
            const searchString = '"positionStart":'+JSON.stringify(element.positionStart,null,0)+',"positionEnd":'+JSON.stringify(element.positionEnd,null,0);
            let searchResults: {path: string; match: any}[] = searchAST(aSTTokens, "", searchString);                    

            if(searchResults.length > 0){
                
                let temp = searchResults[searchResults.length-1].match;
                
                let checkString = JSON.stringify(temp?.recursiveExpressions?.elements);
                
                // Check if RoundingMode is present call string
                if(checkString.includes('"literal":"GroupKind.Local') === false && checkString.includes('"literal":"GroupKind.Global') === false){
                    // Define line number to add to the error object
                    const errorObject: ErrorObject = {
                        positionStart: element.positionStart,
                        positionEnd: element.positionEnd
                    };
                    errorObjects.push(errorObject);
                }
            }
        });


        return errorObjects;
    }
};

export default useGroupKindForTableGroup;