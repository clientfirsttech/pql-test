import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findAllSpecificTokens, findNodesWithRecursiveExpression} from '../rule-assistance'; // Import the function to find specific tokens
// Create a Rule object with the function as a string
export const requireInspectionOfTransformForCombiningFolderFiles: PowerQueryRule = {
    ID: "require-inspection-of-transform-for-combining-folder-files",
    Name: "Use Transform Function to Combine Files in Folder Queries",
    Category: "Best Practice",
    Description: "Investigate the Transform function to combine the data from multiple files in local Folder. By default, the Transform function will use a Sample File which may change at the document library contents change. Either parameterize the SampleFile or use a custom column to parse each row of data.",
    References: [
        {
            Description: "Chapter 16 - The Ultimate Power Query Cookbook for Power BI and Excel",
            Link: "https://amzn.to/3H3EJUq"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) return [];

        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        const errorObjects: ErrorObject[] = [];

        // Find the index of the relevant identifiers in the lexed tokens
        const folderFiles = findAllSpecificTokens(lexTokens, 'Identifier', 'Folder.Files');
        if (folderFiles.length === 0) return errorObjects; // No Folder.Files found

        if (folderFiles.length > 0) {
            // Find the Table.AddColumn and see if it contains a call to a Transform function
            const addColumns = findAllSpecificTokens(lexTokens, 'Identifier', 'Table.AddColumn');

            // Iterate through each AddColumn to see if it contains a Transform function and Content literal
            addColumns.forEach(element => {
                const tempArray : any[] = [];
                tempArray.push(element);
                const transformFunctionCalls = findNodesWithRecursiveExpression(tempArray, aSTTokens,'"literal":"#\\\"Transform');
                const contentLiteral = findNodesWithRecursiveExpression(tempArray, aSTTokens, '"literal":"Content"');
                if (transformFunctionCalls.length > 0 && contentLiteral.length > 0) {
                    transformFunctionCalls.forEach(element => {
                        // Create an error object for each instance of the Transform function
                        const errorObject: ErrorObject = {
                            positionStart: element.tokenRange.positionStart,
                            positionEnd: element.tokenRange.positionEnd
                        };
                        errorObjects.push(errorObject);
                    });
                } else {
                    // If no Transform function is found, return an empty array
                    return errorObjects;
                }
            });



        }

        return errorObjects;
    }
};

export default requireInspectionOfTransformForCombiningFolderFiles