import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findTableBufferPattern, findIdentifiers, findNodesWithRecursiveExpression } from "../rule-assistance";
import { logDebug } from "../rule-assistance";

// Create a Rule object with the function as a string
export const useTableBufferForConditionalJoin: PowerQueryRule = {
    ID: "use-table-buffer-for-conditional-join",
    Name: "Use Table.Buffer for joins with Table.AddColumn and Table.SelectRows",
    Category: "Best Practice",
    Description: "When a conditional join is used with Table.AddColumn and Table.SelectRows please use an instance of Table.Buffer for performance.",
    References: [],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,    
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // If no input is provided, return an empty array
        if (!input) return [];

        // Extract lexed tokens and AST tokens from the input
        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        const errorObjects: ErrorObject[] = [];

        // Find all instances of Table.AddColumn in the lexed tokens
        const addColumnsRef: LexedJson[] = findIdentifiers(lexTokens, 'Table.AddColumn') ?? [];

        // Find all instances of Table.Buffer in the lexed tokens
        const tblBuffer: LexedJson[] = findTableBufferPattern(lexTokens);

        // If no Table.AddColumn is found, return an empty array
        if (addColumnsRef.length > 0) {
            // Find all references to Table.SelectRows within the AST tokens
            const tableSelectRowsNodes = findNodesWithRecursiveExpression(addColumnsRef, aSTTokens, '"literal":"Table.SelectRows');        

            // Iterate through each Table.SelectRows node
            tableSelectRowsNodes.forEach(element => {
                let found = false;

                // Check if any Table.Buffer reference matches the current Table.SelectRows node
                tblBuffer.forEach(buffer => {
                    logDebug("checking buffer: ", buffer.data);
                    if (JSON.stringify(element).includes('"literal":"' + buffer.data + '"') === true) {
                        found = true;
                    } // end if
                });

                // If no matching Table.Buffer is found, create an error object
                if (found === false) {
                    // Define line number to add to the error object
                    const errorObject: ErrorObject = {
                        positionStart: element.tokenRange.positionStart,
                        positionEnd: element.tokenRange.positionEnd
                    };
                    errorObjects.push(errorObject);
                } // end if
            });
        } // end if

        // Return the list of error objects
        return errorObjects;
    }
};

export default useTableBufferForConditionalJoin;