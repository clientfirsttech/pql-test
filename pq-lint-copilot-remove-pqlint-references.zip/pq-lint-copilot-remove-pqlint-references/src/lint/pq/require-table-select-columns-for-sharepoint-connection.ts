import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";

// Create a Rule object with the function as a string
export const requireTableSelectColumnsForSharepointConnection: PowerQueryRule = {
    ID: "require-table-select-columns-for-sharepoint-connection",
    Name: "Use Table.SelectColumns as Final Step in SharePoint List Queries",
    Category: "Best Practice",
    Description: "For SharePoint List connectors, it's best practice to add Table.SelectColumns as the last step. This avoids unwanted columns appearing in your model and increasing the size of your model.",
    References: [],    
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) return [];

        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        const errorObjects: ErrorObject[] = [];

        // Find the index of the relevant identifiers in the lexed tokens
        const spIndex = lexTokens.findIndex((item: LexedJson) => item.kind === 'Identifier' && item.data === 'SharePoint.Tables');

        if (spIndex !== -1) {
            const elements: any = aSTTokens?.variableList?.elements as any;
            // Get row count
            const rowCount: number = elements.length;
            const nodes: any = [];
            // Iterate through the elements in the variableList
            elements.forEach((element: { node: { value: any; }; }, index: any) => {
                const node = element?.node?.value;
                // Check if the current element is a Table.SelectColumns call
                if (node?.head?.identifier.literal === "Table.SelectColumns") {
                    nodes.push(node);
                }
            });

            if (nodes.length > 0) {
                const lineNumber : number = nodes[nodes.length - 1]?.head?.identifier?.tokenRange.positionEnd?.lineNumber;
                // Check if Table.SelectColumns is the last step
                if (rowCount !== (lineNumber)) {
                    const errorObject: ErrorObject = {
                        positionStart: lexTokens[spIndex].positionStart,
                        positionEnd: lexTokens[spIndex].positionEnd
                    };
                    errorObjects.push(errorObject);
                }
            }else { // Doesn't exist so highlight issue
                const errorObject: ErrorObject = {
                    positionStart: lexTokens[spIndex].positionStart,
                    positionEnd: lexTokens[spIndex].positionEnd
                };
                errorObjects.push(errorObject);
            }
        }

        return errorObjects;
    }
};

export default requireTableSelectColumnsForSharepointConnection