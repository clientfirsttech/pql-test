import { ParseResult } from "../../parser/pq/parse-types";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { findIdentifiers, findNodesWithRecursiveExpression } from "../rule-assistance";

// Create a Rule object with the function as a string
export const noEllipsisOperator: PowerQueryRule = {
    ID: "no-ellipsis-operator",
    Name: "Avoid using the Ellipsis Operator in Production Code",
    Category: "Potential Issue",
    Description: "Although the ellipsis operator can be useful for stubbing out code during development, executing it in production will result in an error.  Replace the ellipsis operator with working code.",
    References: [
        {
            Description: "Chapter 12 - The Definitive Guide to Power Query (M)",
            Link: "https://amzn.to/43zc4ye"
        },
    ],
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        for (let i = 0; i < lexTokens.length; i++) {
            if (
                lexTokens[i]?.kind === "Ellipsis" &&
                lexTokens[i]?.data === "..."
            ) {
                // Check if the next token is a function that is likely to be recursive
                errorObjects.push({
                    positionStart: lexTokens[i].positionStart,
                    positionEnd: lexTokens[i].positionEnd,
                });
            }
        }


        return errorObjects;
    }
};

export default noEllipsisOperator;