import { ParseResult } from "../../parser/pq/parse-types";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { findIdentifiers, findNodesWithRecursiveExpression} from "../rule-assistance";

// Create a Rule object with the function as a string
export const requireCreateNavigationPropertiesBeSetToFalseInDataverse: PowerQueryRule = {
    ID: "require-create-navigation-properties-be-set-false-in-dataverse",
    Name: "Disable CreateNavigationProperties to Improve Performance (Especially with DirectQuery)",
    Category: "Best Practice",
    Description: "By default 'Include relationship columns' is included with Dataverse. This can bring more columns over than necessary and affect performance (especially with Direct Query). If intended, set CreateNavigationProperties to true and try to convert to a SQL call instead (ref: https://hatfullofdata.blog/using-sql-on-dataverse-for-power-bi/) which will avoid bringing unecessary tables and preserve query folding. If bringing over those columns aren't intended, uncheck 'Include relationship columns' in the Source step.",
    References: [
        {
            Description: "Overhead Of Getting Relationship Columns In Power BI DirectQuery Mode",
            Link: "https://blog.crossjoin.co.uk/2024/03/10/overhead-of-getting-relationship-columns-in-power-bi-directquery-mode/"
            
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const lexTokens : LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        const instances = findIdentifiers(lexTokens, 'CommonDataService.Database') ?? [];
    
        instances.forEach(element => {
            const tempArray : any[] = [];
            tempArray.push(element);
            const createNavUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens,'"literal":"CreateNavigationProperties"');

            // If not used then add to error objects
            if (createNavUsage.length == 0) {
                const errorObject: ErrorObject = {
                    positionStart: element.positionStart,
                    positionEnd: element.positionEnd
                };
                errorObjects.push(errorObject);
            }
        });


        return errorObjects;
    }
};

export default requireCreateNavigationPropertiesBeSetToFalseInDataverse