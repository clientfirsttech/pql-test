import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { logDebug, findFunctionCallsInAST, findParametersInASTForFunctionCall } from "../rule-assistance";
import { log } from "console";

// Define the rule object
export const useColumnsForTableCombine: PowerQueryRule = {
    ID: "use-columns-for-table-combine", // Unique identifier for the rule
    Name: "Use the Columns Parameter in Table.Combine After Append", // Rule name
    Category: "Best Practice", // Rule category
    Description: "After appending tables, a removal or selection of columns was detected. This can be accomplished using the columns parameter in Table.Combine step; moreover, this allows the context of the column selection to be more concise.", // Rule description
    References: [],
    Severity: SeverityLevel.Warning, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Pro, // Minimum license level required to use the rule
    // The main check function for the rule
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Extract lexed tokens and AST tokens from the input
        const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        const errorObjects: ErrorObject[] = []; // Array to store error objects

        // Find all function calls in the AST
        const functionCalls: any[] = findFunctionCallsInAST(aSTTokens);

        let index = 0; // Index to track the current function call
        functionCalls.forEach(element => {
            // Check if the function call is "Table.Combine"
            if (element?.literal === "Table.Combine") {
                logDebug("Table.Combine Element:", element?.literal);

                // Check the next function call for "Table.RemoveColumns" or "Table.SelectColumns"
                if (index + 1 < functionCalls.length) {
                    if (functionCalls[index + 1]?.literal === "Table.RemoveColumns" || functionCalls[index + 1]?.literal === "Table.SelectColumns") {
                        // Create an error object for the detected issue
                        const errorObject: ErrorObject = {
                            positionStart: functionCalls[index + 1].tokenRange.positionStart, // Start position of the issue
                            positionEnd: functionCalls[index + 1].tokenRange.positionEnd // End position of the issue
                        };
                        errorObjects.push(errorObject); // Add the error object to the list
                    }
                }
            }
            index++; // Increment the index for the next function call
        });

        // Return all collected error objects
        return errorObjects;
    }
};

export default useColumnsForTableCombine;