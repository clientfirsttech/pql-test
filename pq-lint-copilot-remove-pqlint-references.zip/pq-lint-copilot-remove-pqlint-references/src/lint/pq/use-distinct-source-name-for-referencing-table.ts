import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";

// Create a Rule object with the function as a string
export const useDistinctSourceNameForReferencingTable: PowerQueryRule = {
    ID: "use-distinct-source-name-for-referencing-table",
    Name: "Use Descriptive Name Instead of ‘Source’ for Referenced Steps",
    Category: "Best Practice",
    Description: "When referencing a table within Power Query it is better to use a step name other than 'Source' so Step Names can give a clue to the lineage. Source would indicate an external connection. We recommended renaming the step to using the table name reference or another identifier (i.e., #\"Ref: DateDim\"). This has to be done in the advanced editor.",
    References: [
        {   
            Description: "Chapter 8 - Master Your Data with Power Query in Excel and Power BI",
            Link: "https://amzn.to/3HrG2Nd"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) return [];

        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const errorObjects: ErrorObject[] = [];

        const index = lexTokens.findIndex((item: LexedJson) => item.kind === 'Identifier' && item.data === 'Source');
        
        if (index !== -1 && index + 3 < lexTokens.length) {
            const nextElements = lexTokens.slice(index + 1, index + 4);
            if (
                nextElements[0].kind === 'Equal' && nextElements[0].data === '=' &&
                nextElements[1].kind === 'Identifier' &&
                nextElements[2].kind === 'LeftParenthesis' && nextElements[2].data === '('
            ) {
                const dataElement = nextElements[1].data;

                const allowedDataAccessors = [
                    'Table.Combine', 'Table.NestedJoin', 'Table.FuzzyJoin',
                    'Table.Join', 'Table.FuzzyNestedJoin', 'Table.SelectColumns'
                ];

                if (allowedDataAccessors.includes(dataElement)) {
                    const errorObject: ErrorObject = {
                        positionStart: lexTokens[index].positionStart,
                        positionEnd: lexTokens[index].positionEnd
                    };
                    errorObjects.push(errorObject);
                }
            } else if (
                nextElements[0].kind === 'Equal' && nextElements[0].data === '=' &&
                nextElements[1].kind === 'Identifier' &&
                nextElements[2].kind === 'Comma' && nextElements[2].data === ','
            ) {
                const errorObject: ErrorObject = {
                    positionStart: lexTokens[index].positionStart,
                    positionEnd: lexTokens[index].positionEnd
                };
                errorObjects.push(errorObject);
            }
        }

        return errorObjects;
    }
};

export default useDistinctSourceNameForReferencingTable;