import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findTableBufferPattern } from "../rule-assistance";
import { group } from "console";

// Create a Rule object with the function as a string
export const useTableBufferForTableGroup: PowerQueryRule = {
    ID: "use-table-buffer-for-table-group",
    Name: "Use Table.Buffer Before Table.Group for Performance",
    Category: "Potential Issue",
    Description: "Using Table.Sort prior Table.Group can lead to unexpected results. Use Table.Buffer to retain sort order.",
    References: [
        {
            Description: "Keep sorted table for Group By, using Table.Buffer",
            Link: "https://exceltown.com/en/tutorials/power-bi/power-query-m-language/keep-sorted-table-for-group-by-using-table-buffer/",            
        }
    ],
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Pro,    
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) return [];

        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        const errorObjects: ErrorObject[] = [];

        // Find the index of the relevant identifiers in the lexed tokens
        const sortIndex = lexTokens.findIndex((item: LexedJson) => item.kind === 'Identifier' && item.data === 'Table.Sort');
        const groupIndex = lexTokens.findIndex((item: LexedJson) => item.kind === 'Identifier' && item.data === 'Table.Group');

        // Check if Table.Sort is used before Table.Group
        if ((sortIndex !== -1 && groupIndex !== -1) && sortIndex < groupIndex) {
            // Second Find Table.Buffer references
            const tblBuffer: LexedJson[] = findTableBufferPattern(lexTokens);
            // If no Table.Buffer is found, add an error object
            if(tblBuffer.length === 0){
                const errorObject: ErrorObject = {
                    positionStart: lexTokens[groupIndex].positionStart,
                    positionEnd: lexTokens[groupIndex].positionEnd
                };
                errorObjects.push(errorObject);
            }else{ // Check if Table.Buffer is used before Table.Group
                // Assume one instance exists before
                // Later we could check if multiple instances exist and if they are used appropriately
                if(tblBuffer[0].positionStart.lineNumber > lexTokens[groupIndex].positionStart.lineNumber){
                    const errorObject: ErrorObject = {
                        positionStart: lexTokens[groupIndex].positionStart,
                        positionEnd: lexTokens[groupIndex].positionEnd
                    };
                    errorObjects.push(errorObject);
                }
            }
        }

        return errorObjects;
    }
};

export default useTableBufferForTableGroup;