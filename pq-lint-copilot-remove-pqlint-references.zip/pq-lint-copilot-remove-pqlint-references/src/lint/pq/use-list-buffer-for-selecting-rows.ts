import { ParseResult } from "../../parser/pq/parse-types";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { containsTokenSequence, findIdentifiers, findNodesWithRecursiveExpression, logDebug, searchAST } from "../rule-assistance";

// Create a Rule object
export const useListBufferForSelectingRows: PowerQueryRule = {
  ID: "use-list-buffer-for-selecting-rows",
  Name: "Use List.Buffer for Selecting Rows when using List.Contains",
  Category: "Potential Issue",
  Description: "When filtering another table with a list, use List.Buffer to improve performance when selecting rows.",
  References: [
    {
        Description:"List.Buffer: This One Power Query Function Can Speed Up Your Refresh",
        Link: "https://www.youtube.com/watch?v=-9priw29qYc"
    }
],   
  Severity: SeverityLevel.Error,
  MinLicenseLevel: LicenseLevel.Pro,
  Check: (input: ParseResult | undefined): ErrorObject[] => {
    // Cast to access the properties
    const lexTokens : LexedJson[] = (input as ParseResult).lexed as LexedJson[];
    const aSTTokens: any = (input as ParseResult).ast;
    // Initialize an array to collect all error objects
    const errorObjects: ErrorObject[] = [];

    // Find instances of Table.SelectRows calls
    const selectedRowsInstances: LexedJson[] = findIdentifiers(lexTokens, "Table.SelectRows") ?? [];
    const instancesWithBuffer: LexedJson[] = findIdentifiers(lexTokens, "List.Buffer") ?? [];

    // Find the position of the variable list call
    const aSTElements = input?.ast?.variableList?.elements ?? [];

    // Check each Table.SelectRows instance for proper List.Buffer usage
    selectedRowsInstances.forEach(instance => {
        // If List.Buffer is not used anywhere, or there's no List.Buffer call before this Table.SelectRows instance
        if(instancesWithBuffer.length === 0 || 
        !instancesWithBuffer.some(bufferInstance => bufferInstance.positionStart.lineNumber <= instance.positionStart.lineNumber)){
            const tempArray: any[] = [];
            tempArray.push(instance);
                        
            // Construct the search string using the properties of the element
            const searchString = '"positionStart":'+JSON.stringify(instance.positionStart,null,0)+',"positionEnd":'+JSON.stringify(instance.positionEnd,null,0);
            // Check for List.Contains usage
            const listContainsSearch = findNodesWithRecursiveExpression(tempArray, aSTTokens, '"literal":"List.Contains"');
            let hasListExpression = false;
            
            // Check if List.Contains has a ListExpression that is hard-coded.
            if(listContainsSearch.length > 0){
                hasListExpression = JSON.stringify(listContainsSearch[listContainsSearch.length - 1]).includes('"kind":"ListExpression",');
            }

            logDebug('List.Contains Search Results:', JSON.stringify(listContainsSearch));
            // If Table.SelectRows instance is found in AST, flag it as an error
            if (listContainsSearch.length > 0 && hasListExpression === false) {
                const errorObject: ErrorObject = {
                    positionStart: instance.positionStart,
                    positionEnd: instance.positionEnd
                };
                errorObjects.push(errorObject);
            }//end if

        }// end if
    });

    return errorObjects;
  }
};

export default useListBufferForSelectingRows;