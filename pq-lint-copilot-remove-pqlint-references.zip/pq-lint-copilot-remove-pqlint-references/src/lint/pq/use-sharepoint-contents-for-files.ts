import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findIdentifiers, findNodesWithRecursiveExpression, logDebug } from "../rule-assistance";

/**
 * Rule: Use SharePoint.Contents for Files instead of SharePoint.Files
 * This rule recommends using SharePoint.Contents instead of SharePoint.Files to improve performance and reliability.
 */
export const useSharePointContentsForFiles: PowerQueryRule = {
    ID: "use-sharepoint-contents-for-files",
    Name: "Use SharePoint.Contents for Files instead of filtering Folder Path with SharePoint.Files",
    Category: "Best Practice",
    Description: "When importing files from SharePoint, use SharePoint.Contents instead of SharePoint.Files to improve performance and reliability. SharePoint.Contents provides a more efficient way to access files, especially for SharePoint sites with lots of files.",
    References: [
        {
            Description: "Improve File Import from SharePoint in Power BI and Power Query",
            Link: "https://www.thebiccountant.com/2020/11/16/improve-file-import-from-sharepoint-in-power-bi-and-power-query/"
        }
    ],
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] | null => {
        // Extract tokens and AST from input
        const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;

        const errorObjects: ErrorObject[] = [];

        // Find SharePoint.Files calls - these should be replaced with SharePoint.Contents
        const sharePointFilesFind: LexedJson[] = findIdentifiers(lexTokens, "SharePoint.Files") ?? [];

        // Only proceed if SharePoint.Files is found
        if (sharePointFilesFind.length > 0) {
            // Find Table.SelectRows and Table.TransformColumns calls
            const tblSelectRowsFind: LexedJson[] = findIdentifiers(lexTokens, "Table.SelectRows") ?? [];

            tblSelectRowsFind.forEach((element) => {
                // Prepare array for recursive search
                const tempArrayForTableSelect: any[] = [element];
                logDebug(`Text.SelectRows found: ${tblSelectRowsFind.length} instances`);

                // Check if the [Folder Path] column is referenced before Table.SelectRows
                const folderPathCheck = findNodesWithRecursiveExpression(tempArrayForTableSelect, aSTTokens, '"literal":"Folder Path');
                logDebug(`Folder Path found: ${folderPathCheck.length} instances before Table.SelectRows`);

                if (folderPathCheck.length > 0) {
                            // If either Extension or Text.Lower is missing, flag an error
                            errorObjects.push({
                                positionStart: element.positionStart,
                                positionEnd: element.positionEnd
                            });

                    }
                });
        }

        return errorObjects;
    }
};

export default useSharePointContentsForFiles