import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findIdentifiers, findNodesWithRecursiveExpression, logDebug } from "../rule-assistance";


// Define the rule object
export const useCoalesceForRecordFieldCount: PowerQueryRule = {
    ID: "use-coalesce-for-record-field-count", // Unique identifier for the rule
    Name: "For Record.FieldCount use Coalesce (??) to Avoid Loading Errors", // Rule name
    Category: "Potential Issue", // Rule category
    Description: "If a record is empty calling Record.FieldCount will return an error. Add Coalescing Operator (e.g., Record.FieldCount([Column] ?? []) ) to avoid loading errors.", // Rule description
    References: [
        {
            Description: "Chapter 6 - The Definitive Guide to Power Query (M)",
            Link: "https://amzn.to/43zc4ye"
        }
    ], // References for the rule
    Severity: SeverityLevel.Error, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Pro, // Minimum license level required to use the rule
    // The main check function for the rule
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) {
            return [];
        }
        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const aSTTokens: any = input.ast;
        const errorObjects: ErrorObject[] = [];

        // Find all instances of "Record.FieldCount"
        const instances: LexedJson[] = findIdentifiers(lexTokens, "Record.FieldCount") ?? [];

        logDebug(`Found ${instances.length} instance(s) of 'Record.FieldCount'.`);

        // Iterate over each instance of "Record.FieldCount"
        instances.forEach((instance) => {
            // Check if the instance is used with a null coalescing operator
            const tempArray : any[] = [];
            tempArray.push(instance);
            const coalesceUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens,'"kind":"NullCoalescingExpression"');

            if(coalesceUsage.length === 0) {
            const errorObject: ErrorObject = {
                    positionStart: instance.positionStart,
                    positionEnd: instance.positionEnd,
                };
                errorObjects.push(errorObject);
            }
        });

        // Return the collected error objects
        return errorObjects;
    }
};


export default useCoalesceForRecordFieldCount;