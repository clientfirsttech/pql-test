import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findIdentifiers } from "../rule-assistance";

// Define the rule object
export const noPowerBIDataflowsConnection: PowerQueryRule = {
    ID: "no-power-bi-dataflows-connection", // Unique identifier for the rule
    Name: "Avoid Using the Legacy PowerBI.Dataflows Connector", // Rule name
    Category: "Potential Issue", // Rule category
    Description: "Connecting to a Power BI Dataflows using PowerBI.Dataflows is a legacy connection and should be avoided (especially with Linked Entities). Switch to the newer connector PowerPlatform.Dataflows.", // Rule description
    References: [], // References for the rule
    Severity: SeverityLevel.Error, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Free, // Minimum license level required to use the rule
    // The main check function for the rule
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const lexTokens : LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        const instances = findIdentifiers(lexTokens, 'PowerBI.Dataflows') ?? [];
    
        instances.forEach(element => {
            const errorObject: ErrorObject = {
                positionStart: element.positionStart,
                positionEnd: element.positionEnd
            };
            errorObjects.push(errorObject);
        });


        return errorObjects;
    }
};

export default noPowerBIDataflowsConnection;