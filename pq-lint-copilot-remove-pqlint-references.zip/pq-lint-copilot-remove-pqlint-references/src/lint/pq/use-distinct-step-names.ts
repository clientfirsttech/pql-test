import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";

// Create a Rule object with the function as a string
export const useDistinctStepNames: PowerQueryRule = {
    ID: "use-distinct-step-names",
    Name: "Rename Similar Query Steps for Clarity",
    Category: "Best Practice",
    Description: "Rename Query Steps (not column renames, but the actual query steps names found in Applied Steps) to Provide Better Documentation - If several query steps (variables) end with the number 2 or greater, renaming the steps or consolidating the steps will increase for performance and maintainability. For example, if you add three custom columns in a table and the third step is called \"Added Custom Column3\", it can be confusing what column is being added.",
    References: [
        {
            Description: "Doing Power BI the Right Way: 4. Power Query design best practices",
            Link: "https://sqlserverbi.blog/2021/02/14/doing-power-bi-the-right-way-4-power-query-design-best-practices/"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Free,
    AIFixInstructions: {
        Description: "Rename Power Query steps to descriptive past-tense verb phrases",
        Prompt: `StepRenamer {
  Purpose: "Generate clear, descriptive names for Power Query steps that explain what was accomplished"
  
  Context {
    * Generic names like "Navigation1", "Added Custom3" are unclear
    * Descriptive names improve maintainability and understanding
    * Step names should explain business purpose, not implementation
    * Follow Power Query naming conventions
  }
  
  Constraints {
    * Maximum 50 characters
    * Start with past-tense verb
    * Use spaces between words
    * Format: #"Step Name" (with quotes and # prefix)
    * Must be unique within query
    * Describe what was accomplished, not how
    * Output valid M code only
  }
  
  Naming Pattern {
    format: [Past Tense Verb] + [Object] + [Optional Context]
    
    common verbs by operation {
      Source: Loaded, Retrieved, Fetched, Connected
      Filter: Filtered, Selected, Limited, Excluded
      Add: Added, Created, Calculated, Inserted
      Join: Merged, Joined, Combined
      Transform: Transformed, Converted, Modified, Updated
      Rename: Renamed, Relabeled
      Sort: Sorted, Ordered, Arranged
      Group: Grouped, Aggregated, Summarized
      Expand: Expanded, Unpacked, Flattened
    }
  }
  
  Process {
    for each step {
      1. Analyze operation performed
      2. Identify business purpose
      3. Generate: [Verb] + [What] + [Context if needed]
      4. Validate length <= 50 characters
      5. Ensure uniqueness (add context if needed)
      6. Format as #"Name With Spaces"
      7. Update all downstream references
    }
  }
  
  Examples {
    Before:
    Source = Excel.Workbook(...),
    Navigation1 = Source{[Item="Sales"]}[Data],
    #"Added Custom" = Table.AddColumn(Navigation1, "Total", each [Qty] * [Price]),
    #"Added Custom2" = Table.AddColumn(#"Added Custom", "Tax", each [Total] * 0.1),
    #"Filtered Rows" = Table.SelectRows(#"Added Custom2", each [Total] > 1000)
    
    After:
    #"Loaded Excel File" = Excel.Workbook(...),
    #"Retrieved Sales Sheet" = #"Loaded Excel File"{[Item="Sales"]}[Data],
    #"Calculated Line Total" = Table.AddColumn(#"Retrieved Sales Sheet", "Total", each [Qty] * [Price]),
    #"Calculated Sales Tax" = Table.AddColumn(#"Calculated Line Total", "Tax", each [Total] * 0.1),
    #"Filtered High Value Orders" = Table.SelectRows(#"Calculated Sales Tax", each [Total] > 1000)
  }
  
  Edge Cases {
    * Similar operations - differentiate with context (e.g., "Filtered Active Customers", "Filtered Recent Orders")
    * Source steps - be specific about what's loaded (e.g., "Loaded Customer CSV", "Connected to Sales Database")
    * Multiple transforms on same column - specify the transformation (e.g., "Trimmed Product Names", "Uppercased Status Codes")
  }
}`,
        IsActive: true,
        IsWholeQueryFix: true
    },
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const tokens: any = (input as ParseResult).ast;
        const aSTTokens: any = (input as ParseResult).ast;

        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        if (aSTTokens === null || aSTTokens === undefined) {
            return errorObjects; // Return empty array if aSTTokens is null or undefined
        }

        // if parameter ("MetadataExpression") is found, return empty array
        if (aSTTokens.kind === "MetadataExpression") return errorObjects

        const elements: any = tokens?.variableList?.elements as any;
        const literalLists: any[] = []; // Array to store the literal values
        if (elements !== undefined && elements !== null) {
            elements.forEach((element: any, index: any) => {
                const node = element?.node?.key // Fix: Access the 'value' property instead of 'key'
                literalLists.push(node); // Add the literal value to the array
            }); // end for each variable List

        }

        /**
         * Calculates the Levenshtein distance between two strings.
         * 
         * @param a - The first string.
         * @param b - The second string.
         * @returns The Levenshtein distance between the two strings.
         */
        function levenshteinDistance(a: string, b: string): number {
            const matrix = [];

            // Initialize the matrix
            for (let i = 0; i <= b.length; i++) {
                matrix[i] = [i];
            }
            for (let j = 0; j <= a.length; j++) {
                matrix[0][j] = j;
            }

            // Fill in the matrix
            for (let i = 1; i <= b.length; i++) {
                for (let j = 1; j <= a.length; j++) {
                    if (b.charAt(i - 1) === a.charAt(j - 1)) {
                        matrix[i][j] = matrix[i - 1][j - 1];
                    } else {
                        matrix[i][j] = Math.min(
                            matrix[i - 1][j - 1] + 1, // substitution
                            matrix[i][j - 1] + 1,     // insertion
                            matrix[i - 1][j] + 1      // deletion
                        );
                    }
                }
            }

            return matrix[b.length][a.length];
        }

        // Set to keep track of compared pairs
        const comparedPairs = new Set<string>();

        // Initialize a Set to track unique error object keys
        const uniqueErrorKeys = new Set<string>();

        // Compare each pair of literal values and calculate the Levenshtein distance
        for (let i = 0; i < literalLists.length; i++) {
            for (let j = i + 1; j < literalLists.length; j++) {
                const pairKey = `${i}-${j}`;
                const reversePairKey = `${j}-${i}`;
                if (!comparedPairs.has(pairKey) && !comparedPairs.has(reversePairKey)) {
                    comparedPairs.add(pairKey);
                    comparedPairs.add(reversePairKey);
                    try {
                        const distance = levenshteinDistance(literalLists[i].literal, literalLists[j].literal);

                        if (distance <= 1) {
                            //logDebug(`Levenshtein distance between "${literalLists[i].literal}" and "${literalLists[j].literal}" is ${distance}`);
                            // Create a unique key for the error object
                            const uniqueKey = `${literalLists[i].literal}`;

                            // Check if the key already exists
                            if (!uniqueErrorKeys.has(uniqueKey)) {
                                uniqueErrorKeys.add(uniqueKey); // Add the key to the Set

                                // Add the error object to the array
                                const errorObject: ErrorObject = {
                                    positionStart: literalLists[i].tokenRange?.positionStart,
                                    positionEnd: literalLists[i].tokenRange?.positionEnd
                                };
                                errorObjects.push(errorObject);
                            }
                        }

                    } catch (error) {
                        // do nothing
                    }
                }// end if
            }
        } // end for each literal list

        return errorObjects;
    }
};
export default useDistinctStepNames;