import {PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel} from "../rule-types";
import {ParseResult} from "../../parser/pq/parse-types";
import { findIdentifiers } from "../rule-assistance";
// Create a Rule object with the function as a string
export const useTableTransformColumnsForQueryFolding: PowerQueryRule = {
  ID: "use-table-transform-columns-for-query-folding",
  Name: "Avoid Breaking Query Folding with Table.TransformColumnTypes",
  Category: "Potential Issue",
  Description: "Detects use of Table.TransformColumnTypes after a database source, which likely breaks query folding. Use Table.TransformColumns instead to preserve query folding and improve performance.",
  References: [
    {
      Description: "Query Folding Safe Data Type Changes",
      Link: "https://pawarbi.github.io/blog/powerquery/m/queryfolding/2022/06/01/query-folding-data-types-changes-powerbi.html"
    }
  ],
  Severity: SeverityLevel.Error,
  MinLicenseLevel: LicenseLevel.Free,
  AIFixInstructions: {
    Description: "Replace Table.TransformColumnTypes with Table.TransformColumns to maintain query folding.",
    Prompt: `TableTransformColumnsFoldingFixer {
  Purpose: "Replace Table.TransformColumnTypes with Table.TransformColumns to preserve query folding after database sources"
  
  Context {
    * Table.TransformColumnTypes breaks query folding with database sources
    * Table.TransformColumns maintains folding and pushes type conversion to database
    * Query folding improves performance by reducing data transfer
    * Works with Sql.Database, Oracle.Database, CommonDataService.Database
  }
  
  Constraints {
    * Only modify Table.TransformColumnTypes calls after database source steps
    * Preserve all column names and target types
    * Use correct converter functions for each type
    * Output valid M syntax only, no explanatory text
    * Maintain step names and references
  }
  
  Type Mappings {
    Int64.Type or type number => Int64.From
    type text => Text.From
    type date => Date.From
    type datetime => DateTime.From
    type logical => Logical.From
    Currency.Type => Currency.From
  }
  
  Transformation {
    match: Table.TransformColumnTypes(source, {{"Col1", Int64.Type}, {"Col2", type text}})
    
    emit: Table.TransformColumns(source, {{"Col1", Int64.From, Int64.Type}, {"Col2", Text.From, type text}})
  }
  
  Process {
    1. Identify Table.TransformColumnTypes after database source
    2. Extract source reference and column transformation list
    3. For each column transformation:
       a. Keep column name
       b. Map type to converter function
       c. Keep original type
    4. Construct Table.TransformColumns call with format:
       Table.TransformColumns(source, {{"ColumnName", ConverterFn, type}})
    5. Replace old step with new step
    6. Update any references if step name changed
  }
  
  Examples {
    Before:
    #"Changed Types" = Table.TransformColumnTypes(Source, {{"OrderID", Int64.Type}, {"CustomerName", type text}, {"OrderDate", type date}})
    
    After:
    #"Changed Types" = Table.TransformColumns(Source, {{"OrderID", Int64.From, Int64.Type}, {"CustomerName", Text.From, type text}, {"OrderDate", Date.From, type date}})
  }
  
  Edge Cases {
    * Currency.Type - use Currency.From
    * Logical type - use Logical.From (not Text.From)
    * Custom types - preserve as-is and use appropriate converter
    * Multiple type changes - process all in single Table.TransformColumns
  }
}`,
    IsActive: true,
    IsWholeQueryFix: false
  },
  Check: (input: ParseResult | undefined): ErrorObject[] | null => {
    // Cast to LexedJson[] to access the properties
    const tokens : LexedJson[] = (input as ParseResult).lexed as LexedJson[];
    
    // Find the position of the SQL.Database call
    const sqlFind: LexedJson[] = findIdentifiers(tokens, "Sql.Database") ?? [];
    const sqlsFind: LexedJson[] = findIdentifiers(tokens, "Sql.Databases") ?? [];
    const dataverseFind: LexedJson[] = findIdentifiers(tokens, "CommonDataService.Database") ?? [];

      // Create error objects for each Table.TransformColumnTypes found after the database source
      const errorObjects: ErrorObject[] = [];

    // If neither SQL.Database nor CommonDataService.Database is found, return null
    if (sqlFind.length === 0 && sqlsFind.length === 0 && dataverseFind.length === 0) {
      return errorObjects;
    }else{
      // If SQL.Database or CommonDataService.Database is found, check for Table.TransformColumnTypes after it
      const folderableSource: LexedJson = sqlFind[0] || sqlsFind[0] || dataverseFind[0];
      // Find the position of the Table.TransformColumnTypes call
      const tableTransformColumnTypes = findIdentifiers(tokens, "Table.TransformColumnTypes") ?? [];
      const tableTransformColumns = findIdentifiers(tokens, "Table.TransformColumns") ?? [];
      if(tableTransformColumns.length > 0 && tableTransformColumnTypes.length > 0){
        if(tableTransformColumns[0].positionStart.lineNumber < tableTransformColumnTypes[0].positionStart.lineNumber){
          return errorObjects; // If Table.TransformColumns is found, assume code tried to apply query folding
        }
      }//end check

      // Create error objects for each Table.TransformColumnTypes found after the database source
      tableTransformColumnTypes.forEach(transformColumnType => {
        if (folderableSource.positionStart.lineNumber < transformColumnType.positionStart.lineNumber) {
          errorObjects.push({
            positionStart: transformColumnType.positionStart,
            positionEnd: transformColumnType.positionEnd
          });
        }
      });

      return errorObjects;
    }
  }
}

export default useTableTransformColumnsForQueryFolding;