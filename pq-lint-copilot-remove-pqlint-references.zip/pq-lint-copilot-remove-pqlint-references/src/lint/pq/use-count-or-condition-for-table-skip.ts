import { ParseResult } from "../../parser/pq/parse-types";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { findIdentifiers, findNodesWithRecursiveExpression} from "../rule-assistance";

// Create a Rule object
export const useCountOrConditionForTableSkip: PowerQueryRule = {
    ID: "use-count-or-condition-for-table-skip",
    Name: "Explicitly Set Count or Condition in Table.Skip Second Argument",
    Category: "Best Practice",
    Description: "Explicitly set Count or Condition for Table.Skip within second argument. This avoids ambiguity that one row is being removed.",
    References: [
        {
            Description: "Chapter 7 - The Ultimate Power Query Cookbook for Power BI and Excel",
            Link: "https://amzn.to/3H3EJUq"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const lexTokens : LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        const instances = findIdentifiers(lexTokens, 'Table.Skip') ?? [];
    
        instances.forEach(element => {
            const tempArray : any[] = [];
            tempArray.push(element);
            const conditionUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens,'"kind":"EachExpression"');
            const numericUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens,'"literalKind":"Numeric"');
            
            // Check to make sure the second argument is a number or condition
            if (conditionUsage.length === 0 && numericUsage.length === 0) {
                const errorObject: ErrorObject = {
                    positionStart: element.positionStart,
                    positionEnd: element.positionEnd
                };
                errorObjects.push(errorObject);
            }
        });


        return errorObjects;
    }
};

export default useCountOrConditionForTableSkip;