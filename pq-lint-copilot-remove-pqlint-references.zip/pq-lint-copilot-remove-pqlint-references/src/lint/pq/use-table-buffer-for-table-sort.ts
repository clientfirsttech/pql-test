import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findTableBufferPattern } from "../rule-assistance";

// Create a Rule object with the function as a string
export const useTableBufferForTableSort: PowerQueryRule = {
    ID: "use-table-buffer-for-table-sort",
    Name: "Use Table.Buffer Before Table.RemoveDuplicates to Preserve Sort Order",
    Category: "Potential Issue",
    Description: "Using Table.Sort prior Table.RemoveDuplicates can lead to unexpected results. Use Table.Buffer to retain sort order.",
    References: [
        {
            Description: "Potential Issue: Sorting and Removing Duplicates",
            Link: "https://youtu.be/1eIvrXmi4iM"
        },
        {
            Description: "Keep sorted table for Group By, using Table.Buffer",
            Link: "https://exceltown.com/en/tutorials/power-bi/power-query-m-language/keep-sorted-table-for-group-by-using-table-buffer/"
        }
    ],     
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Free,
    AIFixInstructions: {
        Description: "Add Table.Buffer step between Table.Sort and Table.Distinct",
        IsActive: true,
        IsWholeQueryFix: false,
        Prompt: `TableBufferForSortFixer {
  Purpose: "Insert a Table.Buffer step between Table.Sort and Table.Distinct to preserve sort order"

  Context {
    * Table.Sort does not guarantee row order is preserved through subsequent operations
    * Table.Distinct (Remove Duplicates) may discard the sorted order without buffering
    * Table.Buffer materializes the sorted table in memory, locking in the sort order
    * This is a known Power Query behavior that causes unexpected results
  }

  Constraints {
    * Do not remove or modify the existing Table.Sort or Table.Distinct steps
    * Preserve all existing step names, comments, and formatting
    * Output valid M code only, no explanatory text
    * Only add Table.Buffer; do not change any other logic
    * If Table.Buffer already exists between Table.Sort and Table.Distinct, make no changes
  }

  Process {
    1. Identify the step that contains Table.Sort
    2. Identify the step that contains Table.Distinct (Table.RemoveDuplicates)
    3. Find the step name referenced by the Table.Distinct step as its input
    4. Insert a new step that wraps that input with Table.Buffer
    5. Update the Table.Distinct step to reference the new Table.Buffer step
    6. Use a descriptive step name for the buffer step (e.g., #"Buffered Sorted Table")
  }

  Examples {
    Before:
    let
        Source = ...,
        #"Sorted Rows" = Table.Sort(Source, {{"Column1", Order.Ascending}}),
        #"Removed Duplicates" = Table.Distinct(#"Sorted Rows")
    in
        #"Removed Duplicates"

    After:
    let
        Source = ...,
        #"Sorted Rows" = Table.Sort(Source, {{"Column1", Order.Ascending}}),
        #"Buffered Sorted Table" = Table.Buffer(#"Sorted Rows"),
        #"Removed Duplicates" = Table.Distinct(#"Buffered Sorted Table")
    in
        #"Removed Duplicates"
  }

  Edge Cases {
    * Multiple Table.Sort/Table.Distinct pairs - buffer each sorted result before its corresponding Distinct
    * Steps between Sort and Distinct - insert Table.Buffer immediately before the Table.Distinct step
    * Table.Buffer already present between Sort and Distinct - skip, no changes needed
  }
}`
    },
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) return [];

        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const errorObjects: ErrorObject[] = [];

        // Find the index of the relevant identifiers in the lexed tokens
        const sortIndex = lexTokens.findIndex((item: LexedJson) => item.kind === 'Identifier' && item.data === 'Table.Sort');
        const removeDuplicatesIndex = lexTokens.findIndex((item: LexedJson) => item.kind === 'Identifier' && item.data === 'Table.Distinct');

        // Check if Table.Sort is used before Table.Group or Table.Distinct
        if ((sortIndex !== -1 && removeDuplicatesIndex !== -1) && sortIndex < removeDuplicatesIndex) {
            
            // Second Find Table.Buffer references
            const tblBuffer: LexedJson[] = findTableBufferPattern(lexTokens);
            // If no Table.Buffer is found, add an error object
            if(tblBuffer.length === 0){
                const errorObject: ErrorObject = {
                    positionStart: lexTokens[removeDuplicatesIndex].positionStart,
                    positionEnd: lexTokens[removeDuplicatesIndex].positionEnd
                };
                errorObjects.push(errorObject);
            }else{ // Check if Table.Buffer is used before Table.Distinct
                // Assume one instance exists before
                // Later we could check if multiple instances exist and if they are used appropriately
                if(tblBuffer[0].positionStart.lineNumber > lexTokens[removeDuplicatesIndex].positionStart.lineNumber){
                    const errorObject: ErrorObject = {
                        positionStart: lexTokens[removeDuplicatesIndex].positionStart,
                        positionEnd: lexTokens[removeDuplicatesIndex].positionEnd
                    };
                    errorObjects.push(errorObject);
                }
            }
        }

        return errorObjects;
    }
};

export default useTableBufferForTableSort;