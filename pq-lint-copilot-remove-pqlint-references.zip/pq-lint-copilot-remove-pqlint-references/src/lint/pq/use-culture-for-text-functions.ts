import { ParseResult } from "../../parser/pq/parse-types";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { findNodesWithRecursiveExpression, logDebug, checkCultureForFunctionInstances } from "../rule-assistance";
import * as fs from "fs";
import * as path from "path";

// Create a Rule object
export const useCultureForTextFunctions: PowerQueryRule = {
    ID: "use-culture-for-text-functions", // Unique identifier for the rule
    Name: "Define Culture parameter for Specific Text Functions", // Rule name
    Category: "Best Practice", // Rule category
    Description: "When a culture parameter is available, defining it is recommended (e.g., 'en-US'). That ensures your output is predictable regardless of the machine language of your users.", // Rule description
    References: [
        {
            Description: "Chapter 5 - The Definitive Guide to Power Query (M)",
            Link: "https://amzn.to/43zc4ye"
        }
    ],
    Severity: SeverityLevel.Warning, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Pro, // Minimum license level required to use the rule
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast the input to access its properties
        const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;

        // List of Text functions that support the culture parameter
        const textFunctions = ["Text.From", "Text.InferNumberType", "Text.Lower", "Text.Proper", "Text.Upper"];
        // 3rd agurment
        const thirdArgumentFunctions = ["Text.Format"];

        // Combine all date-related functions into one array
        const allTextFunctions = [
            ...textFunctions,
            ...thirdArgumentFunctions
        ];

        // Identify all instances of Date functions with culture parameter
        const instances = lexTokens.filter((current) => {
            return current.kind === "Identifier" && allTextFunctions.includes(current.data);
        });

        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = checkCultureForFunctionInstances(aSTTokens, instances, thirdArgumentFunctions);
        // Return all collected error objects
        return errorObjects;
    }
};

export default useCultureForTextFunctions