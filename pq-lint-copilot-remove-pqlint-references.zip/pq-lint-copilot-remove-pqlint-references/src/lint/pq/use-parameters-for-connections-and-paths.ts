import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { logDebug, RegexPatternsForConstants, findIdentifiers, findNodesWithRecursiveExpression, searchAST } from "../rule-assistance";
import { log } from "console";

export const useParametersForConnectionsAndPaths: PowerQueryRule = {
    ID: "use-parameters-for-connections-and-paths",
    Name: "Avoid Hardcoded File Paths, URLs, or Database References",
    Category: "Potential Issue",
    Description: "Hard coded local file paths, URLs, or database paths in text literals can lead to issues with portability and security. Consider using parameters instead.",
    References: [],
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Free,
    AIFixInstructions:{
        Description: "Extract hardcoded paths and connections to reusable parameters",
        Prompt: `HardcodedValueParameterizer {
  Purpose: "Create parameters for hardcoded file paths, URLs, and database references for reusability"
  
  Context {
    * Hardcoded paths prevent portability across environments
    * Parameters enable environment-specific configuration
    * Centralizes connection management
    * Facilitates deployment and testing
  }
  
  Constraints {
    * Preserve all query logic and results
    * Use descriptive PascalCase parameter names
    * Replace all instances of hardcoded value
    * Output complete executable query
    * Add proper meta properties to parameters
  }
  
  Detection Patterns {
    * File paths: ".xlsx", ".csv", ".txt", ".json", ".parquet"
    * UNC paths: "\\\\server\\share"
    * URLs: "http://", "https://"
    * Database servers: ".database.windows.net", ".database.net"
    * Local paths: "C:\\", "D:\\"
  }
  
  Parameter Syntax {
    template: [ParameterName] = "value" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]
    
    naming {
      * Use PascalCase: SourceFilePath, DatabaseServer, ApiEndpoint
      * Be descriptive and specific
      * Avoid abbreviations
      * Max 50 characters
      * Only letters, numbers, underscores
    }
  }
  
  Process {
    1. Scan query for hardcoded values matching detection patterns
    2. For each unique hardcoded value:
       a. Determine context (file path, URL, database, etc.)
       b. Generate descriptive parameter name from context
       c. Create parameter definition with meta properties
       d. Place parameter at start of query
    3. Replace all instances of hardcoded value with parameter reference
    4. Maintain let...in structure
    5. Verify syntax validity
  }
  
  Examples {
    Before:
    let
        Source = Excel.Workbook(File.Contents("C:\\Data\\Sales.xlsx"), null, true),
        Data = Source{[Item="Sheet1",Kind="Sheet"]}[Data]
    in
        Data
    
    After:
    let
        SourceFilePath = "C:\\Data\\Sales.xlsx" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true],
        Source = Excel.Workbook(File.Contents(SourceFilePath), null, true),
        Data = Source{[Item="Sheet1",Kind="Sheet"]}[Data]
    in
        Data
    
    ---
    
    Before:
    Source = Sql.Database("server.database.windows.net", "SalesDB")
    
    After:
    let
        DatabaseServer = "server.database.windows.net" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true],
        DatabaseName = "SalesDB" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true],
        Source = Sql.Database(DatabaseServer, DatabaseName)
    in
        Source
  }
  
  Edge Cases {
    * Multiple hardcoded values - create parameter for each
    * Same value used multiple times - single parameter referenced multiple times
    * Documentation strings - do not parameterize
    * Already parameterized - skip
  }
}`,
        IsActive: true,
        IsWholeQueryFix: false
    },    
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) return [];

        // Cast to access the properties
        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const aSTTokens: any = input.ast;

        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        if (aSTTokens === null || aSTTokens === undefined) {
            return errorObjects; // Return empty array if aSTTokens is null or undefined
        }

        // If parameter ("MetadataExpression") is found, return an empty array
        if (aSTTokens.kind === "MetadataExpression") return errorObjects;

        // Define regex patterns for local file paths, URLs, and database paths
        const localFilePathRegex = RegexPatternsForConstants.localFilePath;
        const urlRegex = RegexPatternsForConstants.url;
        const databaseRegex = RegexPatternsForConstants.databasePath;

        // Initialize a Set to track processed line numbers
        const processedLineNumbers = new Set<number>();

        const textLiteralArray: any[] = [];


        // Filter out tokens of kind "TextLiteral"
        const textLiteralTokens = lexTokens.filter((token) => token.kind === "TextLiteral");

        // Iterate over the filtered tokens to find matches
        lexTokens.forEach((current, index) => {
            if (current.kind === "TextLiteral") {

                let priorTokenDocumentationRelated = false;

                if (index - 2 > 0) {// Handle documentation scenario

                    if (lexTokens[index - 2].kind === "Identifier" && lexTokens[index - 2].data.startsWith("Documentation.")) {
                        priorTokenDocumentationRelated = true;
                    }
                }

                logDebug("Current Token:", current.data);

                if ((localFilePathRegex.test(current.data) || urlRegex.test(current.data)) && priorTokenDocumentationRelated === false) {
                    logDebug("Matched Token:", current.data);

                    // Check if the line number has already been processed
                    if (!processedLineNumbers.has(current.positionStart.lineNumber)) {
                        processedLineNumbers.add(current.positionStart.lineNumber);

                        // Create an error object with the line number of the matched token
                        const errorObject: ErrorObject = {
                            positionStart: current.positionStart,
                            positionEnd: current.positionEnd,
                        };
                        errorObjects.push(errorObject);
                    }
                }
            }//end if
        });

        // Note: I commented out databases that function calls didn't identify a server for the first argument
        // Define the database identifiers to check for
        const databaseIdentifiers = [
            //"GoogleBigQuery.Database",
            //"GoogleBigQueryAad.Database",
            "AzureHiveLLAP.Database",
            "ApacheHiveLLAP.Database",
            "Impala.Database",
            "Kusto.Databases",
            "AzureDataExplorer.Databases",
            "AzureDataExplorer.KqlDatabase",
            "Netezza.Database",
            "AmazonRedshift.Database",
            "Snowflake.Databases",
            "Vertica.Database",
            //"AmazonAthena.Databases",
            "ClickHouse.Database",
            "CommonDataService.Database",
            "DataVirtuality.Database",
            "Dremio.Databases",
            //"DremioCloud.Databases",
            "Exasol.Database",
            "Indexima.Database",
            "IntersystemsHealthInsight.Database",
            "IRIS.Database",
            "JethroODBC.Database",
            "Kyligence.Database",
            "KyvosODBC.Databases",
            "SingleStoreODBC.Database",
            "TeamDesk.Database",
            //"Access.Database",
            "AnalysisServices.Databases",
            "AnalysisServices.Database",
            "Informix.Database",
            "DB2.Database",
            "MySQL.Database",
            "Oracle.Database",
            "PostgreSQL.Database",
            "SapHana.Database",
            "Sql.Database",
            "Sql.Databases",
            "Sybase.Database",
            "Teradata.Database",
            // Added 10/1/2025
            "Databricks.Catalogs",
            "DatabricksMultiCloud.Catalogs",
            // Added 10/3/2025
            "Foundry.Contents"
        ];

        databaseIdentifiers.forEach((identifier) => {
            const matches: LexedJson[] = findIdentifiers(lexTokens, identifier) ?? [];

            matches.forEach((match) => {
                logDebug(`Matched Database Identifier: ${identifier}`, JSON.stringify(match));

                // Check for associated TextLiteral usage
                const searchString = '"positionStart":'+JSON.stringify(match.positionStart,null,0)+',"positionEnd":'+JSON.stringify(match.positionEnd,null,0);
                let searchResults: {path: string; match: any}[] = searchAST(aSTTokens, "", searchString);
                const literalUsage = searchAST(aSTTokens, "", searchString);

                logDebug("Literal Usage:", JSON.stringify(literalUsage[0]));
                literalUsage.forEach((literal) => {
                    logDebug("Matched Database Literal:", literal);
                    // Get first arugment in the function call
                    const literalCheck = literal.match.recursiveExpressions?.elements[0]?.content?.elements[0]?.node?.literal
                    logDebug("Literal Check:", literalCheck);
                    // Check if the line number has already been processed
                    if (literalCheck !== '' && databaseRegex.test(literalCheck)) {
                        // Create an error object for the matched literal
                        const errorObject: ErrorObject = {
                            positionStart: match.positionStart,
                            positionEnd: match.positionEnd,
                        };
                        errorObjects.push(errorObject);
                    }
                });
            });
        });

        // Return all error objects
        return errorObjects;
    }
};

export default useParametersForConnectionsAndPaths;