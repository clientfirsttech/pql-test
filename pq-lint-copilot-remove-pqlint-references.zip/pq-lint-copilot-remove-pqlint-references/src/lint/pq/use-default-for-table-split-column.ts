import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findNodesWithRecursiveExpression, findIdentifiers } from "../rule-assistance";

// Define the rule object
export const useDefaultForTableSplitColumn: PowerQueryRule = {
    ID: "use-default-for-table-split-column", // Unique identifier for the rule
    Name: "Use the 'Default' Parameter in Table.SplitColumn for Best Practice", // Rule name
    Category: "Best Practice", // Rule category
    Description: "For Table.SplitColumn it is a best practice to use the 'Default' parameter. A default value allows you to identify cells where the split does not provide data for a specific column.", // Rule description
    References: [
        {
            Description: "Best Practice: Use Default Parameter with Table.SplitColumn",
            Link: "https://youtu.be/cO2lk5MWhtQ"
        },
        {
            Description:"Chapter 9 - The Ultimate Power Query Cookbook for Power BI and Excel",
            Link: "https://amzn.to/3H3EJUq"
        }
    ],     
    Severity: SeverityLevel.Warning, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Free, // Minimum license level required to use the rule
    // The main check function for the rule
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const lexTokens : LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];
        const elements : any = aSTTokens?.variableList?.elements as any;

        if(elements === undefined){
            return errorObjects;
        }
    
        elements.forEach((element: { node: { value: any; }; }, index: any) => {
            const node = element?.node?.value;
            // Check if the current element is a Table.SplitColumn call
            if (node?.head?.identifier.literal === "Table.SplitColumn"){
                // Check if the 5th argument exists
                const fifthArg = node?.recursiveExpressions?.elements?.[0].content?.elements?.[4]?.attributeIndex;
               
                const hasFifthArgument = fifthArg === 4 ? true : false;

                if (!hasFifthArgument) {
                    // Create an error object with the line number of the matched token
                    const errorObject: ErrorObject = {
                        positionStart: node?.head?.identifier?.tokenRange?.positionStart,
                        positionEnd: node?.head?.identifier?.tokenRange?.positionEnd,
                    };
                    errorObjects.push(errorObject);                    
                } // end if
            }
        }); // end for each variable List

        return errorObjects;
    }
};

export default useDefaultForTableSplitColumn;