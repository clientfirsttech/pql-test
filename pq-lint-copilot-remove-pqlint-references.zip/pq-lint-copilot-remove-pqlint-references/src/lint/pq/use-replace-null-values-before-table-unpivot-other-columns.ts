import { ParseResult } from "../../parser/pq/parse-types";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { logDebug, searchAST } from "../rule-assistance";

// Create a Rule object to enforce replacing null values before unpivoting columns
export const useReplaceNullValuesBeforeTableUnpivotOtherColumns: PowerQueryRule = {
    ID: "use-replace-null-values-before-table-unpivot-other-columns", // Unique identifier for the rule
    Name: "Use Replace Null Values Before Table Unpivot to Avoid Rows Being Removed", // Rule name
    Category: "Potential Issue", // Rule category
    Description: "The result of an unpivot operation is that each column becomes a row, but all the null values will be gone. It's best to use a placeholder (e.g., |_NULL_|) for replacing null values before the unpivot operation. You can then replace that placeholder after the unpivot operation.", // Rule description
    References: [
        {
            Description: "Potential Issue: Unpivot Columns & Null Values in Power Query",
            Link: "https://youtu.be/pHx3tieoCyM"
        },
        {
            Description: "Unpivot Columns And Keep Null Values in Power Query", // Reference description
            Link: "https://gorilla.bi/power-query/unpivot-and-keep-null-values/" // Reference link
        }
    ],
    Severity: SeverityLevel.Error, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Pro, // Minimum license level required to use the rule
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast the input to access its properties
        const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;

        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // Identify all instances of "Table.UnpivotOtherColumns" in the lexical tokens
        const instances = lexTokens.filter((current) => {
            return current.kind === "Identifier" && current.data === "Table.UnpivotOtherColumns";
        });

        // Iterate over each instance of "Table.UnpivotOtherColumns"
        instances.forEach(element => {
            // Find all instances of "Table.ReplaceValue" that occur before the current "Table.UnpivotOtherColumns"
            const replaceValuesInstances = lexTokens.filter((current) => {
                return current.kind === "Identifier" && current.data === "Table.ReplaceValue" && current.positionStart.lineNumber < element.positionStart.lineNumber;
            });
            logDebug("Replace Values Instances", replaceValuesInstances);

            // Default to false, indicating no valid "Table.ReplaceValue" instance found
            let foundReplaceNullInstances = false;

            // Check each "Table.ReplaceValue" instance for replacing null values
            replaceValuesInstances.forEach((replaceValueElement) => {
                // Construct a search string to locate the corresponding AST node
                const searchString = '"positionStart":' + JSON.stringify(replaceValueElement.positionStart, null, 0) + ',"positionEnd":' + JSON.stringify(replaceValueElement.positionEnd, null, 0);
                let searchResults: { path: string; match: any }[] = searchAST(aSTTokens, "", searchString);

                logDebug("Replace Value Search Results", searchResults);

                if (searchResults.length > 0) {
                    // Check if the second argument of "Table.ReplaceValue" is null
                    const nullCheck = searchResults[0].match.recursiveExpressions?.elements?.[0].content?.elements?.[1]?.node?.literal;
                    const nullLiteralKindCheck = searchResults[0].match.recursiveExpressions?.elements?.[0].content?.elements?.[1]?.node?.literalKind;

                    logDebug("Null Check", nullCheck);
                    logDebug("Null Literal Kind Check", nullLiteralKindCheck);

                    // If the second argument is null, mark as valid
                    if (nullCheck === "null" && nullLiteralKindCheck === "Null") {
                        foundReplaceNullInstances = true;
                    }
                }
            });

            // If no valid "Table.ReplaceValue" instance is found before "Table.UnpivotOtherColumns", add an error object
            if (foundReplaceNullInstances === false) {
                const errorObject: ErrorObject = {
                    positionStart: element.positionStart, // Start position of the error
                    positionEnd: element.positionEnd // End position of the error
                };
                errorObjects.push(errorObject); // Add the error object to the array
            }
        });

        // Return all collected error objects
        return errorObjects;
    }
};

export default useReplaceNullValuesBeforeTableUnpivotOtherColumns;