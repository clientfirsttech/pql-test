import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findIdentifiers, findNodesWithRecursiveExpression } from "../rule-assistance";

// Create a Rule object
export const useDayTypeForWeekTransformations: PowerQueryRule = {
    ID: "use-day-type-for-week-transformations",
    Name: "Use Day.Type in Week Transformation Functions for Culture Safety",
    Category: "Best Practice",
    Description: "For Week Transformation functions, use Day.Type for firstDayOfWeek parameter. This avoids ambiguity or use of culture-dependent settings for firstDayOfWeek.",
    References: [
        {
            Description: "Chapter 7 - The Ultimate Power Query Cookbook for Power BI and Excel",
            Link: "https://amzn.to/3H3EJUq"
        }
    ],    
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,    
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) return [];

        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;        
        const errorObjects: ErrorObject[] = [];
        
        // List of week functions to check
        const weekFunctions = [
            "Date.WeekOfYear",
            "Date.WeekOfMonth",
            "Date.StartOfWeek",
            "Date.EndOfWeek",
            "Date.DayOfWeek"
        ];
        
        // Combine results from findIdentifiers for all week functions
        const weekFunctionInstances = weekFunctions.flatMap(func => findIdentifiers(lexTokens, func) ?? []);

        weekFunctionInstances.forEach(instance => {
            const searchString = '"positionStart":' + JSON.stringify(instance.positionStart, null, 0) + ',"positionEnd":' + JSON.stringify(instance.positionEnd, null, 0);

            const tempArray : any[] = [];
            tempArray.push(instance);
            const dayUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens,'"literal":"Day.');

            // Check to make sure that the API version is 14
            if (dayUsage.length === 0) {
                const errorObject: ErrorObject = {
                    positionStart: instance.positionStart,
                    positionEnd: instance.positionEnd
                };
                errorObjects.push(errorObject);
            }            
        });

        return errorObjects;
    }
};

export default useDayTypeForWeekTransformations;