import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findFunctionExpressions, extractParameters, logDebug } from "../rule-assistance";
import { log } from "console";

// Define the rule object for checking explicit return types in Power Query functions
export const noTypeForParameterForFunction: PowerQueryRule = {
    ID: "no-type-for-parameter-for-function", // Unique identifier for the rule
    Name: "Specify Parameter Types in Function Definitions", // Rule name
    Category: "Potential Issue", // Rule category
    Description: "A type should be identified each parameter of the function. Explicit types do make it visually more clear what type is used and avoids typing errors within the function.", // Rule description
    References: [
        {
            Description: "Chapter 9 - The Definitive Guide to Power Query (M)",
            Link: "https://amzn.to/43zc4ye"
        }
    ], // References for the rule
    Severity: SeverityLevel.Error, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Free, // Minimum license level required to use the rule
    // The main check function for the rule
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast the input to access AST tokens
        const aSTTokens: any = (input as ParseResult).ast;

        // Use the helper function to find all function expressions in the AST
        const functionIdentifiers: any = findFunctionExpressions(aSTTokens);

        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        const functionsIdentified: any = findFunctionExpressions(aSTTokens);

        let results: any[] = [];
        functionIdentifiers.forEach((element: any) => {
            logDebug("Function Identifier: ", element);
            let parameters: any = extractParameters(element);
            logDebug("Parameters: ", parameters);
            results.push(parameters);
        });

        //Flatten array
        results = results.flat();

        // Iterate though each make sure type is not unknown
        results.forEach((parameter: any) => {
            if(parameter.type === 'unknown'){
                errorObjects.push({
                    positionStart: parameter?.positionStart, // Start position of the error
                    positionEnd: parameter?.positionEnd, // End position of the error
                });
            }
        });
        
        // Return the collected error objects
        return errorObjects;
    }
};

export default noTypeForParameterForFunction;