import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findIdentifiers, logDebug, findNodesWithRecursiveExpression } from "../rule-assistance";

// Define the rule object
export const useRecordFieldOrDefaultForFieldSelection: PowerQueryRule = {
    ID: "use-record-field-or-default-for-field-selection", // Unique identifier for the rule
    Name: "Use Record.FieldOrDefault to Avoid Loading Errors", // Rule name
    Category: "Potential Issue", // Rule category
    Description: "Record.Field can lead to loading errors if the field does not exist in the record.  Use Record.FieldOrDefault to avoid loading issues.", // Rule description
    References: [
        {
            Description: "Potential Issue: Using Record.Field can lead to Cell-Level Errors",
            Link: "https://youtu.be/Lqb0c3574Rc"
        },
        {
            Description: "Chapter 6 - The Definitive Guide to Power Query (M)",
            Link: "https://amzn.to/43zc4ye"
        }
    ], // References for the rule
    Severity: SeverityLevel.Error, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Pro, // Minimum license level required to use the rule
    // The main check function for the rule
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) {
            return [];
        }
        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const astTokens: any = input.ast;
        const errorObjects: ErrorObject[] = [];

        // Find all instances of "Record.Field"
        const instances: LexedJson[] = findIdentifiers(lexTokens, "Record.Field") ?? [];

        logDebug(`Found ${instances.length} instance(s) of 'Record.Field'.`);

        // Iterate over each instance of "Record.Field"
        instances.forEach((instance) => {
            const errorObject: ErrorObject = {
                    positionStart: instance.positionStart,
                    positionEnd: instance.positionEnd,
                };
                errorObjects.push(errorObject);
        });

        // Return the collected error objects
        return errorObjects;
    }
};

export default useRecordFieldOrDefaultForFieldSelection;