import { ParseResult } from "../../parser/pq/parse-types";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { checkCultureForFunctionInstances } from "../rule-assistance";

// Create a Rule object
export const useCultureForNumericFunctions: PowerQueryRule = {
    ID: "use-culture-for-numeric-functions", // Unique identifier for the rule
    Name: "Define Culture parameter for Specific Numeric Functions", // Rule name
    Category: "Best Practice", // Rule category
    Description: "When a culture parameter is available, defining it is recommended (e.g., 'en-US'). That ensures your output is predictable regardless of the machine language of your users.", // Rule description
    References: [
        {
            Description: "Chapter 5 - The Definitive Guide to Power Query (M)",
            Link: "https://amzn.to/43zc4ye"
        }
    ],
    Severity: SeverityLevel.Warning, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Pro, // Minimum license level required to use the rule
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast the input to access its properties
        const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;

        // List of Numeric functions that support the culture parameter
        const numericFunctions = [
            "Currency.From", "Decimal.From", "Double.From", "Int16.From", "Int32.From",
            "Int64.From", "Int8.From", "Number.From", "Number.FromText", "Percentage.From", "Single.From"
        ];

        // Functions that use the culture parameter as the third argument
        const thirdArgumentFunctions = ["Number.ToText"];

        // Combine all numeric-related functions into one array
        const allNumericFunctions = [
            ...numericFunctions,
            ...thirdArgumentFunctions
        ];

        // Identify all instances of Numeric functions with culture parameter
        const instances = lexTokens.filter((current) => {
            return current.kind === "Identifier" && allNumericFunctions.includes(current.data);
        });

        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = checkCultureForFunctionInstances(aSTTokens, instances, thirdArgumentFunctions);

        return errorObjects;
    }
};

export default useCultureForNumericFunctions;