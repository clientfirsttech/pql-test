import { ParseResult } from "../../parser/pq/parse-types";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { findIdentifiers, findNodesWithRecursiveExpression} from "../rule-assistance";

// Create a Rule object with the function as a string
export const requireCreateNavigationPropertiesBeSetToFalseInSQL: PowerQueryRule = {
    ID: "require-create-navigation-properties-be-set-false-in-sql",
    Name: "Disable CreateNavigationProperties to Improve Performance (Especially with DirectQuery)",
    Category: "Best Practice",
    Description: "By default 'Include relationship columns' is included with SQL. This can bring more columns over than necessary and affect performance (especially with Direct Query). If intended, set CreateNavigationProperties to true. If bringing over those columns aren't intended, uncheck 'Include relationship columns' in the Source step.",
    References: [
        {
            Description: "Overhead Of Getting Relationship Columns In Power BI DirectQuery Mode",
            Link: "https://blog.crossjoin.co.uk/2024/03/10/overhead-of-getting-relationship-columns-in-power-bi-directquery-mode"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    AIFixInstructions: {
        Description: "Set CreateNavigationProperties to false in SQL.Database or SQL.Databases calls to improve performance.",
        Prompt: "Modify the M code to include CreateNavigationProperties set to false in the options record of SQL.Database or SQL.Databases calls. For example, change Sql.Database(\"ServerName\", \"DatabaseName\") to Sql.Database(\"ServerName\", \"DatabaseName\", [CreateNavigationProperties = false])",
        IsActive: true,
        IsWholeQueryFix: false
    },
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const lexTokens : LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // Find the position of the SQL.Database call
        const sqlFind: LexedJson[] = findIdentifiers(lexTokens, "Sql.Database") ?? [];
        const sqlsFind: LexedJson[] = findIdentifiers(lexTokens, "Sql.Databases") ?? [];

        // Combine SQL.Database and SQL.Databases into a single array
        const instances: LexedJson[] = [
            ...findIdentifiers(lexTokens, "Sql.Database") ?? [],
            ...findIdentifiers(lexTokens, "Sql.Databases") ?? []
        ];

        instances.forEach(element => {
            const tempArray : any[] = [];
            tempArray.push(element);
            const createNavUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens,'"literal":"CreateNavigationProperties"');

            // If not used then add to error objects
            if (createNavUsage.length == 0) {
                const errorObject: ErrorObject = {
                    positionStart: element.positionStart,
                    positionEnd: element.positionEnd
                };
                errorObjects.push(errorObject);
            }
        });


        return errorObjects;
    }
};

export default requireCreateNavigationPropertiesBeSetToFalseInSQL;