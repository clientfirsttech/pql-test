import { ParseResult } from "../../parser/pq/parse-types";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { findIdentifiers, findNodesWithPairedExpression} from "../rule-assistance";

// Create a Rule object with the function as a string
export const noPlainTextClientSecretForWebContents: PowerQueryRule = {
    ID: "no-plain-text-client-secret-for-web-contents",
    Name: "Avoid Using Bearer Tokens Directly in Web.Contents Headers",
    Category: "Potential Issue",
    Description: "Web.Contents() having a Bearer token in the Headers could be a security issue since it's likely a hardcoded client secret is used to get this token. Consider using a more secure method, such as a customer connector, to handle sensitive information.",
    References: [],
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast to access the properties
        const lexTokens : LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        const instances = findIdentifiers(lexTokens, 'Web.Contents') ?? [];
        const headersInstances = findIdentifiers(lexTokens, 'Headers') ?? [];

        if(instances.length == 0) return errorObjects; // No Web.Contents found

        headersInstances.forEach(element => {
            const tempArray : any[] = [];
            tempArray.push(element);

            // Check if the Authorization header is present with #
            const authorizationResults = findNodesWithPairedExpression(tempArray, aSTTokens, '"literal":"#\\\"Authorization');
            // Check if the Authorization header is present without #
            const authorizationResults2 = findNodesWithPairedExpression(tempArray, aSTTokens, '"literal":"Authorization"');
            const bearerResults = findNodesWithPairedExpression(tempArray, aSTTokens, '"literal":"\\\"Bearer ');

            if ((authorizationResults.length > 0 || authorizationResults2.length > 0) && bearerResults.length > 0) {
                const errorObject: ErrorObject = {
                    positionStart: element.positionStart,
                    positionEnd: element.positionEnd
                };
                errorObjects.push(errorObject);
            }
        });


        return errorObjects;
    }
};

export default noPlainTextClientSecretForWebContents;