import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { logDebug, findFunctionCallsInAST, findParametersInASTForFunctionCall } from "../rule-assistance";

// Define the rule object
export const useNewColumnNameForTableDuplicateColumn: PowerQueryRule = {
    ID: "use-new-column-name-for-table-duplicate-column",
    Name: "Rename Duplicated Column in Same Step for Clarity",
    Category: "Best Practice",
    Description: "After duplicating a column, a rename step was called for that new column. This can be accomplished in the duplicate column step.",
    References: [
        {
            Description:"Best Practice: Using New Column Name in Table.DuplicateColumn",
            Link: "https://youtu.be/LNCpoobKq08"
        },
        {
            Description:"Chapter 9 - The Ultimate Power Query Cookbook for Power BI and Excel",
            Link: "https://amzn.to/3H3EJUq"
        }
    ],     
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;
        const errorObjects: ErrorObject[] = [];

        const functionCalls: any[] = findFunctionCallsInAST(aSTTokens);

        const duplicateCalls = functionCalls.filter((call) => {
            return call?.literal === "Table.DuplicateColumn";
        });

        duplicateCalls.forEach(element => {
            logDebug("Duplicate Call Element:", element);

            const parameters: any[] = findParametersInASTForFunctionCall(element, aSTTokens);
            logDebug("Parameters:", parameters);

            if (parameters.length >= 3) {
                const newColumName = parameters[2].literal;
                logDebug("New Column Name:", newColumName);

                const newColumnSearch = newColumName.replace(/"/g, '\\"');
                const functionCallIndex = functionCalls.findIndex((item) => {
                    return item.tokenRange.positionStart.codeUnit === element.tokenRange.positionStart.codeUnit &&
                        item.tokenRange.positionStart.lineNumber === element.tokenRange.positionStart.lineNumber;
                });
                logDebug("Function Call Index:", functionCallIndex);

                const functionCallChecks: any[] = [];
                if (functionCallIndex > 0) {
                    let index = functionCallIndex + 1;
                    while (index <= functionCalls.length) {
                        if (functionCalls[index]?.literal === "Table.RenameColumns") {
                            functionCallChecks.push(functionCalls[index]);
                        }
                        index++;
                    }
                }
                logDebug("Function Call Checks:", functionCallChecks);

                functionCallChecks.forEach((nextFunctionCall) => {
                    logDebug("Next Function Call:", nextFunctionCall);

                    if (nextFunctionCall?.literal === "Table.RenameColumns") {
                        const renameParameters = findParametersInASTForFunctionCall(nextFunctionCall, aSTTokens);
                        logDebug("Rename Parameters:", renameParameters);

                        if (renameParameters.length > 0) {
                            for (let i = 0; i < renameParameters[1]?.content?.elements.length; i++) {
                                if (JSON.stringify(renameParameters[1]?.content?.elements[i]?.node).includes('"literal":"' + newColumnSearch + '"')) {
                                    const errorObject: ErrorObject = {
                                        positionStart: renameParameters[1].tokenRange.positionStart,
                                        positionEnd: renameParameters[1].tokenRange.positionEnd,
                                    };
                                    errorObjects.push(errorObject);
                                    return errorObjects;
                                }
                            }
                        }
                    }
                });
            }
        });

        return errorObjects;
    }
};

export default useNewColumnNameForTableDuplicateColumn;