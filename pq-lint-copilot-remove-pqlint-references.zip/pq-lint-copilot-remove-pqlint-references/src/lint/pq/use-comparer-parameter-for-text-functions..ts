import { ParseResult } from "../../parser/pq/parse-types";
import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { findNodesWithRecursiveExpression, logDebug } from "../rule-assistance";
import { log } from "console";

// Create a Rule object
export const useComparerParameterTextFunctions: PowerQueryRule = {
    ID: "use-comparer-parameter-for-text-functions", // Unique identifier for the rule
    Name: "Define Comparer for Specific Text Functions", // Rule name
    Category: "Best Practice", // Rule category
    Description: "Power Query is case sensitive, so it's a best practice to be explicit on certain text functions to identify the setting (e.g., Comparer.OrdinalIgnoreCase) so you can understand how the function should behave regarding case sensitivity.", // Rule description
    References: [
        {
            Description: "Chapter 11 - The Definitive Guide to Power Query (M)",
            Link: "https://amzn.to/43zc4ye"
        }
    ],
    Severity: SeverityLevel.Warning, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Pro, // Minimum license level required to use the rule
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        // Cast the input to access its properties
        const lexTokens: LexedJson[] = (input as ParseResult).lexed as LexedJson[];
        const aSTTokens: any = (input as ParseResult).ast;

        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];
        // List of Text functions that support the comparer parameter
        const textFunctions = ["Text.StartsWith", "Text.EndsWith", "Text.Contains"];
        // 4th agurment
        const fouthArgumentFunctions = ["Text.PositionOf"];

        // Combine all date-related functions into one array
        const allTextFunctions = [
            ...textFunctions,
            ...fouthArgumentFunctions
        ];

        // Identify all instances of Date functions with comparer parameter
        const instances = lexTokens.filter((current) => {
            return current.kind === "Identifier" && allTextFunctions.includes(current.data);
        });

        // Iterate over each instance
        instances.forEach(element => {
            const tempArray: any[] = [];
            tempArray.push(element);
            logDebug("Element: ", element);

            const exprs = findNodesWithRecursiveExpression(tempArray, aSTTokens, "node")

            if (exprs.length > 0) {
                // Get the last expression in the array to check for the comparer parameter
                const node = exprs[exprs.length - 1];
                logDebug("Exprs: ", exprs[exprs.length - 1]);

                    if (fouthArgumentFunctions.includes(element.data) === false) {// check for comparer in the second argument
                        // Test two known paths to get the comparer parameter
                        const test1 = node?.recursiveExpressions?.elements[0]?.content?.elements[2]?.node?.identifier?.literal;
                        const test2 = node?.recursiveExpressions?.elements[0]?.content?.elements[2]?.node.literal;
                        const test3 = node?.head?.identifier?.literal;
                        const comparerRecordUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens, "literal:'Comparer.'");
                        logDebug("Node: ", node);
                        logDebug("Test 1", test1);
                        logDebug("Test 2", test2);
                        logDebug("Test 3", test3);

                        // Check if the comparer parameter is found, and if not, add an error object
                        if (test1 == undefined && test2 == undefined && !test3.startsWith("Comparer.") && comparerRecordUsage.length === 0) {
                            const errorObject: ErrorObject = {
                                positionStart: element.positionStart,
                                positionEnd: element.positionEnd
                            };
                            errorObjects.push(errorObject);
                        }
                    } else {// check for comparer in the fourth argument
                        // Test two known paths to get the comparer parameter
                        const test1 = node?.recursiveExpressions?.elements[0]?.content?.elements[3]?.node?.identifier?.literal;
                        const test2 = node?.recursiveExpressions?.elements[0]?.content?.elements[3]?.node.literal;
                        const test3 = node?.head?.identifier?.literal
                        const comparerRecordUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens, "literal:'Comparer.'");

                        logDebug("Node: ", node);
                        logDebug("Test 1", test1);
                        logDebug("Test 2", test2);
                        logDebug("Test 3", comparerRecordUsage.length);

                        // Check if the comparer parameter is found, and if not, add an error object
                        if (test1 == undefined && test2 == undefined && !test3.startsWith("Comparer.") && comparerRecordUsage.length === 0) {
                            const errorObject: ErrorObject = {
                                positionStart: element.positionStart,
                                positionEnd: element.positionEnd
                            };
                            errorObjects.push(errorObject);
                        }
                    }
            } // end if


        });

        // Return all collected error objects
        return errorObjects;
    }
};

export default useComparerParameterTextFunctions;