import { PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { containsTokenSequence, findIdentifiers } from "../rule-assistance";

// Create a Rule object
export const useCustomConnectorForExchangeRecurringCalendarEvents: PowerQueryRule = {
    ID: "use-custom-connector-for-exchange-recurring-calendar-events",
    Name: "The Exchange.Contents connectors does not support analytics for recurring calendar events.",
    Category: "Best Practice",
    Description: "Consider using a custom connector instead of the Exchange.Contents connector. Details on recurring calendar events (e.g., consistent time zone information) are not available.",
    References: [
        {
            Description:"Power Query Custom Data Connector for Microsoft Exchange",
            Link: "https://github.com/kerski/powerquery-connector-ms-exchange-rest-api"
        }
    ],     
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: ParseResult | undefined): ErrorObject[] => {
        if (!input) return [];

        const lexTokens: LexedJson[] = input.lexed as LexedJson[];
        const errorObjects: ErrorObject[] = [];

        // Find the position of the Exchange.Contents call
        const instances: LexedJson[] = findIdentifiers(lexTokens, "Exchange.Contents") ?? [];

        // Set the sequence to check for for Table Kind
        const sequenceCheck =   [{
            "kind": "Identifier",
            "data": "Name"
            },
            {
            "kind": "Equal",
            "data": "=",
            },
            {
            "kind": "TextLiteral",
            "data": '"Calendar"'
            }];

            const checkCalendarReference = containsTokenSequence(lexTokens, sequenceCheck);
        // Check for Exchange.Contents instance before checking for Kind and Item
        instances.forEach(instance => {

            // Check if the sequence is found
            if (checkCalendarReference === true) {
                const errorObject: ErrorObject = {
                    positionStart: instance.positionStart,
                    positionEnd: instance.positionEnd
                };
                errorObjects.push(errorObject);
            }
        });

        return errorObjects;
    }
};

export default useCustomConnectorForExchangeRecurringCalendarEvents;