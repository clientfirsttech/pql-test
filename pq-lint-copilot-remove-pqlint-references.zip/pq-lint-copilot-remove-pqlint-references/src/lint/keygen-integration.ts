/**
 * Keygen Integration Module
 *
 * Provides Keygen-specific license validation, activation, and cloud sync
 * functionality for the hybrid license manager (Option C).
 *
 * **STATUS: All Keygen API calls are commented out.**
 * Enable by uncommenting the relevant methods once the Keygen account and
 * product are configured (see `docs/keygen-setup-guide.md`).
 *
 * ## How it works
 *
 * Keygen (https://keygen.sh) is a purpose-built software licensing API.
 * It provides:
 *   - License key generation & validation
 *   - Machine fingerprinting (limit activations to N machines)
 *   - Signed license files for offline validation
 *   - REST API for cloud sync / revocation checks
 *   - Stripe integration for payment-triggered license creation
 *
 * ## Integration points
 *
 * | pq-lint operation       | Keygen API endpoint                           |
 * |-------------------------|-----------------------------------------------|
 * | `activate <key>`        | `POST /v1/accounts/:id/licenses/actions/validate-key` |
 * | `deactivate`            | `DELETE /v1/accounts/:id/machines/:id`         |
 * | `syncWithCloud`         | `POST /v1/accounts/:id/licenses/actions/validate-key` |
 * | Machine fingerprint     | `POST /v1/accounts/:id/machines`               |
 * | Offline signed file     | `GET  /v1/accounts/:id/licenses/:id`  (accept: application/vnd.api+json) |
 */

import { LicenseLevel } from './rule-types';
import { LicensePayload, LicenseValidationResult } from './license-manager';

// ---------------------------------------------------------------------------
// Configuration — set these before uncommenting the API calls
// ---------------------------------------------------------------------------

/**
 * Your Keygen account ID.  Found on the Keygen dashboard under Settings.
 * This is safe to embed in the client — it's a public identifier.
 */
export const KEYGEN_ACCOUNT_ID = 'YOUR_KEYGEN_ACCOUNT_ID';

/**
 * The Keygen product token (public).
 * NOT a secret — this identifies your product in API requests.
 * See docs/keygen-setup-guide.md § "Create a Product".
 */
export const KEYGEN_PRODUCT_ID = 'YOUR_KEYGEN_PRODUCT_ID';

/** Keygen API base URL. */
export const KEYGEN_API_BASE = 'https://api.keygen.sh/v1/accounts';

/** Timeout for Keygen API calls (ms). */
export const KEYGEN_API_TIMEOUT_MS = 5_000;

// ---------------------------------------------------------------------------
// Keygen-specific types (mirror Keygen REST API response shapes)
// ---------------------------------------------------------------------------

/** Subset of a Keygen license validation response. */
export interface KeygenValidationResponse {
    meta: {
        /** 'VALID', 'EXPIRED', 'SUSPENDED', 'OVERDUE', etc. */
        code: string;
        /** true when the license is in a valid state. */
        valid: boolean;
    };
    data: {
        id: string;
        attributes: {
            key: string;
            status: string;
            expiry: string | null;
            metadata: {
                tier?: string;  // 'free' | 'pro' | 'premium'
            };
        };
    };
}

/** Subset of a Keygen machine activation response. */
export interface KeygenMachineResponse {
    data: {
        id: string;
        attributes: {
            fingerprint: string;
            name: string;
            createdAt: string;
        };
    };
}

// ---------------------------------------------------------------------------
// Helper: map Keygen tier string → LicenseLevel enum
// ---------------------------------------------------------------------------

export function keygenTierToLicenseLevel(tier: string | undefined): LicenseLevel {
    switch (tier?.toLowerCase()) {
        case 'premium':
            return LicenseLevel.Premium;
        case 'pro':
            return LicenseLevel.Pro;
        default:
            return LicenseLevel.Free;
    }
}

// ---------------------------------------------------------------------------
// Helper: map KeygenValidationResponse → LicensePayload
// ---------------------------------------------------------------------------

export function keygenResponseToPayload(
    response: KeygenValidationResponse,
    existingSignature: string = 'keygen-validated'
): LicensePayload {
    const attrs = response.data.attributes;
    return {
        key: attrs.key,
        tier: keygenTierToLicenseLevel(attrs.metadata?.tier),
        expiresAt: attrs.expiry ?? new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
        signature: existingSignature,
        lastSyncAt: new Date().toISOString(),
    };
}

// ---------------------------------------------------------------------------
// Helper: generate a machine fingerprint
// ---------------------------------------------------------------------------

/**
 * Generate a deterministic machine fingerprint based on hostname + username.
 * In production, consider using a more robust fingerprint (e.g. MAC address,
 * disk serial, or a stored UUID).
 */
export function generateMachineFingerprint(): string {
    const osModule = require('os') as typeof import('os');
    const crypto = require('crypto') as typeof import('crypto');
    const raw = `${osModule.hostname()}-${osModule.userInfo().username}-${osModule.platform()}-${osModule.arch()}`;
    return crypto.createHash('sha256').update(raw).digest('hex');
}

// ---------------------------------------------------------------------------
// Keygen API functions (ALL COMMENTED OUT — uncomment when ready)
// ---------------------------------------------------------------------------

// /**
//  * Validate a license key against the Keygen API.
//  *
//  * This is the primary activation/validation call.  It tells Keygen to check
//  * the key's status (valid, expired, suspended, overdue) and returns the
//  * license metadata including tier.
//  *
//  * @param licenseKey - The key string the user entered (e.g. from `pql-lint activate <key>`).
//  * @returns Validation result with tier and expiry.
//  */
// export async function validateKeyWithKeygen(licenseKey: string): Promise<LicenseValidationResult> {
//     try {
//         const url = `${KEYGEN_API_BASE}/${KEYGEN_ACCOUNT_ID}/licenses/actions/validate-key`;
//         const response = await fetch(url, {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/vnd.api+json',
//                 'Accept': 'application/vnd.api+json',
//             },
//             body: JSON.stringify({
//                 meta: {
//                     key: licenseKey,
//                 },
//             }),
//             signal: AbortSignal.timeout(KEYGEN_API_TIMEOUT_MS),
//         });
//
//         if (!response.ok) {
//             return {
//                 valid: false,
//                 tier: LicenseLevel.Free,
//                 message: `Keygen API returned HTTP ${response.status}. Running in FREE mode.`,
//             };
//         }
//
//         const body = (await response.json()) as KeygenValidationResponse;
//
//         if (!body.meta.valid) {
//             return {
//                 valid: false,
//                 tier: LicenseLevel.Free,
//                 message: `License is ${body.meta.code}. Running in FREE mode.`,
//             };
//         }
//
//         const tier = keygenTierToLicenseLevel(body.data.attributes.metadata?.tier);
//         return {
//             valid: true,
//             tier,
//             message: `License validated via Keygen. Running in ${LicenseLevel[tier]} mode.`,
//         };
//     } catch (error) {
//         return {
//             valid: false,
//             tier: LicenseLevel.Free,
//             message: `Keygen validation failed: ${error instanceof Error ? error.message : String(error)}. Running in FREE mode.`,
//         };
//     }
// }

// /**
//  * Activate a machine against a license key.
//  *
//  * Keygen's machine activation model lets you limit a license to N machines.
//  * Call this during `pql-lint activate <key>` to register the current machine.
//  *
//  * @param licenseId - The Keygen license ID (from the validation response).
//  * @param licenseKey - The license key (used as bearer token for scoped requests).
//  * @returns The machine ID on success, or null on failure.
//  */
// export async function activateMachineWithKeygen(
//     licenseId: string,
//     licenseKey: string
// ): Promise<string | null> {
//     try {
//         const fingerprint = generateMachineFingerprint();
//         const url = `${KEYGEN_API_BASE}/${KEYGEN_ACCOUNT_ID}/machines`;
//         const response = await fetch(url, {
//             method: 'POST',
//             headers: {
//                 'Authorization': `License ${licenseKey}`,
//                 'Content-Type': 'application/vnd.api+json',
//                 'Accept': 'application/vnd.api+json',
//             },
//             body: JSON.stringify({
//                 data: {
//                     type: 'machines',
//                     attributes: {
//                         fingerprint,
//                         name: require('os').hostname(),
//                     },
//                     relationships: {
//                         license: {
//                             data: { type: 'licenses', id: licenseId },
//                         },
//                     },
//                 },
//             }),
//             signal: AbortSignal.timeout(KEYGEN_API_TIMEOUT_MS),
//         });
//
//         if (!response.ok) {
//             const body = await response.text();
//             console.error(`Machine activation failed (HTTP ${response.status}): ${body}`);
//             return null;
//         }
//
//         const body = (await response.json()) as KeygenMachineResponse;
//         return body.data.id;
//     } catch (error) {
//         console.error(`Machine activation error: ${error instanceof Error ? error.message : String(error)}`);
//         return null;
//     }
// }

// /**
//  * Deactivate (remove) a machine from a license.
//  *
//  * Call this during `pql-lint deactivate` to free up a machine slot.
//  *
//  * @param machineId - The Keygen machine ID (stored locally after activation).
//  * @param licenseKey - The license key for auth.
//  * @returns true on success.
//  */
// export async function deactivateMachineWithKeygen(
//     machineId: string,
//     licenseKey: string
// ): Promise<boolean> {
//     try {
//         const url = `${KEYGEN_API_BASE}/${KEYGEN_ACCOUNT_ID}/machines/${machineId}`;
//         const response = await fetch(url, {
//             method: 'DELETE',
//             headers: {
//                 'Authorization': `License ${licenseKey}`,
//                 'Accept': 'application/vnd.api+json',
//             },
//             signal: AbortSignal.timeout(KEYGEN_API_TIMEOUT_MS),
//         });
//
//         return response.ok || response.status === 204;
//     } catch (error) {
//         console.error(`Machine deactivation error: ${error instanceof Error ? error.message : String(error)}`);
//         return false;
//     }
// }

// /**
//  * Periodic cloud sync using Keygen's validate-key endpoint.
//  *
//  * This replaces the generic `syncWithCloud` method in LicenseManager.
//  * Call it in the background on CLI startup or Azure Function cold start.
//  *
//  * @param licenseKey - The stored license key.
//  * @returns Updated validation result and optional refreshed payload.
//  */
// export async function syncLicenseWithKeygen(
//     licenseKey: string
// ): Promise<{ result: LicenseValidationResult; payload?: LicensePayload }> {
//     try {
//         const url = `${KEYGEN_API_BASE}/${KEYGEN_ACCOUNT_ID}/licenses/actions/validate-key`;
//         const response = await fetch(url, {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/vnd.api+json',
//                 'Accept': 'application/vnd.api+json',
//             },
//             body: JSON.stringify({
//                 meta: {
//                     key: licenseKey,
//                 },
//             }),
//             signal: AbortSignal.timeout(KEYGEN_API_TIMEOUT_MS),
//         });
//
//         if (!response.ok) {
//             return {
//                 result: {
//                     valid: false,
//                     tier: LicenseLevel.Free,
//                     message: `Keygen sync failed (HTTP ${response.status}). License may be revoked.`,
//                 },
//             };
//         }
//
//         const body = (await response.json()) as KeygenValidationResponse;
//
//         if (!body.meta.valid) {
//             return {
//                 result: {
//                     valid: false,
//                     tier: LicenseLevel.Free,
//                     message: `License status: ${body.meta.code}. Running in FREE mode.`,
//                 },
//             };
//         }
//
//         const payload = keygenResponseToPayload(body);
//         return {
//             result: {
//                 valid: true,
//                 tier: payload.tier,
//                 message: `License synced via Keygen. Running in ${LicenseLevel[payload.tier]} mode.`,
//             },
//             payload,
//         };
//     } catch (error) {
//         // Network failure — caller should fall back to grace period
//         return {
//             result: {
//                 valid: true,   // allow grace period
//                 tier: LicenseLevel.Free,  // caller overrides with cached tier
//                 message: `Keygen sync failed (${error instanceof Error ? error.message : 'offline'}). Using cached license.`,
//             },
//         };
//     }
// }
