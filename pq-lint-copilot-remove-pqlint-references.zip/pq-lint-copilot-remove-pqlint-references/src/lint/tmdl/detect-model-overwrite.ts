import { TMDL_Level_Rule, ErrorObject, SeverityLevel, LicenseLevel } from "../rule-types";
import { Raw_TMDL_Parsed_Data } from "../../parser/tmdl/tmdl-parser";
import { logDebug } from "../rule-assistance";

// Create a Rule object
export const detectModelOverwrite: TMDL_Level_Rule = {
    ID: "detect-model-overwrite",
    Name: "TMDL Script contains Model definition which would overwrite existing model.",
    Category: "Potential Issue",
    Description: "Before running the script, check that the script is intended to create or replace the whole model.",
    References: [],
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Free,
    Check: (input: Raw_TMDL_Parsed_Data, tmdlCode: string): ErrorObject[] => {
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        logDebug("Model Data:", input.model);

        if (input.model?.Model) {
            // Iterate over all model definitions
            input.model.Model.forEach((model) => {
                // Calculate the start position
                const tempStartPosition = {
                    codeUnit: 0,
                    lineCodeUnit: 0,
                    lineNumber: model.startPositionLineNumber,
                };

                // Calculate the end position
                const tempEndPosition = {
                    codeUnit: 0,
                    lineCodeUnit: 0,
                    lineNumber: model.startPositionLineNumber, // Keep the same line number
                };

                // Create an error object
                errorObjects.push({
                    positionStart: tempStartPosition,
                    positionEnd: tempEndPosition,
                });
            });
        }

        // Return all collected error objects
        return errorObjects;
    },
};

export default detectModelOverwrite;