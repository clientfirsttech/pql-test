import { TMDL_Level_PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel, TMDL_Level_PowerQueryPairing } from "../../rule-types";
import { ParseResult } from "../../../parser/pq/parse-types";
import { findIdentifiers, findNodesWithRecursiveExpression, logDebug } from "../../rule-assistance";
import { has } from "lodash";

/**
 * Rule that checks if Databricks import mode tables should use partitioning or incremental refresh.
 * 
 * This rule identifies scenarios where:
 * - Data is being imported from Databricks (using Databricks.Catalogs or DatabricksMultiCloud.Catalogs)
 * - The table is in import mode
 * - No incremental refresh is configured
 * - Only a single partition exists
 * - The table contains datetime/date columns (indicating potential for time-based partitioning)
 * 
 * In these cases, the rule suggests using partitioning or incremental refresh to optimize performance,
 * or alternatively considering Direct Query for fact tables or Dual Mode for dimension tables.
 */
export const usePartitioningWhenImportModeDatabricks: TMDL_Level_PowerQueryRule = {
    ID: "use-partitioning-when-import-mode-databricks",
    Name: "Use Partitioning When Importing Data into Databricks",
    Category: "Best Practice",
    Description: "When importing data into Databricks, use partitioning or incremental refresh to optimize performance. Alternatively consider using Direct Query (Fact Table) or Dual Mode (Dimension Table) for large datasets.",
    References: [

        {
            Link: "https://medium.com/dbsql-sme-engineering/introducing-the-power-bi-on-databricks-best-practices-cheatsheet-a55e0aed9575"
            , Description: "Power BI on Databricks Best Practices Cheat Sheet"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: TMDL_Level_PowerQueryPairing[]): ErrorObject[] => {
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // Identifiers to search for with Databricks - these indicate Databricks data sources
        const databaseIdentifiers = [
            "Databricks.Catalogs",           // Standard Databricks connector
            "DatabricksMultiCloud.Catalogs"  // Multi-cloud Databricks connector
        ];

        // Iterate through each pairing to check for optimization opportunities
        for (const pairing of input) {
            // Skip if MCode or properties are null/undefined
            if (!pairing.MCode || !pairing.MCode.properties || !pairing.MCode.properties.mode) {
                continue;
            }

            // Skip if associatedTable is null/undefined
            if (!pairing.AssociatedTable) {
                continue;
            }

            // Cast to access the properties from the parsed PowerQuery result
            const lexTokens: LexedJson[] = (pairing.ParseResult as ParseResult).lexed as LexedJson[];
            const aSTTokens: any = (pairing.ParseResult as ParseResult).ast;
            const associatedTable = pairing.AssociatedTable;
            
            // Check table configuration properties
            const noIncrementalRefresh = (associatedTable?.properties?.isIncremental || false) === false;
            const isImportMode = pairing.MCode.properties.mode?.toLowerCase() === "import";
            const isHidden = (associatedTable?.properties?.isHidden || false) === true;
            const hasDateTimeColumns = associatedTable?.columns ? associatedTable.columns.filter(col => 
                col && col.dataType?.toLowerCase() === 'datetime' || col && col.dataType?.toLowerCase() === 'date').length > 0 : false;
            
            logDebug('table name', associatedTable?.name);
            logDebug('isImportMode:', isImportMode);
            logDebug('hasDateTimeColumns:', JSON.stringify(associatedTable?.columns));

            const numberOfPartitions = associatedTable?.partitions?.length || 0;

            // Only flag tables that meet all criteria for potential optimization
            if (isImportMode && noIncrementalRefresh && numberOfPartitions === 1 && hasDateTimeColumns && !isHidden) {
                // Search for Databricks identifiers in the M code
                databaseIdentifiers.forEach((identifier) => {
                    const databaseFind: LexedJson[] = findIdentifiers(lexTokens, identifier) ?? [];

                    databaseFind.forEach(element => {
                        logDebug('Databricks connector found:', element);

                        // Calculate the start position, adjusting for the M code's position in the TMDL file
                        const tempStartPosition = {
                            codeUnit: element.positionStart.codeUnit,
                            lineCodeUnit: element.positionStart.lineCodeUnit,
                            lineNumber: element.positionStart.lineNumber + pairing.MCode.lineNumber
                        };

                        // Calculate the end position, adjusting for the M code's position in the TMDL file
                        const tempEndPosition = {
                            codeUnit: element.positionEnd.codeUnit,
                            lineCodeUnit: element.positionEnd.lineCodeUnit,
                            lineNumber: element.positionEnd.lineNumber + pairing.MCode.lineNumber
                        };

                        // Create an error object to flag this optimization opportunity
                        errorObjects.push({
                            positionStart: tempStartPosition,
                            positionEnd: tempEndPosition
                        });
                    });
                });
            }
        }

        // Return all collected error objects
        return errorObjects;
    }
};

export default usePartitioningWhenImportModeDatabricks;