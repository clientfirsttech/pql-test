import { TMDL_Level_PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel, TMDL_Level_PowerQueryPairing } from "../../rule-types";
import { ParseResult } from "../../../parser/pq/parse-types";
import { findIdentifiers, findNodesWithRecursiveExpression, logDebug } from "../../rule-assistance";
import { has } from "lodash";

/**
 * Rule that checks if Databricks fact tables should use DirectQuery mode for optimal performance.
 * 
 * This rule identifies scenarios where:
 * - Data is being imported from Databricks (using Databricks.Catalogs or DatabricksMultiCloud.Catalogs)
 * - The table is in import mode (not already DirectQuery mode)
 * - No incremental refresh is configured
 * - The table is identified as a fact table (source of multiple active relationships)
 * 
 * In these cases, the rule suggests using DirectQuery Mode for fact tables to achieve
 * optimal performance with large datasets and real-time data access, following Databricks best practices.
 * 
 * DirectQuery Mode allows fact tables to query data directly from the source without importing,
 * which is ideal for large fact tables that would consume significant memory in Import mode.
 * This approach ensures users always see the most current data while maintaining good performance
 * for analytical queries against Databricks.
 */
export const useDirectQueryModeWithFactTableDatabricks: TMDL_Level_PowerQueryRule = {
    ID: "use-direct-query-mode-with-fact-table-databricks",
    Name: "Use Direct Query Mode with Fact Table in Databricks",
    Category: "Best Practice", 
    Description: "Fact tables connected to Databricks should use DirectQuery mode to optimize performance with large datasets and ensure real-time data access. This prevents memory issues that can occur when importing large fact tables while maintaining query performance through Databricks' compute capabilities.",
    References: [
        {
            Link: "https://medium.com/dbsql-sme-engineering/introducing-the-power-bi-on-databricks-best-practices-cheatsheet-a55e0aed9575",
            Description: "Power BI on Databricks Best Practices Cheat Sheet"
        },
        {
            Link: "https://github.com/databricks-solutions/power-bi-on-databricks-quickstarts/tree/main/02.%20Storage%20Modes",
            Description: "Power BI on Databricks Quickstarts - Storage Modes"
        }        
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: TMDL_Level_PowerQueryPairing[]): ErrorObject[] => {
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // Identifiers to search for with Databricks - these indicate Databricks data sources
        const databaseIdentifiers = [
            "Databricks.Catalogs",           // Standard Databricks connector
            "DatabricksMultiCloud.Catalogs"  // Multi-cloud Databricks connector
        ];

        // Iterate through each pairing to check for optimization opportunities
        for (const pairing of input) {
            // Skip if MCode or properties are null/undefined
            if (!pairing.MCode || !pairing.MCode.properties || !pairing.MCode.properties.mode) {
                continue;
            } // end if MCode validation

            // Skip if associatedTable is null/undefined
            if (!pairing.AssociatedTable) {
                continue;
            } // end if associatedTable validation

            // Cast to access the properties from the parsed PowerQuery result
            const lexTokens: LexedJson[] = (pairing.ParseResult as ParseResult).lexed as LexedJson[];
            const associatedTable = pairing.AssociatedTable;

            // Search for Databricks identifiers in the M code
            databaseIdentifiers.forEach((identifier) => {
                const databaseFind: LexedJson[] = findIdentifiers(lexTokens, identifier) ?? [];
                databaseFind.forEach(element => {
                    logDebug(`Databricks identifier '${identifier}' found in query associated with table '${associatedTable.name}'.`);

                    // Check table configuration properties
                    const noIncrementalRefresh = (associatedTable?.properties?.isIncremental || false) === false;
                    const isHidden = (associatedTable?.properties?.isHidden || false) === true;
                    const isImportMode = pairing.MCode.properties.mode?.toLowerCase() === "import";
                    const relationships = associatedTable?.relationships ?? [];
                    
                    // Identify if the table is a fact table (tables that are sources of relationships)
                    // Fact tables are typically the ones that have multiple active relationships on the 'many' sides
                    const isFactTable = relationships.filter(rel => rel.fromTable === associatedTable.name && rel.isActive).length > 1;

                    // Check if this table meets the criteria for DirectQuery mode recommendation
                    if (isImportMode && noIncrementalRefresh && isFactTable && !isHidden) {
                        // Calculate the start position, adjusting for the M code's position in the TMDL file
                        const tempStartPosition = {
                            codeUnit: element.positionStart.codeUnit,
                            lineCodeUnit: element.positionStart.lineCodeUnit,
                            lineNumber: element.positionStart.lineNumber + pairing.MCode.lineNumber
                        };

                        // Calculate the end position, adjusting for the M code's position in the TMDL file
                        const tempEndPosition = {
                            codeUnit: element.positionEnd.codeUnit,
                            lineCodeUnit: element.positionEnd.lineCodeUnit,
                            lineNumber: element.positionEnd.lineNumber + pairing.MCode.lineNumber
                        };

                        // Create an error object to flag this optimization opportunity
                        errorObjects.push({
                            positionStart: tempStartPosition,
                            positionEnd: tempEndPosition
                        });
                    } // end if DirectQuery criteria check
                }); // end databaseFind.forEach
            }); // end databaseIdentifiers.forEach
        } // end for pairing loop

        // Return all collected error objects
        return errorObjects;
    } // end Check function
}; // end useDirectQueryModeWithFactTableDatabricks

export default useDirectQueryModeWithFactTableDatabricks;