import { TMDL_Level_PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel, TMDL_Level_PowerQueryPairing } from "../../rule-types";
import { ParseResult } from "../../../parser/pq/parse-types";
import { findIdentifiers, findNodesWithRecursiveExpression, logDebug } from "../../rule-assistance";
import { has } from "lodash";

/**
 * Rule that checks if Databricks dimension tables should use Dual mode for optimal performance.
 * 
 * This rule identifies scenarios where:
 * - Data is being imported from Databricks (using Databricks.Catalogs or DatabricksMultiCloud.Catalogs)
 * - The table is in import mode (not already dual mode)
 * - No incremental refresh is configured
 * - The table is identified as a dimension table (target of active relationships)
 * 
 * In these cases, the rule suggests using Dual Mode for dimension tables to achieve
 * both performance benefits and data freshness, following Databricks best practices.
 * 
 * Dual Mode allows dimension tables to serve data from both DirectQuery and Import modes,
 * providing real-time data access when needed while maintaining fast query performance.
 */
export const useDualModeWithDimensionTableDatabricks: TMDL_Level_PowerQueryRule = {
    ID: "use-dual-mode-with-dimension-table-databricks",
    Name: "Use Dual Mode with Dimension Table in Databricks",
    Category: "Best Practice",
    Description: "Dimension tables connected to Databricks should use Dual mode to optimize both performance and data freshness. This allows the table to serve data from both DirectQuery and Import modes based on query requirements.",
    References: [
        {
            Link: "https://medium.com/dbsql-sme-engineering/introducing-the-power-bi-on-databricks-best-practices-cheatsheet-a55e0aed9575",
            Description: "Power BI on Databricks Best Practices Cheat Sheet"
        },
        {
            Link: "https://github.com/databricks-solutions/power-bi-on-databricks-quickstarts/tree/main/02.%20Storage%20Modes",
            Description: "Power BI on Databricks Quickstarts - Storage Modes"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: TMDL_Level_PowerQueryPairing[]): ErrorObject[] => {
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // Identifiers to search for with Databricks - these indicate Databricks data sources
        const databaseIdentifiers = [
            "Databricks.Catalogs",           // Standard Databricks connector
            "DatabricksMultiCloud.Catalogs"  // Multi-cloud Databricks connector
        ];

        // Iterate through each pairing to check for optimization opportunities
        for (const pairing of input) {
            // Skip if MCode or properties are null/undefined
            if (!pairing.MCode || !pairing.MCode.properties || !pairing.MCode.properties.mode) {
                continue;
            } // end if

            // Skip if associatedTable is null/undefined
            if (!pairing.AssociatedTable) {
                continue;
            } // end if

            // Cast to access the properties from the parsed PowerQuery result
            const lexTokens: LexedJson[] = (pairing.ParseResult as ParseResult).lexed as LexedJson[];
            const associatedTable = pairing.AssociatedTable;

            // Search for Databricks identifiers in the M code
            databaseIdentifiers.forEach((identifier) => {
                const databaseFind: LexedJson[] = findIdentifiers(lexTokens, identifier) ?? [];
                databaseFind.forEach(element => {
                    logDebug(`Databricks identifier '${identifier}' found in query associated with table '${associatedTable.name}'.`);

                    // Check table configuration properties
                    const noIncrementalRefresh = (associatedTable?.properties?.isIncremental || false) === false;
                    const isHidden = (associatedTable?.properties?.isHidden || false) === true;
                    const isImportMode = pairing.MCode.properties.mode?.toLowerCase() === "import";
                    const relationships = associatedTable?.relationships ?? [];

                    // Identify if the table is a dimension table (tables that are targets of relationships)
                    const isDimensionTable = relationships.some(rel => rel.toTable === associatedTable.name && rel.isActive);

                    // Check if this table meets the criteria for dual mode recommendation
                    if (isImportMode && noIncrementalRefresh && isDimensionTable && !isHidden) {
                        // Calculate the start position, adjusting for the M code's position in the TMDL file
                        const tempStartPosition = {
                            codeUnit: element.positionStart.codeUnit,
                            lineCodeUnit: element.positionStart.lineCodeUnit,
                            lineNumber: element.positionStart.lineNumber + pairing.MCode.lineNumber
                        };

                        // Calculate the end position, adjusting for the M code's position in the TMDL file
                        const tempEndPosition = {
                            codeUnit: element.positionEnd.codeUnit,
                            lineCodeUnit: element.positionEnd.lineCodeUnit,
                            lineNumber: element.positionEnd.lineNumber + pairing.MCode.lineNumber
                        };

                        // Create an error object to flag this optimization opportunity
                        errorObjects.push({
                            positionStart: tempStartPosition,
                            positionEnd: tempEndPosition
                        });
                    } // end if criteria check
                }); // end databaseFind.forEach
            }); // end databaseIdentifiers.forEach
        } // end for pairing

        // Return all collected error objects
        return errorObjects;
    } // end Check function
}; // end useDualModeWithDimensionTableDatabricks

export default useDualModeWithDimensionTableDatabricks;