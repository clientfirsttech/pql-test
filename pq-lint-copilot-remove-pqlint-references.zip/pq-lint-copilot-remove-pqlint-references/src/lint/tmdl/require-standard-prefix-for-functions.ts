import { TMDL_Level_PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel, TMDL_Level_PowerQueryPairing } from "../rule-types"
import { ParseResult } from "../../parser/pq/parse-types";
import { logDebug } from "../rule-assistance";

// Create a Rule object
export const requireStandardPrefixForFunctions: TMDL_Level_PowerQueryRule = {
    ID: "require-standard-prefix-for-functions",
    Name: "Functions should have a standard prefix",
    Category: "Best Practice",
    Description: "It's a best practice to use a standard prefix for functions 'fx' or 'fn'. This helps in identifying functions easily and maintaining consistency across model (e.g., fnGetData).",
    References: [
        {
            Description: "Chapter 9 - The Definitive Guide to Power Query (M)",
            Link: "https://amzn.to/43zc4ye"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: TMDL_Level_PowerQueryPairing[]): ErrorObject[] => {
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        const standardPrefix = "fn"; // Example standard prefix
        const standardPrefix2 = "fx"; // Example standard prefix);
        for (const pairing of input) {

            // Cast the input to access AST tokens
            const aSTTokens: any = (pairing.ParseResult as ParseResult).ast;
            if (aSTTokens !== null && aSTTokens !== undefined) {
                // aSTToken is not null or undefined, safe to use


                logDebug("kind", aSTTokens.kind);
                logDebug("Line Number ", pairing.MCode.lineNumber);
                logDebug("Name ", pairing.MCode.name);
                logDebug("MAttribute ", pairing.MCode.properties.mAttributes);
                // Check if the kind is a function expression or if it has a specific attribute (UI created function)
                if (aSTTokens.kind === "FunctionExpression" || pairing.MCode.properties.mAttributes?.includes("FunctionQueryBinding")) {
                    // Check if the function name starts with a standard prefix
                    const functionName = pairing.MCode.name;

                    if (!functionName.startsWith(standardPrefix) && !functionName.startsWith(standardPrefix2)) {
                        // Calculate the start position
                        const tempStartPosition = {
                            codeUnit: aSTTokens.tokenRange.positionStart.codeUnit,
                            lineCodeUnit: aSTTokens.tokenRange.positionStart.lineCodeUnit,
                            lineNumber: pairing.MCode.lineNumber
                        }

                        // Calculate the end position
                        const tempEndPosition = {
                            codeUnit: aSTTokens.tokenRange.positionEnd.codeUnit,
                            lineCodeUnit: aSTTokens.tokenRange.positionEnd.lineCodeUnit,
                            lineNumber: pairing.MCode.lineNumber
                        }

                        // Create an error object
                        errorObjects.push({
                            // add for offset
                            positionStart: tempStartPosition,
                            positionEnd: tempEndPosition
                        });
                    }
                }
            } // end if aSTTokens is not null or undefined
        };


        // Check if a function
        // If it is a function, check if it has a standard prefix

        return errorObjects;
    }
};

export default requireStandardPrefixForFunctions;