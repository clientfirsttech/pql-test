import { TMDL_Level_PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel, TMDL_Level_PowerQueryPairing } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findIdentifiers, findNodesWithRecursiveExpression, logDebug } from "../rule-assistance";

// Create a Rule object
export const detectDatabaseQuery: TMDL_Level_PowerQueryRule = {
    ID: "detect-database-query",
    Name: "TMDL Script with Database Query Detected",
    Category: "Potential Issue",
    Description: "Before running the script, check that the script is intended. If you disable requiring user approval for native scripts, this could execute code you don't want to run.",
    References: [],
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Free,
    Check: (input: TMDL_Level_PowerQueryPairing[]): ErrorObject[] => {
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        const databaseIdentifiers = [
            "AnalysisServices.Database",
            "Informix.Database",
            "DB2.Database",
            "MySQL.Database",
            "Oracle.Database",
            "PostgreSQL.Database",
            "SapHana.Database",
            "Sql.Database",
            "Sybase.Database",
            "Teradata.Database"
        ];

        for (const pairing of input) {
            // Cast to access the properties
            const lexTokens: LexedJson[] = (pairing.ParseResult as ParseResult).lexed as LexedJson[];
            const aSTTokens: any = (pairing.ParseResult as ParseResult).ast;

            databaseIdentifiers.forEach((identifier) => {
                const databaseFind: LexedJson[] = findIdentifiers(lexTokens, identifier) ?? [];

                databaseFind.forEach(element => {
                    logDebug('Database found:', element);

                    const tempArray: any[] = [element];
                    const queryUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens, '"literal":"Query"');
                    logDebug('Query Usage:', queryUsage.length);
                    if (queryUsage.length > 0) {
                        // Calculate the start position
                        const tempStartPosition = {
                            codeUnit: element.positionStart.codeUnit,
                            lineCodeUnit: element.positionStart.lineCodeUnit,
                            lineNumber: element.positionStart.lineNumber + pairing.MCode.lineNumber
                        };

                        // Calculate the end position
                        const tempEndPosition = {
                            codeUnit: element.positionEnd.codeUnit,
                            lineCodeUnit: element.positionEnd.lineCodeUnit,
                            lineNumber: element.positionEnd.lineNumber + pairing.MCode.lineNumber
                        };

                        // Create an error object
                        errorObjects.push({
                            positionStart: tempStartPosition,
                            positionEnd: tempEndPosition
                        });
                    }
                });
            });
        }

        // Return all collected error objects
        return errorObjects;
    }
};

export default detectDatabaseQuery;