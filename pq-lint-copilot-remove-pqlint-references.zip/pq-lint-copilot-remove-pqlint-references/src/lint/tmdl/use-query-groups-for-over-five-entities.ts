import { TMDL_Level_PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel, TMDL_Level_PowerQueryPairing } from "../rule-types"
import { logDebug } from "../rule-assistance";

// Create a Rule object
export const useQueryGroupsForOverFiveEntities: TMDL_Level_PowerQueryRule = {
    ID: "use-query-groups-for-over-five-entities",
    Name: "When using more than 5 entities, use query groups",
    Category: "Best Practice",
    Description: "Provide a query group when you have more than 5 queries, parameters, or functions. This helps in organizing and managing the model effectively.",
    References: [
        {
            Description: "Best practices when working with Power Query",
            Link: "https://learn.microsoft.com/en-us/power-query/best-practices#create-groups"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    AIFixInstructions: {
        Description: "Add query groups to organize entities when there are more than 5",
        Prompt: "Add appropriate queryGroup properties to organize the entities. Use logical groupings like 'Parameters', 'Data Sources', 'Transformations', etc. For parameters, use 'Parameters'. For data source queries, use 'Data Sources'. For transformation queries, group them logically based on their purpose.",
        IsActive: true,
        IsWholeQueryFix: true
    },
    Check: (input: TMDL_Level_PowerQueryPairing[]): ErrorObject[] => {
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // Find how many query groups are not defined 
        // versus how many entities exist.
        const numberofEntities = input.length;
        logDebug("Number of Entities", numberofEntities);
        // If the number of entities is greater than 5,
        if (numberofEntities > 5) {
            const numberOfQueryGroups = input.filter((pairing) => {
                // Defensive check: ensure queryGroup exists and is not null/undefined before trimming
                const qg = pairing.MCode?.properties?.queryGroup;
                if (qg == null) {
                    return false;
                }
                return qg.trim().length !== 0;
            }).length;

            logDebug("Number of Query Groups", numberOfQueryGroups);

            if (numberOfQueryGroups === 0) {
                // If there are no query groups, add an error object
                // Create error at the top of the first entity
                errorObjects.push({
                    positionStart: { codeUnit: 0, lineCodeUnit: 0, lineNumber: 1 },
                    positionEnd: { codeUnit: 0, lineCodeUnit: 0, lineNumber: 1 }
                });
            } // end if 
        } // end if

        return errorObjects;
    }
};

export default useQueryGroupsForOverFiveEntities;