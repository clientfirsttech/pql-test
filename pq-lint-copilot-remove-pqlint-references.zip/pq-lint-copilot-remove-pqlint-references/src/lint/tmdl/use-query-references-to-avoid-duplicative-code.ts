import { TMDL_Level_PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel, TMDL_Level_PowerQueryPairing } from "../rule-types"
import { logDebug, RegexPatternsForConstants } from "../rule-assistance";
import { ParseResult } from "../../parser/pq/parse-types";
import * as _ from "lodash"; // Correct import for lodash with types

/**
 * Rule to detect identical query steps across multiple tables in TMDL format.
 * Identifies duplicated logic that should be extracted into query references.
 */
export const useQueryReferencesToAvoidDuplicativeCode: TMDL_Level_PowerQueryRule = {
    ID: "use-query-references-to-avoid-duplicative-code",
    Name: "Identical query steps found in two tables. Use query references to avoid duplicating the same logic",
    Category: "Best Practice",
    Description: "Duplicated query steps can lead to maintenance issues and slower performance. Use query references to reuse logic efficiently.",
    References: [
        {
            Description: "Chapter 2 - Master Your Data with Power Query in Excel and Power BI",
            Link: "https://amzn.to/3HrG2Nd"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: TMDL_Level_PowerQueryPairing[]): ErrorObject[] => {
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        const lexedJsons: LexedJson[][] = [];
        
        // Extract lexed tokens from each Power Query pairing
        for (const pairing of input) {
            // Cast to access the properties
            const lexTokens: LexedJson[] = (pairing.ParseResult as ParseResult).lexed as LexedJson[];
            // Cast the input to access AST tokens
            const aSTTokens: any = (pairing.ParseResult as ParseResult).ast;
            
            // Ensure we have an array of lexed tokens
            lexedJsons.push(Array.isArray(lexTokens) ? lexTokens : [lexTokens]);
        } // end for loop - lexed token extraction
       
        // Compare each set of lexed tokens with every other set to find duplicates
        for (let i = 0; i < lexedJsons.length; i++) {
            for (let j = i + 1; j < lexedJsons.length; j++) {
                logDebug("Comparing lexedJsons at index " + input[i].MCode.name + " and " + input[j].MCode.name);
                logDebug("Number of lexedJsons to compare: " + lexedJsons[i].length + " and " + lexedJsons[j].length);

                // Skip comparison if either query has insufficient tokens
                if (lexedJsons[i].length <= 1 || lexedJsons[j].length <= 1) {
                    logDebug("Skipping comparison due to insufficient lexedJson entries");
                    continue;
                } else {
                    logDebug("Proceeding with comparison");
                    
                    // Compare the token arrays using lodash's differenceWith and isEqual
                    const mismatch = _.differenceWith(lexedJsons[i], lexedJsons[j], _.isEqual);
                    let flagIssue = false;

                    if (mismatch.length > 0) {
                        logDebug("Mismatches found at indices " + mismatch.length);
                        logDebug(JSON.stringify(mismatch[0]));
                        
                        // If the first mismatch occurs after line 3, we have duplicative code
                        logDebug("Mismatch found at indices " + mismatch[0].positionStart.lineNumber);
                        logDebug(lexedJsons[i][0]);
                        logDebug(lexedJsons[j][0]);
                        
                        // Flag as issue if mismatch occurs after initial setup lines
                        if (mismatch[0].positionStart.lineNumber > 3) {
                            flagIssue = true;
                        }
                    } else if (mismatch.length === 0) {
                        // If arrays are identical, we have complete duplication
                        logDebug("Identical lexedJsons found at indices");
                        flagIssue = true;
                    } // end mismatch length check

                    if (flagIssue === true) {
                        // Calculate the start position for the error
                        const tempStartPosition = {
                            codeUnit: lexedJsons[j][0].positionStart.codeUnit,
                            lineCodeUnit: lexedJsons[j][0].positionStart.lineCodeUnit,
                            lineNumber: input[j].MCode.lineNumber
                        }; // end tempStartPosition

                        // Calculate the end position for the error
                        const tempEndPosition = {
                            codeUnit: lexedJsons[j][0].positionEnd.codeUnit,
                            lineCodeUnit: lexedJsons[j][0].positionEnd.lineCodeUnit,
                            lineNumber: input[j].MCode.lineNumber
                        }; // end tempEndPosition

                        // Create an error object for the duplicate code
                        errorObjects.push({
                            positionStart: tempStartPosition,
                            positionEnd: tempEndPosition
                        });
                    } // end flagIssue check
                } // end else block for sufficient tokens
            } // end inner for loop (j)
        } // end outer for loop (i)

        return errorObjects;
    } // end Check function
}; // end useQueryReferencesToAvoidDuplicativeCode rule

export default useQueryReferencesToAvoidDuplicativeCode