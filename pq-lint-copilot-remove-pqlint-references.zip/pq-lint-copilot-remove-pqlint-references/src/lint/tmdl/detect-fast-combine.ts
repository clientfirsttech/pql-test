import { TMDL_Level_Rule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel, TMDL_Level_PowerQueryPairing } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findIdentifiers, findNodesWithRecursiveExpression, logDebug } from "../rule-assistance";
import { Raw_TMDL_Parsed_Data } from "../../parser/tmdl/tmdl-parser";
import { log } from "console";

// Create a Rule object
export const detectFastCombine: TMDL_Level_Rule = {
    ID: "detect-fast-combine",
    Name: "TMDL Script contains fastCombine which updates the model to ignore privacy settings",
    Category: "Potential Issue",
    Description: "Before running the script, check that the script is intended. If you intend to ignore privacy settings, this could combine data you didn't intend to combine.",
    References: [],
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Free,
    Check: (input: Raw_TMDL_Parsed_Data, tmdlCode: string): ErrorObject[] => {
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        logDebug('Model Data:', input.dataAccessOptions);

        if (input.dataAccessOptions) {
            const position = input.dataAccessOptions[''][0];
            const extractedCode = tmdlCode.split('\n') // Split the code into lines
                .slice(position.startPositionLineNumber - 1, position.endPositionLineNumber) // Extract lines inclusively

            logDebug('Extracted Code:', extractedCode);

            for (let i = 0; i < extractedCode.length; i++) {
                const line = extractedCode[i];
                if (line.includes("fastCombine")) {
                    // Calculate the start position
                    const tempStartPosition = {
                        codeUnit: 0,
                        lineCodeUnit: 0,
                        lineNumber: position.startPositionLineNumber + i
                    };

                    // Calculate the end position
                    const tempEndPosition = {
                        codeUnit: 0,
                        lineCodeUnit: 0,
                        lineNumber: position.startPositionLineNumber + i
                    };

                    // Create an error object
                    errorObjects.push({
                        positionStart: tempStartPosition,
                        positionEnd: tempEndPosition
                    });
                }

            }
        }


        // Return all collected error objects
        return errorObjects;
    }
};

export default detectFastCombine;