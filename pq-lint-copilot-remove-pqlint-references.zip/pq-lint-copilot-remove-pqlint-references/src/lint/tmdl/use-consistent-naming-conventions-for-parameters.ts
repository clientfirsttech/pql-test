import { TMDL_Level_PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel, TMDL_Level_PowerQueryPairing } from "../rule-types"
import { logDebug, RegexPatternsForConstants } from "../rule-assistance";
import { ParseResult } from "../../parser/pq/parse-types";

// Create a Rule object
export const useConsistentNamingConventionsForParameters: TMDL_Level_PowerQueryRule = {
    ID: "use-consistent-naming-conventions-for-parameters",
    Name: "Use parameters with only letters, numbers, and underscores.",
    Category: "Best Practice",
    Description: "To maintain clean and consistent code, use parameters that only contain letters, numbers, and underscores.  It should also NOT start with a number. This avoids having special notation (# and double quotes) in the code.",
    References: [
        {
            Description: "Chapter 9 - The Definitive Guide to Power Query (M)",
            Link: "https://amzn.to/43zc4ye"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: TMDL_Level_PowerQueryPairing[]): ErrorObject[] => {
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        const paramRegex = RegexPatternsForConstants.parameterRegex;

        for (const pairing of input) {
            // Cast the input to access AST tokens
            const aSTTokens: any = (pairing.ParseResult as ParseResult).ast;
            if (aSTTokens !== null && aSTTokens !== undefined) {
                // aSTToken is not null or undefined, safe to use
                logDebug("kind", aSTTokens.kind);
                logDebug("Line Number ", pairing.MCode.lineNumber);
                logDebug("Name ", pairing.MCode.name);
                // Check if the kind is a MetaExpression
                if (aSTTokens.kind === "MetadataExpression") {
                    // Check if the function name starts with a standard prefix
                    const parameterName = pairing.MCode.name;

                    // If doesn't match the regex, add to error objects
                    if (!paramRegex.test(parameterName)) {
                        // Calculate the start position
                        const tempStartPosition = {
                            codeUnit: aSTTokens.tokenRange.positionStart.codeUnit,
                            lineCodeUnit: aSTTokens.tokenRange.positionStart.lineCodeUnit,
                            lineNumber: pairing.MCode.lineNumber
                        }

                        // Calculate the end position
                        const tempEndPosition = {
                            codeUnit: aSTTokens.tokenRange.positionEnd.codeUnit,
                            lineCodeUnit: aSTTokens.tokenRange.positionEnd.lineCodeUnit,
                            lineNumber: pairing.MCode.lineNumber
                        }

                        // Create an error object
                        errorObjects.push({
                            // add for offset
                            positionStart: tempStartPosition,
                            positionEnd: tempEndPosition
                        });
                    }
                }
            } // End of if check for aSTTokens
        }
        return errorObjects;
    }
};

export default useConsistentNamingConventionsForParameters