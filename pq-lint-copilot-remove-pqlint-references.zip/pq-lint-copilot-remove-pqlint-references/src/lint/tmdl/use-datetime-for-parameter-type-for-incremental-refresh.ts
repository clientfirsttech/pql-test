import { log } from "console";
import { ParseResult } from "../../parser/pq/parse-types";
import { containsTokenSequence, logDebug } from "../rule-assistance";
import { TMDL_Level_PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel, TMDL_Level_PowerQueryPairing } from "../rule-types";

/**
 * TMDL-level rule to detect when RangeStart or RangeEnd parameters are missing proper datetime type declarations
 * in incremental refresh scenarios.
 * 
 * This rule specifically targets TMDL files and checks that RangeStart and RangeEnd parameters within
 * expressions or partitions have explicit datetime type metadata to ensure compatibility with incremental
 * refresh operations. It validates metadata expressions for proper type declarations such as:
 * - type=datetime
 * - type="DateTime" 
 * - type=DateTime.Type
 * 
 * The rule helps prevent data type mismatch issues that can occur during incremental refresh operations
 * when parameters don't have the correct datetime type specification.
 */
export const useDatetimeParameterForIncrementalRefresh: TMDL_Level_PowerQueryRule = {
    ID: "use-datetime-parameter-for-incremental-refresh",
    Name: "Use Datetime Type for RangeStart and RangeEnd Parameters",
    Category: "Potential Issue",
    Description: "When defining incremental refresh parameters in TMDL expressions, ensure RangeStart and RangeEnd parameters have explicit datetime type declarations in their metadata to prevent data type mismatch issues during incremental refresh operations.",
    References: [
        {
            Description: "Troubleshoot incremental refresh - Data type mismatch",
            Link: "https://learn.microsoft.com/en-us/power-bi/connect-data/incremental-refresh-troubleshoot#cause-data-type-mismatch"
        },
    ],
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: TMDL_Level_PowerQueryPairing[]): ErrorObject[] => {
        // Initialize an array to collect all error objects from all pairings
        const errorObjects: ErrorObject[] = [];

        // Iterate through each TMDL PowerQuery pairing to check for parameter type issues
        for (const pairing of input) {
            // Cast the input to access AST and lexical tokens from the parsed PowerQuery result
            const aSTTokens: any = (pairing.ParseResult as ParseResult).ast;
            const lexTokens: LexedJson[] = (pairing.ParseResult as ParseResult).lexed as LexedJson[];
            logDebug("lexTokens:", lexTokens);
            // Only process if AST tokens are available and valid
            if (aSTTokens !== null && aSTTokens !== undefined) {
                // Log debugging information about the current pairing being processed
                logDebug("AST kind:", aSTTokens.kind);
                logDebug("M Code line number:", pairing.MCode.lineNumber);
                logDebug("M Code name:", pairing.MCode.name);
                
                // Check if this is a metadata expression (where parameter type declarations are found)
                if (aSTTokens.kind === "MetadataExpression" && (pairing.MCode.name === "RangeStart" || pairing.MCode.name === "RangeEnd")) {

                    // Define token sequences to check for proper datetime type declarations
                    const sequenceCheck = [
                        { kind: "KeywordHashDateTime", data: "#datetime" },
                        { kind: "LeftParenthesis", data: "(" },
                    ];

                    const sequenceCheck2 = [
                        { kind: "Identifier", data: "Type" },
                        { kind: "Equal", data: "=" },
                        { kind: "TextLiteral", data: "DateTime" },
                    ];

                    // Check if any of the valid datetime type sequences are present in the lexical tokens
                    const firstCheck = containsTokenSequence(lexTokens, sequenceCheck);
                    const secondCheck = containsTokenSequence(lexTokens, sequenceCheck2);
                    logDebug("First Check (\"DateTime\"):", firstCheck);
                    logDebug("Second Check (datetime):", secondCheck);
 

                    // If none of the valid datetime type declarations are found, flag as error
                    if (!firstCheck && !secondCheck) {
                        const errorObject: ErrorObject = {
                            positionStart: {
                                codeUnit: lexTokens[0].positionStart.codeUnit,
                                lineCodeUnit: lexTokens[0].positionStart.lineCodeUnit,
                                lineNumber: lexTokens[0].positionStart.lineNumber + pairing.MCode.lineNumber
                            },
                            positionEnd: {
                                codeUnit: lexTokens[0].positionEnd.codeUnit,
                                lineCodeUnit: lexTokens[0].positionEnd.lineCodeUnit,
                                lineNumber: lexTokens[0].positionEnd.lineNumber + pairing.MCode.lineNumber
                            }
                        };
                        errorObjects.push(errorObject); // Add the error object to the array
                    }

                } // End of RangeStart/RangeEnd identifier check
            } // End of MetadataExpression check
        } // End of AST tokens validation
        return errorObjects;
    }
};

export default useDatetimeParameterForIncrementalRefresh;