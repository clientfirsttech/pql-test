import { TMDL_Level_PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel, TMDL_Level_PowerQueryPairing } from "../../rule-types";
import { ParseResult } from "../../../parser/pq/parse-types";
import { findIdentifiers, logDebug } from "../../rule-assistance";

/**
 * Rule that checks if Foundry import mode tables should use partitioning or incremental refresh.
 * 
 * This rule identifies scenarios where:
 * - Data is being imported from Foundry (using Foundry.Contents)
 * - The table is in import mode
 * - No incremental refresh is configured
 * - Only a single partition exists
 * - The table contains datetime/date columns (indicating potential for time-based partitioning)
 * 
 * In these cases, the rule suggests using partitioning or incremental refresh to optimize performance,
 * or alternatively considering Direct Query for fact tables or Dual Mode for dimension tables.
 */
export const usePartitioningWhenImportModeFoundry: TMDL_Level_PowerQueryRule = {
    ID: "use-partitioning-when-import-mode-foundry",
    Name: "Use Partitioning When Importing Data from Foundry",
    Category: "Best Practice",
    Description: "When importing data from Foundry, use partitioning or incremental refresh to optimize performance. Alternatively consider using Direct Query (Fact Table) or Dual Mode (Dimension Table) for large datasets.",
    References: [
        {
            Link: "https://www.palantir.com/docs/foundry/analytics-connectivity/power-bi-faqs#how-do-i-optimize-usage-of-the-connector-across-import-and-directquery-modes"
            , Description: "How do I optimize usage of the connector across Import and DirectQuery modes?"
        }
    ],
    Severity: SeverityLevel.Warning,
    MinLicenseLevel: LicenseLevel.Pro,
    Check: (input: TMDL_Level_PowerQueryPairing[]): ErrorObject[] => {
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        // Identifiers to search for with Foundry - these indicate Foundry data sources
        const databaseIdentifiers = [
            "Foundry.Contents"  // Foundry connector
        ];

        // Iterate through each pairing to check for optimization opportunities
        for (const pairing of input) {
            // Cast to access the properties from the parsed PowerQuery result
            const lexTokens: LexedJson[] = (pairing.ParseResult as ParseResult).lexed as LexedJson[];
            const aSTTokens: any = (pairing.ParseResult as ParseResult).ast;
            const associatedTable = pairing.AssociatedTable;
            
            // Check table configuration properties
            const noIncrementalRefresh = (associatedTable?.properties?.isIncremental || false) === false;
            const isImportMode = pairing.MCode.properties?.mode?.toLowerCase() === "import";
            const isHidden = (associatedTable?.properties?.isHidden || false) === true;
            const hasDateTimeColumns = associatedTable?.columns ? associatedTable.columns.filter(col => 
                col && col.dataType?.toLowerCase() === 'datetime' || col && col.dataType?.toLowerCase() === 'date').length > 0 : false;
            
            logDebug('table name', associatedTable?.name);
            logDebug('isImportMode:', isImportMode);
            logDebug('hasDateTimeColumns:', JSON.stringify(associatedTable?.columns));

            const numberOfPartitions = associatedTable?.partitions?.length || 0;

            // Only flag tables that meet all criteria for potential optimization
            if (isImportMode && noIncrementalRefresh && numberOfPartitions === 1 && hasDateTimeColumns && !isHidden) {
                // Search for Foundry identifiers in the M code
                databaseIdentifiers.forEach((identifier) => {
                    const databaseFind: LexedJson[] = findIdentifiers(lexTokens, identifier) ?? [];

                    databaseFind.forEach(element => {
                        logDebug('Foundry connector found:', element);

                        // Calculate the start position, adjusting for the M code's position in the TMDL file
                        const tempStartPosition = {
                            codeUnit: element.positionStart.codeUnit,
                            lineCodeUnit: element.positionStart.lineCodeUnit,
                            lineNumber: element.positionStart.lineNumber + pairing.MCode.lineNumber
                        };

                        // Calculate the end position, adjusting for the M code's position in the TMDL file
                        const tempEndPosition = {
                            codeUnit: element.positionEnd.codeUnit,
                            lineCodeUnit: element.positionEnd.lineCodeUnit,
                            lineNumber: element.positionEnd.lineNumber + pairing.MCode.lineNumber
                        };

                        // Create an error object to flag this optimization opportunity
                        errorObjects.push({
                            positionStart: tempStartPosition,
                            positionEnd: tempEndPosition
                        });
                    });
                });
            }
        }

        // Return all collected error objects
        return errorObjects;
    }
};

export default usePartitioningWhenImportModeFoundry;