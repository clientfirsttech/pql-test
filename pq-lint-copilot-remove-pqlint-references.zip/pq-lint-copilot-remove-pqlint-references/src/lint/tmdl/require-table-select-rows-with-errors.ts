import { TMDL_Level_PowerQueryRule, LexedJson, ErrorObject, SeverityLevel, LicenseLevel, TMDL_Level_PowerQueryPairing } from "../rule-types"
import { ParseResult } from "../../parser/pq/parse-types";
import { findIdentifiers, logDebug } from "../rule-assistance";

// Type definition for pairing detection results
type PairingDetection = {
    LexedJson: LexedJson;
    LineNumber: number;
};

// Create a Rule object
export const requireTableSelectRowsWithErrors: TMDL_Level_PowerQueryRule = {
    ID: "require-table-select-rows-with-errors", // Unique identifier for the rule
    Name: "When Table.RemoveRowsWithErrors is used, please consider having an exception report table.", // Rule name
    Category: "Best Practice", // Rule category
    Description: "Table.RemoveRowsWithErrors can be a convenient way to remove errors, but you should consider creating an exception table to identify the records you are removing from the model.", // Rule description
    References: [
        {
            Description: "Chapter 12 - The Definitive Guide to Power Query (M)",
            Link: "https://amzn.to/43zc4ye"
        },
        {
            Description: "Exception Reporting in Power BI: Catch the Error Rows in Power Query",
            Link: "https://radacad.com/exception-reporting-in-power-bi-catch-the-error-rows-in-power-query/"
        }

    ],
    Severity: SeverityLevel.Warning, // Severity level of the rule
    MinLicenseLevel: LicenseLevel.Pro, // Minimum license level required to use the rule
    Check: (input: TMDL_Level_PowerQueryPairing[]): ErrorObject[] => {
        const errorObjects: ErrorObject[] = [];

        const removeRowsWithErrorsInstances: PairingDetection[] = [];
        const selectRowsWithErrorsInstances: PairingDetection[] = [];
        for (const pairing of input) {
            // Cast to access the properties
            const lexTokens: LexedJson[] = (pairing.ParseResult as ParseResult).lexed as LexedJson[];
            // Find all instances and append to the array
            const foundRemove = findIdentifiers(lexTokens, "Table.RemoveRowsWithErrors") ?? [];
            const foundSelect = findIdentifiers(lexTokens, "Table.SelectRowsWithErrors") ?? [];
            logDebug(`Found ${foundRemove.length} instances of Table.RemoveRowsWithErrors and ${foundSelect.length} instances of Table.SelectRowsWithErrors in line ${pairing.MCode.lineNumber}`);
            for (const instance of foundRemove) {
                // Calculate the start position
                removeRowsWithErrorsInstances.push({
                    LexedJson: instance,
                    LineNumber: pairing.MCode.lineNumber + instance.positionStart.lineNumber
                });
            }// end for

            for (const instance of foundSelect) {
                // Calculate the start position
                selectRowsWithErrorsInstances.push({
                    LexedJson: instance,
                    LineNumber: pairing.MCode.lineNumber + instance.positionEnd.lineNumber
                });
            }// end for
        }

        // If there are no instances of Table.SelectRowsWithErrors, but several instances of Table.RemoveRowsWithErrors, we can return an error object
        if (removeRowsWithErrorsInstances.length >= 1 && selectRowsWithErrorsInstances.length == 0) {
            for (const instance of removeRowsWithErrorsInstances) {
                    // Calculate the start position
                    const tempStartPosition =  { 
                            codeUnit: instance.LexedJson.positionStart.codeUnit, 
                            lineCodeUnit: instance.LexedJson.positionStart.lineCodeUnit, 
                            lineNumber: instance.LineNumber }

                    // Calculate the end position
                    const tempEndPosition =  { 
                            codeUnit: instance.LexedJson.positionEnd.codeUnit, 
                            lineCodeUnit: instance.LexedJson.positionEnd.lineCodeUnit, 
                            lineNumber: instance.LineNumber }                            
                    
                    // Create an error object
                    errorObjects.push({
                        // add for offset
                        positionStart: tempStartPosition,
                        positionEnd: tempEndPosition
                    });
            }
        }

        // Return all collected error objects
        return errorObjects;
    }
};

export default requireTableSelectRowsWithErrors;