import { TMDL_Level_PowerQueryRule, ErrorObject, LexedJson, SeverityLevel, LicenseLevel, TMDL_Level_PowerQueryPairing } from "../rule-types";
import { ParseResult } from "../../parser/pq/parse-types";
import { findIdentifiers } from "../rule-assistance";

// Create a Rule object
export const detectRExecute: TMDL_Level_PowerQueryRule = {
    ID: "detect-r-execute",
    Name: "TMDL Script with R.Execute Detected",
    Category: "Potential Issue",
    Description: "Before running the script, check that the script is intended. If you disable the requiring user approval for native scripts, this could execute code you don't want to run.",
    References: [],
    Severity: SeverityLevel.Error,
    MinLicenseLevel: LicenseLevel.Free,
    Check: (input: TMDL_Level_PowerQueryPairing[]): ErrorObject[] => {
        // Initialize an array to collect all error objects
        const errorObjects: ErrorObject[] = [];

        for (const pairing of input) {
            // Cast to access the properties
            const lexTokens: LexedJson[] = (pairing.ParseResult as ParseResult).lexed as LexedJson[];
            const rFind: LexedJson[] = findIdentifiers(lexTokens, "R.Execute") ?? [];

            // Add to list
            rFind.forEach(element => {
                // Calculate the start position
                const tempStartPosition = {
                    codeUnit: element.positionStart.codeUnit,
                    lineCodeUnit: element.positionStart.lineCodeUnit,
                    lineNumber: element.positionStart.lineNumber + pairing.MCode.lineNumber
                };

                // Calculate the end position
                const tempEndPosition = {
                    codeUnit: element.positionEnd.codeUnit,
                    lineCodeUnit: element.positionEnd.lineCodeUnit,
                    lineNumber: element.positionEnd.lineNumber + pairing.MCode.lineNumber
                };

                // Create an error object
                errorObjects.push({
                    positionStart: tempStartPosition,
                    positionEnd: tempEndPosition
                });
            });
        }

        // Return all collected error objects
        return errorObjects;
    }
};

export default detectRExecute;