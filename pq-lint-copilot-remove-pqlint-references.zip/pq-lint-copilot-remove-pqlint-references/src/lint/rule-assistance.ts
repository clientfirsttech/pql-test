import { log } from "console";
import { LexedJson, ErrorObject } from "./rule-types";

// A constant to enable or disable debug logging throughout the application.
// Set to `true` to enable debug logs, or `false` to disable them.
const DEBUG = true; // Set to false to disable debug logs

/**
 * Logs debug messages to the console if the `DEBUG` constant is set to `true`.
 * 
 * @param args - The arguments to log. Can be any number of arguments of any type.
 * 
 * Usage:
 * - Use this function instead of `logDebug` to ensure debug logs are only printed
 *   when debugging is enabled.
 * - Example: `logDebug("Debug message", someVariable);`
 */
export function logDebug(...args: any[]): void {
    if (process.env.DEBUG || true) { // Use process.env.DEBUG to check if debugging is enabled
        console.log(...args); // Correctly call console.log instead of logDebug
    }
}

// Object containing reusable regex patterns for various checks
export const RegexPatternsForConstants = {
    // Regex to match local file paths (e.g., "C:\path\to\file" or "\\server\share\file")
    localFilePath: /^"([a-zA-Z]:\\|\\\\)[\w\s\\\-\.]+"?/,

    // Regex to match URLs (e.g., "https://example.com" or "http://example.com:8080/path")
    url: /^"https?:\/\/[\w\-\.]+(\.[a-z]{2,3})?(:\d+)?(\/\S*)?"$/,

    // Regex to match database paths (e.g., "server.database.table")
    databasePath: /^"[a-zA-Z0-9\-]{1,}(\.[a-zA-Z0-9\-]+)*(:\d+)?(\/[a-zA-Z0-9\-_\/]*)?\"?$/,

    // Regex to match Azure Service Principal client secrets (e.g., "PfY8Q~jmPJ2si69HsBo.rzZbbxY9z_hUc1vwVa1D")
    clientSecretRegex: /^"[A-Za-z0-9._~+=/-]{20,128}"$/,

    // Regex to match API keys (e.g
    apiKeyRegex: /^"[a-f0-9]{32}"$/,    

    // Regex to match GUIDs (e.g., "9658004c-8083-4630-a7f4-3cb30c95db23")
    guidRegex: /^"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"$/,

    // Regex to match parameters that only have letters, numbers, and underscores
    parameterRegex: /^[a-zA-Z_]\w*$/,

    // Domain ending
    domainEndingRegex: /\.(com|net|org|gov|edu|mil|int|[a-z]{2})"$/

};


/**
 * Finds all tokens with the given kind and data in the lexedJson array.
 * 
 * @param lexedJson - The array of lexed tokens to search.
 * @param kind - The kind of token to search for (e.g., "TextLiteral").
 * @param targetData - The specific data string to search for in the tokens.
 * @returns An array of matching tokens. If no matches are found, returns an empty array.
 */
export function findAllSpecificTokens(lexedJson: any[], kind: string, targetData: string): any[] {
    const matchingTokens: any[] = [];

    for (const token of lexedJson) {
        // Check if the token matches the specified kind and data
        if (token.kind === kind && token.data === targetData) {
            matchingTokens.push(token);
        }
    }

    return matchingTokens;
}


/**
 * Checks if a specific sequence of tokens exists in the lexedJson array.
 * 
 * @param lexedJson - The array of lexed tokens to search.
 * @param sequence - An array of objects representing the sequence to match. Each object should have `kind` and `data` properties.
 * @returns True if the sequence is found, otherwise false.
 */
export function containsTokenSequence(lexedJson: any[], sequence: { kind: string, data: string }[]): boolean {
    for (let i = 0; i <= lexedJson.length - sequence.length; i++) {
        let match = true;

        for (let j = 0; j < sequence.length; j++) {
            const token = lexedJson[i + j];
            const expected = sequence[j];

            if (token.kind !== expected.kind || token.data !== expected.data) {
                match = false;
                break;
            }
        }

        if (match) {
            return true;
        }
    }

    return false;
}

/**
 * Finds the specified identifier in the parsed data.
 * 
 * @param lexedData - The parsed data containing the lexed tokens.
 * @param identifier - The identifier to search for.
 * @returns The LexedJson object of the identifier, or null if not found.
 */
export function findIdentifiers(lexedData: LexedJson[], identifier: string): LexedJson[] | null {
    // Filter the lexedData array to collect all elements that match the identifier
    if(lexedData === undefined || lexedData === null) return [];
    
    return lexedData.filter((item: any) => item.kind === 'Identifier' && item.data === identifier);
}

/**
 * Recursively searches an Abstract Syntax Tree (AST) or a nested object structure
 * to find all nodes with `kind` equal to "FunctionExpression".
 * 
 * @param node - The root node of the AST or object to search.
 * @returns An array of nodes where `kind` is "FunctionExpression".
 */
export function findFunctionExpressions(node: any): any[] {
    let results = [];

    // Check if the current node has the desired kind
    if (node.kind === "FunctionExpression") {
        results.push(node);
    }

    // Recursively search through child nodes if they exist
    for (let key in node) {
        if (node[key] && typeof node[key] === "object") {
            results = results.concat(findFunctionExpressions(node[key]));
        }
    }

    return results;
}

export function extractParameters(functionExpression: any): { name: string; type: string }[] {
    const parameters: { name: string; type: string, positionStart: any, positionEnd: any }[] = [];

    // Check if the FunctionExpression has parameters
    if (functionExpression.parameters?.content?.elements) {
        functionExpression.parameters.content.elements.forEach((csvElement: any) => {
            logDebug("CSV Element: ", csvElement);
            const parameterNode = csvElement.node; // Access the Parameter node
            if (parameterNode?.kind === "Parameter") {
                const name = parameterNode.name?.literal || "unknown"; // Extract parameter name
                const positionStart = parameterNode.name?.tokenRange.positionStart
                const positionEnd = parameterNode.name?.tokenRange.positionEnd 
                logDebug("Paired Type: ",name, ": ", parameterNode.parameterType?.paired);
                // Extract the type from the paired type or primitive type, if nullable is before it will be primitiveTypeKind.paired.paired
                const type = parameterNode.parameterType?.paired?.primitiveTypeKind || parameterNode.parameterType?.paired?.paired?.primitiveTypeKind || "unknown"; // Extract parameter type
                parameters.push({ name, type, positionStart, positionEnd });
            }
        });
    }

    return parameters;
}



/**
 * Recursively searches an object for a snippet string and collects matching objects.
 * 
 * @param obj - The object to search.
 * @param currentPath - The current path in the object being searched.
 * @param snippetStr - The snippet string to search for.
 * @param results - An array to collect the results, each containing the path and matching object.
 * @returns An array of objects containing the path and matching object.
 */
export function searchAST(obj: any, currentPath: string, snippetStr: string, results: { path: string; match: any }[] = []): { path: string; match: any }[] {
    if (typeof obj !== 'object' || obj === null) return results;

    // Check if the current object matches the snippet
    if (JSON.stringify(obj, null, 0).includes(snippetStr)) {
        // Check if the object has the specific property we're looking for
        if (obj?.recursiveExpressions) {
            results.push({ path: currentPath, match: obj });
        }
    }

    // Recursively search in all keys of the object/array
    if (Array.isArray(obj)) {
        obj.forEach((item, index) => searchAST(item, `${currentPath}[${index}]`, snippetStr, results));
    } else {
        Object.entries(obj).forEach(([key, value]) => {
            searchAST(value, currentPath ? `${currentPath}.${key}` : key, snippetStr, results);
        });
    }

    return results;
}

/**
 * Searches for paired expression values in an object.
 *
 * @param obj - The object to search.
 * @param currentPath - The current path in the object being searched.
 * @param snippetStr - The snippet string to search for in the object.
 * @param results - An array to collect the results, each containing the path and matching object.
 * @returns An array of objects containing the path and matching object.
 */
export function searchPairedExpressionValues(
    obj: any,
    currentPath: string,
    snippetStr: string,
    results: { path: string; match: any }[] = []
): { path: string; match: any }[] {
    // Return if the object is not valid
    if (typeof obj !== 'object' || obj === null) return results;

    // Check if the current object matches the snippet
    if (JSON.stringify(obj, null, 0).includes(snippetStr)) {
        // If the object has a 'value' property, add it to the results
        if (obj?.value) {
            results.push({ path: currentPath, match: obj });
        }
    }

    // Recursively search in all keys of the object/array
    if (Array.isArray(obj)) {
        obj.forEach((item, index) =>
            searchPairedExpressionValues(item, `${currentPath}[${index}]`, snippetStr, results)
        );
    } else {
        Object.entries(obj).forEach(([key, value]) => {
            searchPairedExpressionValues(
                value,
                currentPath ? `${currentPath}.${key}` : key,
                snippetStr,
                results
            );
        });
    }

    return results;
}


/**
 * Searches for paired expressions in the AST tokens, such as patterns like `Headers[#"Authorization" = "Bearer " + Token]`.
 *
 * @param instances - The array of lexed tokens to search through.
 * @param aSTTokens - The Abstract Syntax Tree (AST) tokens to search within.
 * @param searchExpression - The expression to search for in the recursive expressions.
 * @returns An array of objects containing the matched tokens.
 */
export function findNodesWithPairedExpression(instances: LexedJson[], aSTTokens: any, searchExpression: string): any[] {
    const results: any[] = [];

    // Iterate through each instance in the lexed tokens
    instances.forEach(element => {
        // Construct the search string using the positionStart and positionEnd properties of the element
        const searchString = '"positionStart":' + JSON.stringify(element.positionStart, null, 0) + ',"positionEnd":' + JSON.stringify(element.positionEnd, null, 0);

        // Search for paired expression values in the AST tokens
        let searchResults: { path: string; match: any }[] = searchPairedExpressionValues(aSTTokens, "", searchString);

        // Process each search result
        for (const searchResult of searchResults) {
            let path = searchResult.path;
            let currentValue = getValueFromPath(aSTTokens, path);
            let checkString = JSON.stringify(currentValue?.value);

            // Check if the current value contains the search expression
            if (checkString && checkString.includes(searchExpression) === true) {
                // Perform a more specific search within the current value
                let getMoreSpecificNode = searchPairedExpressionValues(currentValue?.value, currentValue?.value.value, searchExpression);

                // Add the most specific match to the results
                if (getMoreSpecificNode.length > 0 && getMoreSpecificNode[getMoreSpecificNode.length - 1].match !== undefined) {
                    results.push(getMoreSpecificNode[getMoreSpecificNode.length - 1].match);
                }
            }
        }
    });

    return results;
}



/**
 * Extracts and sorts unique line numbers from the given lexTokens.
 * 
 * @param lexTokens - The array of lexed tokens.
 * @returns A sorted array of unique line numbers.
 */
export function getSortedUniqueLineNumbers(lexTokens: LexedJson[]): number[] {
    const uniqueLineNumbers: Set<number> = new Set();

    // Iterate through the lexTokens and collect unique line numbers
    lexTokens.forEach(token => {
        uniqueLineNumbers.add(token.positionStart.lineNumber);
        uniqueLineNumbers.add(token.positionEnd.lineNumber);
    });

    // Convert the set to an array and sort it
    return Array.from(uniqueLineNumbers).sort((a, b) => a - b);
}

/**
 * Checks for missing comments before Table.AddColumn instances.
 * 
 * @param lexTokens - The array of lexed tokens.
 * @param identifier - The identifier to search for.
 * @returns An array of error objects indicating missing comments.
 */
export function checkMissingComments(lexTokens: LexedJson[], identifier: string): ErrorObject[] {
    const sortedUniqueLineNumbers = getSortedUniqueLineNumbers(lexTokens);
    const errorObjects: ErrorObject[] = [];

    // Identify the instances of the identifier in the lexTokens
    const instances = lexTokens.filter((current) => {
        return current.kind === "Identifier" && current.data === identifier;
    });

    // Iterate through each instance
    instances.forEach(element => {
        const positionLineNum: number = element.positionStart.lineNumber;
        const previousLineExists: boolean = sortedUniqueLineNumbers.includes(positionLineNum - 1);
        logDebug("Position Line Number: ", positionLineNum);
        logDebug(positionLineNum - 1);
        logDebug(previousLineExists);
        if (previousLineExists) {
            // If the previous line does exist, this indicates the comment is missing, add an error object
            const errorObject: ErrorObject = {
                positionStart: element.positionStart,
                positionEnd: element.positionEnd
            };
            errorObjects.push(errorObject);
        }
    });

    return errorObjects;
}


/**
 * Recursively searches an object for parent nodes with a specific literal value.
 * 
 * @param node - The object to search.
 * @param literal - The literal value to search for.
 * @returns An array of parent nodes with the specified literal value.
 * */
export function findParentNodesWithLiteral(node: any, literal: string): any[] {
    let results: any[] = [];
    if (node.kind === "IdentifierExpression" && node.identifier?.literal === literal) {
        results.push(node);
    }
    if (node.recursiveExpressions?.elements) {
        for (const element of node.recursiveExpressions.elements) {
            results = results.concat(findParentNodesWithLiteral(element, literal));
        }
    }
    // Recursively search through all properties of the node
    for (const key in node) {
        if (node[key] && typeof node[key] === "object") {
            results = results.concat(findParentNodesWithLiteral(node[key], literal));
        }
    }
    return results;
}

/**
 * Extracts the parent path from a given path string.
 * 
 * @param path - The full path string (e.g., "variableList.elements[5].node.value").
 * @returns The parent path string (e.g., "variableList.elements[5].node").
 */
export function getParentPath(path: string): string {
    const pathParts = path.split('.'); // Split the path into parts
    pathParts.pop(); // Remove the last part (e.g., "value")
    return pathParts.join('.'); // Rejoin the remaining parts
}

/**
 * Navigates an object structure based on a given path string.
 * 
 * @param obj - The object to navigate.
 * @param path - The path string (e.g., "variableList.elements[5].node.value").
 * @returns The value at the specified path, or undefined if the path is invalid.
 */
export function getValueFromPath(obj: any, path: string): any {
    const pathParts = path.split('.'); // Split the path into parts
    let currentNode = obj;

    for (const part of pathParts) {
        // Check if the current part is an array index (e.g., elements[5])
        const arrayMatch = part.match(/^(\w+)\[(\d+)\]$/);
        if (arrayMatch) {
            const arrayKey = arrayMatch[1]; // e.g., "elements"
            const arrayIndex = parseInt(arrayMatch[2], 10); // e.g., 5
            if (!currentNode[arrayKey] || !Array.isArray(currentNode[arrayKey]) || currentNode[arrayKey].length <= arrayIndex) {
                return undefined; // Invalid array access
            }
            currentNode = currentNode[arrayKey][arrayIndex];
        } else {
            // Navigate to the next property
            if (!currentNode[part]) {
                return undefined; // Invalid property access
            }
            currentNode = currentNode[part];
        }
    }

    return currentNode; // Return the final value
}

/**
 * 
 * @param instances - The array of lexed tokens to search through.
 * @param aSTTokens - The Abstract Syntax Tree (AST) tokens.
 * @param searchExpression - The expression to search for in the recursive expressions.
 * @returns     An array of objects containing the matched tokens.    
 */
export function findNodesWithRecursiveExpression(instances: LexedJson[], aSTTokens: any, searchExpression: string): any[] {
    const results: any[] = [];
    instances.forEach(element => {
    // Construct the search string using the properties of the element
    const searchString = '"positionStart":'+JSON.stringify(element.positionStart,null,0)+',"positionEnd":'+JSON.stringify(element.positionEnd,null,0);
    //logDebug("Search String: ", searchString);
    let searchResults: {path: string; match: any}[] = searchAST(aSTTokens, "", searchString);                    
    //logDebug("Initial Search Results", searchExpression, JSON.stringify(searchResults));
    for (const searchResult of searchResults) {
        let path = searchResult.path;
        let parentPath = getParentPath(path);
        let parentValue = getValueFromPath(aSTTokens, parentPath);
        let checkString = JSON.stringify(parentValue?.value?.recursiveExpressions?.elements);
        
        if(checkString && checkString.includes(searchExpression) === true){
            let getMoreSpecificNode = searchAST(parentValue,parentValue?.value?.recursiveExpressions?.elements,searchExpression);
            //logDebug("More Specific Node Search Results",searchExpression, JSON.stringify(getMoreSpecificNode));
            results.push(getMoreSpecificNode[getMoreSpecificNode.length - 1].match);
        }
    }
});

return results;

}



/**
 * Finds instances of the Table.Buffer pattern in the lexed data.
 * 
 * @param lexedData - The array of lexed tokens to search through.
 * @returns An array of objects containing the matched tokens.
 */
export function findTableBufferPattern(lexedData: any[]): any[] {
    const results: any[] = [];

    // Iterate through the lexedData array
    for (let i = 0; i < lexedData.length - 2; i++) {
        // Ensure we have at least 3 elements to check the pattern
        const current = lexedData[i];
        const next = lexedData[i + 1];
        const nextNext = lexedData[i + 2];

        // Check for the pattern: Identifier -> Equal -> Identifier (Table.Buffer)
        if (
            current.kind === "Identifier" &&
            next.kind === "Equal" &&
            nextNext.kind === "Identifier" &&
            nextNext.data === "Table.Buffer"
        ) {
            results.push(current);
        }
    }

    return results;
}

/**
 * Recursively traverses an Abstract Syntax Tree (AST) to find all function calls.
 * 
 * @param ast - The root node of the Abstract Syntax Tree (AST) to search.
 * @param sliceNumber - (Optional) The number of function calls to return from the end of the list.
 *                      If not provided, all function calls are returned.
 * @returns An array of strings representing the function calls found in the AST.
 * 
 * Usage:
 * - This function identifies function calls in the AST by looking for nodes of kind "IdentifierExpression"
 *   that contain a dot (e.g., "Table.AddColumn") and excludes hash-prefixed or quoted variables.
 * - If `sliceNumber` is provided, only the last `sliceNumber` function calls are returned.
 * 
 * Example:
 * ```typescript
 * const ast = { ... }; // Your AST structure
 * const functionCalls = findFunctionCallsInAST(ast, 5);
 * console.log(functionCalls); // Logs the last 5 function calls found in the AST
 * ```
 */
export function findFunctionCallsInAST(ast: any, sliceNumber?: number): string[] {
    const functionCalls: string[] = [];

    function traverse(node: any) {
        if (!node || typeof node !== "object") return;

        // Check if the node is a function call
        // Check if the node is a function call
        if (
            node.kind === "IdentifierExpression" &&
            node.identifier?.literal &&
            node.identifier.literal.includes(".") && // Ensure it contains a dot
            !node.identifier.literal.startsWith("#") && // Exclude hash-prefixed variables
            !node.identifier.literal.startsWith('"') && // Exclude double-quoted variables
            !node.identifier.literal.startsWith('#"') // Exclude escaped double-quoted variables
        ) {
            functionCalls.push(node.identifier);
        }

        // Recursively traverse child nodes
        for (const key in node) {
            if (node[key] && typeof node[key] === "object") {
                traverse(node[key]);
            }
        }
    }

    // Start traversal from the root AST node
    traverse(ast);

    // Return all function calls if sliceNumber is not provided, otherwise slice
    return sliceNumber ? functionCalls.slice(-1 * sliceNumber) : functionCalls;
}


/**
 * Finds the parameters for a specific function call in the AST.
 * 
 * @param element - The AST node representing the function call.
 * @param aSTTokens - The Abstract Syntax Tree (AST) tokens to search within.
 * @returns An array of parameter nodes for the specified function call.
 */
export function findParametersInASTForFunctionCall(element: any, aSTTokens: any): any[] {
    // Return an empty array if the element is undefined
    if (element === undefined) return [];
    
    // Construct the search string using the positionStart and positionEnd properties of the element
    const searchString = '"positionStart":' + JSON.stringify(element?.tokenRange?.positionStart, null, 0) + 
                         ',"positionEnd":' + JSON.stringify(element?.tokenRange?.positionEnd, null, 0);
    
    // Search the AST tokens for matches based on the constructed search string
    let searchResults: { path: string; match: any }[] = searchAST(aSTTokens, "", searchString);   
    
    // Initialize an array to store the extracted parameters
    const parameters: any[] = [];

    // Iterate through the search results
    searchResults.forEach((result) => {
        // Extract the recursive expressions and their elements
        for (let i = 0; i < result.match?.recursiveExpressions?.elements[0].content?.elements.length; i++) {
            // Push the node of each element into the parameters array
            parameters.push(result.match?.recursiveExpressions?.elements[0].content?.elements[i]?.node);
        } // end for
    });

    // Return the collected parameters
    return parameters;
}

// Temporary function to get the parent kind recursively
// Used for debugging purposes and finding FieldSelector for records
function getParentKindRecursively(astTokens: any, path: string): string[] {
    const kinds: string[] = [];
    let currentPath = path;

    while (currentPath) {
        // Get the parent path
        const parentPath = getParentPath(currentPath);

        // Retrieve the parent value from the AST
        const parentValue = getValueFromPath(astTokens, parentPath);

        // If the parent exists, get its kind and add it to the list
        if (parentValue?.kind) {
            kinds.push(parentValue.kind);
            kinds.push(parentValue?.identifier?.literal);
        }

        // Update the current path to the parent path for the next iteration
        currentPath = parentPath;
    }

    return kinds;
}


/**
 * Checks for missing culture parameters in specific Power Query text functions.
 * @param aSTTokens The AST tokens.
 * @param instances The lexed identifier instances to check.
 * @returns Array of ErrorObject for each instance missing a culture parameter.
 */
export function checkCultureForFunctionInstances(
    aSTTokens: any,
    instances: LexedJson[],
    thirdArgumentFunctions: string[] = []
): ErrorObject[] {
    const errorObjects: ErrorObject[] = [];

    instances.forEach(element => {
        const tempArray: any[] = [];
        tempArray.push(element);
        logDebug("Element: ", element);

        // Construct the search string using the properties of the element
        const searchString =
            '"positionStart":' +
            JSON.stringify(element.positionStart, null, 0) +
            ',"positionEnd":' +
            JSON.stringify(element.positionEnd, null, 0);
        let searchResults: { path: string; match: any }[] = searchAST(aSTTokens, "", searchString);
        if (searchResults.length > 0) {
            const result = searchResults[searchResults.length - 1];
            logDebug("Search Result: ", JSON.stringify(result));
            if (thirdArgumentFunctions.includes(element.data) === false) {
                const test1 = result.match.recursiveExpressions?.elements[0]?.content?.elements[1]?.node?.literal;
                const test2 = result.match.recursiveExpressions?.elements[0]?.content?.elements[1]?.node?.identifier?.literal;

                // Check if the culture parameter is found, and if not, add an error object
                if (test1 == undefined && test2 == undefined) {
                    const errorObject: ErrorObject = {
                        positionStart: element.positionStart,
                        positionEnd: element.positionEnd
                    };
                    errorObjects.push(errorObject);
                }
            } else {
                // check for culture in the third argument
                const test1 = result.match.recursiveExpressions?.elements[0]?.content?.elements[2]?.node?.identifier?.literal;
                const test2 = result.match.recursiveExpressions?.elements[0]?.content?.elements[2]?.node.literal;
                const cultureRecordUsage = findNodesWithRecursiveExpression(tempArray, aSTTokens, '"literal":"Culture"');

                // Check if the culture parameter is found, and if not, add an error object
                if (test1 == undefined && test2 == undefined && cultureRecordUsage.length === 0) {
                    const errorObject: ErrorObject = {
                        positionStart: element.positionStart,
                        positionEnd: element.positionEnd
                    };
                    errorObjects.push(errorObject);
                }
            }
        }
    });

    return errorObjects;
}