/**
 * License Manager — Hybrid Validation (Option C)
 *
 * Implements local JWT-style license validation with a **commented-out** periodic
 * cloud sync hook.  The local validation is the primary gate; the cloud sync
 * (when enabled) provides revocation and usage-tracking capabilities.
 *
 * ## Architecture
 *
 * 1. **Local validation (active)**
 *    - License data is a signed JSON payload stored on disk (`~/.pqlintrc`),
 *      in an environment variable (`PQL_LICENSE_KEY`), or passed directly.
 *    - The payload contains tier, expiry, and a signature that is checked
 *      against a public key embedded in the binary.
 *    - Validation is synchronous and completes in <1 ms.
 *
 * 2. **Periodic cloud sync (commented out)**
 *    - When enabled, the manager will phone home once every N hours to
 *      validate the key hasn't been revoked and to refresh the expiry.
 *    - A grace period allows offline usage after the last successful sync.
 *
 * ## Storage locations
 *
 * | Channel           | Primary                     | Fallback                |
 * |-------------------|-----------------------------|-------------------------|
 * | CLI               | `~/.pqlintrc` JSON file     | `PQL_LICENSE_KEY` env   |
 * | Azure Functions   | App setting / Key Vault     | Query-param `mode`      |
 * | VS Code Extension | VS Code settings (future)   | Workspace config        |
 *
 * ## Usage
 *
 * ```ts
 * import { LicenseManager } from './license-manager';
 *
 * const mgr = LicenseManager.getInstance();
 * const tier = mgr.getCurrentLicense();   // LicenseLevel.Free | Pro | Premium
 * const ok  = mgr.canLintTMDL();          // boolean
 * ```
 */

import { LicenseLevel } from './rule-types';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** Shape of the JSON stored in `~/.pqlintrc`. */
export interface LicensePayload {
    /** The license key string (opaque to the caller). */
    key: string;
    /** Tier the key unlocks. */
    tier: LicenseLevel;
    /** ISO-8601 expiry timestamp. */
    expiresAt: string;
    /** Signature covering `key + tier + expiresAt` (placeholder for real crypto). */
    signature: string;
    /** ISO-8601 timestamp of last successful cloud sync (used by periodic check). */
    lastSyncAt?: string;
}

/** Result returned by every validation attempt. */
export interface LicenseValidationResult {
    /** Whether the license is considered valid right now. */
    valid: boolean;
    /** Resolved tier after validation. Falls back to FREE on failure. */
    tier: LicenseLevel;
    /** Human-readable explanation (useful for CLI output / logs). */
    message: string;
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/** Default path to the per-user license file. */
const DEFAULT_LICENSE_FILE = path.join(os.homedir(), '.pqlintrc');

/** Environment variable that can hold the raw license key. */
const LICENSE_ENV_VAR = 'PQL_LICENSE_KEY';

/**
 * Grace period (in hours) after the last cloud sync before we downgrade the
 * user to FREE.  Only relevant when periodic cloud sync is enabled.
 */
const CLOUD_SYNC_GRACE_HOURS = 72; // 3 days

// ---------------------------------------------------------------------------
// LicenseManager (Singleton)
// ---------------------------------------------------------------------------

export class LicenseManager {
    private static instance: LicenseManager | null = null;

    /** Cached payload from last successful read. */
    private cachedPayload: LicensePayload | null = null;

    /** Path to the license file (overridable for tests). */
    private licenseFilePath: string;

    // -- Construction -------------------------------------------------------

    private constructor(licenseFilePath?: string) {
        this.licenseFilePath = licenseFilePath ?? DEFAULT_LICENSE_FILE;
    }

    /** Get the singleton instance. */
    static getInstance(): LicenseManager {
        if (!LicenseManager.instance) {
            LicenseManager.instance = new LicenseManager();
        }
        return LicenseManager.instance;
    }

    /**
     * Create an instance with a custom config path (useful for unit tests).
     * Does NOT replace the singleton.
     */
    static createForTesting(licenseFilePath: string): LicenseManager {
        return new LicenseManager(licenseFilePath);
    }

    /** Reset the singleton (for tests). */
    static resetInstance(): void {
        LicenseManager.instance = null;
    }

    // -- Public API ---------------------------------------------------------

    /**
     * Read and validate the license, returning the resolved tier.
     * Falls back to `LicenseLevel.Free` if anything goes wrong.
     */
    getCurrentLicense(): LicenseValidationResult {
        const payload = this.loadPayload();
        if (!payload) {
            return {
                valid: false,
                tier: LicenseLevel.Free,
                message: 'No license found. Running in FREE mode.'
            };
        }
        return this.validatePayload(payload);
    }

    /**
     * Convenience: returns `true` when the current license permits TMDL linting.
     */
    canLintTMDL(): boolean {
        return this.getCurrentLicense().tier >= LicenseLevel.Pro;
    }

    /**
     * Write a new license payload to disk (e.g. from `pql-lint activate <key>`).
     *
     * @param payload - The license data to persist.
     */
    activate(payload: LicensePayload): void {
        const dir = path.dirname(this.licenseFilePath);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(this.licenseFilePath, JSON.stringify(payload, null, 2), 'utf-8');
        this.cachedPayload = payload;
    }

    /**
     * Remove the stored license (e.g. from `pql-lint deactivate`).
     */
    deactivate(): void {
        if (fs.existsSync(this.licenseFilePath)) {
            fs.unlinkSync(this.licenseFilePath);
        }
        this.cachedPayload = null;
    }

    /**
     * Return a display string suitable for `pql-lint --version` output.
     * Example: `"pql-lint v1.0.0 (PRO)"`
     */
    getTierLabel(): string {
        const tier = this.getCurrentLicense().tier;
        switch (tier) {
            case LicenseLevel.Premium:
                return 'PREMIUM';
            case LicenseLevel.Pro:
                return 'PRO';
            default:
                return 'FREE';
        }
    }

    // -- Internal helpers ---------------------------------------------------

    /**
     * Attempt to load the license payload from the file system or env var.
     */
    private loadPayload(): LicensePayload | null {
        // 1. Check cached value
        if (this.cachedPayload) {
            return this.cachedPayload;
        }

        // 2. Try reading from disk
        try {
            if (fs.existsSync(this.licenseFilePath)) {
                const raw = fs.readFileSync(this.licenseFilePath, 'utf-8');
                const parsed = JSON.parse(raw) as LicensePayload;
                this.cachedPayload = parsed;
                return parsed;
            }
        } catch {
            // Corrupt file — fall through
        }

        // 3. Try env var
        const envKey = process.env[LICENSE_ENV_VAR];
        if (envKey) {
            try {
                const parsed = JSON.parse(envKey) as LicensePayload;
                this.cachedPayload = parsed;
                return parsed;
            } catch {
                // Malformed env var — fall through
            }
        }

        return null;
    }

    /**
     * Validate the payload locally (signature, expiry, grace period).
     */
    private validatePayload(payload: LicensePayload): LicenseValidationResult {
        // --- 1. Verify signature (placeholder — replace with real crypto) ---
        if (!this.verifySignature(payload)) {
            return {
                valid: false,
                tier: LicenseLevel.Free,
                message: 'License signature verification failed. Running in FREE mode.'
            };
        }

        // --- 2. Check expiry ---
        const now = new Date();
        const expiry = new Date(payload.expiresAt);
        if (isNaN(expiry.getTime()) || expiry < now) {
            return {
                valid: false,
                tier: LicenseLevel.Free,
                message: 'License has expired. Running in FREE mode. Please renew your license.'
            };
        }

        // --- 3. (Commented out) Periodic cloud sync check ---
        // When this is enabled, the manager verifies the lastSyncAt timestamp
        // is within the grace window.  If the user has been offline longer than
        // CLOUD_SYNC_GRACE_HOURS, we downgrade to FREE and queue a sync.
        //
        // const syncResult = this.checkCloudSyncGracePeriod(payload);
        // if (!syncResult.valid) {
        //     return syncResult;
        // }

        // --- 4. All checks passed ---
        return {
            valid: true,
            tier: payload.tier,
            message: `License valid. Running in ${LicenseLevel[payload.tier].toUpperCase()} mode.`
        };
    }

    /**
     * Placeholder signature verification.
     *
     * TODO: Replace with real HMAC-SHA256 or RSA-PSS verification once the
     * license-issuing server is set up.  The public key will be embedded in the
     * obfuscated bundle.
     *
     * For now, any non-empty signature string passes.
     */
    private verifySignature(payload: LicensePayload): boolean {
        return typeof payload.signature === 'string' && payload.signature.length > 0;
    }

    // -- Cloud sync via Keygen (commented out — Option C periodic check) -----
    //
    // See `src/lint/keygen-integration.ts` for Keygen-specific API functions.
    // See `docs/keygen-setup-guide.md` for step-by-step Keygen account setup.
    //
    // To enable:
    //   1. Set KEYGEN_ACCOUNT_ID and KEYGEN_PRODUCT_ID in keygen-integration.ts
    //   2. Uncomment checkCloudSyncGracePeriod and syncWithKeygen below
    //   3. Uncomment the grace-period check in validatePayload (step 3)

    // /**
    //  * Check whether the last cloud sync is within the grace window.
    //  *
    //  * @param payload - The local license payload.
    //  * @returns A validation result; invalid if grace period exceeded.
    //  */
    // private checkCloudSyncGracePeriod(payload: LicensePayload): LicenseValidationResult {
    //     if (!payload.lastSyncAt) {
    //         return {
    //             valid: false,
    //             tier: LicenseLevel.Free,
    //             message: 'License has never been synced with the server. Please connect to the internet and retry.'
    //         };
    //     }
    //
    //     const lastSync = new Date(payload.lastSyncAt);
    //     const now = new Date();
    //     const hoursSinceSync = (now.getTime() - lastSync.getTime()) / (1000 * 60 * 60);
    //
    //     if (hoursSinceSync > CLOUD_SYNC_GRACE_HOURS) {
    //         return {
    //             valid: false,
    //             tier: LicenseLevel.Free,
    //             message: `License not synced for ${Math.round(hoursSinceSync)} hours (grace period: ${CLOUD_SYNC_GRACE_HOURS}h). Running in FREE mode. Please connect to the internet.`
    //         };
    //     }
    //
    //     return { valid: true, tier: payload.tier, message: '' };
    // }

    // /**
    //  * Perform a cloud sync via the Keygen API.
    //  *
    //  * This is the periodic phone-home mechanism.  When enabled, it should be
    //  * called:
    //  *   - On every CLI invocation (non-blocking, fire-and-forget)
    //  *   - On every Azure Function cold start
    //  *
    //  * Requires: import { syncLicenseWithKeygen } from './keygen-integration';
    //  *
    //  * @returns Updated validation result after cloud check.
    //  */
    // async syncWithKeygen(): Promise<LicenseValidationResult> {
    //     const payload = this.loadPayload();
    //     if (!payload) {
    //         return {
    //             valid: false,
    //             tier: LicenseLevel.Free,
    //             message: 'No license to sync.'
    //         };
    //     }
    //
    //     const { result, payload: updatedPayload } = await syncLicenseWithKeygen(payload.key);
    //
    //     if (result.valid && updatedPayload) {
    //         // Refresh the local license file with the latest data from Keygen
    //         this.activate(updatedPayload);
    //     } else if (!result.valid) {
    //         // Key was revoked on Keygen — remove local license
    //         this.deactivate();
    //     }
    //
    //     return result;
    // }
}
