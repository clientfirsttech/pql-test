import { LicenseLevel } from './rule-types';

/**
 * Filters an array of rules to only include those permitted at the given license level.
 *
 * Rules are permitted when their `MinLicenseLevel` is less than or equal to the caller's
 * active license level.  For example:
 *   - A FREE-tier caller receives only rules marked `LicenseLevel.Free`.
 *   - A PRO-tier caller receives rules marked `LicenseLevel.Free` OR `LicenseLevel.Pro`.
 *   - A PREMIUM-tier caller receives all rules.
 *
 * @param rules - Array of rules that each expose a `MinLicenseLevel` property.
 * @param licenseLevel - The active license level of the calling user.
 * @returns A new array containing only the rules permitted at the given tier.
 */
export function filterRulesByLicense<T extends { MinLicenseLevel: LicenseLevel }>(
    rules: T[],
    licenseLevel: LicenseLevel
): T[] {
    return rules.filter(rule => rule.MinLicenseLevel <= licenseLevel);
}

/**
 * Returns `true` when TMDL linting is permitted for the given license level.
 *
 * TMDL linting is a PRO (and above) feature.  FREE-tier users must receive a
 * clear upgrade message rather than a generic error.
 *
 * @param licenseLevel - The active license level of the calling user.
 * @returns `true` if TMDL linting is allowed; `false` otherwise.
 */
export function isTMDLLintingAllowed(licenseLevel: LicenseLevel): boolean {
    return licenseLevel >= LicenseLevel.Pro;
}

/**
 * The user-facing upgrade message shown when a FREE-tier user attempts a PRO feature.
 */
export const TMDL_PRO_UPGRADE_MESSAGE =
    'TMDL linting is a PRO feature. Upgrade your license to access this capability.';
