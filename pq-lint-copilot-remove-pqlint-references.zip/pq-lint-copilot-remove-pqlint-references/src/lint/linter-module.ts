import { ParseResult } from '../parser/pq/parse-types'; // Import parsing result type
import { PowerQueryRule, ErrorObject, RuleResult, TMDL_Level_PowerQueryPairing, TMDL_Level_PowerQueryRule, TMDL_Level_Rule } from './rule-types'; // Import types
import { extractNamedExpressionMCode, extractPartitionMCode } from './extract-m-code'; // Import code extraction functions
import { parsePowerQueryText } from '../parser/pq/parse-pq'; // Import parsing functions

import * as fs from 'fs'; // Import file system module
import * as path from 'path'; // Import path module
import { extractMCodeAndProperties, M_Code, Raw_TMDL_Parsed_Data, parseTMDLLines, extractTableAndProperties, Table_Code, Relationship_Code, extractRelationshipAndProperties } from '../parser/tmdl/tmdl-parser';
import { logDebug } from './rule-assistance';


/**
 * Lints a given .tmdl file and returns the results of the applied rules.
 * 
 * @param filePath - The path to the .tmdl file to lint.
 * @param rules - An array of rules to apply.
 * @param debug - Optional flag to enable debug logging.
 * @param verbose - Optional flag to enable verbose rules (showing rules that passed)
 * @returns A promise that resolves to an array of RuleResult objects.
 * @throws Will throw an error if the file is not a .tmdl file or if there is a parsing error.
 */
export async function lintFile(filePath: string, rules: PowerQueryRule[], debug: boolean = false, verbose: boolean = false): Promise<RuleResult[]> {
    // Check if the file is a .tmdl file
    if (!filePath.endsWith('.tmdl')) {
        throw new Error('File is not a .tmdl file');
    }

    // Read the file content
    const fileContent = fs.readFileSync(filePath, 'utf-8');

    let code: any = '';
    // Extract named expressions and partitions from the code
    if (filePath.endsWith('expressions.tmdl')) {
        code = extractNamedExpressionMCode(fileContent);
    } else {
        code = extractPartitionMCode(fileContent);
    }

    if (debug) {
        console.log(code[0].mCode);
    }

    // Parse the code using the parsePowerQueryText function
    const parsedCode: ParseResult = await parsePowerQueryText(code[0].mCode);

    if (debug) {
        console.log(parsedCode);
    }

    // Check for parsing errors
    if (parsedCode.error !== null) {
        throw new Error(`Error parsing code: ${parsedCode.error}`);
    }

    const totalRuleResults: RuleResult[] = [];

    // Apply each rule to the parsed code
    rules.forEach((rule) => {
        const ruleResults: RuleResult[] = [];
        const errorObjects: ErrorObject[] | null = parsedCode.ast !== undefined ? rule.Check(parsedCode) : null;

        // Handle verbosity, but only add to ruleResults if no errors exist
        if (verbose && (errorObjects?.length === 0 || errorObjects === null)) {
            if (debug) {
                console.log("Adding entry for rule wih no errors: ", rule.Name);
            }
            const ruleResult: RuleResult = {
                ID: rule.ID,
                Name: rule.Name,
                Category: rule.Category,
                Description: rule.Description,
                References: rule.References,
                Severity: rule.Severity,
                Passed: true,
                ErrorInformation: {
                    errorLocation: {
                        positionStart: { codeUnit: 0, lineCodeUnit: 0, lineNumber: -1 }, // -1 to indicate no error
                        positionEnd: { codeUnit: 0, lineCodeUnit: 0, lineNumber: -1 }, // -1 to indicate no error
                    },
                    filePath: null
                }
            };
            totalRuleResults.push(ruleResult);
        }

        // If errors are found, create RuleResult objects for each error
        if (errorObjects !== null) {
            for (const errorObject of errorObjects) {
                const ruleResult: RuleResult = {
                    ID: rule.ID,
                    Name: rule.Name,
                    Category: rule.Category,
                    Description: rule.Description,
                    References: rule.References,
                    Severity: rule.Severity,
                    Passed: false,
                    ErrorInformation: {
                        errorLocation: errorObject,
                        filePath: filePath
                    }
                };
                ruleResults.push(ruleResult);
            }
        } // end if

        // Add the rule results to the total results
        totalRuleResults.push(...ruleResults);

        // Debug logging
        if (debug) {
            console.log(`Rule "${rule.Name}" checked: ${ruleResults.length} errors found`);
        }
    });

    // Increment line numbers for positionStart and positionEnd in each rule result
    for (let i = 0; i < totalRuleResults.length; i++) {
        const ruleResult = totalRuleResults[i];

        if (ruleResult.Passed === false) {
            // Replace the ErrorInformation object with updated line numbers
            const errorLocation = ruleResult.ErrorInformation.errorLocation;

            ruleResult.ErrorInformation = {
                errorLocation: {
                    positionStart: errorLocation.positionStart
                        ? {
                            ...errorLocation.positionStart,
                            lineNumber: errorLocation.positionStart.lineNumber + 1,
                        }
                        : { codeUnit: 0, lineCodeUnit: 0, lineNumber: 0 },
                    positionEnd: errorLocation.positionEnd
                        ? {
                            ...errorLocation.positionEnd,
                            lineNumber: errorLocation.positionEnd.lineNumber + 1,
                        }
                        : { codeUnit: 0, lineCodeUnit: 0, lineNumber: 0 },
                },
                filePath: ruleResult.ErrorInformation.filePath, // Retain the existing filePath
            };
        }// end if
    }// end for

    if (debug) {
        console.log(totalRuleResults);
    }

    // Return the results of the applied rules
    return totalRuleResults;
}

/**
 * Lints a given parsed code file and returns the results of the applied rules.
 * 
 * @param parsedCode - The parsed code to lint.
 * @param rules - An array of rules to apply.
 * @param debug - Optional flag to enable debug logging.
 * @param offset - The line number offset to apply to the error locations.
 * @param verbose - Optional flag to enable verbose rules (showing rules that passed)
 * @returns A promise that resolves to an array of RuleResult objects.
 * @throws Will throw an error if the file if there is a parsing error.
 */
export async function lintMCode(parsedCode: ParseResult, rules: PowerQueryRule[], debug: boolean = false, offset: number = 1, verbose: boolean = false): Promise<RuleResult[]> {
    if (debug) {
        console.log(parsedCode);
        console.log("Linting M Code with offset: ", offset);
        console.log("Linting M Code with verbose: ", verbose);
    }

    // Check for parsing errors
    if (parsedCode.error !== null) {
        throw new Error(`Error parsing code: ${parsedCode.error}`);
    }

    const totalRuleResults: RuleResult[] = [];

    // Apply each rule to the parsed code
    rules.forEach((rule) => {
        const ruleResults: RuleResult[] = [];
        const errorObjects: ErrorObject[] | null = parsedCode.ast !== undefined ? rule.Check(parsedCode) : null;

        // Handle verbosity, but only add to ruleResults if no errors exist
        if (verbose && (errorObjects?.length === 0 || errorObjects === null)) {
            if (debug) {
                console.log("Adding entry for rule wih no errors: ", rule.Name);
            }
            const ruleResult: RuleResult = {
                ID: rule.ID,
                Name: rule.Name,
                Category: rule.Category,
                Description: rule.Description,
                References: rule.References,
                Severity: rule.Severity,
                Passed: true,
                ErrorInformation: {
                    errorLocation: {
                        positionStart: { codeUnit: 0, lineCodeUnit: 0, lineNumber: -1 },
                        positionEnd: { codeUnit: 0, lineCodeUnit: 0, lineNumber: -1 }
                    },
                    filePath: null
                },
                AIFixInstructions: {
                    Description: rule.AIFixInstructions?.Description || '',
                    IsActive: rule.AIFixInstructions?.IsActive || false,
                    Prompt: (rule.AIFixInstructions && 'Prompt' in rule.AIFixInstructions) ? rule.AIFixInstructions.Prompt : '',
                    IsWholeQueryFix: (rule.AIFixInstructions && 'IsWholeQueryFix' in rule.AIFixInstructions) ? rule.AIFixInstructions.IsWholeQueryFix : false
                }

            };
            ruleResults.push(ruleResult);
        }

        // If errors are found, create RuleResult objects for each error
        if (errorObjects !== null) {
            for (const errorObject of errorObjects) {
                if (debug) {
                    console.log("ErrorObject: ", JSON.stringify(errorObject, null, 2));
                }

                const ruleResult: RuleResult = {
                    ID: rule.ID,
                    Name: rule.Name,
                    Category: rule.Category,
                    Description: rule.Description,
                    References: rule.References,
                    Severity: rule.Severity,
                    Passed: false,
                    ErrorInformation: {
                        errorLocation: errorObject,
                        filePath: null
                    },
                    AIFixInstructions: {
                        Description: rule.AIFixInstructions?.Description || '',
                        IsActive: rule.AIFixInstructions?.IsActive || false,
                        Prompt: (rule.AIFixInstructions && 'Prompt' in rule.AIFixInstructions) ? rule.AIFixInstructions.Prompt : '',
                        IsWholeQueryFix: (rule.AIFixInstructions && 'IsWholeQueryFix' in rule.AIFixInstructions) ? rule.AIFixInstructions.IsWholeQueryFix : false
                    }
                };
                ruleResults.push(ruleResult);
            }
        }
        // Add the rule results to the total results
        totalRuleResults.push(...ruleResults);

        // Debug logging
        if (debug) {
            console.log(`Rule "${rule.Name}" checked: ${ruleResults.length} errors found`);
        }
    });

    if (debug) {
        console.log(totalRuleResults);
    }

    // Increment line numbers for positionStart and positionEnd in each rule result
    for (let i = 0; i < totalRuleResults.length; i++) {
        const ruleResult = totalRuleResults[i];

        if (ruleResult.Passed === false) {
            // Replace the ErrorInformation object with updated line numbers
            const errorLocation = ruleResult.ErrorInformation.errorLocation;

            ruleResult.ErrorInformation = {
                errorLocation: {
                    positionStart: errorLocation.positionStart
                        ? {
                            ...errorLocation.positionStart,
                            lineNumber: errorLocation.positionStart.lineNumber + offset,
                        }
                        : { codeUnit: 0, lineCodeUnit: 0, lineNumber: -1 },
                    positionEnd: errorLocation.positionEnd
                        ? {
                            ...errorLocation.positionEnd,
                            lineNumber: errorLocation.positionEnd.lineNumber + offset,
                        }
                        : { codeUnit: 0, lineCodeUnit: 0, lineNumber: -1 },
                },
                filePath: ruleResult.ErrorInformation.filePath, // Retain the existing filePath
            };
        }// end if
    }// end for

    // Return the results of the applied rules
    return totalRuleResults;
}

/**
 * Lints a given TMDL code and returns Power Query pairings for analysis.
 * 
 * This function extracts M code from TMDL content (both table partitions and expressions),
 * parses each M code block, and creates pairings that associate the parsed code with
 * its original TMDL context. This enables detailed analysis of Power Query code within
 * the broader TMDL model structure.
 * 
 * @param tmdlCode - The TMDL code to analyze and extract M code from
 * @returns A promise that resolves to an array of TMDL_Level_PowerQueryPairing objects
 *          containing M code, parse results, and associated table information
 */
export async function getPowerQueryPairingsForLinting(tmdlCode: string): Promise<TMDL_Level_PowerQueryPairing[]> {
    // Extract named expressions and partitions
    
    // Extract Partitions
    const tblCode: Table_Code[] = extractTableAndProperties(tmdlCode);

    // Extract Relationships
    const relCode: Relationship_Code[] = extractRelationshipAndProperties(tmdlCode);

    // Extract Expressions (these are tables not visible, parameters, or functions)
    const expressionCode: M_Code[] = extractMCodeAndProperties(tmdlCode).filter(item => item.resultType === "Expression");
    
    logDebug("Extracted M Code: ", JSON.stringify(expressionCode, null, 2));
    // Setup pairing results
    const pairingResults: TMDL_Level_PowerQueryPairing[] = [];
    // Filter out calculated tables
    for (const codeBlock of expressionCode) {
        // Check if the code block is a calculated table
        if (codeBlock.properties?.isCalculated === true) {
            pairingResults.push({
                MCode: codeBlock,
                ParseResult: {
                    ast: null,
                    error: "Calculated tables are not supported for linting.",
                    lexed: undefined
                },
                AssociatedTable: null
            });
        }
        else {
            const parseResult = await parsePowerQueryText(codeBlock.code ?? "");

            pairingResults.push({
                MCode: codeBlock,
                ParseResult: parseResult,
                AssociatedTable: null
            });
        }// end if
    } //end for

    // Process table partitions
    for (const table of tblCode) {
        // Find relationships associated with this table
        const associatedRelationships = relCode.filter(rel => 
            rel.fromTable === table.name || rel.toTable === table.name
        );

        for (const partition of table.partitions) {
            // Check if the partition is calculated
            if (partition.properties?.isCalculated === true) {
                pairingResults.push({
                    MCode: partition,
                    ParseResult: {
                        ast: null,
                        error: "Calculated partitions are not supported for linting.",
                        lexed: undefined
                    },
                    AssociatedTable: {
                        ...table,
                        relationships: associatedRelationships
                    }
                });
            } else {
                const parseResult = await parsePowerQueryText(partition.code ?? "");

                pairingResults.push({
                    MCode: partition,
                    ParseResult: parseResult,
                    AssociatedTable: {
                        ...table,
                        relationships: associatedRelationships
                    }
                });
            }
        }
    }

    return pairingResults
};

/**
 * Lints raw TMDL code by extracting and analyzing all embedded M code blocks.
 * 
 * This comprehensive linting function processes TMDL content at multiple levels:
 * 1. Extracts M code from table partitions and expressions
 * 2. Parses each M code block using Power Query parser
 * 3. Applies Power Query-specific linting rules to parsed code
 * 4. Applies TMDL-level rules that work with Power Query pairings
 * 5. Applies TMDL-structural rules that analyze the raw TMDL content
 * 
 * Line number adjustments are automatically applied to ensure error locations
 * map correctly to the original TMDL file positions.
 * 
 * @param tmdlCode - The raw TMDL code as a string to be analyzed
 * @param rules - Array of Power Query rules to apply to individual M code blocks
 * @param tmdlLevelPQRules - Array of rules that analyze Power Query pairings across the model
 * @param tmdlLevelRules - Array of rules that analyze raw TMDL structure and content
 * @param debug - Optional flag to enable detailed debug logging and file output
 * @param verbose - Optional flag to include passed rules in results (default: false)
 * @returns A promise that resolves to an array of RuleResult objects with detailed findings
 */
export async function lintTMDLCode(tmdlCode: string, rules: PowerQueryRule[], tmdlLevelPQRules: TMDL_Level_PowerQueryRule[], tmdlLevelRules: TMDL_Level_Rule[], debug: boolean = false, verbose: boolean = false): Promise<RuleResult[]> {
    // Extract named expressions and partitions
    const mCode: M_Code[] = extractMCodeAndProperties(tmdlCode);
    const parsedTMDLData: Raw_TMDL_Parsed_Data = parseTMDLLines(tmdlCode);

    if (debug) {
        // Temporary logging to the `parsed_files` directory
        const parsedFilesDir = path.join(__dirname, './parsed_files');
        if (!fs.existsSync(parsedFilesDir)) {
            fs.mkdirSync(parsedFilesDir, { recursive: true });
        }

        // Write named expressions to a file
        fs.writeFileSync(
            path.join(parsedFilesDir, 'm_code_tmdl.json'),
            JSON.stringify(mCode, null, 3),
            'utf-8'
        );
    }// end if

    // Parse the code using the parsePowerQueryText function
    const pairingResults: TMDL_Level_PowerQueryPairing[] = await getPowerQueryPairingsForLinting(tmdlCode);

    const totalRuleResults: RuleResult[] = [];

    // Apply each rule to the pairing results
    for (const pairing of pairingResults) {

        if (debug) {
            console.log("Pairing 1: ", JSON.stringify(pairing.MCode.code));
            console.log("Parse Result Error: ", JSON.stringify(pairing.ParseResult.error));
        }

        if (pairing && pairing.MCode.properties?.isCalculated === false) { // Make sure calculated tables are ignored
            // Lint the parsed code and make sure offset is 0
            const ruleResults = await lintMCode(pairing.ParseResult, rules, debug, 0, verbose);

            const tempRuleResults: RuleResult[] = [];

            // Adjust line numbers for each rule result
            for (const ruleResult of ruleResults) {
                if (ruleResult.Passed === false) {
                    const updatedRuleResult: RuleResult = {
                        ...ruleResult,
                        ErrorInformation: {
                            ...ruleResult.ErrorInformation,
                            errorLocation: {
                                positionStart: ruleResult.ErrorInformation.errorLocation.positionStart
                                    ? {
                                        ...ruleResult.ErrorInformation.errorLocation.positionStart,
                                        // Increment line number by the block's line number
                                        lineNumber: ruleResult.ErrorInformation.errorLocation.positionStart.lineNumber + pairing.MCode.lineNumber
                                    }
                                    : { codeUnit: 0, lineCodeUnit: 0, lineNumber: 0 },
                                positionEnd: ruleResult.ErrorInformation.errorLocation.positionEnd
                                    ? {
                                        ...ruleResult.ErrorInformation.errorLocation.positionEnd,
                                        // Increment line number by the block's line number
                                        lineNumber: ruleResult.ErrorInformation.errorLocation.positionEnd.lineNumber + pairing.MCode.lineNumber
                                    }
                                    : { codeUnit: 0, lineCodeUnit: 0, lineNumber: 0 },
                            },
                        },
                        AIFixInstructions: {
                            Description: ruleResult.AIFixInstructions?.Description || '',
                            IsActive: ruleResult.AIFixInstructions?.IsActive || false,
                            Prompt: (ruleResult.AIFixInstructions && 'Prompt' in ruleResult.AIFixInstructions) ? ruleResult.AIFixInstructions.Prompt : '',
                            IsWholeQueryFix: (ruleResult.AIFixInstructions && 'IsWholeQueryFix' in ruleResult.AIFixInstructions) ? ruleResult.AIFixInstructions.IsWholeQueryFix : false
                        }
                    };
                    // If the rule failed, add it to the temporary results
                    tempRuleResults.push(updatedRuleResult);
                } else if (verbose && ruleResult.Passed) {// If the rule passed just add it to the results
                    const updatedRuleResult: RuleResult = {
                        ...ruleResult,
                        AIFixInstructions: {
                            Description: ruleResult.AIFixInstructions?.Description || '',
                            IsActive: ruleResult.AIFixInstructions?.IsActive || false,
                            Prompt: (ruleResult.AIFixInstructions && 'Prompt' in ruleResult.AIFixInstructions) ? ruleResult.AIFixInstructions.Prompt : '',
                            IsWholeQueryFix: (ruleResult.AIFixInstructions && 'IsWholeQueryFix' in ruleResult.AIFixInstructions) ? ruleResult.AIFixInstructions.IsWholeQueryFix : false
                        }
                    };
                    // If the rule passed, add it to the temporary results
                    tempRuleResults.push(updatedRuleResult);
                }
            }//end if
            // Add the temporary results to the total results
            totalRuleResults.push(...tempRuleResults);
        }// end for
    } // end if


    for (const rule of tmdlLevelPQRules) {
        if (debug) {
            console.log("Rule:", rule);
        }
        const errorObjects: ErrorObject[] | null = rule.Check(pairingResults);

        // Handle verbosity, but only add to ruleResults if no errors exist
        if (verbose && (errorObjects?.length === 0 || errorObjects === null)) {
            if (debug) {
                console.log("Adding entry for rule wih no errors: ", rule.Name);
            }
            const ruleResult: RuleResult = {
                ID: rule.ID,
                Name: rule.Name,
                Category: rule.Category,
                Description: rule.Description,
                References: rule.References,
                Severity: rule.Severity,
                Passed: true,
                ErrorInformation: {
                    errorLocation: {
                        positionStart: { codeUnit: 0, lineCodeUnit: 0, lineNumber: 0 },
                        positionEnd: { codeUnit: 0, lineCodeUnit: 0, lineNumber: 0 }
                    },
                    filePath: null
                },
                AIFixInstructions: {
                    Description: rule.AIFixInstructions?.Description || '',
                    IsActive: rule.AIFixInstructions?.IsActive || false,
                    Prompt: (rule.AIFixInstructions && 'Prompt' in rule.AIFixInstructions) ? rule.AIFixInstructions.Prompt : '',
                    IsWholeQueryFix: (rule.AIFixInstructions && 'IsWholeQueryFix' in rule.AIFixInstructions) ? rule.AIFixInstructions.IsWholeQueryFix : false
                }
            };
            totalRuleResults.push(ruleResult);
        }

        // If errors are found, create RuleResult objects for each error
        if (errorObjects !== null) {
            for (const errorObject of errorObjects) {
                if (debug) {
                    console.log("ErrorObject: ", JSON.stringify(errorObject, null, 2));
                }

                const ruleResult: RuleResult = {
                    ID: rule.ID,
                    Name: rule.Name,
                    Category: rule.Category,
                    Description: rule.Description,
                    References: rule.References,
                    Severity: rule.Severity,
                    Passed: false,
                    ErrorInformation: {
                        errorLocation: errorObject,
                        filePath: null
                    },
                    AIFixInstructions: {
                        Description: rule.AIFixInstructions?.Description || '',
                        IsActive: rule.AIFixInstructions?.IsActive || false,
                        Prompt: (rule.AIFixInstructions && 'Prompt' in rule.AIFixInstructions) ? rule.AIFixInstructions.Prompt : '',
                        IsWholeQueryFix: (rule.AIFixInstructions && 'IsWholeQueryFix' in rule.AIFixInstructions) ? rule.AIFixInstructions.IsWholeQueryFix : false
                    }
                };
                totalRuleResults.push(ruleResult);
            }
        }
    }

    // Check TMDL level rules
    for (const tmdlRule of tmdlLevelRules) {
        if (debug) {
            console.log("Rule:", tmdlRule);
        }
        const errorObjects: ErrorObject[] | null = tmdlRule.Check(parsedTMDLData, tmdlCode);

        // Handle verbosity, but only add to ruleResults if no errors exist
        if (verbose && (errorObjects?.length === 0 || errorObjects === null)) {
            if (debug) {
                console.log("Adding entry for rule wih no errors: ", tmdlRule .Name);
            }
            const ruleResult: RuleResult = {
                ID: tmdlRule.ID,
                Name: tmdlRule.Name,
                Category: tmdlRule.Category,
                Description: tmdlRule.Description,
                References: tmdlRule.References,
                Severity: tmdlRule.Severity,
                Passed: true,
                ErrorInformation: {
                    errorLocation: {
                        positionStart: { codeUnit: 0, lineCodeUnit: 0, lineNumber: 0 },
                        positionEnd: { codeUnit: 0, lineCodeUnit: 0, lineNumber: 0 }
                    },
                    filePath: null
                },
                AIFixInstructions: {
                    Description: tmdlRule.AIFixInstructions?.Description || '',
                    IsActive: tmdlRule.AIFixInstructions?.IsActive || false,
                    Prompt: (tmdlRule.AIFixInstructions && 'Prompt' in tmdlRule.AIFixInstructions) ? tmdlRule.AIFixInstructions.Prompt : '',
                    IsWholeQueryFix: (tmdlRule.AIFixInstructions && 'IsWholeQueryFix' in tmdlRule.AIFixInstructions) ? tmdlRule.AIFixInstructions.IsWholeQueryFix : false
                }
            };
            totalRuleResults.push(ruleResult);
        }
        
        // If errors are found, create RuleResult objects for each error
        if (errorObjects !== null) {
            for (const errorObject of errorObjects) {
                if (debug) {
                    console.log("ErrorObject: ", JSON.stringify(errorObject, null, 2));
                }

                const ruleResult: RuleResult = {
                    ID: tmdlRule.ID,
                    Name: tmdlRule.Name,
                    Category: tmdlRule.Category,
                    Description: tmdlRule.Description,
                    References: tmdlRule.References,
                    Severity: tmdlRule.Severity,
                    Passed: false,
                    ErrorInformation: {
                        errorLocation: errorObject,
                        filePath: null
                    }
                };
                totalRuleResults.push(ruleResult);
            }
        } // end if
    }

    if (debug) {
        console.log("Total Rule Results:", totalRuleResults);
    }

    return totalRuleResults;
}