import { ParseResult } from '../parser/pq/parse-types'; // Import the missing type
import { M_Code, Raw_TMDL_Parsed_Data, Table_Code } from '../parser/tmdl/tmdl-parser';

export enum SeverityLevel {
  None = 0,
  Info = 1,
  Warning = 2,
  Error = 3
}

export enum LicenseLevel {
  Free = 0,
  Pro = 1,
  Premium = 2
}

/**
 * Interface representing a rule to be applied during linting.
 */
export interface PowerQueryRule {
  /**
   * Unique identifier for the rule.
   */
  ID: string;

  /**
   * Name of the rule.
   */
  Name: string;

  /**
   * Category of the rule.
   */
  Category: string;

  /**
   * Description of the rule.
   */
  Description: string;

  /**
   * References related to the rule.
   */
  References: Reference[];

  /**
   * Severity level of the rule.
   */
  Severity: SeverityLevel;

  /**
   * Minimum License level required to use the rule.
   * 0 = Free, 1 = Pro, 2 = Premium
   */
  MinLicenseLevel: LicenseLevel;

  /**
   * Function to check the input and return an array of error objects or null.
   * 
   * @param input - The parsed result to check.
   * @returns An array of error objects if errors are found, otherwise null.
   */
  Check: (input: ParseResult | undefined) => ErrorObject[] | null;
  AIFixInstructions?: AIFixInternalInstructions | AIFix;
}

export interface AIFixInternalInstructions {
  Description: string;
  Prompt: string;
  IsActive: boolean;
  IsWholeQueryFix: boolean;
}

export interface AIFix {
  Description: string;
  IsActive: boolean;
}

/**
 * Interface representing a rule to be applied during linting.
 */
export interface TMDL_Level_PowerQueryRule {
  /**
   * Unique identifier for the rule.
   */
  ID: string;

  /**
   * Name of the rule.
   */
  Name: string;

  /**
   * Category of the rule.
   */
  Category: string;

  /**
   * Description of the rule.
   */
  Description: string;

  /**
   * References related to the rule.
   */
  References: Reference[];

  /**
   * Severity level of the rule.
   */
  Severity: SeverityLevel;

  /**
   * Minimum License level required to use the rule.
   * 0 = Free, 1 = Pro, 2 = Premium
   */
  MinLicenseLevel: LicenseLevel;

  /**
   * Function to check the input and return an array of error objects or null.
   * 
   * @param input - The array of MCode to check.
   * @returns An array of error objects if errors are found, otherwise null.
   */
  Check: (input: TMDL_Level_PowerQueryPairing[]) => ErrorObject[] | null;

  // Optional AI Fix Instructions
  AIFixInstructions?: AIFixInternalInstructions | AIFix;
}

export interface TMDL_Level_PowerQueryPairing{
  MCode: M_Code;
  ParseResult: ParseResult;
  AssociatedTable: Table_Code | null; // This can be if the power query is not associated with a table (eg. parameter or function)
}

/**
 * Interface representing a rule to be applied during linting.
 */
export interface TMDL_Level_Rule {
  /**
   * Unique identifier for the rule.
   */
  ID: string;

  /**
   * Name of the rule.
   */
  Name: string;

  /**
   * Category of the rule.
   */
  Category: string;

  /**
   * Description of the rule.
   */
  Description: string;

  /**
   * References related to the rule.
   */
  References: Reference[];

  /**
   * Severity level of the rule.
   */
  Severity: SeverityLevel;

  /**
   * Minimum License level required to use the rule.
   * 0 = Free, 1 = Pro, 2 = Premium
   */
  MinLicenseLevel: LicenseLevel;

  /**
   * Function to check the input and return an array of error objects or null.
   * 
   * @param input - TMDL parsed data
   * @param tmdlCode - The raw TMDL code to check.
   * @returns An array of error objects if errors are found, otherwise null.
   */
  Check: (input: Raw_TMDL_Parsed_Data, tmdlCode: string) => ErrorObject[] | null;

  // Optional AI Fix Instructions
  AIFixInstructions?: AIFixInternalInstructions | AIFix;
}

/**
 * Interface representing a reference with a hyperlink and description.
 */
export interface Reference {
  /**
   * The hyperlink for the reference.
   */
  Link: string;

  /**
   * A brief description of the reference.
   */
  Description: string;
}


/**
 * Interface representing the result of applying a rule.
 */
export interface RuleResult {
  /**
   * Unique identifier for the rule.
   */
  ID: string;

  /**
   * Name of the rule.
   */
  Name: string;

  /**
   * Category of the rule.
   */
  Category: string;

  /**
   * Description of the rule.
   */
  Description: string;

  /**
   * Indicates whether the rule passed or failed.
   */
  Passed: boolean;

  /**
   * References related to the rule.
   */
  References: Reference[];

  /**
   * Severity level of the rule.
   */
  Severity: number;

  /**
   * Information about the error found by the rule.
   */
  ErrorInformation: {
    /**
     * position where the error was found.
     */
    errorLocation: ErrorObject;

    /**
     * File path where the error was found.
     */
    filePath: string | null;
  };

  AIFixInstructions?: AIFixInternalInstructions | AIFix;
}

/**
 * Interface representing an error object.
 */
export interface ErrorObject {
  positionStart: Position;
  positionEnd: Position;
}

/**
 * Interface representing a position in the code.
 */
export interface Position {
  /**
   * The code unit position.
   */
  codeUnit: number;

  /**
   * The line code unit position.
   */
  lineCodeUnit: number;

  /**
   * The line number.
   */
  lineNumber: number;
}

/**
 * Interface representing a lexed token in JSON format.
 */
export interface LexedJson {
  /**
   * The kind of the token.
   */
  kind: string;

  /**
   * The data of the token.
   */
  data: string;

  /**
   * The starting position of the token.
   */
  positionStart: Position;

  /**
   * The ending position of the token.
   */
  positionEnd: Position;
}