import { log } from "console";

// Interface representing an expression with its properties
export interface Expression {
    name: string | null;
    mCode: string | null;
    resultType: string | null;
    lineNumber: number | null;
}

// Interface representing a partition with its properties
export interface Partition {
    name: string;
    resultType: string;
    mCode: string;
    lineNumber: number;
}

/**
 * Get the line number in the file content based on the match index.
 * @param fileContent - The content of the file as a string.
 * @param matchIndex - The index of the match in the file content.
 * @returns The line number where the match is found.
 */
function getLineNumber(fileContent: string, matchIndex: number): number {
    const lines = fileContent.substring(0, matchIndex).split('\n');
    return lines.length;
}

/**
 * Extract named expressions and their M code from a file.
 * @param tmdlCode - The path to the file containing the expressions.
 * @returns An array of Expression objects containing the name, M code, result type, and line number.
 */
export function extractNamedExpressionMCode(tmdlCode: string): Expression[] {
    const expressions = tmdlCode.split('expression ').slice(1);
    const result = expressions.map(expression => {
        // Extract the name of the expression
        const nameMatch = expression.match(/^(\S+)/);
        const name = nameMatch ? nameMatch[1] : null;
        console.log("expression name:", expression);
        // Extract the M code of the expression
        const mCodeMatch = expression.match(/=\s*let([\s\S]*?)in\s*([\s\S]*?)(?=\s*lineageTag)/);
        const mCodeParameterMatch = expression.match(/=\s*([\s\S]*?)meta\s\[[^\]]*?\]\s*lineageTag:/g);
        const functionCodeMatch = expression.match(/(\w+)\s*=\s*\(([\s\S]*?)\)\s*=>\s*let([\s\S]*?)in\s*([\s\S]*?)(?=\s*lineageTag)/);
        console.log("expression mCodeMatch:", mCodeMatch);
        console.log("expression mCodeParameterMatch:", mCodeParameterMatch);
        console.log("expression functionCodeMatch:", functionCodeMatch);
        if (mCodeMatch) {
            let mCode = mCodeMatch ? `let${mCodeMatch[1]}in${mCodeMatch[2]}` : null;
            mCode = mCode ? removeTripleBackticks(mCode) : null;
            const mCodeIndex = mCodeMatch ? expression.indexOf(mCodeMatch[0]) : -1;
            const lineNumber = mCodeIndex !== -1 ? getLineNumber(tmdlCode, tmdlCode.indexOf(expression) + mCodeIndex) : null;
            console.log("expression mCode:", mCode);
            // Extract the result type of the expression
            const resultTypeMatch = expression.match(/annotation PBI_ResultType = (\S+)/);
            const resultType = resultTypeMatch ? resultTypeMatch[1] : null;

            return { name, mCode, resultType, lineNumber };
        } else if (mCodeParameterMatch) {
            // Extract the M code of the parameter expression
            let mCode = mCodeParameterMatch[0].split('lineageTag:')[0].trim();
            mCode = mCode.slice(1).trim(); // Remove the leading '='
            mCode = mCode ? removeTripleBackticks(mCode) : '';
            const mCodeIndex = mCodeParameterMatch ? expression.indexOf(mCodeParameterMatch[0]) : -1;
            const lineNumber = mCodeIndex !== -1 ? getLineNumber(tmdlCode, tmdlCode.indexOf(expression) + mCodeIndex) : null;
            const resultType = "Meta Expression";

            return { name, mCode, resultType, lineNumber };
        } else if (functionCodeMatch) {
            // Extract the M code of the parameter expression
            let mCode = functionCodeMatch[0].split('lineageTag:')[0].trim();
            mCode = mCode ? removeTripleBackticks(mCode) : '';
            const mCodeIndex = functionCodeMatch ? expression.indexOf(functionCodeMatch[0]) : -1;
            const lineNumber = mCodeIndex !== -1 ? getLineNumber(tmdlCode, tmdlCode.indexOf(expression) + mCodeIndex) : null;
            const resultType = "Function Expression";

            return { name, mCode, resultType, lineNumber };
        } else {
            // Return a default Expression object when no match is found
            return { name, mCode: null, resultType: null, lineNumber: null };
        }
    });

    return result;
}

/**
 * Removes leading and trailing triple backticks from a given code string.
 * 
 * @param code - The code string from which to remove the triple backticks.
 * @returns The cleaned code string without leading and trailing triple backticks.
 */
function removeTripleBackticks(code: string): string {
    return code.trim().replace(/^```|```$/g, '').trim();
}

/**
 * Extract partitions and their M code from a file.
 * @param tmdlCode - The path to the file containing the expressions.
 * @returns An array of Partition objects containing the name, result type, M code, and line number.
 */
export function extractPartitionMCode(tmdlCode: string, debug: boolean = false): Partition[] {
    const partitions: Partition[] = [];

    // Split the TMDL code by the keyword "partition"
    const partitionBlocks = tmdlCode.split('partition ').slice(1); // Skip the first split as it is before the first "partition"

    partitionBlocks.forEach((block, index) => {
        if (debug) {
            console.log(`Processing partition block ${index + 1}:`, block);
        }

        // Extract the name of the partition
        const nameMatch = block.match(/^'([^']*)'|^([\w\-_]*)/);
        const name = nameMatch ? (nameMatch[1] || nameMatch[2]) : null;

        // Extract the M code of the partition
        const mCodeMatch = block.match(/source\s=\s*([\s\S]*?)(?=annotation|changedProperty|$)/);
        let mCode = mCodeMatch ? mCodeMatch[1] : null;
        mCode = mCode ? removeTripleBackticks(mCode) : '';

        // Calculate the line number of the partition
        const partitionStartIndex = tmdlCode.indexOf(block);
        const lineNumber = getLineNumber(tmdlCode, partitionStartIndex);

        // Push the partition object to the array
        partitions.push({
            name: name || '',
            resultType: 'Table',
            mCode: mCode.trim(),
            lineNumber
        });
    });

    return partitions;

}

/**
 * Extract shared expressions and their M code from a file.
 * @param dataflowCode - The content containing the expressions.
 * @returns An array of Expression objects containing the name, M code, result type, and line number.
 */
export function extractDataflowMCode(dataflowCode: string): Expression[] {
    const expressions = dataflowCode.split('shared ').slice(1);
    const result = expressions.map(expression => {
        // Extract the name of the expression
        const nameMatch = expression.match(/^[\s\S]*?(?==)/);
        let name = nameMatch ? nameMatch[0] : null;
        name = name ? name.trim() : null;

        // Extract the M code of the expression
        const mCodeMatch = expression.match(/=\s*(let|\([\s\S]*?\))([\s\S]*?)in\s*([\s\S]*?)(?=\sshared|$)/g);

        // const mCodeFunctionMatch = expression.match(/^\s=\s*(let|\([\s\S]*?\))\s=>/);
        let mCode = mCodeMatch ? `${mCodeMatch[0]}` : null;
        mCode = mCode ? removeTripleBackticks(mCode).slice(1).trim() : null;
        const mCodeIndex = mCodeMatch ? expression.indexOf(mCodeMatch[0]) : -1;
        const lineNumber = mCodeIndex !== -1 ? getLineNumber(dataflowCode, dataflowCode.indexOf(expression) + mCodeIndex) : null;
        let resultType = 'Table';
        if (mCode && mCode.startsWith('(')) {
            resultType = 'Function';
        }
        return {
            name: name || '',
            resultType: resultType,
            mCode: mCode ? mCode.trim() : null,
            lineNumber: lineNumber
        }
    });

    return result;
}