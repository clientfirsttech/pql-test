// Import all rules
import { PowerQueryRule } from './rule-types';
export { filterRulesByLicense, isTMDLLintingAllowed, TMDL_PRO_UPGRADE_MESSAGE } from './license-filter';
import consolidateSimilarTableTransformColumnTypes from '../lint/pq/consolidate-similar-table-transform-column-types';
import consolidateSimilarTableRenames from '../lint/pq/consolidate-similar-table-renames';
import useEnableFoldingWithNativeQueries from '../lint/pq/use-enable-folding-with-native-queries';
import noTypeForParameterForFunction from '../lint/pq/no-type-for-parameter-for-function';
import noReturnTypeForFunction from '../lint/pq/no-return-type-for-function';
import useTypeWithAddColumn from '../lint/pq/use-type-with-add-column';
import useGroupKindForTableGroup from '../lint/pq/use-group-kind-for-table-group';
import useSpecificParametersForFuzzyMerge from '../lint/pq/use-specific-parameters-for-fuzzy-merge';
import useSpecificParameterForNumberRound from '../lint/pq/use-specific-parameter-for-number-round';
import requireCommentForTableAddColumn from '../lint/pq/require-comment-for-table-add-column';
import requireCommentForTableAppend from '../lint/pq/require-comment-for-table-append';
import requireCommentForTableFuzzyNestedJoin from '../lint/pq/require-comment-for-table-fuzzy-nested-join';
import requireCommentForTableJoin from '../lint/pq/require-comment-for-table-join';
import requireCommentForTableNestedJoin from '../lint/pq/require-comment-for-table-nested-join';
import useDistinctStepNames from '../lint/pq/use-distinct-step-names';
import requireInspectionOfTransformForCombiningSharepointFiles from '../lint/pq/require-inspection-of-transform-for-combining-sharepoint-files';
import requireTableSelectColumnsForSharepointConnection from '../lint/pq/require-table-select-columns-for-sharepoint-connection';
import useOdataForSharepointConnection from '../lint/pq/use-odata-for-sharepoint-connection';
import useDistinctSourceNameForReferencingTable from '../lint/pq/use-distinct-source-name-for-referencing-table';
import useTableFormatForSourceControl from '../lint/pq/use-table-format-for-source-control';
import useTableBufferForTableGroup from '../lint/pq/use-table-buffer-for-table-group';
import useTableBufferForTableSort from '../lint/pq//use-table-buffer-for-table-sort';
import useTableTransformColumnsForQueryFolding from '../lint/pq/use-table-transform-columns-for-query-folding';
import useParametersForConnectionsAndPaths from '../lint/pq/use-parameters-for-connections-and-paths';
import useMissingFieldParameterForTableRemoveColumns from '../lint/pq/use-missing-field-parameter-for-table-remove-columns';
import useMissingFieldParameterForTableReorderColumns from '../lint/pq/use-missing-field-parameter-for-table-reorder-columns';
import useMissingFieldParameterForTableSelectColumns from '../lint/pq/use-missing-field-parameter-for-table-select-columns';
import useTableBufferForConditionalJoin from '../lint/pq/use-table-buffer-for-conditional-join';
import requireInspectionOfTransformForCombiningFolderFiles from '../lint/pq/require-inspection-of-transform-for-combining-folder-files';
import useRelativePathWithWebContents from '../lint/pq/use-relative-path-or-query-with-web-contents';
import noDynamicUrlWithWebContents from '../lint/pq/no-dynamic-url-with-web-contents';
import useBufferModeDelayedWithTableBuffer from '../lint/pq/use-buffer-mode-delayed-with-table-buffer';
import requireCreateNavigationPropertiesBeSetToFalseInDataverse from '../lint/pq/require-create-navigation-properties-be-set-false-in-dataverse';
import requireCreateNavigationPropertiesBeSetToFalseInSQL from '../lint/pq//require-create-navigation-properties-be-set-false-in-sql';
import noPowerBIDataflowsConnection from '../lint/pq/no-power-bi-dataflows-connection';
import useTableForExcelConnection from '../lint/pq/use-table-for-excel-connection';
import useItemAndKindForExcelConnection from '../lint/pq/use-item-and-kind-for-excel-connection';
import useVersion15ForSharePointTables from '../lint/pq/use-version-15-for-sharepoint-tables';
import useVersion15ForSharePointFiles from '../lint/pq/use-version-15-for-sharepoint-files';
import useNameForSalesforceData from '../lint/pq/use-name-for-salesforce-data';
import useNameForSalesforceReports from '../lint/pq/use-name-for-salesforce-reports';
import useCultureForTablePromoteHeaders from '../lint/pq/use-culture-for-table-promote-headers';
import useCountOrConditionForTableSkip from '../lint/pq/use-count-or-condition-for-table-skip';
import useDayTypeForWeekTransformations from '../lint/pq/use-day-type-for-week-transformations';
import noPlainTextClientForParameter from '../lint/pq/no-plain-text-client-secret-as-parameter';
import noPlainTextClientSecretForWebContents from '../lint/pq/no-plain-text-client-secret-for-web-contents';
import useExplicitTypesForDataflows from '../lint/pq/use-explicit-types-for-dataflows';
import useDefaultForTableSplitColumn from '../lint/pq/use-default-for-table-split-column';
import useNewColumnNameForTableDuplicateColumn from '../lint/pq/use-new-column-name-for-table-duplicate-column';
import useNewColumnNamesForTableExpandColumn from '../lint/pq/use-new-column-names-for-table-expand-column';
import useNewColumnNamesForTableExpandRecordColumn from '../lint/pq/use-new-column-names-for-table-expand-record-column';
import useColumnsForTableCombine from '../lint/pq/use-columns-for-table-combine';
import useTypeTextForParameter from '../lint/pq/use-type-text-for-parameter';
import useReplaceNullValuesBeforeTableUnpivotOtherColumns from '../lint/pq/use-replace-null-values-before-table-unpivot-other-columns';
import useCultureForDateFunctions from '../lint/pq/use-culture-for-date-functions';
import useValueTypeWithAllRowsForTableGroup from '../lint/pq/use-value-type-with-all-rows-for-table-group';
import useCultureForNumericFunctions from '../lint/pq/use-culture-for-numeric-functions';
import useCultureForTextFunctions from '../lint/pq/use-culture-for-text-functions';
import useCoalesceForRecordFieldCount from '../lint/pq/use-coalesce-for-record-field-count';
import useRecordFieldOrDefaultForFieldSelection from '../lint/pq/use-record-field-or-default-for-field-selection';
import useCustomConnectorForExchangeRecurringCalendarEvents from '../lint/pq/use-custom-connector-for-exchange-recurring-calendar-events';
import useCustomConnectorForMicrosoftPlanner from '../lint/pq/use-custom-connector-for-microsoft-planner';
import requireStandardPrefixForFunctions from './tmdl/require-standard-prefix-for-functions';
import useQueryGroupsForOverFiveEntities from './tmdl/use-query-groups-for-over-five-entities';
import useConsistentNamingConventionsForParameters from './tmdl/use-consistent-naming-conventions-for-parameters';
import useComparerParameterTextFunctions from './pq/use-comparer-parameter-for-text-functions.';
import detectPythonExecute from './tmdl/detect-python.execute';
import detectRExecute from './tmdl/detect-r-execute';
import detectWebContentsPost from './tmdl/detect-web-contents-post';
import detectFastCombine from './tmdl/detect-fast-combine';
import detectFolderFiles from './tmdl/detect-folder-files';
import detectDatabaseQuery from './tmdl/detect-database-query';
import detectModelOverwrite from './tmdl/detect-model-overwrite';
import useValueTypeWithConditionalJoin from './pq/use-value-type-with-conditional-join';
import requireTableSelectRowsWithErrors from './tmdl/require-table-select-rows-with-errors';
import replaceRecursionWithIterationFunctions from './pq/replace-recursion-with-iteration-functions';
import consolidateMultipleTableReplaceValueCalls from './pq/consolidate-multiple-table-replace-value-calls';
import detectValueNativeQuery from './tmdl/detect-value-native-query';
import noEllipsisOperator from './pq/no-ellipsis-operator';
import useQueryReferencesToAvoidDuplicativeCode from './tmdl/use-query-references-to-avoid-duplicative-code';
import useAlternativeForTextCleanAndTrimUsage from './pq/use-alternative-for-text-clean-and-trim-usage';
import useTextLowerForExtensionFilter from './pq/use-text-lower-for-extension-filter';
import noEqualOnBothRangesForIncrementalRefresh from './pq/no-equal-on-both-ranges-for-incremental-refresh';
import useSharePointContentsForFiles from './pq/use-sharepoint-contents-for-files';
import noAIFunctions from './pq/no-ai-functions';
import useListBufferForSelectingRows from './pq/use-list-buffer-for-selecting-rows';
import useFolderContentsForFiles from './pq/use-folder-contents-for-files';
import detectFolderContents from './tmdl/detect-folder-contents';
import usePartitioningWhenImportModeDatabricks from './tmdl/azure-databricks/use-partitioning-when-import-mode-databricks';
import usePartitioningWhenImportModeFoundry from './tmdl/foundry/use-partitioning-when-import-mode-foundry';
import useDatetimeParameterForIncrementalRefresh from './tmdl/use-datetime-for-parameter-type-for-incremental-refresh';
import useDualModeWithDimensionTableDatabricks from './tmdl/azure-databricks/use-dual-mode-with-dimension-table-databricks';
import { useDirectQueryModeWithFactTableDatabricks } from './tmdl/azure-databricks/use-direct-query-mode-with-fact-table-databricks';
// Combine all rules into a single array
export const allPQRules = [
    consolidateSimilarTableTransformColumnTypes,
    consolidateSimilarTableRenames,
    useEnableFoldingWithNativeQueries,
    noTypeForParameterForFunction,
    noReturnTypeForFunction,
    useTypeWithAddColumn,
    useGroupKindForTableGroup,
    useSpecificParametersForFuzzyMerge,
    useSpecificParameterForNumberRound,
    requireCommentForTableAddColumn,
    requireCommentForTableAppend,
    requireCommentForTableFuzzyNestedJoin,
    requireCommentForTableJoin,
    requireCommentForTableNestedJoin,
    useDistinctStepNames,
    requireInspectionOfTransformForCombiningSharepointFiles,
    requireInspectionOfTransformForCombiningFolderFiles,
    requireTableSelectColumnsForSharepointConnection,
    useOdataForSharepointConnection,
    useDistinctSourceNameForReferencingTable,
    useTableFormatForSourceControl,
    useTableBufferForTableGroup,
    useTableBufferForTableSort,
    useTableTransformColumnsForQueryFolding,
    useParametersForConnectionsAndPaths,
    useMissingFieldParameterForTableRemoveColumns,
    useMissingFieldParameterForTableReorderColumns,
    useMissingFieldParameterForTableSelectColumns,
    useTableBufferForConditionalJoin,
    useRelativePathWithWebContents,
    noDynamicUrlWithWebContents,
    useBufferModeDelayedWithTableBuffer,
    requireCreateNavigationPropertiesBeSetToFalseInDataverse,
    requireCreateNavigationPropertiesBeSetToFalseInSQL,
    noPowerBIDataflowsConnection,
    useTableForExcelConnection,
    useItemAndKindForExcelConnection,
    useVersion15ForSharePointTables,
    useVersion15ForSharePointFiles,
    useNameForSalesforceData,
    useNameForSalesforceReports,
    useCultureForTablePromoteHeaders,
    useCountOrConditionForTableSkip,
    useDayTypeForWeekTransformations,
    noPlainTextClientForParameter,
    noPlainTextClientSecretForWebContents,
    useExplicitTypesForDataflows,
    useDefaultForTableSplitColumn,
    useNewColumnNameForTableDuplicateColumn,
    useNewColumnNamesForTableExpandColumn,
    useNewColumnNamesForTableExpandRecordColumn,
    useColumnsForTableCombine,
    useTypeTextForParameter,
    useReplaceNullValuesBeforeTableUnpivotOtherColumns,
    useCultureForDateFunctions,
    useCultureForNumericFunctions,
    useCultureForTextFunctions,
    useValueTypeWithAllRowsForTableGroup,
    useRecordFieldOrDefaultForFieldSelection,
    useCoalesceForRecordFieldCount,
    useCustomConnectorForExchangeRecurringCalendarEvents,
    useCustomConnectorForMicrosoftPlanner,
    useComparerParameterTextFunctions,
    useValueTypeWithConditionalJoin,
    replaceRecursionWithIterationFunctions,
    consolidateMultipleTableReplaceValueCalls,
    noEllipsisOperator,
    useAlternativeForTextCleanAndTrimUsage,
    useTextLowerForExtensionFilter,
    noEqualOnBothRangesForIncrementalRefresh,
    useSharePointContentsForFiles,
    noAIFunctions,
    useListBufferForSelectingRows,
    useFolderContentsForFiles
];

// Combine all TMDL rules into a single array
export const allTMDLLevelPQRules = [
    requireStandardPrefixForFunctions,
    useQueryGroupsForOverFiveEntities,
    useConsistentNamingConventionsForParameters,
    requireTableSelectRowsWithErrors,
    useQueryReferencesToAvoidDuplicativeCode,
    usePartitioningWhenImportModeDatabricks,
    usePartitioningWhenImportModeFoundry,
    useDatetimeParameterForIncrementalRefresh,
    useDualModeWithDimensionTableDatabricks,
    useDirectQueryModeWithFactTableDatabricks
];

// Combine all TMDL Power Query rules into a single array
export const allTMDLSecurityLevelPQRules = [
    detectPythonExecute,
    detectRExecute,
    detectWebContentsPost,
    detectFolderFiles,
    detectFolderContents,
    detectDatabaseQuery,
    detectValueNativeQuery
];

// Combine all TMDL rules into a single array
export const allTMDLSecurityLevelRules = [
    detectFastCombine,
    detectModelOverwrite
];
/**
 * Converts all rules to JSON while excluding the `Check` function.
 * 
 * @param includePrompt - If true (default), keeps the Prompt property in AIFixInstructions. 
 *                        If false, strips the Prompt property to prevent exposure in API responses.
 * @returns An array of rule objects without the `Check` function.
 */
export function getRulesAsJson(includePrompt: boolean = true): object[] {
    // Combine all rules into a single array
    const rules = [
        ...allPQRules,
        ...allTMDLLevelPQRules,
        ...allTMDLSecurityLevelPQRules,
        ...allTMDLSecurityLevelRules
    ];

    // Sort rules by MinLicenseLevel, then category, then id
    rules.sort((a, b) => {
        // Compare MinLicenseLevel
        if (a.MinLicenseLevel && b.MinLicenseLevel && a.MinLicenseLevel !== b.MinLicenseLevel) {
            return String(a.MinLicenseLevel).localeCompare(String(b.MinLicenseLevel));
        }

        // Compare category
        if (a.Category && b.Category && a.Category !== b.Category) {
            return a.Category.localeCompare(b.Category);
        }

        // Compare id
        if (a.ID && b.ID) {
            return a.ID.localeCompare(b.ID);
        }

        return 0; // Default to equal if all properties are the same
    });   
    console.log('rules', JSON.stringify(rules, null, 2));
    return rules.map(rule => {
        const { Check, ...ruleWithoutCheck } = rule; // Exclude the `Check` function
        
        // Ensure AIFixInstructions exists with appropriate properties based on includePrompt flag
        if (!ruleWithoutCheck.AIFixInstructions) {
            if(includePrompt){
                // Include Prompt property for internal AI fix operations
                ruleWithoutCheck.AIFixInstructions = {
                    Description: "TBD",
                    Prompt: "TBD",  
                    IsActive: false,
                    IsWholeQueryFix: false
                };
            } else {
                // Exclude Prompt property for API responses
                ruleWithoutCheck.AIFixInstructions = {
                    Description: "TBD",
                    IsActive: false
                };
            }
        } else if (!includePrompt) {
            // Strip Prompt and IsWholeQueryFix properties from existing AIFixInstructions when not needed
            if ('Prompt' in ruleWithoutCheck.AIFixInstructions || 'IsWholeQueryFix' in ruleWithoutCheck.AIFixInstructions) {
                const { Prompt, IsWholeQueryFix, ...aiFixWithoutPrompt } = (ruleWithoutCheck.AIFixInstructions as any);
                ruleWithoutCheck.AIFixInstructions = {
                    ...aiFixWithoutPrompt
                };
            }
        }
        
        return ruleWithoutCheck;
    });
}