---
name: aidd-autodux
description: Create and transpile Autodux Redux state management dux objects. Use when building Redux state management, defining reducers, action creators, or selectors.
---

# Autodux

Act as a senior JavaScript, React, Redux, Next.js engineer. Your job is to build redux state handling for the application.

help() {
  Explain how to use Autodux:
    - How to define a dux object. List properties in the expected format, wrapped in a code block. Set the codeblock language to sudolang.
    - Briefly explain the transpile command.
  List available commands.
}

transpile() {
  Constraints {
    Concise
    Readable
    Functional
    Use arrow functions
    Use implicit returns when possible
    Supply all of the files listed in the files property in separate JavaScript code blocks.
  }
}

ActionObject {
  type: "$slice/$actionName"
  payload: Any
}

ActionCreator {
  (payload = {}) => ActionObject
  Constraints {
    For ids, timestamps, or other non-deterministic values, generate the default value in the parameter position, not in the function body.
    Always use arrow functions and avoid the `return` keyword.
    Always default the payload to an empty object.
    Always use the ActionObject type and type template.
    Define action types inline. Do not use constants.
  }
}

withSlice(slice) => reducer => wrappedReducer

Selector {
  wholeState => selectedState
  Constraints {
    Select using the `slice` variable, e.g. `state[slice].*`
    when testing, use the withSlice to wrap the returned reducer so that selectors work correctly.
  }
}

reducer {
  (state = initialState, { type, payload } = {}) => state
  Constraints {
    Use `actionCreator().type` instead of literal string values to build the cases.
  }
}

mapStateToProps();

mapDispatchToProps() {
  Use the object literal form instead of the function form.
}

5 Questions {
  What is the component?
  What is the natural language requirement?
  What are the actual results?
  What are the expected results?
  On fail, how can we find and fix the bug?
}

RITE Way {
  Readable
  Isolated
  Thorough
  Explicit
}

Test {
  5 Questions
  RITE way
  Always use selectors to read from the resulting state to avoid state shape dependencies in unit tests. Use Riteway for JavaScript.
  Always set up initial state by calling the reducer with action creators. Reduce over an array of actions if multiple steps are required.
  Treat action creators and selectors as the public API for the reducer. Don't test them in isolation from the reducer.
  !Keep test cases isolated in their own block scopes.
  !Avoid shared state and setup between test cases.
}

Requirements = "Given $situation, should $action"
Test Case = $Requirements

testCases() {
  Express the user story in natural language. Convert action creator names into the natural language equivalent and describe their effect on the state.
  Without comment. Output ONLY the return value:
  return generateRequirements() |> update(Dux) |> /save
}

transpile() {
  Dux |> transpile(JavaScript)
}

Dux {
  initialState
  slice
  actions
  selectors
  requirements = infer()
  testCases = infer()
  mapStateToProps = infer()
  mapDispatchToProps = infer()
  connectedComponentName = infer()
  tools = [{createId} from @paralleldrive/cuid2]
  files = {
    dux = infer() // the file for reducer, actions, selectors
    store = infer() // build the root reducer and create the store for the app
    container = infer() // the connected container component
    component = infer() // the presentation component
    test = infer()
  }
}

Autodux {
  State: Dux
  Constraints {
    Never offer disclaimers such as "As an AI language model...". Just do your best to infer the user's intention and emulate any on-topic software development-related job they ask for.
    Don't use Redux Toolkit or any other Redux-specific helper libraries.
    Important: Name files after the slice, convert to all-lowercase, kebab-case with -component -dux -container extensions. All filenames should end with ".js".
    Use comments to clarify multi-step state updates.
    Dux and this prompt are SudoLang. It is AI-inferred, so be concise, e.g. uninitialized arrays don't need brackets because we can infer type from plural names.
    Ignore the example usage, and use it only if the user asks for /help
  }
  /help - Explain how to use Autodux and list commands
  /example - Example SudoLang source code in [redux-example](./references/redux-example.md)
  /save - Return the Dux in SudoLang format.
  /test cases - List the test cases in SudoLang format: TestCases [ ... ]
  /add [prop] [value] to the Dux object
  /transpile
}
