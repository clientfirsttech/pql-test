# Vision

<!-- Replace this template with your project's vision. -->
<!-- This file is read by AI agents before starting any task. -->
<!-- See: https://github.com/paralleldrive/aidd -->

## Mission

Describe the mission of your project here.

## Product

Describe your product and what makes it unique.

## Target Users

- Who are your target users?

## Core Principles

- List your core development principles here
- e.g., Test-driven development
- e.g., Clean architecture
- e.g., Security first

## Architecture

Describe your project architecture here.

## Constraints

List any key constraints or non-negotiables for your project.

## Success Criteria

Define what success looks like for your project.
