# AIDD Framework Template

This project uses the [AIDD Framework](https://github.com/paralleldrive/aidd) for AI-Driven Development with GitHub Copilot support.

## Quick Start

### Prerequisites

- [Node.js 18+](https://nodejs.org)
- [GitHub Copilot](https://github.com/features/copilot) (recommended)

### Setup

1. Clone this repository
2. Install dependencies: `npm install`
3. Open in VS Code with GitHub Copilot enabled

### Using the @aidd Agent (GitHub Copilot)

Open GitHub Copilot Chat (`Ctrl+Shift+I`) and type **`@aidd`** to invoke the AIDD agent.

**Available Commands:**

- `@aidd help` - Show all AIDD commands and workflows
- `@aidd plan` - Review priorities and suggest next steps
- `@aidd discover` - Interactive feature discovery session
- `@aidd task: [description]` - Plan and execute tasks with TDD
- `@aidd execute: [epic-name]` - Execute previously planned epic
- `@aidd review` - Code review with best practices
- `@aidd churn` - Identify refactoring candidates (hotspot analysis)
- `@aidd fix: [description]` - Fix bugs following AIDD process
- `@aidd log` - Document changes in changelog
- `@aidd commit` - Create conventional commits

See [COPILOT-QUICKSTART.md](COPILOT-QUICKSTART.md) for detailed examples and workflows.

## Project Structure

```
ai/                     # AIDD Framework skills and commands (from upstream)
  ├── commands/         # Command definitions
  ├── skills/           # Specialized skill modules
  └── scaffolds/        # Project scaffolding templates

aidd-custom/            # Project-specific AIDD customizations
  ├── config.yml        # AIDD configuration
  ├── AGENTS.md         # Project-specific agent instructions
  └── index.md          # Custom skills index

.github/
  ├── agents/           # GitHub Copilot custom agent definitions
  └── copilot-instructions.md  # Copilot workspace instructions

.cursor/                # Cursor editor integration (symlink to ai/)
.vscode/                # VS Code settings for Copilot
```

## Updating AIDD Framework

To pull the latest AIDD framework files from the upstream project:

```bash
# Run the upgrade script
./scripts/aidd-upgrade.sh
```

Or manually update using `npx`:

```bash
npx aidd .
```

See [UPGRADING.md](UPGRADING.md) for detailed upgrade instructions.

## Development with AI Agents

This template supports multiple AI coding tools:

| Tool | Configuration |
|------|--------------|
| **GitHub Copilot** | `.github/agents/aidd.agent.md`, `.github/copilot-instructions.md` |
| **Cursor** | `.cursor/` (symlink to `ai/`) |
| **Claude Code** | `AGENTS.md` |
| **Other AI Tools** | `ai/` directory (universal) |

## Vision

See [vision.md](vision.md) for project goals, architecture decisions, and constraints.

## License

See [LICENSE](LICENSE) for details.
